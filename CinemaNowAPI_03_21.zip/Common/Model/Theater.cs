﻿namespace CinemaNowApi.Common.Model
{
    public class Theater
    {
    }
}
