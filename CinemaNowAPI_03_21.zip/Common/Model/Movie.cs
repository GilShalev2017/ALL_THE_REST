namespace CinemaNowApi.Common.Model
{
    public class Movie
    {
        public string Id { get; set; }
        public string title { get; set; }
        public string overview { get; set; }
        public string posterPath { get; set; }
        public string backdropPath { get; set; }
    }
}
