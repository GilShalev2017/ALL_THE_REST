#!/bin/sh

aws ec2 describe-security-groups --group-ids sg-0e62f1f8b5183913a --region us-east-1 --query 'SecurityGroups[0].IpPermissions' > cloudformation/security-group.json

aws ec2 authorize-security-group-ingress --group-id sg-02c729030481bdc59 --region us-east-2 --cli-input-json file://cloudformation/security-group.json
