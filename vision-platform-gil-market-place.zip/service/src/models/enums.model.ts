
export enum JobState {
    INITIAL = "INITIAL",
    IN_PROGRESS = "IN_PROGRESS",
    COMPLETED = "COMPLETED",
    ERROR = "ERROR",
    CANCELED = "CANCELED",
    QUEUED = 'QUEUED'
}
export enum QMessegeType {
    START_JOB_PROCESSING,
    CANCEL_JOB_PROCESSING,
    JOB_PROCESSING_STATUS
}
export enum Gender {
    MALE = 'MALE',
    FEMALE = 'FEMALE'
}
export enum AuthLevel {
    USER = 'USER',
    ADMIN = 'ADMIN',
    SUPER = 'SUPER'
}
