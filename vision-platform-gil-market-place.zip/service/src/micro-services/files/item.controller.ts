import {
    Count,
    CountSchema,
    Filter,
    FilterExcludingWhere,
    repository,
    Where,
} from '@loopback/repository';
import {
    post,
    param,
    get,
    getModelSchemaRef,
    patch,
    put,
    del,
    requestBody, RestBindings, Request, Response, api, oas
} from '@loopback/rest';
import {AssetUrlResponse, Item} from '../../models';
import {ItemRepository} from '../../repositories';
import {inject} from '@loopback/core';
import {FileSystem} from "../../services/file-system";
import * as path from "path";
import {authenticate} from "@loopback/authentication";

@authenticate('jwt')
@api({
    basePath: "/files"
})
export class FileController {
    constructor(
        @repository(ItemRepository)
        public itemRepository: ItemRepository,
    ) {
    }

    @get('/deleteFromS3/{id}', {
        responses: {
            '200': {
                description: 'S3 Object Key',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(Item, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async deleteFromS3(
        @param.path.string('id') id: string
    ): Promise<void> {
        console.log("s3ObjectKey="+id);
        return FileSystem.removeFileFromS3(id);
    }

    @post('/uploadToS3', {
        responses: {
            '200': {
                description: 'Item model instance',
                content: {'application/json': {schema: getModelSchemaRef(Item)}},
            },
        },
    })
    async uploadToS3(
        @requestBody.file()
            request: Request,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ): Promise<AssetUrlResponse> {
        return FileSystem.uploadToS3(request, response, this.itemRepository);
    }

    @post('/items/{id}', {
        responses: {
            '200': {
                description: 'Item model instance',
                content: {'application/json': {schema: getModelSchemaRef(Item)}},
            },
        },
    })
    async create(
        @requestBody.file()
            request: Request,
        @param.path.string('id') id: string,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ): Promise<Item> {
        return FileSystem.upload(request, id, response, this.itemRepository);
    }

    @get('/items/count', {
        responses: {
            '200': {
                description: 'Item model count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async count(
        @param.where(Item) where?: Where<Item>,
    ): Promise<Count> {
        return this.itemRepository.count(where);
    }

    @get('/items', {
        responses: {
            '200': {
                description: 'Array of Item model instances',
                content: {
                    'application/json': {
                        schema: {
                            type: 'array',
                            items: getModelSchemaRef(Item, {includeRelations: true}),
                        },
                    },
                },
            },
        },
    })
    async find(
        @param.filter(Item) filter?: Filter<Item>,
    ): Promise<Item[]> {
        return this.itemRepository.find(filter);
    }

    @patch('/items', {
        responses: {
            '200': {
                description: 'Item PATCH success count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async updateAll(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Item, {partial: true}),
                },
            },
        })
            item: Item,
        @param.where(Item) where?: Where<Item>,
    ): Promise<Count> {
        return this.itemRepository.updateAll(item, where);
    }

    @get('/items/{id}', {
        responses: {
            '200': {
                description: 'Item model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(Item, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async findById(
        @param.path.string('id') id: string,
        @param.filter(Item, {exclude: 'where'}) filter?: FilterExcludingWhere<Item>
    ): Promise<Item> {
        return this.itemRepository.findById(id, filter);
    }

    @patch('/items/{id}', {
        responses: {
            '204': {
                description: 'Item PATCH success',
            },
        },
    })
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Item, {partial: true}),
                },
            },
        })
            item: Item,
    ): Promise<void> {
        await this.itemRepository.updateById(id, item);
    }

    @put('/items/{id}', {
        responses: {
            '204': {
                description: 'Item PUT success',
            },
        },
    })
    async replaceById(
        @param.path.string('id') id: string,
        @requestBody() item: Item,
    ): Promise<void> {
        await this.itemRepository.replaceById(id, item);
    }

    @del('/items/{id}', {
        responses: {
            '204': {
                description: 'Item DELETE success',
            },
        },
    })
    async deleteById(@param.path.string('id') id: string): Promise<void> {
        await this.itemRepository.deleteById(id);
    }


    @authenticate.skip()
    @get('/static')
    @oas.response.file()
    async getStatic(
        @param.query.string('key') key: string,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ) {
        try {
            const filename = key.split('/').pop() as string;
            FileSystem.securePath(key);
            response.download(process.env.STORAGE_FOLDER + key, filename);
            return response;
        } catch (e) {
            console.log("Error fetching file", key);
            throw new Error("Error fetching file");
        }
    }

    @authenticate.skip()
    @get('/static/zip')
    @oas.response.file()
    async getStaticZip(
        @param.query.string('key') key: string,
        @inject(RestBindings.Http.RESPONSE) response: Response,
    ) {
        try {
            FileSystem.createDirectory(process.env.STORAGE_FOLDER + 'zip');
            const output = process.env.STORAGE_FOLDER + `zip/input-${new Date().getTime()}.zip`;
            FileSystem.securePath(key);
            await FileSystem.zipFolder(process.env.STORAGE_FOLDER + key, output)
            response.download(output, "input.zip");
            return response;
        } catch (e) {
            console.log("Error zipping file", key);
            throw new Error("Error zipping file");
        }
    }
}
