import {NewMevolveUserModel} from "../../../models";
import {Credentials, TokenObject} from "@loopback/authentication-jwt";
import {getModelSchemaRef, SchemaObject} from "@loopback/rest";
import {Model, model, property} from "@loopback/repository";
import {UserProfile} from "@loopback/security";


export interface ILoginResponseBase {
    identifier: string;
}
export interface LoginResponse {
    identifier: string;
    token: TokenObject;
    admin?: boolean;
    id?: string
}
export type RefreshGrant = {
    refreshToken: string;
    oldAccessToken?: string;
};

@model()
export class PasswordResetRequest extends Model {
    @property()
    email: string;
    @property()
    confirmationCode: string;
    @property()
    password: string;
    @property()
    password2: string;
}
@model()
export class EmailRequest extends Model {
    @property()
    email: string;
}
@model()
export class LoginResponseBase extends Model {
    @property()
    identifier: string;
}
export const getRequestSchema = <T extends object>(modelObj: Function & {prototype: T}) => {
    return {
        required: true,
        content: {
            'application/json': {schema: getModelSchemaRef(modelObj)},
        }
    }
}
export const getResponseSchema = <T extends object>(modelObj: Function & {prototype: T}) => {
    return {
        responses: {
            '200': {
                description: 'User',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(modelObj),
                    },
                },
            },
        },
    }}

export abstract class AbstractAuthService {

    abstract signUp(newUserRequest: NewMevolveUserModel): Promise<LoginResponse>;

    abstract login(credentials: Credentials): Promise<LoginResponse>;

    abstract refresh(refreshToken: RefreshGrant): Promise<TokenObject>;

    abstract forgotPassword(email: string): Promise<ILoginResponseBase>;

    abstract resetPassword(request: PasswordResetRequest): Promise<ILoginResponseBase>;
}


