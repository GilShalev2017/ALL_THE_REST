import {del, get, getModelSchemaRef, param, patch, post, put, requestBody,} from '@loopback/rest';
import {CloudProvider, Device, User} from '../../models';
import {AzureUtilsService} from "../../services";
import {authenticate} from "@loopback/authentication";
import {inject} from "@loopback/core";
import {SecurityBindings, securityId} from "@loopback/security";
import {AwsIotService} from "./logic/aws-iot.service";
import {
  AbstractIotService,
  Modules,
  NewModuleRequest,
  EnrollmentResponse,
  NewMultipleModuleRequest
} from "./logic/abstract-iot.service";
import {AzureIotService} from "./logic/azure-iot.service";
import {Enroll, EnrollDelete} from "./enroll.model";
import {repository} from "@loopback/repository";
import {UserRepository} from "../users/user.repository";

interface AzureDevice {
  deviceId: string;
  authType?: string;
  autoGenKeys?: boolean;
  primaryKey?: string;
  secondaryKey?: string;
  edgeEnabled?: boolean;
  hubEnabled?: boolean;
  iotDomainName?: string;
}

@authenticate('jwt')
export class DeviceController {
  constructor(
      @repository(UserRepository) protected userRepository: UserRepository
  ) {}

  public static getUserIoTService(user: User): AbstractIotService {

    if (user.cloudProvider?.provider === CloudProvider.AWS) {
      return new AwsIotService(user);
    }
    return new AzureIotService(user);
  }

  private static toDeviceModelDomain(azureDevice: AzureDevice, user: User) {
    return {
      ...azureDevice,
      id: azureDevice.deviceId,
      name: azureDevice.deviceId,
      edgeEnabled: true,
      iotDomainName: user? user.cloudProvider?.iotDomainName ?? 'moshe-iot-1.azure-devices.net' : null
    }
  }

  @post('/devices', {
    responses: {
      '200': {
        description: 'Device model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                deviceId: {
                  type: 'string',
                },
              },
            },
          },
        },
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Device, {
            title: 'NewDevice',
            exclude: ['id'],
          }),
        },
      },
    })
    device: Omit<Device, 'id'>,
    @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<Device> {
    return DeviceController.getUserIoTService(currentUserProfile).createDevice(device);
  }


  @post('/devices/enroll', {
    responses: {
      '200': {
        description: 'Device enroll model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                deviceId: {
                  type: 'string',
                },
              },
            },
          },
        },
      },
    },
  })
  async enroll(
      @requestBody({
        content: {
          'application/json': {
            schema: getModelSchemaRef(Enroll, {
              title: 'NewDeviceEnroll',
            }),
          },
        },
      })
      enroll: Enroll,
      @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<EnrollmentResponse> {
    if (enroll.caCertificate) {
      return DeviceController.getUserIoTService(currentUserProfile).createDeviceEnrollment(enroll.deviceId, enroll.certificate, enroll.caCertificate);
    }
    return DeviceController.getUserIoTService(currentUserProfile).createDeviceEnrollment(enroll.deviceId, enroll.certificate);
  }

  @post('/devices/enroll/delete', {
    responses: {
      '200': {
        description: 'Device enroll model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                deviceId: {
                  type: 'string',
                },
              },
            },
          },
        },
      },
    },
  })
  async deleteEnroll(
      @requestBody({
        content: {
          'application/json': {
            schema: getModelSchemaRef(EnrollDelete, {
              title: 'DeviceEnrollDelete',
            }),
          },
        },
      })
          enroll: EnrollDelete,
      @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<string> {
    return DeviceController.getUserIoTService(currentUserProfile).deleteDeviceEnrollment(enroll.deviceId);
  }


  @put('/devices/{id}', {
    responses: {
      '200': {
        description: 'Device model instance',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                deviceId: {
                  type: 'string',
                },
              },
            },
          },
        },
      },
    },
  })
  async update(
      @requestBody({
        content: {
          'application/json': {
            schema: getModelSchemaRef(Device, {
              title: 'NewDevice',
              exclude: ['id'],
            }),
          },
        },
      })
      device: Omit<Device, 'id'>,
      @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<Device> {
    return DeviceController.getUserIoTService(currentUserProfile).updateDevice(device);
  }


  //
  // @get('/devices/count', {
  //   responses: {
  //     '200': {
  //       description: 'Device model count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async count(
  //   @param.where(Device) where?: Where<Device>,
  // ): Promise<Count> {
  //   return this.deviceRepository.count(where);
  // }

  @get('/devices', {
    responses: {
      '200': {
        description: 'Array of Device model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              devices: getModelSchemaRef(Device, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
      @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<Device[]> {
    return DeviceController.getUserIoTService(currentUserProfile).getUserDevices();
  }

  // @patch('/devices', {
  //   responses: {
  //     '200': {
  //       description: 'Device PATCH success count',
  //       content: {'application/json': {schema: CountSchema}},
  //     },
  //   },
  // })
  // async updateAll(
  //   @requestBody({
  //     content: {
  //       'application/json': {
  //         schema: getModelSchemaRef(Device, {partial: true}),
  //       },
  //     },
  //   })
  //   device: Device,
  //   @param.where(Device) where?: Where<Device>,
  // ): Promise<Count> {
  //   return this.deviceRepository.updateAll(device, where);
  // }
  //
  @get('/devices/{id}/modules')
  async findById(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('id') id: string,
  ): Promise<Modules> {
    return DeviceController.getUserIoTService(currentUserProfile).getDeviceModules(id);
  }

  @get('/devices/{id}')
  async getDeviceById(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('id') id: string,
  ): Promise<Device> {
    return DeviceController.toDeviceModelDomain(await AzureUtilsService.getDevice(currentUserProfile, id), currentUserProfile);
  }

  @patch('/devices/{id}')
  async updateById(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('id') id: string,
      @requestBody() body: NewModuleRequest
  ): Promise<void> {
    await DeviceController.getUserIoTService(currentUserProfile).deployModules(id, body);
  }

  @patch('/devices/multiple/{id}')
  async updateMultipleById(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('id') id: string,
      @requestBody() body: NewMultipleModuleRequest
  ): Promise<void> {
    await DeviceController.getUserIoTService(currentUserProfile).deployMultipleModules(id, body);
  }

  @post('/devices/{id}/deleteModule')
  async deleteModule(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('id') id: string,
    @requestBody()
    body: {moduleName: string}
  ): Promise<void> {
    await DeviceController.getUserIoTService(currentUserProfile).deleteModules(id, body.moduleName);
  }
  //
  // @put('/devices/{id}', {
  //   responses: {
  //     '204': {
  //       description: 'Device PUT success',
  //     },
  //   },
  // })
  // async replaceById(
  //   @param.path.string('id') id: string,
  //   @requestBody() device: Device,
  // ): Promise<void> {
  //   await this.deviceRepository.replaceById(id, device);
  // }
  //
  @del('/devices/{id}', {
    responses: {
      '204': {
        description: 'Device DELETE success',
      },
    },
  })
  async deleteById(@inject(SecurityBindings.USER) currentUserProfile: User, @param.path.string('id') id: string): Promise<void> {
    await AzureUtilsService.deleteById(currentUserProfile, id);
  }
}
