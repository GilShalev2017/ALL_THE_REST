import {
    AbstractIotService,
    EnrollmentResponse,
    Modules,
    NewModuleRequest,
    NewMultipleModuleRequest
} from "./abstract-iot.service";
import {User} from "../../users/user.model";
import {Device} from "../device.model";
import {AzureUtilsService} from "../../../services";

interface AzureDevice {
    deviceId: string;
    authType?: string;
    autoGenKeys?: boolean;
    primaryKey?: string;
    secondaryKey?: string;
    edgeEnabled?: boolean;
    hubEnabled?: boolean;
    iotDomainName?: string;
}

export class AzureIotService extends AbstractIotService {
    constructor(user: User, update = false) {
        super();
        this.user = user;
    }

    public toDeviceModel(azureDevice: AzureDevice) {
        return {
            ...azureDevice,
            id: azureDevice.deviceId,
            name: azureDevice.deviceId,
            edgeEnabled: true,
            iotDomainName: this.user? this.user.cloudProvider?.iotDomainName ?? 'moshe-iot-1.azure-devices.net' : null
        }
    }

    async getUserDevices(): Promise<Device[]> {
        const devices = await AzureUtilsService.listDevices(this.user);
        return devices.map(device => this.toDeviceModel(device));
    }

    getDeviceModules(deviceId: string): Promise<Modules> {
        return AzureUtilsService.getModules(this.user, deviceId)
    }

    async deployModules(deviceId: string, moduleRequest: NewModuleRequest): Promise<void> {
        await AzureUtilsService.deployModules(this.user, deviceId, moduleRequest.moduleName, moduleRequest.moduleUri, moduleRequest.connectionString);
    }

    deployMultipleModules(deviceId: string, moduleRequest: NewMultipleModuleRequest): Promise<void> {
        return Promise.resolve(undefined);
    }

    deleteModules(deviceId: string, moduleName: string): Promise<void> {
        return AzureUtilsService.deleteModule(this.user, deviceId, moduleName);
    }

    async createDevice(device: Omit<Device, "id">): Promise<Device> {
        return this.toDeviceModel(await AzureUtilsService.createDevice(this.user, device));
    }

    async createDeviceEnrollment(deviceId: string, certificate: string): Promise<EnrollmentResponse> {
        console.log(this.user);
        return AzureUtilsService.createDeviceEnrollment(this.user, deviceId, certificate);
    }

    async deleteDeviceEnrollment(deviceId: string): Promise<string> {
        console.log(this.user);
        return AzureUtilsService.deleteDeviceEnrollment(this.user, deviceId);
    }

    async updateDevice(device: Omit<Device, "id">): Promise<Device> {
        return this.toDeviceModel(await AzureUtilsService.createDevice(this.user, device, true))
    }

    getEvents(deviceId: string): Promise<string[]> {
        return AzureUtilsService.getEvents(deviceId);
    }

    sendToDevice(deviceId: string, module: string, message: string): Promise<void> {
        return AzureUtilsService.sendToModule(AzureUtilsService.getConnectionString(this.user), deviceId, module, message);
    }

}
