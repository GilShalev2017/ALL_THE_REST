import {Device} from "../device.model";
import {User} from "../../users/user.model";
import {IndividualEnrollment} from "azure-iot-provisioning-service/dist/interfaces";
import {CreateKeysAndCertificateResponse} from "aws-sdk/clients/iot";
import {Feature} from "../feature.model";


export interface Module {
    status?: string;
}
export interface Modules {
    [key: string]: Module;
}

export interface NewModuleRequest {
    moduleName: string,
    moduleUri: string,
    connectionString: string
}

export interface NewMultipleModuleRequest {
    selectedModules: Feature[],
    connectionString: string
}

export interface EnrollmentResponse {
    certRes?: CreateKeysAndCertificateResponse;
    dataEndpoint?: string;
    credEndpoint?: string;
    azure?: IndividualEnrollment;
}

export abstract class AbstractIotService {
    user: User;

    abstract getUserDevices(): Promise<Device[]>;
    abstract getDeviceModules(deviceId: string): Promise<Modules>;
    abstract deployModules(deviceId: string, moduleRequest: NewModuleRequest): Promise<void>;
    abstract deployMultipleModules(deviceId: string, moduleRequest: NewMultipleModuleRequest): Promise<void>;
    abstract deleteModules(deviceId: string, moduleName: string): Promise<void>;
    abstract createDevice(device: Omit<Device, 'id'>): Promise<Device>;
    abstract updateDevice(device: Omit<Device, 'id'>): Promise<Device>;
    abstract createDeviceEnrollment(deviceId: string, certificate: string, caCertificate?: string): Promise<EnrollmentResponse>;
    abstract deleteDeviceEnrollment(deviceId: string): Promise<string>;
    abstract getEvents(deviceId: string): Promise<string[]>;
    abstract sendToDevice(deviceId: string, module: string, message: string): Promise<void>;
}
