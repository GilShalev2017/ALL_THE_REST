import {
    AbstractIotService,
    EnrollmentResponse,
    Modules,
    NewModuleRequest,
    NewMultipleModuleRequest
} from "./abstract-iot.service";
import {User} from "../../users/user.model";
import {Device} from "../device.model";
import {AwsUtilsService, AzureUtilsService} from "../../../services";
import AWS, {GreengrassV2, Iot} from "aws-sdk";
import {ComponentDeploymentSpecifications, CoreDevice} from "aws-sdk/clients/greengrassv2";
import {HttpErrors} from "@loopback/rest";
import {
    AttachPolicyRequest, CreateKeysAndCertificateResponse,
    RegisterThingRequest,
} from "aws-sdk/clients/iot";

export const groupARNPrefix = 'arn:aws:iot:us-east-1:435076512082:thinggroup/';
import * as fs from 'fs';
import {exec} from 'child_process';

export class AwsIotService extends AbstractIotService {
    greengrassv2: GreengrassV2;
    iot: Iot;

    constructor(user: User) {
        super();
        this.user = user;
        AwsUtilsService.config();
        this.greengrassv2 = new AWS.GreengrassV2();
        this.iot = new AWS.Iot();
    }

    static toDeviceModel(device: CoreDevice): Device {
        return <Device>{
            ...device,
            deviceId: device.coreDeviceThingName,
            name: device.coreDeviceThingName,
            id: device.coreDeviceThingName,
            connectionState: 'Connected'
        };
    }

    static toModule(device: CoreDevice): Device {
        return <Device>{
            ...device,
            deviceId: device.coreDeviceThingName,
            name: device.coreDeviceThingName,
            id: device.coreDeviceThingName,
        };
    }

    async getUserDevices(): Promise<Device[]> {
        try {
            const devices = await this.greengrassv2.listCoreDevices({
                // thingGroupArn: this.user.cloudProvider?.iotDomainName ?? defaultGroupARN
            }).promise();
            return devices.coreDevices?.map(AwsIotService.toDeviceModel) ?? [];
        } catch (e) {
            console.log("error getting devices", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getDeviceModules(deviceId: string): Promise<Modules> {
        try {
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();
            return modules.installedComponents?.reduce((map: Modules, item) => {
                if (item.componentName) {
                    map[item.componentName] = {
                        ...item,
                        status: item.lifecycleState
                    };
                }
                return map;
            }, {}) ?? {};
        } catch (e) {
            console.log("error getting device modules", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async deployModules(deviceId: string, moduleRequest: NewModuleRequest): Promise<void> {
        try {
            const moduleName = moduleRequest.moduleName === 'realsense-ai' ? 'com.intel.realsense' : moduleRequest.moduleName + '-' + new Date().getTime();
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();

            const version = Math.floor(Math.random() * 10000);
            const json = moduleRequest.moduleName === 'realsense-ai' ? {
                "RecipeFormatVersion": "2020-01-25",
                "ComponentName": "com.intel.realsense",
                "ComponentVersion": "0.1." + version,
                "ComponentType": "aws.greengrass.generic",
                "ComponentDescription": "Docker container with Vision Platform Demo binaries.",
                "ComponentPublisher": "Intel Corporation",
                "ComponentConfiguration": {
                    "DefaultConfiguration": {
                        "accessControl": {
                            "aws.greengrass.ipc.mqttproxy": {
                                "com.intel.realsense:pubsub:1": {
                                    "policyDescription": "Allows access to publish/subscribe to all topics.",
                                    "operations": [
                                        "aws.greengrass#PublishToIoTCore",
                                        "aws.greengrass#SubscribeToIoTCore"
                                    ],
                                    "resources": [
                                        "*"
                                    ]
                                }
                            }
                        },
                        "aws_env": "-e AWS_IOT_THING_NAME=$AWS_IOT_THING_NAME -e AWS_REGION=$AWS_REGION -e SVCUID=$SVCUID -e AWS_GG_NUCLEUS_DOMAIN_SOCKET_FILEPATH_FOR_COMPONENT=$AWS_GG_NUCLEUS_DOMAIN_SOCKET_FILEPATH_FOR_COMPONENT -e AWS_CONTAINER_AUTHORIZATION_TOKEN=$AWS_CONTAINER_AUTHORIZATION_TOKEN -e AWS_CONTAINER_CREDENTIALS_FULL_URI=$AWS_CONTAINER_CREDENTIALS_FULL_URI",
                        "docker_flags": " --device-cgroup-rule \"c 81:* rmw\" --device-cgroup-rule \"c 189:* rmw\" ",
                        "docker_mounts": "-v /dev:/dev -v /greengrass/v2:/greengrass/v2",
                        "docker_volumes": "--mount source=vol_models,target=/app/all_models",
                        "docker_cmd": "./run.sh"
                    }
                },
                "ComponentDependencies": {
                    "aws.greengrass.DockerApplicationManager": {
                        "VersionRequirement": "~2.0.0"
                    }
                },
                "Manifests": [
                    {
                        "Platform": {
                            "os": "all"
                        },
                        "Lifecycle": {
                            "Run": {
                                "Script": "docker run --rm {configuration:/docker_mounts} {configuration:/docker_volumes} {configuration:/docker_flags} {configuration:/aws_env} public.ecr.aws/h2d5i2r7/librealsense:realsense-app"
                            }
                        },
                        "Artifacts": [
                            {
                                "Uri": "docker:public.ecr.aws/h2d5i2r7/librealsense:realsense-app",
                                "Unarchive": "NONE",
                                "Permission": {
                                    "Read": "OWNER",
                                    "Execute": "NONE"
                                }
                            }
                        ]
                    }
                ],
                "Lifecycle": {}
            } : {
                "RecipeFormatVersion": "2020-01-25",
                "ComponentName": moduleName,
                "ComponentVersion": "0.1." + version,
                "ComponentDescription": moduleName,
                "ComponentPublisher": "Amazon",
                "Manifests": [
                    {
                        "Name": "Linux",
                        "Platform": {
                            "os": "linux"
                        },
                        "Lifecycle": {
                            "Install": {
                                "Script": "docker load -i {artifacts:path}/bare-min.tar"
                            },
                            "Run": {
                                "Script": `docker run --rm --name ${moduleName} bare-min`
                            }
                        },
                        "Artifacts": [
                            {
                                "Uri": "s3://scoe-greengrass-artifacts-2/bare-min.tar"
                            }
                        ]
                    }
                ]
            }

            const componentResponse = await this.greengrassv2.createComponentVersion({
                inlineRecipe: JSON.stringify(json)
            }).promise();
            console.log(componentResponse);
            const components: ComponentDeploymentSpecifications = {};
            components[moduleName] = {
                componentVersion: '0.1.' + version
            }
            if (modules.installedComponents) {
                for (const installedComponent of modules.installedComponents) {
                    if (installedComponent.componentName) {
                        components[installedComponent.componentName] = {
                            componentVersion: installedComponent.componentVersion
                        }
                    }
                }
            }
            const deploymentResponse = await this.greengrassv2.createDeployment({
                targetArn: 'arn:aws:iot:us-east-1:739177214603:thing/' + deviceId,
                components: components
            }).promise();
            console.log(deploymentResponse);
        } catch (e) {
            console.log("error deploying module", e);
            throw new HttpErrors.BadRequest(e?.code);
        }
    }

    async deployMultipleModules(deviceId: string, multipleModuleRequest: NewMultipleModuleRequest): Promise<void> {
        try {
            const newModuleDate = new Date().getTime();
            const version = Math.floor(Math.random() * 10000);
            const components: ComponentDeploymentSpecifications = {};
            for (const feature of multipleModuleRequest.selectedModules) {
                const newModuleName = feature.name + '-' + newModuleDate;
                const json = {
                    "RecipeFormatVersion": "2020-01-25",
                    "ComponentName": newModuleName,
                    "ComponentVersion": "0.1." + version,
                    "ComponentDescription": newModuleName,
                    "ComponentPublisher": "Amazon",
                    "Manifests": [
                        {
                            "Name": "Linux",
                            "Platform": {
                                "os": "linux"
                            },
                            "Lifecycle": {
                                "Install": {
                                    "Script": "docker load -i {artifacts:path}/bare-min.tar"
                                },
                                "Run": {
                                    "Script": `docker run --rm --name ${newModuleName} bare-min`
                                }
                            },
                            "Artifacts": [
                                {
                                    "Uri": "s3://scoe-greengrass-artifacts-2/bare-min.tar"
                                }
                            ]
                        }
                    ]
                }
                const componentResponse = await this.greengrassv2.createComponentVersion({
                    inlineRecipe: JSON.stringify(json)
                }).promise();
                console.log(componentResponse);
                components[newModuleName] = {
                    componentVersion: '0.1.' + version
                }
            }
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();
            if (modules.installedComponents) {
                for (const installedComponent of modules.installedComponents) {
                    if (installedComponent.componentName) {
                        components[installedComponent.componentName] = {
                            componentVersion: installedComponent.componentVersion
                        }
                    }
                }
            }
            const deploymentResponse = await this.greengrassv2.createDeployment({
                targetArn: 'arn:aws:iot:us-east-1:739177214603:thing/' + deviceId,
                components: components
            }).promise();
            console.log(deploymentResponse);
        } catch (e) {
            console.log("error deploying module", e);
            throw new HttpErrors.BadRequest(e?.code);
        }
    }

    async deleteModules(deviceId: string, moduleName: string): Promise<void> {
        try {
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();
            console.log(modules);
            const components: ComponentDeploymentSpecifications = {};
            if (modules.installedComponents) {
                for (const installedComponent of modules.installedComponents) {
                    if (installedComponent.componentName && installedComponent.componentName !== moduleName) {
                        components[installedComponent.componentName] = {
                            componentVersion: installedComponent.componentVersion
                        }
                    }
                }
            }
            const deploymentResponse = await this.greengrassv2.createDeployment({
                targetArn: 'arn:aws:iot:us-east-1:739177214603:thing/' + deviceId,
                components: components
            }).promise();
            console.log(deploymentResponse);
        } catch (e) {
            console.log("error deleting module", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    createDevice(device: Omit<Device, "id">): Promise<Device> {
        return Promise.reject();
    }

    async createDeviceEnrollment(deviceId: string, certificate: string, caCertificate: string): Promise<EnrollmentResponse> {
        const registerCertificateRequest = {
            certificatePem: certificate,
            status: 'ACTIVE',
        };

        try {
            // Instead of registering certificate we will verify the certificate is signed by Intel CA.
            // const certRes = await this.iot.registerCertificateWithoutCA(registerCertificateRequest).promise();
            const createCertParams = {
                setAsActive: true
            };

            const certRes = await this.iot.createKeysAndCertificate(createCertParams).promise();

            console.log('Certificate registered successfully', certRes);

            const attachPolicyRequest: AttachPolicyRequest = {
                policyName: 'GreengrassTESCertificatePolicyVisionPlatformProvisionRoleAlias',
                target: certRes.certificateArn ?? ''
            };
            let res = await this.iot.attachPolicy(attachPolicyRequest).promise();
            console.log('Attach Policy Success', res);
            attachPolicyRequest.policyName = 'GreengrassV2IoTThingPolicy';
            res = await this.iot.attachPolicy(attachPolicyRequest).promise();
            attachPolicyRequest.policyName = 'GreengrassTESCertificatePolicyGreengrassCoreTokenExchangeRoleAlias';
            res = await this.iot.attachPolicy(attachPolicyRequest).promise();
            attachPolicyRequest.policyName = 'GreengrassTESCertificatePolicyGreengrassV2TokenExchangeRoleAlias';
            res = await this.iot.attachPolicy(attachPolicyRequest).promise();

            console.log('Attach Policy Success', res);

            const request: RegisterThingRequest = {
                templateBody: JSON.stringify({
                    "Parameters": {
                        "ThingName": {
                            "Type": "String"
                        },
                        "SerialNumber": {
                            "Type": "String"
                        },
                        "Location": {
                            "Type": "String",
                            "Default": "WA"
                        },
                        "CertificateId": {
                            "Type": "String"
                        }
                    },
                    "Resources": {
                        "thing": {
                            "Type": "AWS::IoT::Thing",
                            "Properties": {
                                "ThingName": {"Ref": "ThingName"},
                                "ThingGroups": ["GreengrassQuickStartGroup"]
                            },
                            "OverrideSettings": {
                                "AttributePayload": "MERGE",
                                "ThingTypeName": "REPLACE",
                                "ThingGroups": "REPLACE"
                            }
                        },
                        "certificate": {
                            "Type": "AWS::IoT::Certificate",
                            "Properties": {
                                "CertificateId": {"Ref": "CertificateId"}
                            }
                        }
                    }
                }),
                parameters: {
                    'ThingName': deviceId,
                    'CertificateId': certRes.certificateId ?? '',
                }
            }

            res = await this.iot.registerThing(request).promise();
            console.log('Thing registered successfully', res);

            const endpointRequestParams = {
                endpointType: 'iot:CredentialProvider'
            };

            const credEndpoint = (await this.iot.describeEndpoint(endpointRequestParams).promise()).endpointAddress ?? '';
            endpointRequestParams.endpointType = 'iot:Data-ATS'
            const dataEndpoint = (await this.iot.describeEndpoint(endpointRequestParams).promise()).endpointAddress ?? '';

            console.log('Credentials Endpoint: ' + credEndpoint);
            console.log('Data Endpoint: ' + dataEndpoint);
            return {
                certRes,
                dataEndpoint,
                credEndpoint
            };

        } catch (e) {
            console.log('Error creating device enrollment', e);
            return Promise.reject();
        }
    }

    deleteDeviceEnrollment(deviceId: string): Promise<string> {
        return Promise.reject();
    }

    updateDevice(device: Omit<Device, "id">): Promise<Device> {
        return Promise.reject();
    }

    async getEvents(): Promise<string[]> {
        try {
            const dynamodb = new AWS.DynamoDB();
            const response = await dynamodb.query({
                TableName: "iot-events",
                ScanIndexForward: false,
                ExpressionAttributeValues: {
                    ":v1": {
                        S: "iot"
                    }
                },
                KeyConditionExpression: "hub = :v1",
                Limit: 10
            }).promise();
            return response.Items ? response.Items.map(item => {
                return JSON.stringify({
                    created: item.created.N,
                    payload: item.payload?.M ?? response.Items?.[0].payload_raw?.B?.toString()
                })
            }) : [];
        } catch (e) {
            console.log("error getting events", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    static async sendToDeviceStatic(deviceId: string, module: string, message: string): Promise<void> {
        try {
            const iotdata = new AWS.IotData({endpoint: 'a1z1niunapoaag-ats.iot.us-east-1.amazonaws.com'});
            const response = await iotdata.publish({
                qos: 0,
                topic: "topic_1",
                payload: JSON.stringify({
                    "message": message
                })
            }).promise()
            console.log(response);
        } catch (e) {
            console.log("error sending to device", e);
        }
    }

    async sendToDevice(deviceId: string, module: string, message: string): Promise<void> {
        await AwsIotService.sendToDeviceStatic('', '', message);
    }
}
