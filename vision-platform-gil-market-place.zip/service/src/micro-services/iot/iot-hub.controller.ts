import {get, param, post, requestBody} from "@loopback/rest";
import {AzureUtilsService} from "../../services";
import {inject} from "@loopback/core";
import {SecurityBindings} from "@loopback/security";
import {User} from "../users/user.model";
import {authenticate} from "@loopback/authentication";
import {AwsIotService} from "./logic/aws-iot.service";
import {DeviceController} from "./device.controller";

export class IotHubController {
    @get('/list')
    async list(): Promise<void> {
        // return AzureUtilsService.listDevices();
    }
    @post('/device')
    async create(): Promise<string> {
        // await AzureUtilsService.createDevice({deviceId: "test1"});
        return "ok";
    }
    @authenticate('jwt')
    @post('/subscribeToEvents')
    async subscribe(
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<void> {
        await AzureUtilsService.subscribeToEventsHub(currentUserProfile);
    }
    @authenticate('jwt')
    @post('/unsubscribeToEvents')
    async unsubscribe(
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<void> {
        await AzureUtilsService.unSubscribeToEventsHub(currentUserProfile);
    }
    @authenticate('jwt')
    @get('/events/{id}')
    async getEvents(
        @param.path.string('id') id: string,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<string[]> {
        return DeviceController.getUserIoTService(currentUserProfile).getEvents(id);
    }
    @authenticate('jwt')
    @get('/events-aws/{id}')
    async getEventsAWS(
        @param.path.string('id') id: string,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<string[]> {
        return new AwsIotService(currentUserProfile).getEvents();
    }
    @authenticate('jwt')
    @get('/logs/{id}/{moduleName}')
    async getLogs(
        @param.path.string('id') id: string,
        @param.path.string('moduleName') moduleName: string,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<object> {
        return AzureUtilsService.getLogs(currentUserProfile, id, moduleName);
    }
    @authenticate('jwt')
    @post('/sendToDevice')
    async sendToDevice(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @requestBody() body: {message: string, module: string, deviceId: string}
    ): Promise<void> {
        return DeviceController.getUserIoTService(currentUserProfile).sendToDevice(body.deviceId, body.module, body.message);
    }
    @get('/testAzure')
    async test(): Promise<void> {
        return AzureUtilsService.getHubList();
    }
}
