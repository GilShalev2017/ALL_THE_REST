import AWS, {S3} from "aws-sdk";
import proxy from "proxy-agent";
import {ObjectList} from "aws-sdk/clients/s3";

interface Body extends S3.Object {
    Body?: string
}

export class AwsUtilsService {

    static async enableUser(userNamePrm: string): Promise<number> {
        return new Promise(resolve => {

            if (process?.env?.IS_LOCALHOST_ENV?.toString() === "true" || process.env.LOCAL || process.env.testMode) {

                const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
                AWS.config.update({region: 'us-west-2', httpOptions: {...httpOptions}});
            }

            const cognito = new AWS.CognitoIdentityServiceProvider();
            const params = {
                UserPoolId: process.env.AWS_COGNITO_USER_POOL,
                Username: userNamePrm
            }
            cognito.adminConfirmSignUp(params, (err, data) => {
                console.log(err)
                console.log(data)
                resolve(err ? -1 : 1);
            })

        });
    }

    static async listObjects(bucket: string): Promise<ObjectList> {
        const s3 = new AWS.S3();
        const params = {
            Bucket: bucket
        };


        try {
            const res = await s3.listObjects(params).promise();
            return res?.Contents ? res.Contents : [];
        } catch (e) {
            console.log(e);
            return [];
        }

    }

    static async getLatestFileInBucket(bucket: string): Promise<Body> {
        try {
            const res = await this.listObjects(bucket);
            if (!res || res?.length === 0) {
                return {};
            }
            //ascending
            res.sort((a: S3.Object, b: S3.Object) => {
                if (a.LastModified && b.LastModified) {
                    return a.LastModified.valueOf() - b.LastModified.valueOf()
                }
                return 0;
            })

            const lastModifiedObject = res[res.length - 1];
            if (lastModifiedObject.Key) {
                const file = await AwsUtilsService.downloadS3Object(bucket, lastModifiedObject.Key)
                return file;
            }
            return {};
        } catch (e) {
            console.log(e);
            return {};
        }
    }

    static async downloadS3Object(bucket: string, key: string): Promise<S3.Object> {

        const s3 = new AWS.S3();
        try {
            const res = await s3.getObject({Bucket: bucket, Key: key}).promise();
            return res;
        } catch (e) {
            return {}
        }
    }

    static async downloadS3(bucket: string, key: string) {
        console.log("using access key", process.env.AWS_ACCESS_KEY_ID);
        const s3 = new AWS.S3();
        const url = s3.getSignedUrl('getObject', {
            Bucket: bucket,
            Key: key,
            Expires: 60 * 60
        })
        return url;
    }

    static config() {
        const config = {region: 'us-east-1', httpOptions: {}};
        if (process?.env?.IS_LOCALHOST_ENV?.toString() === "true"  || process.env.USE_PROXY) {
            console.log("Using AWS proxy");
            config.httpOptions = {agent: proxy("http://proxy-us.intel.com:911")};
        }
        AWS.config.update({...config});
    }

    static async sendEmail(to: string, subject: string, message: string) {
        this.config();
        const params = {
            Destination: { /* required */
                // CcAddresses: [],
                ToAddresses: [to]
            },
            Message: { /* required */
                Body: { /* required */
                    // Html: {
                    //   Charset: "UTF-8",
                    //   Data: "HTML_FORMAT_BODY"
                    // },
                    Text: {
                        Charset: "UTF-8",
                        Data: message
                    }
                },
                Subject: {
                    Charset: 'UTF-8',
                    Data: subject
                }
            },
            Source: 'info@mevolve-cloud.com',
        };

        const sendPromise = new AWS.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();
        sendPromise.then(
            (data) => {
                console.log("email id", data.MessageId);
            }).catch(
            (err) => {
                console.error(err, err.stack);
            });
    }
}
