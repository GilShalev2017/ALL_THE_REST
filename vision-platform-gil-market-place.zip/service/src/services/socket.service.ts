import {bind, BindingScope, inject, Context, Application} from "@loopback/core";

@bind({scope: BindingScope.SINGLETON})
export class SocketService {
    constructor(@inject.context() private ctx: Context) {
        console.log("Init socket service");
        // this.init();
    }

    async init() {
        const app = await this.ctx.get<Application>('application.instance');
        const http = require('http').Server(app);
        const io = require("socket.io")(http, {
            cors: {
                origin: '*',
            }
        });
        io.on("connection", function(socket: any) {
            console.log("a user connected!");
        });
        http.listen(8080, () => {
            console.log('listening on *:8080');
        });
    }
}
