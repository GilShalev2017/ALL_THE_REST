import {
  /* inject, Application, CoreBindings, */
  lifeCycleObserver, // The decorator
  LifeCycleObserver, service, // The interface
} from '@loopback/core';
import {RabbitMqService, SocketService} from "../services";

/**
 * This class will be bound to the application as a `LifeCycleObserver` during
 * `boot`
 */
@lifeCycleObserver('')
export class InitObserver implements LifeCycleObserver {

  constructor(
      @service(RabbitMqService) public rabbitMqService: RabbitMqService,
      @service(SocketService) public socketService: SocketService,
  ) {}


  /**
   * This method will be invoked when the application starts
   */
  async start(): Promise<void> {
    console.log("is this really running?");
  }

  /**
   * This method will be invoked when the application stops
   */
  async stop(): Promise<void> {
    // Add your logic for stop
  }
}
