import {NavbarItem} from './framework/navbar/navbar-config';
import {environment} from '../environments/environment';

export const menuItems: NavbarItem[] = [{
  displayName: 'Users',
  icon: 'account_circle',
  path: 'users',
  onlyAdmin: true,
}, {
  displayName: 'Features',
  icon: 'account_circle',
  path: 'features',
}, {

  displayName: 'Devices',
  icon: 'camera_rear',
  path: 'devices',
}, {
  displayName: 'Account',
  icon: 'account_box',
  path: 'account',
}, {

  displayName: 'Editor',
  icon: 'edit',
  path: 'editor',
}, {
  displayName: 'Metrics',
  icon: 'poll',
  path: environment.serverUrl + 'grafana/',
  onlyAdmin: true,
  target: '_blank',
}, {
  displayName: 'Logs',
  icon: 'receipt',
  path: 'http://localhost',
  onlyAdmin: true,
  target: '_blank',
}, {
  displayName: 'API Explorer',
  icon: 'api',
  path: environment.serverUrl,
  onlyAdmin: true,
  target: '_blank'
}, {
  displayName: 'Logout',
  icon: 'logout',
  path: '#',
}];
