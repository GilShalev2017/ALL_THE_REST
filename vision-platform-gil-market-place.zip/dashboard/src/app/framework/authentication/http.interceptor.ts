import {Injectable} from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor, HttpResponse, HttpErrorResponse
} from '@angular/common/http';
import {BehaviorSubject, Observable, Subject, throwError} from 'rxjs';
import {UserService} from './user.service';
import {map, catchError, switchMap, take, filter, tap} from 'rxjs/operators';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  private isTokenRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(private userService: UserService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const {token} = this.userService;
    if (token) {
      request = this.addToken(request, token);
    }

    return next.handle(request).pipe(catchError(error => {
      if (error instanceof HttpErrorResponse ) {
        if (error.status === 401) {
          return this.handleError(request, next);
        } else {
          return next.handle(request)
        }
      }

    }));

  }

  private handleError(request: HttpRequest<any>, next: HttpHandler) {
    if (!this.isTokenRefreshing) {
      this.refreshTokenSubject.next(null);
      this.isTokenRefreshing = true;
      return this.userService.tokenRefresh().pipe(
        switchMap((token: any) => {
          this.isTokenRefreshing = false;
          this.refreshTokenSubject.next(token);
          return next.handle(this.addToken(request, token.accessToken));
        }));

    } else {
      return this.refreshTokenSubject.pipe(
        filter(token => token != null),

        switchMap(token => {
          this.isTokenRefreshing = false;
          return next.handle(this.addToken(request, token));
        }));
    }
  }

  private addToken(request: HttpRequest<any>, token: string) {
    return request.clone({
      setHeaders: {
        'Authorization': `Bearer ${token}`
      }
    });
  }

}
