import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router} from '@angular/router';
import {AuthenticationModule} from './authentication.module';
import {UserService} from './user.service';

@Injectable({
  providedIn: AuthenticationModule
})
export class CanActivateGuardService implements CanActivate {
  constructor(
    private userService: UserService,
    private router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot): boolean {
    if (this.userService.isAuthenticated()) {
      return true;
    } else {
      this.router.navigate(['login']);
      return false;
    }
  }
}
