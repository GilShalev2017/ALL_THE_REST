import { Component, OnInit } from '@angular/core';
import {NavbarConfig} from '../navbar/navbar-config';
import {menuItems} from '../../menu-items';

@Component({
  selector: 'app-sidebar',
  template: `
    <app-navbar></app-navbar>
  `,
  styles: []
})
export class SidebarComponent {
}
