import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {map, startWith} from 'rxjs/operators';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-selector-creator',
  templateUrl: './selector-creator.component.html',
  styleUrls: ['./selector-creator.component.css']
})
export class SelectorCreatorComponent<T extends {body: string}> implements OnInit, OnChanges {

  form: FormGroup;
  control = new FormControl();
  filteredItems: Observable<T[]>;

  @Input()
  items: T[];

  @Input()
  itemName: string;

  @Output() create = new EventEmitter();
  @Output() selected = new EventEmitter<T>();

  constructor() { }

  ngOnInit(): void {
    this.form = new FormGroup({});
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.items && !changes.items.previousValue) {
      this.filteredItems = this.control.valueChanges
        .pipe(
          startWith(''),
          map(value => typeof value === 'string' ? value : value.body),
          map(name => name ? this._filter(name) : this.items.slice())
        );
    }
  }

  displayBody(entity: {body: string}): string {
    return entity && entity.body ? entity.body : '';
  }

  itemSelected(value: any) {
    if (value === 'NEW_ITEM') {
      this.control.setValue('');
      this.create.emit();
    } else {
      this.assign(this.control.value);
    }
  }

  assign(value: T) {
    this.selected.emit(value);
    this.control.setValue('');
  }

  private _filter(name: string): T[] {
    const filterValue = name.toLowerCase();

    return this.items.filter(option => option.body && option.body.toLowerCase().indexOf(filterValue) > -1);
  }
}
