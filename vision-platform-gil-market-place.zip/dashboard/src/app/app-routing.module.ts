import {FeaturesComponent} from './demo/features/features.component';
import {DevicesComponent} from './demo/devices/devices.component';
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import {CanActivateGuardService} from './framework/authentication/can-activate-guard.service';
import {SidebarComponent} from './framework/layouts/sidebar.component';
import {UsersComponent} from './demo/users/users.component';
import {EntityTableComponent} from './demo/entity-table/entity-table.component';
import {FileEditorComponent} from './demo/editor/file-editor.component';
import {FullScreenComponent} from './framework/layouts/full-screen.component';
import {SelectCloudProviderComponent} from './demo/select-cloud-provider/select-cloud-provider.component';
import {DeviceComponent} from './demo/device/device.component';
import {AccountComponent} from "./demo/account/account.component";


const routes: Routes = [
{
    path: 'features',
    component: SidebarComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: FeaturesComponent
      }
    ]
  },

{
    path: 'devices',
    component: SidebarComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: DevicesComponent
      }
    ]
  },
  {
    path: 'device/:id',
    component: SidebarComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: DeviceComponent
      }
    ]
  },
  {
    path: 'account',
    component: SidebarComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: AccountComponent
      }
    ]
  },
  {
    path: 'select-cloud-provider',
    component: FullScreenComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: SelectCloudProviderComponent
      }
    ]
  },
  {
    path: 'users',
    component: SidebarComponent,
    canActivate: [CanActivateGuardService],
    children: [
      {
        path: '',
        component: UsersComponent
      }
    ]
  },
  {
    path: 'editor',
    component: FileEditorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})

export class AppRoutingModule {
}
