import {Observable} from "rxjs";
import {FormGroup} from "@angular/forms";
import {Device} from "azure-iothub/dist/device";
import {Feature} from "../demo/features/features.service";

export enum LoadingProgress {
  INITIAL,
  LOADING,
  ERROR,
  DONE
}

export enum AuthLevel {
  USER = 'USER',
  ADMIN = 'ADMIN',
  SUPER = 'SUPER'
}
export enum USER_ACTIONS {
  USER_EDIT = 'USER_EDIT',
  USER_ADD = 'USER_ADD'
}

export enum Auth {
  LOGIN = 'LOGIN',
  REGISTER = 'REGISTER',
  PASSWORD_RESET = 'PASSWORD_RESET',
  PASSWORD_UPDATE = 'PASSWORD_UPDATE',
  ADMIN_CONFIRMATION = 'ADMIN_CONFIRMATION',
}
export interface Entity {
  id: string;
}
export abstract class EntityService {
  displayName: string;
  fields: { [key: string]: EntityFieldMetadata; };
  // count?: number;
  abstract delete(id: string): Observable<void>;
  abstract get(page: number, pageSize: number, refresh?: boolean): Observable<Entity[]>;
  abstract getCount(): Observable<number>;
  abstract getSingleForm(entity?: Entity): FormGroup;
  abstract save(id: string, entity: Entity): Observable<Entity>;
}

export interface EntityFieldMetadata {
  displayName: string;
  type?: 'text' | 'boolean';
  isPicture?: boolean;
  isHidden?: boolean;
  enumValues?: object;
  isEnum?: boolean;
}


export interface FileNode {
  name: string;
  children?: FileNode[];
}
export interface UserCloudProvider {
  intelManaged: boolean;
  connectionString?: string;
  clientId?: string;
  secret?: string;
  tenantId?: string;
  subscriptionId?: string;
  eventsHubConnectionString?: string;
  iotDomainName?: string;
  provider?: 'AZURE' | 'AWS';
  dpsServiceOperationsHostName?: string;
}

export interface DeviceRequest {
  deviceId: string;
  authType?: string;
  autoGenKeys?: boolean;
  primaryKey?: string;
  secondaryKey?: string;
  edgeEnabled?: boolean;
  hubEnabled?: boolean;
}

export interface DeviceDescription {
  deviceId: string;
  capabilities?: Device.Capabilities;
  [x: string]: any;
}

export interface GetFeaturesResponse {
  features: Feature[];
  count: number;
}

export interface AssetUrlResponse {
  assetUrl: string;
}

