import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DateUtilsService {

  constructor() { }

  getCalendarDay(date: Date) {
    return '' + date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
  }

  getDaysArray(howManyDays: number): string[] {
    const daysArray: string[] = [];
    const now = new Date();
    for (let i = 0; i < howManyDays; i++) {
      const day = new Date(now.getTime() - 24 * 3600 * 1000 * i);
      daysArray.push(this.getCalendarDay(day));
    }
    return daysArray;
  }
}
