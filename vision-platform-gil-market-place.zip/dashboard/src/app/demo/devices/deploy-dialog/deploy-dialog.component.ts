import {AfterViewInit, Component, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {LoadingProgress} from 'src/app/models/interfaces';
import {Device, DevicesService} from '../devices.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatPaginator, PageEvent} from '@angular/material/paginator';
import {Feature, FeaturesService} from '../../features/features.service';
import {MatTableDataSource} from '@angular/material/table';
import {Subject, Subscription} from 'rxjs';
import {debounceTime, distinctUntilChanged, switchMap, tap} from 'rxjs/operators';

@Component({
  selector: 'app-deploy-dialog',
  templateUrl: './deploy-dialog.component.html',
  styleUrls: ['./deploy-dialog.component.css']
})
export class DeployDialogComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;
  error: string;
  moduleName: string;
  dockerImage: string;
  dataSource: MatTableDataSource<Feature>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  page = 0;
  filterText: string;
  maxPageSize = 12;
  pageSize = 12;
  totalLength = 0;
  pageEvent: PageEvent;
  selectedModulesMap = new Map();
  searchQuery$ = new Subject<string>();
  private searchSubscription: Subscription;
  busy = false;

  constructor(
    private snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<DeployDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      device: Device,
      totalLength: number,
      moduleKeys: string[]
    },
    public devicesService: DevicesService,
    public featuresService: FeaturesService) {
    this.totalLength = this.data.totalLength;
  }

  searchFeatures() {
    if (!this.filterText) {
      this.getAllFeatures();
    } else {
      this.getFilteredFeatures();
    }
  }

  setSelection(featuresArray: Feature[]) {
    featuresArray.forEach(element => {
      if (this.selectedModulesMap.has(element.name)) {
        element.selected = true;
      }
    });
  }

  setDeployed(featuresArray: Feature[]) {
    featuresArray.forEach(element => {
      if (this.data.moduleKeys.some(e => e.includes(element.name))) {
        element.deployed = true;
      }
    });
  }

  applyFilter() {
    this.page = 0;
    this.searchQuery$.next(this.filterText);
  }

  configureDataSourceSelectionAndDeployment(features: Feature[]) {
    this.dataSource = new MatTableDataSource(features);
    this.setSelection(features);
    this.setDeployed(features);
  }

  getFilteredFeatures() {
    this.featuresService.getFilteredFeatures(this.page, this.pageSize, this.filterText).subscribe(filteredFeatures => {
      this.configureDataSourceSelectionAndDeployment(filteredFeatures);
    });
  }

  getAllFeatures() {
    this.featuresService.get(this.page, this.pageSize).subscribe((features: Feature[]) => {
      this.configureDataSourceSelectionAndDeployment(features);
    });
  }

  ngOnInit(): void {
    this.getAllFeatures();

    this.searchSubscription = this.searchQuery$.pipe(
      debounceTime(700),
      distinctUntilChanged(),
      tap(() => this.busy = true),
      switchMap((text: string) => this.featuresService.getFilteredFeatures(this.page, this.pageSize, this.filterText)),
      tap(() => this.busy = false))
      .subscribe((features: Feature[]) => {
        this.configureDataSourceSelectionAndDeployment(features);
      });
  }

  onPageChange(event?: PageEvent) {
    if (this.pageSize < this.maxPageSize) {
      this.paginator.pageIndex = event.previousPageIndex;
      return event;
    }
    this.page = event.pageIndex;
    this.searchFeatures();
    return event;
  }

  cancel() {
    this.dialogRef.close();
  }

  save() {
    this.state = LoadingProgress.LOADING;
    const selectedFeatures = Array.from(this.selectedModulesMap.values());
    this.devicesService.deployMultiple(this.data.device.deviceId, selectedFeatures, this.data.device.authentication?.symmetricKey.primaryKey)
      .subscribe(() => {
        this.state = LoadingProgress.DONE;
        this.dialogRef.close(true);
        this.snackBar.open('Deploying to device started...', null, {
          duration: 3000
        });
      }, (err) => {
        console.log('error deploying', err);
        this.state = LoadingProgress.ERROR;
        this.error = err?.error?.error?.message || err?.statusText;
      });
  }

  select(item) {
    if (this.selectedModulesMap.has(item.name)) {
      this.selectedModulesMap.delete(item.name);
    } else {
      this.selectedModulesMap.set(item.name, item);
    }
  }
}
