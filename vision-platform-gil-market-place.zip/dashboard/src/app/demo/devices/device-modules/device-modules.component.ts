import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {LoadingProgress} from 'src/app/models/interfaces';
import {Device, DevicesService, Module, Modules} from '../devices.service';
import {SingleEntityComponent} from "../../entity-table/single-entity/single-entity.component";
import {MatDialog} from "@angular/material/dialog";
import {DeployDialogComponent} from "../deploy-dialog/deploy-dialog.component";
import {StreamEventsComponent} from "../../stream-events/stream-events.component";
import {ConfirmComponent} from "../../../dialogs/confirm/confirm.component";
import {tap} from "rxjs/operators";
import {MatSnackBar} from "@angular/material/snack-bar";
import {FeaturesService} from "../../features/features.service";

@Component({
  selector: 'app-device-modules',
  templateUrl: './device-modules.component.html',
  styleUrls: ['./device-modules.component.css']
})
export class DeviceModulesComponent implements OnInit, OnChanges {
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;

  @Input()
  device: Device;

  modules: Modules;
  moduleKeys: string[] = [];

  constructor(private snackBar: MatSnackBar, public dialog: MatDialog, public resource: DevicesService, public featuresService: FeaturesService) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!this.modules && this.device) {
      this.get(true);
    }
  }

  get(refresh: boolean) {
    this.state = LoadingProgress.LOADING;
    this.resource.getDeviceById(this.device.deviceId, refresh).subscribe(modules => {
      this.modules = modules;
      this.moduleKeys = modules ? Object.keys(modules) : [];
      this.state = LoadingProgress.DONE;
    });
  }

  deploy() {
    this.featuresService.getCount().subscribe( response => {
      this.dialog.open(DeployDialogComponent, {
        width: '1100px',
        data: {
          device: this.device,
          totalLength: response,
          moduleKeys: this.moduleKeys
        }
      }).afterClosed().subscribe((data) => {
        console.log('closed', data);
      });
    });
  }

  refresh() {
    this.get(true);
  }

  monitor() {
    this.dialog.open(StreamEventsComponent, {
      height: '700px',
      width: '700px',
      data: {
        device: this.device
      }
    });
  }

  deleteModule(moduleKey: string) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this module?`,
        doAction: () => {
          return this.resource.deleteModule(this.device.deviceId, moduleKey).pipe(tap(() => {
            this.moduleKeys.splice(this.moduleKeys.indexOf(moduleKey), 1);
            this.snackBar.open(this.resource.displayName + ' deleted successfully!', null, {
              duration: 2000,
            });
          }));
        }
      }
    });
  }
}
