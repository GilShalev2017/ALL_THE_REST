import {Component, OnInit} from '@angular/core';
import {LoadingProgress, UserCloudProvider} from 'src/app/models/interfaces';
import {DevicesService} from "../devices/devices.service";

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;

  cloudProvider: UserCloudProvider = null;
  cloudProviders = ['azure', 'aws'];

  constructor(private devicesService: DevicesService) { }

  ngOnInit(): void {
    this.devicesService.getCloudProvider().subscribe(cloudProvider => {
      this.state = LoadingProgress.DONE;
      this.cloudProvider = cloudProvider;
    }, err => {
      this.state = LoadingProgress.ERROR;
    });
  }

}
