import {Component, OnInit} from '@angular/core';
import {FeaturesService} from './features.service';

@Component({
  selector: 'app-features',
  template: '<app-entity-table [resource]="featureResource"></app-entity-table>',
  styleUrls: []
})
export class FeaturesComponent implements OnInit {
  featureResource: any;

  constructor(private featuresService: FeaturesService) {
    this.featureResource = featuresService;
  }

  ngOnInit(): void {
  }
}
