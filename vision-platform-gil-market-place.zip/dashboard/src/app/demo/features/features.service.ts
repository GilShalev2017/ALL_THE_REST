import {Injectable} from '@angular/core';
import {AuthLevel, Entity, EntityService, GetFeaturesResponse} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {FormControl, FormGroup} from "@angular/forms";
import {UserService} from "../../framework/authentication/user.service";

export enum SharingType {
  PRIVATE = 'PRIVATE',
  PUBLIC = 'PUBLIC',
}

export interface Feature extends Entity {
  name: string;
  dockerImgUrl: string;
  descriptiveName: string;
  picture: string;
  owner: string;
  sharingType: SharingType;
  selected?: boolean;
  deployed?: boolean;
} // entity

@Injectable({
  providedIn: 'root'
})
export class FeaturesService implements EntityService {

  displayName = 'feature';
  count = 0;
  fields = {
    name: {displayName: 'Name', isHidden: false},
    dockerImgUrl: {displayName: 'Docker image url', isHidden: false},
    descriptiveName: {displayName: 'Descriptive name', isHidden: false},
    picture: {displayName: 'Picture', isHidden: true, isPicture: true},
    owner: {displayName: 'Owner', isHidden: true},
    sharingType: {
      displayName: 'Sharing type',
      isHidden: false,
      isEnum: true,
      enumValues: this.enumSelector(SharingType)
    },
  }; // fields

  sharingTypes = {};

  constructor(private httpClient: HttpClient, private userService: UserService) {
    this.sharingTypes = this.enumSelector(SharingType);
  }

  getSingleForm(feature: Feature): FormGroup {
    const controls = Object.keys(this.fields).reduce((controlMap, field) => {
      controlMap[field] = new FormControl(feature ? feature[field] : '');
      if (field === 'sharingType') {
        if (!this.userService.isAdmin()) {
          if (!feature) { //for newly created feature
            controlMap[field].value = SharingType.PRIVATE;
          }
          controlMap[field].disable(); //for regular user - make the field readonly
        }
      } else if (field === 'owner') {
        controlMap[field].value = this.userService.getUserEmail();
      }
      return controlMap;
    }, {});
    return new FormGroup(controls);
  }

  getCount(): Observable<number> {
    return this.httpClient.get<number>(environment.serverUrl + 'features/count');
  }

  get(page: number, pageSize: number): Observable<Entity[]> {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };

    return this.httpClient.get<Feature[]>(environment.serverUrl + 'features/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getFilteredFeatures(page: number, pageSize: number, filterText: string) {
    const likeFilterText = `%${filterText}%`;
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ],
      where: {
        name: {
          ilike: likeFilterText,
        }
      }
    };

    return this.httpClient.get<Feature[]>(environment.serverUrl + 'features/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getFeatures(page: number, pageSize: number) {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };
    return this.httpClient.get<GetFeaturesResponse>(environment.serverUrl + 'features/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getFeatureById(id: string) {
    return this.httpClient.get<Feature>(environment.serverUrl + 'features/' + id);
  }

  delete(featureId: string): Observable<void> {
    return this.httpClient.delete<void>(environment.serverUrl + `features/${featureId}`, {});
  }

  save(id: string, entity: Feature): Observable<Feature> {
    if (!this.userService.isAdmin()) {
      entity.sharingType = SharingType.PRIVATE;
    }
    if (id) {
      return this.httpClient.put<Feature>(environment.serverUrl + 'features/' + id, entity);
    } else {
      return this.httpClient.post<Feature>(environment.serverUrl + 'features', entity);
    }
  }

  enumSelector(definition) {
    return Object.keys(definition)
      .map(key => ({value: definition[key], title: key}));
  }
}
