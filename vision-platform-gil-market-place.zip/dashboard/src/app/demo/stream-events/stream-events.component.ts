import {Component, Inject, Input, OnDestroy, OnInit} from '@angular/core';
import { LoadingProgress } from 'src/app/models/interfaces';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {Device, DevicesService} from '../devices/devices.service';
import {interval, ReplaySubject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {MatSnackBar} from "@angular/material/snack-bar";

@Component({
  selector: 'app-stream-events',
  templateUrl: './stream-events.component.html',
  styleUrls: ['./stream-events.component.css']
})
export class StreamEventsComponent implements OnInit, OnDestroy  {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;

  @Input()
  device: Device;

  listening = false;

  moduleKeys: string[] = [];
  events: string[] = [];
  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  newMessage: string;
  selectedModule: string;

  constructor(
    private snackBar: MatSnackBar,
    private devicesService: DevicesService,
  ) { }

  ngOnInit(): void {
    this.devicesService.getDeviceById(this.device.deviceId).subscribe(modules => {
      this.moduleKeys = modules ? Object.keys(modules) : [];
    });
  }

  ngOnDestroy() {
    this.devicesService.unSubscribe().subscribe();
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  listen(start: boolean) {
    this.listening = start;
    if (start) {
      this.destroyed$ = new ReplaySubject(1);
      this.devicesService.subscribe().subscribe(() => {
        interval(3000).pipe(takeUntil(this.destroyed$)).subscribe(() => {
          this.devicesService.getEvents(this.device.deviceId).subscribe(events => {
            this.events = [...this.events, ...events.map(event => {
              const e = JSON.stringify(event);
              if (this.events.indexOf(e) === -1) {
                return e;
              }
            })];
          });
        });
      });
    } else {
      this.devicesService.unSubscribe().subscribe();
      this.destroyed$.next(true);
    }
  }

  send() {
    this.state = LoadingProgress.LOADING;
    this.devicesService.sendMessageToDevice(this.device.deviceId, this.newMessage, this.selectedModule).subscribe(() => {
      this.snackBar.open('Successfully sent a message!', null, {
        duration: 3000,
      });
      this.state = LoadingProgress.DONE;
    });
    this.newMessage = '';
  }
}
