import {Component, Input, OnInit} from '@angular/core';
import {DevicesService} from '../devices/devices.service';
import {LoadingProgress} from '../../models/interfaces';
import {MatSelectChange} from "@angular/material/select";

@Component({
  selector: 'app-device-logs',
  templateUrl: './device-logs.component.html',
  styleUrls: ['./device-logs.component.css']
})
export class DeviceLogsComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.INITIAL;

  @Input()
  deviceId: string;
  moduleKeys: string[] = [];
  logs;
  currentModule: string;

  constructor(private devicesService: DevicesService) { }

  ngOnInit(): void {
    this.devicesService.getDeviceById(this.deviceId).subscribe(modules => {
      this.moduleKeys = modules ? Object.keys(modules) : [];
    });
  }

  getLogs() {
    this.state = LoadingProgress.LOADING;
    this.logs = '';
    this.devicesService.getLogs(this.deviceId, this.currentModule).subscribe(logs => {
      this.logs = logs.payload;
      this.state = LoadingProgress.DONE;
    }, err => {
      console.log(err);
      this.state = LoadingProgress.ERROR;
    });
  }
  getLogsFromEvent($event: MatSelectChange) {
    this.currentModule = $event.value;
    this.getLogs();
  }
}
