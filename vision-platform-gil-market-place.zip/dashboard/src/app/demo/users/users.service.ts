import { Injectable } from '@angular/core';
import {AuthLevel, Entity, EntityService} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {FormControl, FormGroup} from "@angular/forms";

export interface User extends Entity {
  email: string;
  firstName?: string;
  lastName?: string;
  weight?: number;
  gender?: string;
  birthDate?: Date;
  height?: number;
  activityLevel?: number;
  apeiron?: boolean;
  age?: number;
  authLevel?: AuthLevel;
}

@Injectable({
  providedIn: 'root'
})
export class UsersService implements EntityService {

  displayName = 'user';
  fields = {
    firstName: {
      displayName: 'First Name',
    },
    lastName: {
      displayName: 'Last Name',
    },
    email: {
      displayName: 'Email',
    },
    authLevel: {
      displayName: 'Auth Level',
    }
  }

  constructor(private httpClient: HttpClient) {}

  getSingleForm(user: User): FormGroup {
    return new FormGroup({
      firstName: new FormControl(user?.firstName || ''),
      lastName: new FormControl(user?.lastName || ''),
      email: new FormControl(user?.email || ''),
    })
  }

  getCount(): Observable<number> {
    return of(0);
  }

  get(page: number, pageSize: number): Observable<Entity[]> {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'email ASC'
      ]
    };
    return this.httpClient.get<User[]>(environment.serverUrl + 'users/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getUserById(id: string) {
    return this.httpClient.get<User>(environment.serverUrl + 'users/' + id);
  }

  delete(userId: string): Observable<void> {
    return this.httpClient.delete<void>(environment.serverUrl + `users/${userId}`, {});
  }

  save(id: string, entity: User): Observable<User> {
    if (id) {
      return this.httpClient.put<User>(environment.serverUrl + 'users/' + id, entity);
    } else {
      return this.httpClient.post<User>(environment.serverUrl + 'users', entity);
    }
  }
}
