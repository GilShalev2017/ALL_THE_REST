const { Gitlab } = require('@gitbeaker/node');

const api = new Gitlab({
    host: 'https://' + process.env.CI_SERVER_HOST,
    token: process.env.GITLAB_TOKEN,
});

const projectId = process.env.CI_PROJECT_ID;
const pipelineId = process.env.CI_PIPELINE_ID;
const jobId = process.env.CI_JOB_ID;
const jobUrl = process.env.CI_JOB_URL;
const version = "0.0." + process.env.CI_PIPELINE_IID;
const commitBranch = process.env.CI_COMMIT_BRANCH;

console.log("Creating a release with the following environment variables: ");
console.log('- projectId: ' + projectId);
console.log('- jobId: ' + jobId);
// console.log('- jobUrl: ' + jobUrl);
console.log('- version: ' + version);


let tag = async () => {
    try {
        console.log(`Creating a tag v${version} on projectId: ${projectId} ${commitBranch} branch`)
        res = await api.Tags.create(projectId, {tag_name: 'v' + version, ref: commitBranch});
        // console.log(res);
    } catch(err) {
        if (err.description === '404 Tag Not Found') {
            console.log('Tag not found... creating a new tag')
            try {
                res = await api.Tags.create(projectId, {tag_name: 'v' + version, ref: commitBranch});
            } catch(err) {
                console.log("Tagging error: " + err.description);
            }
        } else {
            console.log("Tagging error: " + err.description);
        }
    }
}

let release = async () => {
    try {
        const jobs = await api.Jobs.showPipelineJobs(projectId, pipelineId);
        const buildJobUrl = jobs[0].web_url;
        const buildJobId = jobs[0].id;
        const documentJobUrl = jobs[1].web_url;
        const documentJobId = jobs[1].id;
        console.log(`Creating a release... Intel® Vision Platform v${version}`)
        let res = await api.Releases.create(projectId, {
            name: `Intel® Vision Platform v${version}`,
            tag_name: 'v' + version,
            description: "Release Notes placeholder",
        });
        console.log(res);

        await api.Jobs.keepArtifacts(projectId, buildJobId);
        await api.Jobs.keepArtifacts(projectId, documentJobId);
        // console.log(res);
    } catch (err) {
        console.log("Release error: " + err.description);
    }
}

async function releaseSequence() {
    await tag();
    await release();
}

releaseSequence();
