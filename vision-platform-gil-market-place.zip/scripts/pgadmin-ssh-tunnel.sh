ssh -i ~/Downloads/aws-mevolve-moshe.pem -L 5433:mevolve-staging.cluster-cmo57r3mhchm.us-west-2.rds.amazonaws.com:5432  ubuntu@ec2-54-202-54-43.us-west-2.compute.amazonaws.com
