ssh -i ~/Downloads/scoe.pem ubuntu@ec2-34-229-64-188.compute-1.amazonaws.com
