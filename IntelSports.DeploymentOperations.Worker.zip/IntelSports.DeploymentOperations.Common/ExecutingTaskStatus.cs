﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Common
{
    public enum StatusOptions
    {
        TaskStarting,
        TaskStarted,
        TaskCompleted,
        TaskCompletedWithError,
        ProcessExited,
        ErrorDataReceived,
        TaskStopped,
        TaskStoppedError,
    }

    public class ExecutingTaskStatus
    {
        public string TaskId { get; set; }
        public string ExecuterId { get; set; }
        public DateTime? StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public StatusOptions Status { get; set; }
        public string StatusString { get; set; }
        public string ErrorData { get; set; }
    }
}
