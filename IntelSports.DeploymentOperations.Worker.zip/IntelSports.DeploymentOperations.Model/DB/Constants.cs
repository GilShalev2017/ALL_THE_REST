﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class Constants
    {
        //COMPLETED TASKS
        public const string COLUMN_COMPLETED_TASK_ID = "Id";
        public const string COLUMN_COMPLETED_TASK_CATEGORY_GROUP = "CategoryGroup";
        public const string COLUMN_COMPLETED_TASK_NAME = "Name";
        public const string COLUMN_COMPLETED_TASK_DESCRIPTION = "Description";
        public const string COLUMN_COMPLETED_TASK_PARAMS = "TaskParameters";
        public const string COLUMN_COMPLETED_TASK_START_DATE_TIME = "StartDateTime";
        public const string COLUMN_COMPLETED_TASK_END_DATE_TIME = "EndDateTime";
        public const string COLUMN_COMPLETED_TASK_STATUS = "Status";
        public const string COLUMN_COMPLETED_TASK_ERROR = "Error";
        public const string COLUMN_COMPLETED_TASK_EXECUTER_NAME = "ExecuterName";
        public const string COLUMN_COMPLETED_TASK_DEPLOYMENT_ID = "DeploymentId";
        public const string COLUMN_COMPLETED_TASK_FD_CONTROLLER_ID = "FdControllerId";
    }
}
