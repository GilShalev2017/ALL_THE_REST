using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class ExecutingTaskData
    {
        public string TaskId { get; set; }
        public string ExecuterId { get; set; }
        public DateTime? StartDateTime { get; set; }
        public string DeploymentId { get; set; }
        public string Data { get; set; }
        public string FlowExecuterId { get; set; }
        public string FlowId { get; set; }
        public bool IsFlinkTask { get; set; }
        public FlinkTaskType FlinkTaskType { get; set; }
        public string ExecuterName { get; set; }
        public string FdControllerId { get; set; }
        public string TaskType { get; set; }
        public string DynamicTaskName { get; set; }
    }
}
