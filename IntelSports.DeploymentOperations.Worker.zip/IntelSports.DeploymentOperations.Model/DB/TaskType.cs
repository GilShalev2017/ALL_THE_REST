﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    //public enum TaskType
    //{
    //    General,
    //    KDSPublisher,
    //    Flink,
    //    DebugKit,
    //    V4V,
    //    KdsInspecting,
    //    MVV,
    //    RendererOutputVideoCreator,
    //}
}
