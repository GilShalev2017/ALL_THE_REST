﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class FdController
    {
        public string Name { get; set; }
        public string ConnectionId { get; set; }
        public string ConnectionStatus { get; set; }
        public string DeploymentId { get; set; }
    }
}
