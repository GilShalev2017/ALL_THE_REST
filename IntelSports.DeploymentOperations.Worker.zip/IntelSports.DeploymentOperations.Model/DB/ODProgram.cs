﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public enum CategoryGroup
    {
        DeploymentConfiguration,
        Validation,
        Publishers,
        Playback,
        Flink,
        Debug,
        None
    }

    //public enum Prerequisite
    //{
    //    AwsCredentials,
    //    AwsCli,
    //    Kubectl,
    //    Java,
    //    DotNet,
    //    Zip,
    //    None,
    //}

    public enum ProgramType
    {
        dotnet,
        java,
        python,
        bashScript,
        golang,
        windowsBatchScript,
        none,
    }

    public class ODProgram
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Package { get; set; }
        public bool IsPackageCompressed { get; set; }
        public string ExecutedProgram { get; set; }
        public string ExecutedProgramParams { get; set; }
        public CategoryGroup CategoryGroup { get; set; }
        public ProgramType ProgramType { get; set; }
        //public List<Prerequisite> Prerequisites { get; set; }
        public string ConfigurationFile { get; set; }
    }
}
