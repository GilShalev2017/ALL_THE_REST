﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public enum CamMode
    {
        Auto,
        Manual
    }
    public enum RunMode
    {
        runPclRender,
        runPcl,
        runRecam
    }
}
