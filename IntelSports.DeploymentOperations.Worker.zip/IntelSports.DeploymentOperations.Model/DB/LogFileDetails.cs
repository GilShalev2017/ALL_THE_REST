﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class LogFileDetails
    {
        public string LogFileName { get; set; }
        public string S3BucketName { get; set; }
        public string S3BucketRegion { get; set; }
        public string S3BaseKey { get; set; }
    }
}
