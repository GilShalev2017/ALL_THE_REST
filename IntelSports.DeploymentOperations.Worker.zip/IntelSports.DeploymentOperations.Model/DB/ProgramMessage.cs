﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class ProgramMessage
    {
        public string DeploymentId { get; set; }
        public string MessageDetails { get; set; }
        public string MessageName { get; set; }
        public string MessageSource { get; set; }
        public string MessageDestination { get; set; }
        public string GameID { get; set; }
        public string PlayID { get; set; }
        public string RunID { get; set; }
        public string ExecuterId { get; set; }
        public string FlowExecuterId { get; set; }
    }
}
