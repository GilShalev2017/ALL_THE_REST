﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class FlowPayload
    {
        public string FlowId { get; set; }
        public string DeploymentId { get; set; }
        public string FlowExecuterId { get; set; }
        public string ExecuterName { get; set; }
        public string FlowTaskParameters { get; set; }
        public string FlowJsonParameters { get; set; }
        //public bool RunWithErros { get; set; }
        //public string GameId { get; set; }
        //public string PlayId { get; set; }
        //public string RunId { get; set; }
    }
}
