﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public enum FlowStatus
    {
        FlowStarting,
        FlowStarted,
        FlowCompleted,
        FlowCompletedWithError,
        FlowStopping,
        FlowStopped,
        FlowStoppedError,
    }
    public class Activity
    {
        public string RunningTaskName { get; set; }
        public TaskStatus RunningTaskStatus { get; set; }
    }

    public class ExecutingFlowStatus
    {
        public string FlowId { get; set; }
        public string GameId { get; set; }
        public string PlayId { get; set; }
        public string RunId { get; set; }
        public string FlowExecuterId { get; set; }
        public string FdControllerId { get; set; }
        public string DeploymentId { get; set; }
        public DateTime? StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public FlowStatus Status { get; set; }
        public string StatusString { get; set; }
        public string ErrorData { get; set; }
        public string ExecuterName { get; set; }
        //public string GameId { get; set; }
        //public string PlayId { get; set; }
        //public string RunId { get; set; }
        public float Progress { get; set; }
        public Activity Activity { get; set; }
    }
}
