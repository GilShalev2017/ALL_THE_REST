﻿using System;
using System.Threading.Tasks;
using IntelSports.DeploymentOperations.AWSCognitoSecurity;
using IntelSports.DeploymentOperations.Model.DB;
using Microsoft.AspNetCore.SignalR.Client;
using System.Threading;

namespace IntelSports.DeploymentOperations.Model
{
    public class TaskExecuterHubClient
    {
        public HubConnection connection = null;
        private SystemProcessTaskExecuter systemProcessTaskExecuter = null;
        private IOpenIdConnect iOpenIdConnect = null;

        //private Action<TaskPayload> onStopTask = null;

        public TaskExecuterHubClient(string url, IOpenIdConnect iOpenIdConnect, SystemProcessTaskExecuter systemProcessTaskExecuter)
        {
            this.iOpenIdConnect = iOpenIdConnect;

            //onStopTask = new Action<TaskPayload>(OnStopTaskHandler);

            connection = new HubConnectionBuilder().WithUrl(url, options =>
            {
                 options.AccessTokenProvider = () => Task.FromResult(this.iOpenIdConnect.GetIdTokenAsync(this.iOpenIdConnect.BasicLoginRequest).Result);
            })
            .Build();


            this.systemProcessTaskExecuter = systemProcessTaskExecuter;

            connection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                Console.WriteLine("Recieved a message: " + message);
            });

            connection.StartAsync();

            //  Register with Server Hub
            //connection.SendAsync("RegisterProgram");
            //connection.SendAsync("RegisterWorker", null);
        }

        //public void OnStopTaskHandler(TaskPayload payload)
        //{
        //    if (!systemProcessTaskExecuter.process.HasExited)
        //    {
        //        systemProcessTaskExecuter.process.Kill();
        //        connection.SendAsync("StopTaskCompleted");
        //        Console.WriteLine("StopTaskCompleted");
        //    }
        //}

        private Task Connection_Closed(Exception arg)
        {
            Console.WriteLine("SystemProcessTaskExecuter: Connection Closed");
            return Task.FromResult("");
            
        }

        public async Task ReportExecutingTaskStatus(ExecutingTaskStatus executingTaskStatus)
        {
            try
            {
                await connection.InvokeAsync("ExecutingTaskStatus", executingTaskStatus);
            }
            catch(Exception xcp)
            {
                Console.WriteLine(xcp.Message);
            }
        }
        public async Task ReportOutputDataReceived(ExecutingTaskData executingTaskData)
        {
            try
            {
                await connection.InvokeAsync("OutputDataReceived", executingTaskData);
            }
            catch (Exception xcp)
            {
                Console.WriteLine(xcp.Message);
            }
        }
        
        public async Task Disconnect()
        {
            await this.connection.StopAsync();
        }
    }
}

//public async Task ReportEvent(string methodName, string message)
//{
//    await connection.InvokeAsync(methodName, message);
//}

//public async Task ReportEvent(string methodName)
//{
//    await connection.InvokeAsync(methodName);
//}