﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.AWSCognitoSecurity
{
    public interface IOpenIdConnect
    {
        public Task<string> GetIdTokenAsync(BasicLoginRequest basicLoginRequest);
        public BasicLoginRequest BasicLoginRequest { get; set; }
    }
}
