﻿using Amazon.CognitoIdentityProvider;
using Amazon.Extensions.CognitoAuthentication;
using System;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.AWSCognitoSecurity
{
    public class AWSCognitoService : IOpenIdConnect
    {
        private BasicLoginRequest basicLoginRequest;
        protected string PoolId { get; set; }
        protected string ApppClientId { get; set; }
        protected AmazonCognitoIdentityProviderClient AmazonCognitoIdentityProviderClient { get; set; }
        protected CognitoUserPool CognitoUserPool { get; set; }
        public BasicLoginRequest BasicLoginRequest { get { return this.basicLoginRequest; } set { this.basicLoginRequest = value; } }

        public AWSCognitoService(string poolId, string appClientId, Amazon.RegionEndpoint region)
        {
            PoolId = poolId;
            ApppClientId = appClientId;
            AmazonCognitoIdentityProviderClient = new AmazonCognitoIdentityProviderClient(new Amazon.Runtime.AnonymousAWSCredentials(), region);
            CognitoUserPool = new CognitoUserPool(poolId, appClientId, AmazonCognitoIdentityProviderClient);         
        }

        public AWSCognitoService(string poolId, string appClientId, Amazon.RegionEndpoint region, BasicLoginRequest basicLoginRequest)
        {
            PoolId = poolId;
            ApppClientId = appClientId;
            AmazonCognitoIdentityProviderClient = new AmazonCognitoIdentityProviderClient(new Amazon.Runtime.AnonymousAWSCredentials(), region);
            CognitoUserPool = new CognitoUserPool(poolId, appClientId, AmazonCognitoIdentityProviderClient);
            this.basicLoginRequest = basicLoginRequest;
        }
        public async Task<string> GetIdTokenAsync(BasicLoginRequest basicLoginRequest)
        {
            CognitoUser user = new CognitoUser(basicLoginRequest.UserName, ApppClientId, CognitoUserPool, AmazonCognitoIdentityProviderClient);
            InitiateSrpAuthRequest authRequest = new InitiateSrpAuthRequest()
            {
                Password = basicLoginRequest.Password
            };

            AuthFlowResponse authResponse = await user.StartWithSrpAuthAsync(authRequest).ConfigureAwait(false);
            if (authResponse.AuthenticationResult == null || string.IsNullOrEmpty(authResponse.AuthenticationResult.AccessToken))
                throw new Exception("Authentication Failed: Retrieveing Access Token from AWS Cognito service has failed.");

            return authResponse.AuthenticationResult.AccessToken;
        }
    }
}
