﻿using System;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using IntelSports.DeploymentOperations.AWS.S3;
using IntelSports.DeploymentOperations.AWSCognitoSecurity;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace IntelSports.DeploymentOperations.Worker
{
    class Program
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static void Main(string[] args)
        {
            try
            {
                AddLog4Net();

                log.Info("fdcontroller - worker application has launched");

                //  Validate Environment Variables
                log.Info("Validating Environment Variables");
                if (!ValidateEnvVariables())
                {
                    log.Info("Environment Variables found to be invalid / missing. Exiting...");
                    return;
                }

                //  Get Deployment JSON
                log.Info("Reading local deployment.json");
                var deploymentJsonFile = JObject.Parse(File.ReadAllText(Environment.GetEnvironmentVariable("DEPLOYMENT_JSON"))); // "/etc/deployment/deployment.json"

                //  Validate Deployment JSON File to make sure that it has all required fields
                log.Info("Validating the deployment.json file");
                if (!ValidateDeploymentJSON(deploymentJsonFile))
                {
                    log.Info("File deployment.json found to be invalid. Exiting...");
                    return;
                }

                //  Set All Application Configurations
                log.Info("Setting Application Configurations");
                var waitForConfigurationsTask = SetConfigurations(deploymentJsonFile);
                waitForConfigurationsTask.Wait();
                                              
                log.Info("WorkerConfig = " + WorkerConfig.GetConfigurationString());
                log.Info("configFile.DeploymentOperationsServerHubURL:" + WorkerConfig.DeploymentOperationsServerHubURL);
                log.Info("configFile.WaitBeforeRetryConnectingInMilliseconds:" + WorkerConfig.WaitBeforeRetryConnectingInMilliseconds);

                //  Create an OpenId Connect Authentication using AWS Cognito Service

                //var cognitoServiceEndPoint = RegionEndpoint.GetBySystemName(WorkerConfig.CognitoRegion);
                //var basicLoginRequest = new BasicLoginRequest() { Password = WorkerConfig.CognitoPassword, UserName = WorkerConfig.CognitoUserName };
                //IOpenIdConnect cognitoSecurityService = new AWSCognitoService(WorkerConfig.CognitoPoolId.ToString(), WorkerConfig.CognitoAppClientId, cognitoServiceEndPoint, basicLoginRequest);

                //    var token1 = cognitoSecurityService.GetIdTokenAsync(cognitoSecurityService.BasicLoginRequest); ;

                //Hard coded 

                var cognitoServiceEndPoint = RegionEndpoint.GetBySystemName(WorkerConfig.CognitoRegion);
                var basicLoginRequest = new BasicLoginRequest() { Password = "TRD34%@sls_0(*&)", UserName = "FDCONTROLLER_WORKER" };
                IOpenIdConnect cognitoSecurityService = new AWSCognitoService("us-east-1_YuSwcvMEa", "4t4035igo154q99ac8s3qf28e1", cognitoServiceEndPoint, basicLoginRequest);

                log.Info("Creating ExecutionManager");
                ExecutionManager executionManager = new ExecutionManager(cognitoSecurityService);
                log.Info("DownloadAllMissingPrograms");
                executionManager.DownloadAllMissingPrograms();

                //executionManager.RunAllTasks(configFile);

                log.Info("Creating WorkerHubClient");
                AutoResetEvent resetEvent = new AutoResetEvent(false);
                WorkerHubClient workerHubClient = new WorkerHubClient(resetEvent, executionManager, cognitoSecurityService);
                var task = workerHubClient.Init();
                task.Wait();


                if (workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    executionManager.SetHubConnection(workerHubClient);

                    log.Info("Docker running. Press any key to stop it.");
                    Console.WriteLine("Docker running. Press any key to stop it.");

                    resetEvent.WaitOne();
                }

                if (workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Disconnected)
                {
                    while (workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Disconnected)
                    {
                        log.Info("Retrying to connect again after waiting " + WorkerConfig.WaitBeforeRetryConnectingInMilliseconds.ToString() + " MilliSeconds...");

                        var delayTask = Task.Delay(WorkerConfig.WaitBeforeRetryConnectingInMilliseconds);
                        delayTask.Wait();

                        var retryTask = workerHubClient.Init();
                        retryTask.Wait();
                        if (workerHubClient.hubConnection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                        {
                            executionManager.SetHubConnection(workerHubClient);

                            log.Info("Docker running.Press any key to stop it.");
                            Console.WriteLine("Docker running. Press any key to stop it.");

                            resetEvent.WaitOne();
                        }

                    }
                }
            }
            catch (Exception exc)
            {
                log.Fatal(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "Main " + exc.Message);
             
                Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "Main " + exc.Message);
                
                Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "StackTrace is " + exc.StackTrace);

                if (exc.InnerException != null)
                {
                    log.Fatal(exc.InnerException.Message);
                    Console.WriteLine(exc.InnerException.Message);
                }
            }
        }

        private static bool ValidateEnvVariables()
        {
            log.Info("Inside ValidateEnvVariables");
            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("APP_CLIENT_ID")))
            {
                Console.WriteLine("APP_CLIENT_ID ENV variable is not set. Exiting");
                log.Error("APP_CLIENT_ID ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("COGNITO_POOL_ID")))
            {
                Console.WriteLine("COGNITO_POOL_ID ENV variable is not set. Exiting");
                log.Error("COGNITO_POOL_ID ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("COGNITO_REGION")))
            {
                Console.WriteLine("COGNITO_REGION ENV variable is not set. Exiting");
                log.Error("COGNITO_REGION ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("COGNITO_PASSWORD")))
            {
                Console.WriteLine("COGNITO_PASSWORD ENV variable is not set. Exiting");
                log.Error("COGNITO_PASSWORD ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("COGNITO_USER_NAME")))
            {
                Console.WriteLine("COGNITO_USER_NAME ENV variable is not set. Exiting");
                log.Error("COGNITO_USER_NAME ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("DEPLOYMENT_JSON")))
            {
                Console.WriteLine("DEPLOYMENT_JSON ENV variable is not set. Exiting");
                log.Error("DEPLOYMENT_JSON ENV variable is not set. Exiting");
                return false;
            }

            return true;
        }

        private static bool ValidateDeploymentJSON(JObject deploymentJsonFile)
        {
            log.Info("Inside ValidateDeploymentJSON");

            //  Get flink_jobmanager
            string flinkJobManagerEndpoint = deploymentJsonFile["compute_clusters"]["fd19_flink"]["flink_jobmanager"].ToString();
            if (string.IsNullOrEmpty(flinkJobManagerEndpoint) || flinkJobManagerEndpoint == "##MISSING##")
            {
                log.Error("flink_jobmanager (compute_clusters->fd19_flink->flink_jobmanager) is missing or not set in deployment.json. Existing...");
                Console.WriteLine("flink_jobmanager (compute_clusters->fd19_flink->flink_jobmanager) is missing or not set in deployment.json. Existing...");
                return false;
            }

            //  Get DynamoDBRegion
            //string dynamoDBRegion = deploymentJsonFile["periodic_metadata"]["region"].ToString();  // Change when it has it's own section in Deployment JSON
            //if (string.IsNullOrEmpty(dynamoDBRegion) || dynamoDBRegion == "##MISSING##")
            //{
            //    log.Error("region (periodic_metadata->region) is missing or not set in deployment.json. Existing...");
            //    Console.WriteLine("region (periodic_metadata->region) is missing or not set in deployment.json. Existing...");
            //    return false;
            //}

            //  Get StaicMetadataBucket
            string staicMetadataBucket = deploymentJsonFile["periodic_metadata"]["s3_bucket_static"].ToString();
            if (string.IsNullOrEmpty(staicMetadataBucket) || staicMetadataBucket == "##MISSING##")
            {
                log.Error("s3_bucket_static (periodic_metadata->s3_bucket_static) is missing or not set in deployment.json. Existing...");
                Console.WriteLine("s3_bucket_static (periodic_metadata->s3_bucket_static) is missing or not set in deployment.json. Existing...");
                return false;
            }

            //  Get StaicMetadataBucketRegion
            string staicMetadataBucketRegion = deploymentJsonFile["periodic_metadata"]["region"].ToString();
            if (string.IsNullOrEmpty(staicMetadataBucketRegion) || staicMetadataBucketRegion == "##MISSING##")
            {
                log.Error("region (periodic_metadata->region) is missing or not set in deployment.json. Existing...");
                Console.WriteLine("region (periodic_metadata->region) is missing or not set in deployment.json. Existing...");
                return false;
            }

            //  Get DeploymentId
            string deploymentId = deploymentJsonFile["deployment_id"].ToString();
            if (string.IsNullOrEmpty(deploymentId) || deploymentId == "##MISSING##")
            {
                log.Error("deployment_id is missing or not set in deployment.json. Existing...");
                Console.WriteLine("deployment_id is missing or not set in deployment.json. Existing...");
                return false;
            }

            //  Get Deployment Region
            string deploymentRegion = deploymentJsonFile["region"].ToString();
            if (string.IsNullOrEmpty(deploymentRegion) || deploymentRegion == "##MISSING##")
            {
                log.Error("region is missing or not set in deployment.json. Existing...");
                Console.WriteLine("region is missing or not set in deployment.json. Existing...");
                return false;
            }

            try
            {
                //if (deploymentJsonFile["mq"] != null)
                {
                    //  Get play_status_queue
                    string play_status_queue = deploymentJsonFile["mq"]["cvt"]["play_status_queue"].ToString();
                    if (string.IsNullOrEmpty(play_status_queue) || play_status_queue == "##MISSING##")
                    {
                        log.Error("play_status_queue is missing or not set in deployment.json. Existing...");
                        Console.WriteLine("play_status_queue is missing or not set in deployment.json. Existing...");
                        return false;
                    }

                    //  Get play_status_queue
                    string play_status_topic = deploymentJsonFile["mq"]["cvt"]["play_status_topic"].ToString();
                    if (string.IsNullOrEmpty(play_status_topic) || play_status_topic == "##MISSING##")
                    {
                        log.Error("play_status_topic is missing or not set in deployment.json. Existing...");
                        Console.WriteLine("play_status_topic is missing or not set in deployment.json. Existing...");
                        return false;
                    }

                    //  Get mq_auth
                    string mq_auth = deploymentJsonFile["mq"]["cvt"]["mq_auth"].ToString();
                    if (string.IsNullOrEmpty(mq_auth) || mq_auth == "##MISSING##")
                    {
                        log.Error("mq_auth is missing or not set in deployment.json. Existing...");
                        Console.WriteLine("mq_auth is missing or not set in deployment.json. Existing...");
                        return false;
                    }
                }
            }
            catch(Exception xcp)
            {
                log.Error("Getting Broker Data" + xcp);
            }

            return true;
        }


        static void AddLog4Net()
        {
            XmlDocument log4netConfig = new XmlDocument();
            log4netConfig.Load(File.OpenRead("log4net.config"));
            var repo = log4net.LogManager.CreateRepository(Assembly.GetEntryAssembly(),
                       typeof(log4net.Repository.Hierarchy.Hierarchy));
            log4net.Config.XmlConfigurator.Configure(repo, log4netConfig["log4net"]);
        }

        private static void SetConfigurationsFromEnvVariables()
        {
            log.Info("Inside SetConfigurationsFromEnvVariables");

            WorkerConfig.CognitoPoolId = Environment.GetEnvironmentVariable("COGNITO_POOL_ID");
            WorkerConfig.CognitoRegion = Environment.GetEnvironmentVariable("COGNITO_REGION");
            WorkerConfig.CognitoUserName = Environment.GetEnvironmentVariable("COGNITO_USER_NAME");
            WorkerConfig.CognitoPassword = Environment.GetEnvironmentVariable("COGNITO_PASSWORD");
            WorkerConfig.CognitoAppClientId = Environment.GetEnvironmentVariable("APP_CLIENT_ID");
        }
        private static void SetConfigurationsFromDeploymentJSON(JObject deploymentJsonFile)
        {
            log.Info("Inside SetConfigurationsFromDeploymentJSON");

            WorkerConfig.FlinkJobManagerEndpoint = deploymentJsonFile["compute_clusters"]["fd19_flink"]["flink_jobmanager"].ToString();   
           //WorkerConfig.DynamoDBRegion = deploymentJsonFile["periodic_metadata"]["region"].ToString();  // Change when it has it's own section in Deployment JSON
            WorkerConfig.StaicMetadataBucket = deploymentJsonFile["periodic_metadata"]["s3_bucket_static"].ToString();
            WorkerConfig.StaicMetadataBucketRegion = deploymentJsonFile["periodic_metadata"]["region"].ToString();
            WorkerConfig.DeploymentId = deploymentJsonFile["deployment_id"].ToString();
            WorkerConfig.DeploymentRegion = deploymentJsonFile["region"].ToString();

            WorkerConfig.PlayStatusQueue = string.Format("tee_control.sports.intel.com/{0}/cvt-requests", WorkerConfig.DeploymentId);
            WorkerConfig.PlayStatusTopic = string.Format("tee_control.sports.intel.com/{0}/cvt", WorkerConfig.DeploymentId);

            //try
            //{
            //    if (deploymentJsonFile["mq"] != null)
            //    {
            //        log.Info("Found mq node in deployment.json");

            //        WorkerConfig.PlayStatusQueue = deploymentJsonFile["mq"]["cvt"]["play_status_queue"].ToString();
            //        WorkerConfig.PlayStatusQueue = WorkerConfig.PlayStatusQueue.Replace(@"/queue/","");
            //        WorkerConfig.PlayStatusTopic = deploymentJsonFile["mq"]["cvt"]["play_status_topic"].ToString();
            //        WorkerConfig.PlayStatusTopic = WorkerConfig.PlayStatusTopic.Replace(@"/topic/", "");
            //        WorkerConfig.MqAuth = deploymentJsonFile["mq"]["cvt"]["mq_auth"].ToString();

            //        log.Info("Found PlayStatusQueue = " + WorkerConfig.PlayStatusQueue);
            //        log.Info("Found PlayStatusTopic = " + WorkerConfig.PlayStatusTopic);
            //        log.Info("Found MqAuth = " + WorkerConfig.MqAuth);
            //    }
            //    else
            //    {
            //        log.Info("mq node wasn't found in deployment.json");

            //        WorkerConfig.PlayStatusQueue = string.Format("tee_control.sports.intel.com/{0}/cvt-requests", WorkerConfig.DeploymentId);
            //        WorkerConfig.PlayStatusTopic = string.Format("tee_control.sports.intel.com/{0}/cvt", WorkerConfig.DeploymentId);
            //        WorkerConfig.MqAuth = "https://mq-auth-int.tee.sports.intel.com/token";
            //    }
            //}
            //catch(Exception xcp)
            //{
            //    log.Error("Exception Inside SetConfigurationsFromDeploymentJSON" + xcp);

            //    log.Error("Configuring with hard-coded values");

            //    WorkerConfig.PlayStatusQueue = string.Format("/queue/tee_control.sports.intel.com/{0}/cvt-requests", WorkerConfig.DeploymentId);
            //    WorkerConfig.PlayStatusTopic = string.Format("/topic/tee_control.sports.intel.com/{0}/cvt", WorkerConfig.DeploymentId);
            //    WorkerConfig.MqAuth = "https://mq-auth-int.tee.sports.intel.com/token";
            //}
        }

        private static async Task SetConfigurationsFromWorkerConfigFile(JObject deploymentJsonFile)
        {
            log.Info("Inside SetConfigurationsFromWorkerConfigFile");

            var keyName = "FDController/fdcontroller-worker.json";
          
            IIntelSportsS3Client s3Client = new IntelSportsS3Client(WorkerConfig.StaicMetadataBucketRegion);

            log.Info("Trying to read fdcontroller-worker.json from static bucket");
            var workerConfigFile = await s3Client.GetS3JSONFileAsJObject(deploymentJsonFile["periodic_metadata"]["s3_bucket_static"].ToString(), keyName);
            log.Info("Read successfully fdcontroller-worker.json from static bucket");

            WorkerConfig.DeploymentOperationsServerHubURL = workerConfigFile["DeploymentOperationsServerHubURL"].ToString();
            int.TryParse(workerConfigFile["WaitBeforeRetryConnectingInMilliseconds"].ToString(), out int result);
            if (result == 0)
                result = 3000;
            WorkerConfig.WaitBeforeRetryConnectingInMilliseconds = result;

            WorkerConfig.S3BucketForUploadDownloadPrograms = workerConfigFile["S3BucketForUploadDownloadPrograms"].ToString();
            WorkerConfig.S3BucketRegionForUploadDownloadPrograms = workerConfigFile["S3BucketRegionForUploadDownloadPrograms"].ToString();
           
            WorkerConfig.DynamoDBRegion = WorkerConfig.S3BucketRegionForUploadDownloadPrograms;

            WorkerConfig.ProgramsTableName = workerConfigFile["ProgramsTableName"].ToString();
            WorkerConfig.TasksTableName = workerConfigFile["TasksTableName"].ToString();
            WorkerConfig.FlowsTableName = workerConfigFile["FlowsTableName"].ToString();
            WorkerConfig.CompletedTasksTableName = workerConfigFile["CompletedTasksTableName"].ToString();
        }
        private static async Task SetConfigurations(JObject deploymentJsonFile)
        {
            log.Info("Inside SetConfigurations");

            try
            {               
                // Set Configurations from Deployment JSON
                SetConfigurationsFromDeploymentJSON(deploymentJsonFile);

                // Set Configurations from FD Controller Worker's Configuration file  - S3 Static Metadata Bucket
                await SetConfigurationsFromWorkerConfigFile(deploymentJsonFile);

                //  Set Configurations from Env Variables
                SetConfigurationsFromEnvVariables();
               
            }
            catch (AmazonS3Exception e)
            {
                // If bucket or object does not exist
                Console.WriteLine("Error encountered ***. Message:'{0}' when reading object", e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Unknown encountered on server. Message:'{0}' when reading object", e.Message);
            }
        }       
        
    }
}
