﻿using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.S3;
using Amazon.S3.Transfer;
using Aws4RequestSigner;
using IntelSports.DeploymentOperations.AWS.S3;
using IntelSports.DeploymentOperations.AWSCognitoSecurity;
using IntelSports.DeploymentOperations.Model;
using IntelSports.DeploymentOperations.Model.DB;
using Microsoft.AspNetCore.SignalR.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using TaskStatus = IntelSports.DeploymentOperations.Model.DB.TaskStatus;

namespace IntelSports.DeploymentOperations.Worker
{
    public class ExecutionManager
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static List<ODProgram> _odPrograms;
        private static List<ODTask> _odTasks;
        private static List<ODFlow> _odFlows;
        private static Dictionary<string, ODTask> _odTasksById;
        private static Dictionary<string, ODProgram> _odProgramsById;
        private static Dictionary<string, ODFlow> _odFlowsById;
        private static string _installationDirectory = "/app/ODProgramsFolder";

        private Dictionary<string, ITaskExecuter> _executers = new Dictionary<string, ITaskExecuter>();
        private Dictionary<string, ITaskExecuter> _flinkExecuters = new Dictionary<string, ITaskExecuter>();
        private Dictionary<string, Dictionary<string, ITaskExecuter>> _flowExecuters = new Dictionary<string, Dictionary<string, ITaskExecuter>>();
        private WorkerHubClient _workerHubClient;

        private ExecutingFlowStatus _currentExecutingFlowStatus;
        private static object _syncObj = new object();
        private IOpenIdConnect iOpenIdConnect = null;
        private static string v4vPodName = string.Empty;

        public static TransferUtility _fileTransferUtility;

        public static string _waitForFlinkToStopExecuterID;
        private string _waitForFlinkToStopFlowExecuterID;
        public bool _shouldStopWaitingTask;

        private string _flowGameId;
        private string _flowRunId;
        private string _flowPlayId;

        static ExecutionManager()
        {
            log.Info("Inside static ExecutionManager construcotr");

            CreateDestinationDirectories();

            CreateS3ProgramInnerFolders();
        }
        public ExecutionManager(IOpenIdConnect iOpenIdConnect)
        {
            this.iOpenIdConnect = iOpenIdConnect;

            _fileTransferUtility = new TransferUtility(new AmazonS3Client(RegionEndpoint.GetBySystemName(WorkerConfig.S3BucketRegionForUploadDownloadPrograms)));

            RefreshODCollections();

            var t1 = Task.Run(() => SetKubernetesAccess());

            t1.Wait();

            var t2 = Task.Run(() => RunGetFlinkJobsTask());

            t2.Wait();
        }
        public void SetHubConnection(WorkerHubClient workerHubClient)
        {
            _workerHubClient = workerHubClient;
        }
        private static void CreateS3ProgramInnerFolders()
        {
            log.Info("Inside CreateS3ProgramInnerFolders");

            //In case inner folder exist - it'll stay as it with its content, if not it will be created
            IIntelSportsS3Client s3Client = new IntelSportsS3Client(WorkerConfig.S3BucketRegionForUploadDownloadPrograms);

            foreach (string categoryName in Enum.GetNames(typeof(CategoryGroup)))
            {
                var folderName = categoryName + @"/";
                s3Client.CreateS3Folder(WorkerConfig.S3BucketForUploadDownloadPrograms, folderName);
            }

            //The exception is Flink/FlinkJars that isn't part of the CategoryGroup enum
            s3Client.CreateS3Folder(WorkerConfig.S3BucketForUploadDownloadPrograms, "Flink/FlinkJars/");
        }
        private static void CreateDestinationDirectories()
        {
            log.Info("Inside CreateDestinationDirectories");

            if (!Directory.Exists(_installationDirectory))
            {
                Directory.CreateDirectory(_installationDirectory);
            }

            foreach (string categoryName in Enum.GetNames(typeof(CategoryGroup)))
            {
                var destinationDirectory = string.Format("{0}/{1}", _installationDirectory, categoryName);

                if (!Directory.Exists(destinationDirectory))
                {
                    Directory.CreateDirectory(destinationDirectory);
                }
            }
        }
        public void RefreshODCollections()
        {
            log.Info("Inside RefreshODCollections");

            try
            {
                //TODO in deployment - AwsAccessKeyId +  AwsSecretAccessKey are probably redundant
                var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(WorkerConfig.DynamoDBRegion));

                _odPrograms = GetProgramList(dynamoDbClient);
                _odTasks = GetTaskList(dynamoDbClient);
                _odFlows = GetFlowList(dynamoDbClient);

                _odTasksById = _odTasks.ToDictionary(x => x.Id, x => x);
                _odProgramsById = _odPrograms.ToDictionary(x => x.Id, x => x);
                _odFlowsById = _odFlows.ToDictionary(x => x.Id, x => x);
            }
            catch (Exception xcp)
            {
                log.Fatal(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "RefreshODCollections " + xcp.Message);
                Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "RefreshODCollections " + xcp.Message);
            }
        }
        public static List<ODTask> GetTaskList(AmazonDynamoDBClient dynamoDbClient)
        {
            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = WorkerConfig.TasksTableName
            };

            result = dynamoDbClient.ScanAsync(req).Result;

            List<ODTask> list = new List<ODTask>();

            foreach (var item in result.Items)
            {
                ODTask task = new ODTask
                {
                    Id = item[Constants.COLUMN_TASK_ID].S,
                    Name = item[Constants.COLUMN_TASK_NAME].S,
                    ODProgramId = item[Constants.COLUMN_TASK_PROGRAM_ID].S,
                    ODProgramName = item[Constants.COLUMN_TASK_PROGRAM_NAME].S,
                };

                if (item.ContainsKey(Constants.COLUMN_TASK_DESCRIPTION))
                {
                    task.Description = item[Constants.COLUMN_TASK_DESCRIPTION].S;
                }

                if (item.ContainsKey(Constants.COLUMN_TASK_CATEGORY_GROUP))
                {
                    task.CategoryGroup = item[Constants.COLUMN_TASK_CATEGORY_GROUP].S;
                }

                if (item.ContainsKey(Constants.COLUMN_TASK_PARAMS))
                {
                    task.TaskParameters = item[Constants.COLUMN_TASK_PARAMS].S;
                }

                if (item.ContainsKey(Constants.COLUMN_WORKING_DIRECTORY))
                {
                    task.WorkingDirectory = item[Constants.COLUMN_WORKING_DIRECTORY].S;
                }

                task.ReportStandardOutput = item[Constants.COLUMN_REPORT_STDOUT].S.ToLower() == "true" ? true : false;

                list.Add(task);
            }

            return list;
        }
        public static List<ODProgram> GetProgramList(AmazonDynamoDBClient dynamoDbClient)
        {
            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = WorkerConfig.ProgramsTableName
            };

            result = dynamoDbClient.ScanAsync(req).Result;

            List<ODProgram> list = new List<ODProgram>();

            foreach (var item in result.Items)
            {
                ODProgram odp = new ODProgram
                {
                    Id = item[Constants.COLUMN_PROGRAM_ID].S,
                    Name = item[Constants.COLUMN_PROGRAM_NAME].S,
                    Description = item[Constants.COLUMN_PROGRAM_DESCRIPTION].S,
                    Package = item[Constants.COLUMN_PROGRAM_PACKAGE].S,
                    ExecutedProgram = item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM].S,
                    ExecutedProgramParams = item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS].S,
                };

                if (item.ContainsKey(Constants.COLUMN_PROGRAM_CONFIG_FILE))
                {
                    var configurationFile = item[Constants.COLUMN_PROGRAM_CONFIG_FILE].S;
                    odp.ConfigurationFile = configurationFile;
                }

                if (bool.TryParse(item[Constants.COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED].S, out bool parsedIsCompressed))
                {
                    odp.IsPackageCompressed = parsedIsCompressed;
                }

                if (Enum.TryParse(item[Constants.COLUMN_PROGRAM_CATEGORY_GROUP].S, out CategoryGroup parsedCategoryGroup))
                {
                    odp.CategoryGroup = parsedCategoryGroup;
                }

                list.Add(odp);
            }

            return list;
        }
        public static List<ODFlow> GetFlowList(AmazonDynamoDBClient dynamoDbClient)
        {
            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = WorkerConfig.FlowsTableName
            };

            result = dynamoDbClient.ScanAsync(req).Result;

            List<ODFlow> list = new List<ODFlow>();

            foreach (var item in result.Items)
            {
                ODFlow flow = new ODFlow
                {
                    Id = item[Constants.COLUMN_FLOW_ID].S,
                    Name = item[Constants.COLUMN_FLOW_NAME].S,
                    RunInParallel = item[Constants.COLUMN_RUN_IN_PARALLEL].S,
                };

                if (item.ContainsKey(Constants.COLUMN_FLOW_DESCRIPTION))
                {
                    flow.Description = item[Constants.COLUMN_FLOW_DESCRIPTION].S;
                }

                var jsonTasks = item[Constants.COLUMN_FLOW_TASKS].S;
                var tasks = JsonConvert.DeserializeObject<List<ODTask>>(jsonTasks);
                flow.Tasks = tasks;

                list.Add(flow);
            }

            return list;
        }
        public void DownloadAllMissingPrograms()
        {
            log.Info("Inside DownloadAllMissingPrograms");

            if (_odPrograms == null)
                return;

            foreach (var program in _odPrograms)
            {
                if (IsProgramMissing(program))
                {
                    try
                    {
                        DownloadProgram(program);

                        if (program.IsPackageCompressed)
                        {
                            UncompressPackage(program);
                        }
                    }
                    catch (Exception xcp)
                    {
                        log.Error(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadAllMissingPrograms" + xcp.Message);
                        Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadAllMissingPrograms" + xcp.Message);
                    }
                }
            }
        }
        private void UncompressPackage(ODProgram program)
        {
            log.Info("Inside UncompressPackage - for program: " + program.Name + " with package: " + program.Package);

            string sourceArchiveFileName = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, program.CategoryGroup, program.Name, program.Package);

            string destinationDirectoryName = string.Format("{0}/{1}/{2}", _installationDirectory, program.CategoryGroup, program.Name);

            ZipFile.ExtractToDirectory(sourceArchiveFileName, destinationDirectoryName);
        }
        private void DownloadProgram(ODProgram program)
        {
            log.Info("Inside DownloadProgram - for program: " + program.Name + " with package: " + program.Package);

            try
            {
                var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, program.CategoryGroup, program.Name, program.Package);

                var destinationDirectory = string.Format("{0}/{1}/{2}", _installationDirectory, program.CategoryGroup, program.Name);

                if (!Directory.Exists(destinationDirectory))
                {
                    Directory.CreateDirectory(destinationDirectory);
                }

                var s3FileKey = string.Format("{0}/{1}/{2}", program.CategoryGroup, program.Name, program.Package);

                _fileTransferUtility.Download(filePath, WorkerConfig.S3BucketForUploadDownloadPrograms, s3FileKey);
            }
            catch (Exception xcp)
            {
                log.Error(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadProgram" + xcp);
                Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadProgram" + xcp);
            }
        }
        private void DownloadDebugKitProgramAndUncompress()
        {
            log.Info("Inside DownloadDebugKitProgramAndUncompress");

            try
            {
                var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.DEBUG, Constants.DEBUG_KIT_TASKS, Constants.DEBUG_KIT_TASKS_ZIP);

                var destinationDirectory = string.Format("{0}/{1}/{2}", _installationDirectory, Constants.DEBUG, Constants.DEBUG_KIT_TASKS);

                if (!Directory.Exists(destinationDirectory))
                {
                    Directory.CreateDirectory(destinationDirectory);
                }
                else
                {
                    return; //if FlinkApp exists
                }

                var s3FileKey = string.Format("{0}/{1}/{2}", Constants.DEBUG, Constants.DEBUG_KIT_TASKS, Constants.DEBUG_KIT_TASKS_ZIP);

                _fileTransferUtility.Download(filePath, WorkerConfig.S3BucketForUploadDownloadPrograms, s3FileKey);

                string sourceArchiveFileName = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.DEBUG, Constants.DEBUG_KIT_TASKS, Constants.DEBUG_KIT_TASKS_ZIP);

                string destinationDirectoryName = string.Format("{0}/{1}/{2}", _installationDirectory, Constants.DEBUG, Constants.DEBUG_KIT_TASKS);

                ZipFile.ExtractToDirectory(sourceArchiveFileName, destinationDirectoryName);

                //Copy upload.sh to /mnt/lustre
                var uploadFilePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.DEBUG, Constants.DEBUG_KIT_TASKS, "upload.sh");

                File.Copy(uploadFilePath, "/mnt/lustre/upload.sh");
            }
            catch (Exception xcp)
            {
                log.Error(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadDebugKitProgramAndUncompress" + xcp);
            }
        }
        private void DownloadPublisherProgramAndUncompress()
        {
            log.Info("Inside DownloadPublisherProgramAndUncompress");

            try
            {
                var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.PUBLISHERS, Constants.KDS_PUBLISHER_TASKS, Constants.KDS_PUBLISHER_TASKS_ZIP);

                var destinationDirectory = string.Format("{0}/{1}/{2}", _installationDirectory, Constants.PUBLISHERS, Constants.KDS_PUBLISHER_TASKS);

                if (!Directory.Exists(destinationDirectory))
                {
                    Directory.CreateDirectory(destinationDirectory);
                }
                else
                {
                    return; //if FlinkApp exists
                }

                var s3FileKey = string.Format("{0}/{1}/{2}", Constants.PUBLISHERS, Constants.KDS_PUBLISHER_TASKS, Constants.KDS_PUBLISHER_TASKS_ZIP);

                _fileTransferUtility.Download(filePath, WorkerConfig.S3BucketForUploadDownloadPrograms, s3FileKey);

                string sourceArchiveFileName = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.PUBLISHERS, Constants.KDS_PUBLISHER_TASKS, Constants.KDS_PUBLISHER_TASKS_ZIP);

                string destinationDirectoryName = string.Format("{0}/{1}/{2}", _installationDirectory, Constants.PUBLISHERS, Constants.KDS_PUBLISHER_TASKS);

                ZipFile.ExtractToDirectory(sourceArchiveFileName, destinationDirectoryName);
            }
            catch (Exception xcp)
            {
                log.Error(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadPublisherProgramAndUncompress" + xcp);
            }
        }
        public void DownloadFlinkProgramAndUncompress()
        {
            log.Info("Inside DownloadFlinkProgramAndUncompress");

            try
            {
                var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.FLINK, Constants.FLINK_TASKS, Constants.FLINK_TASKS_ZIP);

                var destinationDirectory = string.Format("{0}/{1}/{2}", _installationDirectory, Constants.FLINK, Constants.FLINK_TASKS);

                if (!Directory.Exists(destinationDirectory))
                {
                    Directory.CreateDirectory(destinationDirectory);
                }
                else
                {
                    return; //if FlinkApp exists
                }

                var s3FileKey = string.Format("{0}/{1}/{2}", Constants.FLINK, Constants.FLINK_TASKS, Constants.FLINK_TASKS_ZIP);

                _fileTransferUtility.Download(filePath, WorkerConfig.S3BucketForUploadDownloadPrograms, s3FileKey);

                string sourceArchiveFileName = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.FLINK, Constants.FLINK_TASKS, Constants.FLINK_TASKS_ZIP);

                string destinationDirectoryName = string.Format("{0}/{1}/{2}", _installationDirectory, Constants.FLINK, Constants.FLINK_TASKS);

                ZipFile.ExtractToDirectory(sourceArchiveFileName, destinationDirectoryName);
            }
            catch (Exception xcp)
            {
                log.Error(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadFlinkProgramAndUncompress" + xcp);
                Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "DownloadFlinkProgramAndUncompress" + xcp);
            }
        }
        public bool IsProgramMissing(ODProgram program)
        {
            var destinationFolder = string.Format("{0}/{1}/{2}", _installationDirectory, program.CategoryGroup, program.Name);

            //TODO complete: need to find if application/script is there too
            if (!Directory.Exists(destinationFolder))
                return true;

            return false;
        }
        private ODTask PrepareTaskToRun(string taskId, bool areParametersOverriden, string overridingParameters)
        {
            log.Info("Inside PrepareTaskToRun - for taskId: " + taskId);

            if (!_odTasksById.ContainsKey(taskId))
            {
                RefreshODCollections();
            }

            var odTask = _odTasksById[taskId];

            if (odTask != null)
            {
                var odProgram = _odProgramsById[odTask.ODProgramId];
                if (odProgram == null)
                    return null;

                //Download program if it doesn't exist
                if (IsProgramMissing(odProgram))
                {
                    //ReportPackageStatus(executerId, "Downloading program to fdController docker");

                    DownloadProgram(odProgram);

                    if (odProgram.IsPackageCompressed)
                    {
                        //ReportPackageStatus(executerId, "Uncompressing the program package");

                        UncompressPackage(odProgram);
                    }
                }

                //C:\Program Files\dotnet\dotnet.exe
                //C:\NotInUseTatsProjects\DemoApp\bin\Debug\netcoreapp2.2\DemoApp.dll 2000 3000 30
                //odTask.ProgramParameters = "DemoApp.dll 2000 3000 30";

                var programParameters = odProgram.ExecutedProgramParams;

                if (!string.IsNullOrEmpty(odTask.TaskParameters))
                {
                    if (areParametersOverriden)
                    {
                        programParameters = programParameters + " " + overridingParameters;
                    }
                    else
                    {
                        programParameters = programParameters + " " + odTask.TaskParameters;
                    }
                }

                var appFolderPath = string.Format(@"{0}/{1}/{2}/", _installationDirectory, odProgram.CategoryGroup, odProgram.Name);

                //Pay attention to the needed whitespace between the ExecutedProgramParams & TaskParameters
                //var appFullPath = string.Format(@"{0}{1} {2}", appFolderPath, odProgram.ExecutedProgramParams, odTask.TaskParameters);

                odTask.ProgramToExecute = odProgram.ExecutedProgram;

                odTask.WorkingDirectory = appFolderPath;

                var os = Environment.OSVersion;
                if (os.Platform == PlatformID.Win32NT)
                {
                    odTask.WorkingDirectory = @"C:/" + odTask.WorkingDirectory;
                }

                // option 1 - full path
                //odTask.ProgramParameters = appFullPath;

                // option 2 - relative path + WorkingDirectory
                odTask.ProgramParameters = programParameters;

                log.Info("Exiting PrepareTaskToRun - for taskId: " + taskId);

                return odTask;
            }

            log.Info(string.Format("Inside PrepareTaskToRun - for taskId: {0}. Task Wasn't found", taskId));

            return null;
        }
        private string ReplaceSystemArguments(string originalParameters, string executerId, string deploymentId, string gameId, string s3ConfigBucket, string s3ConfigBucketRegion, string flowExecuterId)
        {
            string before = originalParameters;

            log.Info(string.Format("Received: originalParameters={0}, executerId={1}, deploymentId={2}, gameId={3}, s3ConfigBucket={4}, s3ConfigBucketRegion={5}, flowExecuterId={6}"
                , originalParameters, executerId, deploymentId, gameId, s3ConfigBucket, s3ConfigBucketRegion, flowExecuterId));

            if (originalParameters.Contains("$executerId"))
            {
                originalParameters = originalParameters.Replace("$executerId", executerId);
            }

            if (originalParameters.Contains("$programsBucketRegion"))
            {
                originalParameters = originalParameters.Replace("$programsBucketRegion", WorkerConfig.S3BucketRegionForUploadDownloadPrograms);
            }

            if (originalParameters.Contains("$programsBucket"))
            {
                originalParameters = originalParameters.Replace("$programsBucket", WorkerConfig.S3BucketForUploadDownloadPrograms);
            }

            if (originalParameters.Contains("$deploymentId"))
            {
                originalParameters = originalParameters.Replace("$deploymentId", deploymentId);
            }

            if (originalParameters.Contains("$gameId"))
            {
                originalParameters = originalParameters.Replace("$gameId", gameId);
            }

            if (originalParameters.Contains("$s3ConfigBucketRegion"))
            {
                originalParameters = originalParameters.Replace("$s3ConfigBucketRegion", s3ConfigBucketRegion);
            }

            if (originalParameters.Contains("$s3ConfigBucket"))
            {
                originalParameters = originalParameters.Replace("$s3ConfigBucket", s3ConfigBucket);
            }

            if (originalParameters.Contains("$flinkJobManagerEndpoint"))
            {
                originalParameters = originalParameters.Replace("$flinkJobManagerEndpoint", WorkerConfig.FlinkJobManagerEndpoint);
            }

            if (originalParameters.Contains("$flowExecuterID") && !string.IsNullOrEmpty(flowExecuterId))
            {
                originalParameters = originalParameters.Replace("$flowExecuterID", flowExecuterId);
            }

            if (originalParameters.Contains("$playStatusQueue") && !string.IsNullOrEmpty(WorkerConfig.PlayStatusQueue))
            {
                WorkerConfig.PlayStatusQueue = WorkerConfig.PlayStatusQueue.Replace("/queue","");
                originalParameters = originalParameters.Replace("$playStatusQueue", WorkerConfig.PlayStatusQueue);
            }

            if (originalParameters.Contains("$playStatusTopic") && !string.IsNullOrEmpty(WorkerConfig.PlayStatusTopic))
            {
                originalParameters = originalParameters.Replace("$playStatusTopic", WorkerConfig.PlayStatusTopic);
            }

            if (originalParameters.Contains("$mqUserName") && !string.IsNullOrEmpty(WorkerConfig.BrokerData.mq_username))
            {
                originalParameters = originalParameters.Replace("$mqUserName", WorkerConfig.BrokerData.mq_username);
            }
            if (originalParameters.Contains("$mqPassword") && !string.IsNullOrEmpty(WorkerConfig.BrokerData.mq_password))
            {
                originalParameters = originalParameters.Replace("$mqPassword", WorkerConfig.BrokerData.mq_password);
            }
            if (originalParameters.Contains("$mqStompUrl") && !string.IsNullOrEmpty(WorkerConfig.BrokerData.mq_stomp_url))
            {
                originalParameters = originalParameters.Replace("$mqStompUrl", WorkerConfig.BrokerData.mq_stomp_url);
            }
            if (originalParameters.Contains("$mqOpenwireUrl") && !string.IsNullOrEmpty(WorkerConfig.BrokerData.mq_openwire_url))
            {
                originalParameters = originalParameters.Replace("$mqOpenwireUrl", WorkerConfig.BrokerData.mq_openwire_url);
            }
            if (originalParameters.Contains("$mqWssUrl") && !string.IsNullOrEmpty(WorkerConfig.BrokerData.mq_wss_url))
            {
                originalParameters = originalParameters.Replace("$mqWssUrl", WorkerConfig.BrokerData.mq_wss_url);
            }

            log.Info(string.Format("After replacement: before (originalParameters)={0}, after={1}", before, originalParameters));

            return originalParameters;
        }
        public Task<ExecutingTaskStatus> RunTask(TaskPayload payload, string serverHubURL)
        {
            log.Info("Inside RunTask\n TaskPayload values are:\n");

            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(payload))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(payload);
                log.Info(string.Format("{0}={1}", name, value));
            }

            if (payload.TaskType == "KDSPublisher")
            {
                return RunKDSPublisherTask(payload, serverHubURL);
            }
            else if (payload.TaskType == "DebugKit")
            {
                return RunDebugKit(payload, serverHubURL);
            }
            else if (payload.TaskType == "V4V")
            {
                return RunV4V(payload, serverHubURL);
            }
            else if (payload.TaskType == "PrepareDeployment")
            {
                return RunPrepareDeployment(payload, serverHubURL);
            }

            var executerId = Guid.NewGuid().ToString();

            ODTask task = PrepareTaskToRun(payload.TaskId, payload.AreParametersOverriden, payload.OverridingParameters);

            if (payload.TaskType == "MVV")//TODO check if we can add the DynamicParameters for all the other tasks
            {
                //TODO address the version of python to execute!
                task.ProgramToExecute = "python3";
                task.ProgramParameters = task.ProgramParameters + " " + payload.DynamicParameters;
            }
            else
            {
                if (!string.IsNullOrEmpty(payload.DynamicParameters))
                {
                    task.ProgramParameters = task.ProgramParameters + " " + payload.DynamicParameters;
                }
            }

            //Convert task / program System arguments
            task.ProgramParameters = ReplaceSystemArguments(task.ProgramParameters, executerId, payload.DeploymentId, payload.GameId, WorkerConfig.StaicMetadataBucket, WorkerConfig.StaicMetadataBucketRegion, payload.FlowExecuterId);

            if (payload.RunAsPartOfAFlow && payload.TaskId == "7d0e6dc9-d2a0-4b86-a7cf-6b9b5ff9d8fb" && _shouldStopWaitingTask) //'Wait for clip creation to finish' task
            {
                task.ProgramParameters = task.ProgramParameters + " " + "exit";
            }

            log.Info(string.Format("Worker Received 'RunTask' for taskId: {0}, task name: {1}, by user {1}", payload.TaskId, task.Name, payload.ExecuterName));

            ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(serverHubURL, this.iOpenIdConnect, payload, executerId,
                                                                       WorkerConfig.CompletedTasksTableName, WorkerConfig.DynamoDBRegion, WorkerConfig.FdControllerName,
                                                                       task.Name, task.Description, task.CategoryGroup, task.TaskParameters);

            if (payload.RunAsPartOfAFlow)
            {
                lock (_syncObj)
                {
                    if (_flowExecuters.ContainsKey(payload.FlowExecuterId))
                    {
                        var executersDic = _flowExecuters[payload.FlowExecuterId];

                        executersDic.Add(executerId, taskExecuter);
                    }
                    else
                    {
                        var executersDic = new Dictionary<string, ITaskExecuter>
                        {
                            { executerId, taskExecuter }
                        };

                        _flowExecuters.Add(payload.FlowExecuterId, executersDic);
                    }
                }
            }
            else
            {
                _executers.Add(executerId, taskExecuter);
            }

            log.Info(string.Format("Before launching task id: {0}, with executer id: {1}, with executer name: {2}", payload.TaskId, executerId, payload.ExecuterName));

            Task<ExecutingTaskStatus> result = taskExecuter.ExecuteTask(task);

            log.Info(string.Format("Worker launched task id: {0} with executer id: {1}, with executer name: {2} successfully", payload.TaskId, executerId, payload.ExecuterName));

            return result;
        }
        public async void StopTask(string executerId)
        {
            log.Info("Worker Received 'StopTask' for executerId: " + executerId);

            if (_executers.ContainsKey(executerId))
            {
                ITaskExecuter executer = _executers[executerId];

                if (executer != null)
                {
                    var result = await executer.StopTask();

                    log.Info("In StopTask - we got result = " + result);
                }
                //TODO consider keeping it and removing only if process stopped
                //Listen to process end (exit/terminated ...) and remove from _executers
                _executers.Remove(executerId);
            }
            else
            {
                log.Info("In StopTask - we couldn't find the executerId: " + executerId + " In _executers");
            }
        }
        public async void StopFlinkListener(ProgramMessage programMessage)
        {
            log.Info(string.Format("Worker Received 'StopFlinkListener' with DeploymentId = {0}, MessageName = {1}", programMessage.DeploymentId, programMessage.MessageName));

            //if (programMessage != null && !string.IsNullOrEmpty(programMessage.MessageName) && !string.IsNullOrEmpty(programMessage.ExecuterId) && !string.IsNullOrEmpty(programMessage.FlowExecuterId))
            //{
            //    log.Info(string.Format("Worker Received 'StopFlinkListener' with MessageName = {0}, ExecuterId = {1}, ExecuterId = {2}, FlowExecuterId = {3}" + programMessage.MessageName, programMessage.ExecuterId, programMessage.FlowExecuterId));
            //}

            //Original
            //if (_flowExecuters.ContainsKey(programMessage.FlowExecuterId))
            //{
            //    var executers = _flowExecuters[programMessage.FlowExecuterId];

            //    if(executers.ContainsKey(programMessage.ExecuterId))
            //    {
            //        ITaskExecuter executer = executers[programMessage.ExecuterId];

            //        if (executer != null)
            //        {
            //            var result = await executer.StopTask(true);//simulateTaskCompleted = true!!!

            //            log.Info("In StopFlinkListener - we got result = " + result);

            //            _executers.Remove(programMessage.ExecuterId);
            //        }
            //    }
            //}
            if (!string.IsNullOrEmpty(_waitForFlinkToStopFlowExecuterID) && _flowExecuters.ContainsKey(_waitForFlinkToStopFlowExecuterID))
            {
                var executers = _flowExecuters[_waitForFlinkToStopFlowExecuterID];

                if (executers.ContainsKey(_waitForFlinkToStopExecuterID))
                {
                    ITaskExecuter executer = executers[_waitForFlinkToStopExecuterID];

                    if (executer != null)
                    {
                        var result = await executer.StopTask(true);//simulateTaskCompleted = true!!!

                        log.Info("In StopFlinkListener - we got result = " + result);

                        _executers.Remove(_waitForFlinkToStopExecuterID);
                    }
                }
            }
            else
            {
                log.Info("In StopFlinkListener - we couldn't find the executerId: " + programMessage.ExecuterId + " In _flowExecuters");
            }

            //1. If programMessage will contain task executerId than we can simply call StopTask(programMessage.ExecuterId)
            //For that flink should get the waiting task executer id and for this we need to break the structure of polymorphism
            //The FDC should be familiar with its running tasks, and after running the waiting task it needs to push its executer id to the
            //flink file which is also not recommended 

            //2. The MessageDetails can contain some symbolic data and it should look for the relevant task - again breaking the polymorphism / performs coupling
            //and it should run now the concrete tasks that are running

            //3. Registering at the task level is busy wait, too consuming (each task is regsiter itself and 
            //and we don't want them to stop but through the executionManager, which needs to manage who is running 
            //or not

            //4. a better solution would be a simple task that is waiting on some message: kds/ActiveMQ/SQS/DynamoDB and it'll stop when it sees the flink message

            //5.Message may include: program source, program dst, identifiers: deploymentID(mandatory), GameId, RunId, PlayId
        }
        public static Dictionary<String, Object> FirstDyn2Dict(dynamic dynObj)
        {
            var dictionary = new Dictionary<string, object>();
            foreach (PropertyDescriptor propertyDescriptor in TypeDescriptor.GetProperties(dynObj))
            {
                object obj = propertyDescriptor.GetValue(dynObj);
                dictionary.Add(propertyDescriptor.Name, obj);
            }
            return dictionary;
        }
        public static void ConvertDynamic2Dictionary(dynamic dynObj, Dictionary<string, string> dictionary)
        {
            if (dynObj == null)
            {
                return;
            }

            Dictionary<String, Object> firstDic = FirstDyn2Dict(dynObj);

            foreach (string key in firstDic.Keys)
            {
                if (!(firstDic[key] is JObject))
                {
                    dictionary.Add(key, firstDic[key].ToString());
                }
                else //this is JObject
                {
                    ConvertDynamic2Dictionary(firstDic[key], dictionary);
                }
            }
        }
        private string GetTaskParametersFromFlowTaskParameters(Dictionary<string, string> flowParametersDictionary, ODTask task)
        {
            if (flowParametersDictionary.ContainsKey(task.Id))
            {
                return flowParametersDictionary[task.Id];
            }

            return string.Empty;
        }
        private string GetTaskParametersFromFlowJson(Dictionary<string, string> flowParametersDictionary, ODTask task)
        {
            var currentParams = task.TaskParameters.Split(" ");

            var finalParameters = "";

            for (int i = 0; i < currentParams.Length; i += 2)
            {
                var paramNameWithoutPrefix = currentParams[i].Replace("--", "");
               
                var currentParamsValue = currentParams[i+1];

                if (flowParametersDictionary.ContainsKey(paramNameWithoutPrefix))
                {
                    if (string.IsNullOrEmpty(finalParameters))
                    {
                        finalParameters = "--" + paramNameWithoutPrefix + " " + flowParametersDictionary[paramNameWithoutPrefix];
                    }
                    else
                    {
                        finalParameters = finalParameters + " --" + paramNameWithoutPrefix + " " + flowParametersDictionary[paramNameWithoutPrefix];
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(finalParameters))
                    {
                        finalParameters = "--" + paramNameWithoutPrefix + " " + currentParamsValue;
                    }
                    else
                    {
                        finalParameters = finalParameters + " --" + paramNameWithoutPrefix + " " + currentParamsValue;
                    }
                }
            }

            return finalParameters;
        }
        public Dictionary<string, string> GetParametersDictionary(FlowPayload payload)
        {
            Dictionary<string, string> parametersDictionary = new Dictionary<string, string>();

            if (!string.IsNullOrEmpty(payload.FlowTaskParameters))
            {
                dynamic flowParametersObject = JObject.Parse(payload.FlowTaskParameters);

                ConvertDynamic2Dictionary(flowParametersObject, parametersDictionary);
            }
            else if (!string.IsNullOrEmpty(payload.FlowJsonParameters))
            {
                //Here we need a better parsing of a complex json
                dynamic flowJsonParametersObject = JObject.Parse(payload.FlowJsonParameters);

                ConvertDynamic2Dictionary(flowJsonParametersObject, parametersDictionary);
            }

            return parametersDictionary;
        }
        public void OverrideTaskParameters(Dictionary<string, string> parametersDictionary, ODTask currentTask, FlowPayload payload, TaskPayload taskPayload)
        {
            if (parametersDictionary != null && parametersDictionary.ContainsKey(currentTask.Id))
            {
                if (!string.IsNullOrEmpty(payload.FlowTaskParameters))
                {
                    var taskParameters = GetTaskParametersFromFlowTaskParameters(parametersDictionary, currentTask);
                    taskPayload.AreParametersOverriden = true;
                    taskPayload.OverridingParameters = taskParameters;
                }
            }
            else if (!string.IsNullOrEmpty(payload.FlowJsonParameters))
            {
                if (!string.IsNullOrEmpty(currentTask.TaskParameters))
                {
                    var taskParameters = GetTaskParametersFromFlowJson(parametersDictionary, currentTask);
                    taskPayload.AreParametersOverriden = true;
                    taskPayload.OverridingParameters = taskParameters;
                }
            }
        }
        private void UpdateClipParameters(Dictionary<string, string> parametersDictionary)
        {
            if (parametersDictionary.ContainsKey("gameId"))
            {
                _currentExecutingFlowStatus.GameId = parametersDictionary["gameId"];
            }

            if (parametersDictionary.ContainsKey("playId"))
            {
                _currentExecutingFlowStatus.PlayId = parametersDictionary["playId"];
            }

            if (parametersDictionary.ContainsKey("runId"))
            {
                _currentExecutingFlowStatus.RunId = parametersDictionary["runId"];
            }
        }
        public async void RunFlow(FlowPayload payload, string serverHubURL)
        {
            log.Info("Worker Received 'RunFlow' for FlowId: " + payload.FlowId);

            _waitForFlinkToStopExecuterID = Guid.NewGuid().ToString();
            _shouldStopWaitingTask = false;

            //ReportFlinkListenerTaskIdToHub(payload.DeploymentId, _waitForFlinkToStopExecuterID, payload.FlowExecuterId);//currently report that for every flow,
            //later report only for clip creation flow

            string flowExecuterId = Guid.NewGuid().ToString();

            if (!_odFlowsById.ContainsKey(payload.FlowId))
            {
                RefreshODCollections();
            }

            ODFlow odFlow = _odFlowsById[payload.FlowId];

            _currentExecutingFlowStatus = new ExecutingFlowStatus()
            {
                FlowId = payload.FlowId,
                DeploymentId = payload.DeploymentId,
                FlowExecuterId = flowExecuterId,
                ExecuterName = payload.ExecuterName,
                Status = FlowStatus.FlowStarting,
                //GameId = payload.GameId,
                //PlayId = payload.PlayId,
                //RunId = payload.RunId,
                Progress = 0,
                Activity = new Model.DB.Activity()
            };

            Dictionary<string, string> parametersDictionary = GetParametersDictionary(payload);

            UpdateClipParameters(parametersDictionary);

            ReportStatus(_currentExecutingFlowStatus);

            if (odFlow.RunInParallel.ToString().ToLower() == "true")
            {
                _currentExecutingFlowStatus.Status = FlowStatus.FlowStarted;

                ReportStatus(_currentExecutingFlowStatus);

                //Filter tasks to run only regular tasks
                Parallel.ForEach(odFlow.Tasks, (currentTask) =>
                {
                    var taskPayload = new TaskPayload()
                    {
                        TaskId = currentTask.Id,
                        DeploymentId = payload.DeploymentId,
                        RunAsPartOfAFlow = true,
                        ExecuterName = payload.ExecuterName,
                        FlowExecuterId = flowExecuterId,
                        FlowId = payload.FlowId,
                    };

                    if (parametersDictionary != null)
                    {
                        OverrideTaskParameters(parametersDictionary, currentTask, payload, taskPayload);
                    }

                    RunTask(taskPayload, serverHubURL);
                });

                _currentExecutingFlowStatus.Status = FlowStatus.FlowCompleted;

                ReportStatus(_currentExecutingFlowStatus);
            }
            else
            {
                _currentExecutingFlowStatus.Status = FlowStatus.FlowStarted;

                ReportStatus(_currentExecutingFlowStatus);

                float taskProgressStep = 100F / odFlow.Tasks.Count;

                //float taskProgressStep = 100F / odFlow.Tasks.Count;
                //float taskProgressStepRounded = (float)Math.Round(taskProgressStep * 100f) / 100f;

                //Filter tasks to run only regular tasks
                foreach (ODTask currentTask in odFlow.Tasks)
                {
                    if (currentTask.Id == "7d0e6dc9-d2a0-4b86-a7cf-6b9b5ff9d8fb")
                    {
                        _waitForFlinkToStopFlowExecuterID = flowExecuterId; //In case of 'Wait For Flink Job To Complete' - save the flowExecuterId as well
                    }

                    if (currentTask.Name == "send_cvt_run_request_with_frame_ranges")
                    {
                        GetBrokerData();
                    }

                    var taskPayload = new TaskPayload()
                    {
                        TaskId = currentTask.Id,
                        DeploymentId = payload.DeploymentId,
                        RunAsPartOfAFlow = true,
                        ExecuterName = payload.ExecuterName,
                        FlowExecuterId = flowExecuterId,
                        FlowId = payload.FlowId
                    };

                    if (parametersDictionary != null)
                    {
                        OverrideTaskParameters(parametersDictionary, currentTask, payload, taskPayload);
                    }

                    //Report before task start
                    _currentExecutingFlowStatus.Activity.RunningTaskName = currentTask.Name;
                    _currentExecutingFlowStatus.Activity.RunningTaskStatus = TaskStatus.TaskStarted;
                    ReportStatus(_currentExecutingFlowStatus);

                    ExecutingTaskStatus result = await RunTask(taskPayload, serverHubURL);

                    //Report after task ended
                    _currentExecutingFlowStatus.Progress = _currentExecutingFlowStatus.Progress + taskProgressStep;
                    _currentExecutingFlowStatus.Activity.RunningTaskStatus = result.Status;
                    ReportStatus(_currentExecutingFlowStatus);

                    if (result.Status == TaskStatus.TaskCompletedWithError || result.Status == TaskStatus.TaskStopped)
                    {
                        if (result.Status == TaskStatus.TaskStopped)
                        {
                            _currentExecutingFlowStatus.Status = FlowStatus.FlowStopped;
                        }
                        else
                        {
                            _currentExecutingFlowStatus.Status = FlowStatus.FlowCompletedWithError;
                        }

                        ReportStatus(_currentExecutingFlowStatus);

                        return;
                    }
                }

                _currentExecutingFlowStatus.Progress = 100;
                _currentExecutingFlowStatus.Status = FlowStatus.FlowCompleted;

                ReportStatus(_currentExecutingFlowStatus);
            }
        }
        public void StopFlow(string flowExecuterId)
        {
            log.Info("Worker Received 'StopFlow' for flowExecuterId: " + flowExecuterId);

            if (_flowExecuters.ContainsKey(flowExecuterId))
            {
                _currentExecutingFlowStatus.Status = FlowStatus.FlowStopping;

                ReportStatus(_currentExecutingFlowStatus);

                Dictionary<string, ITaskExecuter> taskExecuters = _flowExecuters[flowExecuterId];

                foreach (ITaskExecuter taskExecuter in taskExecuters.Values)
                {
                    //TODO need to await?
                    taskExecuter.StopTask();
                }

                //Run finalization tasks of Flow
                //Get their list


                //This code is obsolete , the task was removed
                var taskPayload = new TaskPayload() { TaskId = "a13db123-9a19-447b-8692-3b0b3bc75114", DeploymentId = WorkerConfig.DeploymentId, RunAsPartOfAFlow = true, FlowExecuterId = flowExecuterId, FlowId = flowExecuterId };

                RunTask(taskPayload, WorkerConfig.DeploymentOperationsServerHubURL);

                _flowExecuters.Remove(flowExecuterId);

                _currentExecutingFlowStatus.Status = FlowStatus.FlowStopped;

                ReportStatus(_currentExecutingFlowStatus);
            }
        }
        private string FindCommentParameter(string dynamicParameters)
        {
            var segments = dynamicParameters.Split("--c");

            if (segments.Length < 2)
                return null;

            var segments2 = segments[1].Split(" ");

            var comment = segments2[1].Replace("\"", "");

            return comment;
        }
        private string GetS3DebugKitBucketUrl(TaskPayload payload, string timeArgument, string comment)
        {
            var stringsForMode = payload.DynamicParameters.Split("--mode");

            var mode = stringsForMode[1].Split(" ")[1];

            if (mode == "3") //here no files are being uploaded
            {
                return string.Empty;
            }
            else if (mode == "1")
            {
                dynamic jsonObject = JObject.Parse(payload.JsonConfigDynamicParameters);

                var strings = payload.DynamicParameters.Split(" ");

                var startFrame = strings[1];

                string framesRange;

                if (payload.DynamicParameters.Contains("endFrame"))
                {
                    //--frame 126075 --endFrame 12068 --mode 2 y n n y n 1
                    var endFrame = strings[3];

                    framesRange = startFrame + "-" + endFrame;
                }
                else
                {
                    //--frame 126075 --mode 2 y n n y n 1 <-check framesMarginSize 
                    var framesMarginSizeString = jsonObject["GeneralParams"]["framesMarginSize"].ToString();

                    int.TryParse(framesMarginSizeString, out int framesMarginSize);

                    var endFrame = Convert.ToInt32(startFrame) + framesMarginSize;

                    int startFrameInt = Convert.ToInt32(startFrame) - framesMarginSize;

                    framesRange = startFrameInt.ToString() + "-" + endFrame;
                }

                var todayAsString = DateTime.Now.ToString("ddMMyyyy");

                var timeAsString = timeArgument;//"hhmmss"

                //var s3DebugKitBucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/production-v4/debug-kits/" + SportGroupInformation + "/" + VenueInformation + "/" + GameID + "_" + framesRange + "_" + todayAsString + "_" + timeAsString + "?region=us-east-1&tab=overview";
                //Since SportGroupInformation, VenueInformation, GameID exist only in the client the full path will be composed only in the client
                //So we return only the following
                var s3DebugKitBucketUrl = framesRange + "_" + todayAsString + "_" + timeAsString;
                return s3DebugKitBucketUrl;
            }
            else
            {
                var strings = payload.DynamicParameters.Split(" ");

                var startFrame = strings[1];

                string framesRange;

                if (payload.DynamicParameters.Contains("endFrame"))
                {
                    //--frame 126075 --endFrame 12068 --mode 2 y n n y n 1
                    var endFrame = strings[3];

                    framesRange = "F" + startFrame + "-" + endFrame;
                }
                else
                {
                    //--frame 126075 --mode 2 y n n y n 1 <-check framesMarginSize 
                    dynamic jsonObject = JObject.Parse(payload.JsonConfigDynamicParameters);

                    var framesMarginSizeString = jsonObject["GeneralParams"]["framesMarginSize"].ToString();

                    int.TryParse(framesMarginSizeString, out int framesMarginSize);

                    var endFrame = Convert.ToInt32(startFrame) + framesMarginSize;

                    int startFrameInt = Convert.ToInt32(startFrame) - framesMarginSize;

                    framesRange = "F" + startFrameInt.ToString() + "-" + endFrame;
                }

                var todayAsString = DateTime.Now.ToString("ddMMyyyy");

                var s3DebugKitBucketUrl = "";

                s3DebugKitBucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/debug-kits/" + payload.DeploymentId + "/" + todayAsString + "_" + timeArgument + "/" + framesRange + "/?region=us-east-1&tab=overview";

                if (!string.IsNullOrEmpty(comment))
                {
                    s3DebugKitBucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/debug-kits/" + payload.DeploymentId + "/" + todayAsString + "_" + timeArgument + "/" + framesRange + "_" + comment + "/?region=us-east-1&tab=overview";
                }
                return s3DebugKitBucketUrl;
            }
        }
        public Task<ExecutingTaskStatus> RunPrepareDeployment(TaskPayload payload, string serverHubURL)
        {
            log.Info("Worker Received 'RunTask' of type: " + payload.TaskType);

            var executerId = Guid.NewGuid().ToString();

            var jsonFilePath = CreateRunPrepareDeploymentJsonFile(payload.DeploymentId, payload.JsonConfigDynamicParameters, executerId);

            ODTask task = new ODTask();

            task.ProgramToExecute = "python3";

            task.ProgramParameters = "init.py";

            log.Info("Calculated Task Parameters = " + task.ProgramParameters);

            var appFolderPath = string.Format(@"{0}/{1}/{2}/", _installationDirectory, Constants.DEPLOYMENT_CONFIGURATION, Constants.V4_PREPARE_CONFIGURATION);

            task.WorkingDirectory = appFolderPath;

            ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(serverHubURL, this.iOpenIdConnect, payload, executerId,
                                                                       WorkerConfig.CompletedTasksTableName, WorkerConfig.DynamoDBRegion, WorkerConfig.FdControllerName,
                                                                       string.Empty, string.Empty, CategoryGroup.Debug.ToString(), string.Empty);

            _executers.Add(executerId, taskExecuter);

            Task<ExecutingTaskStatus> result = taskExecuter.ExecuteTask(task);

            return result;
        }
        public Task<ExecutingTaskStatus> RunV4V(TaskPayload payload, string serverHubURL)
        {
            log.Info("Worker Received 'RunTask' of type: " + payload.TaskType);
            log.Info("Inside RunV4V");

            var executerId = Guid.NewGuid().ToString();

            ODTask task = new ODTask();

            //FindV4VPodName();
            v4vPodName = payload.TargetPod;

            if (string.IsNullOrEmpty(v4vPodName))
            {
                log.Info("Worker Couldn't find V4V pod name");
                return null;
            }

            if (CreateV4VJsonFileAndCopyItToDestination(payload.JsonConfigDynamicParameters))
            {
                CreateV4VShellScriptInvoker(payload.DynamicParameters);

                task.ReportStandardOutput = true;
                task.ProgramToExecute = "/bin/bash";
                //Or produce a script (copied it from linux) and run the script
                task.ProgramParameters = "./invoke_v4v.sh";
                //(2)task.ProgramParameters = "kubectl exec -it v4vClusterName --bash -c 'python3.8 V4V.py " + payload.DynamicParameters + "'";
                //task.ProgramParameters = "kubectl exec -it " + v4vPodName + " -- bash -c 'python3.8 V4V.py " + payload.DynamicParameters + "'";

                ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(serverHubURL, this.iOpenIdConnect, payload, executerId,
                                                                          WorkerConfig.CompletedTasksTableName, WorkerConfig.DynamoDBRegion, WorkerConfig.FdControllerName,
                                                                          string.Empty, string.Empty, CategoryGroup.Debug.ToString(), string.Empty);

                _executers.Add(executerId, taskExecuter);

                log.Info(string.Format("Before launching task id: {0}, with executer id: {1}, with executer name: {2}", payload.TaskId, executerId, payload.ExecuterName));

                Task<ExecutingTaskStatus> result = taskExecuter.ExecuteTask(task);

                log.Info(string.Format("Worker launched task id: {0} with executer id: {1}, with executer name: {2} successfully", payload.TaskId, executerId, payload.ExecuterName));

                return result;
            }

            return null;
        }
        public Task<ExecutingTaskStatus> RunDebugKit(TaskPayload payload, string serverHubURL)
        {
            log.Info("Worker Received 'RunTask' of type: " + payload.TaskType);

            var executerId = Guid.NewGuid().ToString();

            DownloadDebugKitProgramAndUncompress();

            ODTask task = new ODTask();

            task.ReportStandardOutput = true;

            //TODO when the script accepts the json - supply it as one of its parameters
            //currently only override the json
            var jsonFilePath = CreateDebugKitJsonFile(payload.DeploymentId, payload.JsonConfigDynamicParameters, executerId);

            //We need to send the current time to the DebugKit
            var timeAsString = DateTime.Now.ToString("hhmmss");
            var timeArgument = " --t " + timeAsString;

            task.ProgramToExecute = "python3";
            task.ProgramParameters = "debugKit.py " + payload.DynamicParameters + timeArgument;

            log.Info("Calculated Task Parameters = " + task.ProgramParameters);

            var appFolderPath = string.Format(@"{0}/{1}/{2}/", _installationDirectory, Constants.DEBUG, Constants.DEBUG_KIT_TASKS);

            //Pay attention to the needed whitespace between the ExecutedProgramParams & TaskParameters
            //var appFullPath = string.Format(@"{0}{1}", appFolderPath, task.ProgramToExecute);

            task.WorkingDirectory = appFolderPath;

            var comment = FindCommentParameter(payload.DynamicParameters);

            payload.s3BucketUrl = GetS3DebugKitBucketUrl(payload, timeAsString, comment);

            //SetLogFileDetails(payload, executerId);

            ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(serverHubURL, this.iOpenIdConnect, payload, executerId,
                                                                       WorkerConfig.CompletedTasksTableName, WorkerConfig.DynamoDBRegion, WorkerConfig.FdControllerName,
                                                                       string.Empty, string.Empty, CategoryGroup.Debug.ToString(), string.Empty);

            _executers.Add(executerId, taskExecuter);

            log.Info(string.Format("Before launching task id: {0}, with executer id: {1}, with executer name: {2}", payload.TaskId, executerId, payload.ExecuterName));

            Task<ExecutingTaskStatus> result = taskExecuter.ExecuteTask(task);

            log.Info(string.Format("Worker launched task id: {0} with executer id: {1}, with executer name: {2} successfully", payload.TaskId, executerId, payload.ExecuterName));

            return result;
        }
        public Task<ExecutingTaskStatus> RunKDSPublisherTask(TaskPayload payload, string serverHubURL)
        {
            log.Info("Worker Received 'RunTask' of type: " + payload.TaskType);

            var executerId = Guid.NewGuid().ToString();

            DownloadPublisherProgramAndUncompress();

            ODTask task = new ODTask();

            task.ReportStandardOutput = true;

            var jsonFilePath = CreateKdsPublisherTaskJsonFile(payload.JsonConfigDynamicParameters, executerId);

            task.ProgramToExecute = "dotnet";
            task.ProgramParameters = "Intel.FreeD.FD19Publisher.dll " + " --configFileName " + jsonFilePath;// jsonFilePath;

            var appFolderPath = string.Format(@"{0}/{1}/{2}/", _installationDirectory, Constants.PUBLISHERS, Constants.KDS_PUBLISHER_TASKS);

            //Pay attention to the needed whitespace between the ExecutedProgramParams & TaskParameters
            //var appFullPath = string.Format(@"{0}{1}", appFolderPath, task.ProgramToExecute);

            task.WorkingDirectory = appFolderPath;

            ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(serverHubURL, this.iOpenIdConnect, payload, executerId,
                                                                       WorkerConfig.CompletedTasksTableName, WorkerConfig.DynamoDBRegion, WorkerConfig.FdControllerName,
                                                                       string.Empty, string.Empty, CategoryGroup.Publishers.ToString(), string.Empty);

            _executers.Add(executerId, taskExecuter);

            log.Info(string.Format("Before launching task id: {0}, with executer id: {1}, with executer name: {2}", payload.TaskId, executerId, payload.ExecuterName));

            Task<ExecutingTaskStatus> result = taskExecuter.ExecuteTask(task);

            log.Info(string.Format("Worker launched task id: {0} with executer id: {1}, with executer name: {2} successfully", payload.TaskId, executerId, payload.ExecuterName));

            return result;
        }
        public Task<ExecutingTaskStatus> RunFlinkTask(FlinkTaskPayload payload, string serverHubURL)
        {
            log.Info("Worker Received 'RunFlinkTask' of type: " + payload.FlinkTaskType);

            var executerId = Guid.NewGuid().ToString();

            DownloadFlinkProgramAndUncompress();

            ODTask task = new ODTask();

            task.ReportStandardOutput = true;
            payload.IsFlinkTask = true;

            var jsonFilePath = CreateFlinkTaskJsonFile(payload);

            if (payload.FlinkTaskType == FlinkTaskType.UploadJar)
            {
                DownloadFlinkJar(payload.JarName);

                //DownloadFlinkJarFromArtifactory(payload.JarName);
            }

            task.ProgramToExecute = "java";
            task.ProgramParameters = "-jar monitoringApi6.jar " + jsonFilePath;

            var appFolderPath = string.Format(@"{0}/{1}/{2}/", _installationDirectory, Constants.FLINK, Constants.FLINK_TASKS);

            //Pay attention to the needed whitespace between the ExecutedProgramParams & TaskParameters
            var appFullPath = string.Format(@"{0}{1}", appFolderPath, task.ProgramToExecute);

            task.WorkingDirectory = appFolderPath;

            ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(serverHubURL, this.iOpenIdConnect, payload, executerId,
                                                                       WorkerConfig.CompletedTasksTableName, WorkerConfig.DynamoDBRegion, WorkerConfig.FdControllerName,
                                                                       string.Empty, string.Empty, CategoryGroup.Flink.ToString(), string.Empty);

            _flinkExecuters.Add(executerId, taskExecuter);

            Task<ExecutingTaskStatus> /*Task<ExecutingFlinkTaskStatus>*/ result = taskExecuter.ExecuteTask(task);

            return result;
        }
        public void DownloadFlinkJar(string jarName)
        {
            log.Info("Inside  DownloadFlinkJar");

            var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.FLINK, Constants.FLINK_TASKS, jarName);

            if (File.Exists(filePath))
            {
                return;
            }

            var s3FileKey = string.Format("{0}/{1}/{2}", Constants.FLINK, Constants.FLINK_JARS, jarName);

            _fileTransferUtility.Download(filePath, WorkerConfig.S3BucketForUploadDownloadPrograms, s3FileKey);

        }
        private static bool CreateV4VShellScriptInvoker(string commandLine)
        {
            log.Info("Inside CreateV4VShellScriptInvoker");

            try
            {
                string filepath = "invoke_v4v.sh";

                string command = "kubectl exec -it " + v4vPodName + " -- bash -c 'python3.8 V4V.py " + commandLine + "'";

                string[] lines = { "#!/bin/bash", command };

                File.WriteAllLines(filepath, lines);
            }
            catch (Exception xcp)
            {
                log.Error("Error in CreateV4VShellScriptInvoker " + xcp.Message);

                return false;
            }

            return true;
        }
        private static bool CreateV4VConfigUploader()
        {
            log.Info("Inside CreateV4VConfigUploader");

            try
            {
                //kubectl cp ./V4VConfig.json v4v-5bc8dc47c6-jdglb:/config/V4VConfig.json
                string filepath = "copy_v4v_config.sh";

                string command = "kubectl cp ./V4VConfig.json " + v4vPodName + ":/config/V4VConfig.json";

                string[] lines = { "#!/bin/bash", command };

                File.WriteAllLines(filepath, lines);
            }
            catch (Exception xcp)
            {
                log.Error("Error in CreateV4VConfigUploader " + xcp.Message);

                return false;
            }

            return true;
        }
        private void FindV4VPodName()
        {
            try
            {
                Process process = new Process();
                process.StartInfo.FileName = "/bin/bash";
                //process.StartInfo.FileName = "cmd.exe"; //Windows
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.EnableRaisingEvents = true;
                //process.StartInfo.Arguments = "kubectl get pods | grep -i 'v4v'";
                //process.StartInfo.Arguments = "kubectl get pods | grep -i 'fdcontroller'";
                process.OutputDataReceived += FindV4V_OutputDataReceived;
                process.Start();

                process.WaitForExit();
            }
            catch (Exception xcp)
            {
                log.Info("Exception occuured at FindV4VPodName: " + xcp.Message);
            }
        }
        private void FindV4V_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            //fdcontroller - 0                     0 / 1     Pending   0          143m
            var podNameSplits = e.Data.Split(" ");
            if (podNameSplits.Length > 1)
            {
                v4vPodName = podNameSplits[0];
            }
        }
        private void CreateV4VJsonFile(string jsonContent)
        {
            log.Info("Inside CreateV4VJsonFile");

            var filePath = "V4VConfig.json";

            dynamic jsonObject = JObject.Parse(jsonContent);

            jsonContent = JsonConvert.SerializeObject(jsonObject);

            File.WriteAllText(filePath, jsonContent);
        }
        public bool CreateV4VJsonFileAndCopyItToDestination(string jsonContent)
        {
            log.Info("Inside CreateV4VJsonFileAndCopyItToDestination");

            CreateV4VJsonFile(jsonContent);

            return CopyV4VConfigToDestination();
        }
        public bool CopyV4VConfigToDestination()
        {
            log.Info("Inside CopyV4VConfigToDestination");

            try
            {
                CreateV4VConfigUploader();

                Process process = new Process();

                process.StartInfo.FileName = "/bin/bash"; //Linux

                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.EnableRaisingEvents = true;

                process.StartInfo.Arguments = "./copy_v4v_config.sh";
                //process.StartInfo.Arguments = "kubectl cp ./V4VConfig.json " + v4vPodName + ":/config/V4VConfig.json"; //Linux

                process.Start();

                process.BeginErrorReadLine();
                process.BeginOutputReadLine();
                process.WaitForExit();

                return true;
            }
            catch (Exception xcp)
            {
                log.Info("Exception occuured at CopyV4VConfigToDestination: " + xcp.Message);
            }

            return false;
        }
        public string CreateRunPrepareDeploymentJsonFile(string deploymentId, string jsonContent, string executerId)
        {
            log.Info("Inside CreateRunPrepareDeploymentJsonFile");

            var fileName = "prepDepUiConfig.json";

            var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.DEPLOYMENT_CONFIGURATION, Constants.V4_PREPARE_CONFIGURATION, fileName);

            dynamic jsonObject = JObject.Parse(jsonContent);

            var serializedObject = JsonConvert.SerializeObject(jsonObject);

            File.WriteAllText(filePath, serializedObject);

            return fileName;
        }
        public string CreateDebugKitJsonFile(string deploymentId, string jsonContent, string executerId)
        {
            log.Info("Inside CreateDebugKitJsonFile");

            var fileName = /*executerId +*/ "debugKitConfig.json";

            var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.DEBUG, Constants.DEBUG_KIT_TASKS, fileName);

            dynamic jsonObject = JObject.Parse(jsonContent);

            jsonObject["Logging"]["LogFileName"] = executerId + "_debugKit.log";// + jsonObject["Logging"]["LogFileName"];
            jsonObject["Logging"]["S3BaseKey"] = "Reports/DebugKit/" + deploymentId;
            jsonObject["Logging"]["S3BucketName"] = WorkerConfig.S3BucketForUploadDownloadPrograms;
            jsonObject["Logging"]["S3BucketRegion"] = WorkerConfig.S3BucketRegionForUploadDownloadPrograms;

            jsonContent = JsonConvert.SerializeObject(jsonObject);

            File.WriteAllText(filePath, jsonContent);

            return fileName;
        }
        public string CreateKdsPublisherTaskJsonFile(string jsonContent, string executerId)
        {
            log.Info("Inside CreateKdsPublisherTaskJsonFile");

            var fileName = executerId + "fd19publisher.json";

            var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.PUBLISHERS, Constants.KDS_PUBLISHER_TASKS, fileName);

            dynamic jsonObject = JObject.Parse(jsonContent);
            jsonObject["Logging"]["LogFileName"] = executerId + "-" + jsonObject["Logging"]["LogFileName"];
            jsonObject["Logging"]["S3BucketPath"] = WorkerConfig.S3BucketForUploadDownloadPrograms;
            jsonObject["Logging"]["S3BucketRegion"] = WorkerConfig.S3BucketRegionForUploadDownloadPrograms;
            jsonObject["Logging"]["S3BaseKey"] = "Reports/Publishers/";

            jsonContent = JsonConvert.SerializeObject(jsonObject);

            File.WriteAllText(filePath, jsonContent);

            return fileName;
        }
        public string CreateFlinkTaskJsonFile(FlinkTaskPayload payload)
        {
            log.Info("Inside CreateFlinkTaskJsonFile");

            dynamic flinkTaskJsonObject = new JObject();

            flinkTaskJsonObject.baseUrl = WorkerConfig.FlinkJobManagerEndpoint;
            // flinkTaskJsonObject.baseUrl = "http://localhost:8081/";

            switch (payload.FlinkTaskType)
            {
                case FlinkTaskType.UploadJar:
                    flinkTaskJsonObject.url = @"/jars/upload";
                    flinkTaskJsonObject.method = "POST";
                    flinkTaskJsonObject.filePath = payload.JarName;
                    break;

                case FlinkTaskType.GetDeployedJarList:
                    flinkTaskJsonObject.url = @"/jars";
                    flinkTaskJsonObject.method = "GET";
                    break;

                case FlinkTaskType.RunJar:
                    flinkTaskJsonObject.url = @"/jars/" + payload.JarName + @"/run";
                    flinkTaskJsonObject.method = "POST";
                    break;

                case FlinkTaskType.GetDeployedJarPlan:
                    flinkTaskJsonObject.url = @"/jars/" + payload.JarName + @"/plan";
                    flinkTaskJsonObject.method = "GET";
                    break;


                case FlinkTaskType.StopJob:
                    //flinkTaskJsonObject.url = @"/jobs/" + payload.JobId + @"/stop";   <=commented out
                    //flinkTaskJsonObject.method = "POST";
                    flinkTaskJsonObject.url = @"/jobs/" + payload.JobId + @"/yarn-cancel";
                    flinkTaskJsonObject.method = "GET";
                    dynamic requestBody = new JObject();
                    requestBody.targetDirectory = @"/";
                    requestBody.drain = false;
                    flinkTaskJsonObject.requestBody = requestBody;
                    break;


                case FlinkTaskType.JobsOverview:
                    flinkTaskJsonObject.url = @"/jobs/overview";
                    flinkTaskJsonObject.method = "GET";
                    break;
            }

            string serializedJsonString = flinkTaskJsonObject.ToString();// JsonConvert.SerializeObject(flinkTaskJson);

            var fileName = payload.FlinkTaskType + ".json";

            var filePath = string.Format("{0}/{1}/{2}/{3}", _installationDirectory, Constants.FLINK, Constants.FLINK_TASKS, fileName);

            File.WriteAllText(filePath, serializedJsonString);

            return fileName;
        }
        public async void ReportPackageStatus(string executerId, string data)
        {
            try
            {
                if (_workerHubClient.hubConnection.State == HubConnectionState.Connected)
                {
                    await _workerHubClient.hubConnection.InvokeAsync("OutputDataReceived", executerId, data);
                }
            }
            catch (Exception xcp)
            {
                log.Error(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "ReportPackageStatus" + xcp);
                Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "ReportPackageStatus" + xcp);
            }
        }
        public async void ReportStatus(ExecutingFlowStatus executingFlowStatus)
        {
            try
            {
                if (_workerHubClient.hubConnection.State == HubConnectionState.Connected)
                {
                    await _workerHubClient.hubConnection.InvokeAsync("ExecutingFlowStatus", executingFlowStatus);
                }
            }
            catch (Exception xcp)
            {
                log.Error(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "ReportStatus" + xcp);
                Console.WriteLine(Constants.MAJOR_ERROR_HAS_OCURRED_IN + "ReportStatus" + xcp);
            }
        }
        public void RunGetFlinkJobsTask()
        {
            log.Info("Inside RunGetFlinkJobsTask");

            try
            {
                TaskPayload payload = new TaskPayload { TaskId = "11ce4446-5a7e-42cb-8023-95b614d77747", DeploymentId = WorkerConfig.DeploymentId, ExecuterName = "FDC" };

                RunTask(payload, WorkerConfig.DeploymentOperationsServerHubURL);
            }
            catch (Exception xcp)
            {
                log.Info("Inside RunGetFlinkJobsTask. Excption = " + xcp);
            }
        }

        //public void FindIfProcessIsRunning()
        //{
        //    Process[] pname = Process.GetProcessesByName("notepad");
        //    if (pname.Length == 0)
        //}
        public static void SetKubernetesAccess()
        {
            log.Info("Inside SetKubernetesAccess");

            try
            {
                var connectCommand = string.Format("aws eks update-kubeconfig --name fd19_{0} --region {1} --role arn:aws:iam::753274046439:role/fd19_{2}_eks_user", WorkerConfig.DeploymentId, WorkerConfig.DeploymentRegion, WorkerConfig.DeploymentId);

                string[] lines = { "#!/bin/bash", connectCommand };

                var filepath = string.Format("{0}/{1}", _installationDirectory, "connect-to-kubernetes.sh");

                File.WriteAllLines(filepath, lines);

                //var programToExecute = "aws eks update-kubeconfig --name fd19_e07gil8fmzb78mr --region us-east-1 --role arn:aws:iam::753274046439:role/fd19_e07gil8fmzb78mr_eks_user";

                Process process = new Process();
                process.StartInfo.FileName = "/bin/bash";
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.EnableRaisingEvents = true;
                process.StartInfo.Arguments = filepath;

                process.Start();

                process.WaitForExit();
            }
            catch (Exception xcp)
            {
                log.Info(xcp);
            }
        }
        //private static void ListenToCVTTopic(string jarName)
        //{
        //    log.Info("Inside DownloadJarFromArtifactory");

        //    try
        //    {
        //        string[] lines = { "#!/bin/bash", command };

        //        var filepath = string.Format("{0}/{1}", _installationDirectory, string.Format("download{0}.sh", jarName));

        //        File.WriteAllLines(filepath, lines);

        //        Process process = new Process();
        //        process.StartInfo.FileName = "/bin/bash";
        //        process.StartInfo.RedirectStandardOutput = true;
        //        process.StartInfo.RedirectStandardError = true;
        //        process.StartInfo.UseShellExecute = false;
        //        process.EnableRaisingEvents = true;
        //        process.StartInfo.Arguments = filepath;

        //        process.Start();

        //        process.WaitForExit();
        //    }
        //    catch (Exception xcp)
        //    {

        //    }
        //}

        public static void GetBrokerData()
        {
            try
            {
                if (WorkerConfig.BrokerData != null && !string.IsNullOrEmpty(WorkerConfig.BrokerData.mq_username))
                {
                    return;
                }

                log.Info("Inside GetBrokerData, Called From RunFlow");

                HttpClient client = new HttpClient();

                client.DefaultRequestHeaders.Add("Authorization", WorkerConfig.CognitoIdToken);// "eyJraWQiOiJkckdDeWFZTkxSSCtvU2F6YUNDRUNnbER6WnhSc21ZNEN2bFYzVFpIUE5VPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiIwNTlmMTcyOC02NDBhLTQwNzYtYmFmMC05M2JiZWNhMTNjM2QiLCJjb2duaXRvOmdyb3VwcyI6WyJwZGFhc19kZXZlbG9wZXJzIiwidGVtcF9kZXZlbG9wZXJzIiwiZGV2ZWxvcGVycyJdLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiY29nbml0bzpwcmVmZXJyZWRfcm9sZSI6ImFybjphd3M6aWFtOjo3NTMyNzQwNDY0Mzk6cm9sZVwvVEVNUC1URUUxOS1Db250cm9sLUFjY2Vzcy1BbGwiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9ZdVN3Y3ZNRWEiLCJjb2duaXRvOnVzZXJuYW1lIjoiZ2lsIiwiY29nbml0bzpyb2xlcyI6WyJhcm46YXdzOmlhbTo6NzUzMjc0MDQ2NDM5OnJvbGVcL1RFRTE5LUNvbnRyb2wtUERBQVMtQWNjZXNzLWFsbC1Sb2xlIiwiYXJuOmF3czppYW06Ojc1MzI3NDA0NjQzOTpyb2xlXC9URU1QLVRFRTE5LUNvbnRyb2wtQWNjZXNzLUFsbCIsImFybjphd3M6aWFtOjo3NTMyNzQwNDY0Mzk6cm9sZVwvVEVFMTktQ29udHJvbC1BY2Nlc3MtQWxsIl0sImF1ZCI6IjRzMXRvOHFic2hsNnFkcXB1MDc1dDNvanRjIiwiZXZlbnRfaWQiOiIzNTBlYTZkNS0wZWVkLTQyMjMtYmUxNi1lYzYzMjQxYzA1ZDYiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTYxNDQ1MjIwMSwiZXhwIjoxNjE0NTM4NjAxLCJpYXQiOjE2MTQ0NTIyMDIsImVtYWlsIjoic2hhbGV2LmdpbEBpbnRlbC5jb20ifQ.fzhpl_s_aV3zsnni2onNdSRZnLDdiPav-zzKGU8J_b08b92QtGuI4fIvRPiNeny1_1LTVmMuMpvtN3Bn-67Vxi6IZC_XmiIoXG5bISB_t6yRL8x4XkJdLuBFWZOgNlO_QSjstsvNAvoimHQ5b5Y2MSPrjhJE9tZmkp49rldhzqm0Nyl5jWpr4PNuJ7Gl3D720OXjnnHu2NgV-usA46Y-gJeqeHCdy11nINjA4y9A5SstcZ35Pm7hFQq8_M0xNEtiNyZDHwlA5VGpnR1wKtbsyrk0QavEvMbXpBDRtSnZx8HUPsqSAArQcoPajCfagveuCEnsap7glmVYb76TER2soA");

                string url = "";

                log.Info("WorkerConfig.MqAuth = " + WorkerConfig.MqAuth);

                //if (!string.IsNullOrEmpty(WorkerConfig.MqAuth))
                //{
                //    url = WorkerConfig.MqAuth;
                //}
                //else
                //{
                url = "https://oyehf1z2cg.execute-api.us-west-2.amazonaws.com/default/api/Broker";
                //}

                //var responsestr = client.GetStringAsync(url).Result;

                var response = client.GetAsync(url).Result;

                log.Info("Response returned: " + response.ToString());

                string content = response.Content.ReadAsStringAsync().Result;

                log.Info("Broker Data found: " + content);

                var brokerData = JsonConvert.DeserializeObject<BrokerData>(content);

                WorkerConfig.BrokerData = brokerData;
            }
            catch (Exception xcp)
            {
                log.Error("Exception Inside GetBrokerData" + xcp);

                log.Error("Configuring with hard-coded values");

                WorkerConfig.BrokerData = new BrokerData { mq_username = "tee_lambda", mq_password = "NoneNoneNoneNone", mq_stomp_url = "stomp+ssl://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61614", mq_openwire_url = "ssl://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61617", mq_wss_url = "wss://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61619" };
            }
        }
    }
}

//public static void GetBrokerData()
//{
//    try
//    {
//        log.Info("Inside GetBrokerData");

//        HttpClient client = new HttpClient();

//        client.DefaultRequestHeaders.Add("Authorization", WorkerConfig.CognitoIdToken);// "eyJraWQiOiJkckdDeWFZTkxSSCtvU2F6YUNDRUNnbER6WnhSc21ZNEN2bFYzVFpIUE5VPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiIwNTlmMTcyOC02NDBhLTQwNzYtYmFmMC05M2JiZWNhMTNjM2QiLCJjb2duaXRvOmdyb3VwcyI6WyJwZGFhc19kZXZlbG9wZXJzIiwidGVtcF9kZXZlbG9wZXJzIiwiZGV2ZWxvcGVycyJdLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiY29nbml0bzpwcmVmZXJyZWRfcm9sZSI6ImFybjphd3M6aWFtOjo3NTMyNzQwNDY0Mzk6cm9sZVwvVEVNUC1URUUxOS1Db250cm9sLUFjY2Vzcy1BbGwiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9ZdVN3Y3ZNRWEiLCJjb2duaXRvOnVzZXJuYW1lIjoiZ2lsIiwiY29nbml0bzpyb2xlcyI6WyJhcm46YXdzOmlhbTo6NzUzMjc0MDQ2NDM5OnJvbGVcL1RFRTE5LUNvbnRyb2wtUERBQVMtQWNjZXNzLWFsbC1Sb2xlIiwiYXJuOmF3czppYW06Ojc1MzI3NDA0NjQzOTpyb2xlXC9URU1QLVRFRTE5LUNvbnRyb2wtQWNjZXNzLUFsbCIsImFybjphd3M6aWFtOjo3NTMyNzQwNDY0Mzk6cm9sZVwvVEVFMTktQ29udHJvbC1BY2Nlc3MtQWxsIl0sImF1ZCI6IjRzMXRvOHFic2hsNnFkcXB1MDc1dDNvanRjIiwiZXZlbnRfaWQiOiIzNTBlYTZkNS0wZWVkLTQyMjMtYmUxNi1lYzYzMjQxYzA1ZDYiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTYxNDQ1MjIwMSwiZXhwIjoxNjE0NTM4NjAxLCJpYXQiOjE2MTQ0NTIyMDIsImVtYWlsIjoic2hhbGV2LmdpbEBpbnRlbC5jb20ifQ.fzhpl_s_aV3zsnni2onNdSRZnLDdiPav-zzKGU8J_b08b92QtGuI4fIvRPiNeny1_1LTVmMuMpvtN3Bn-67Vxi6IZC_XmiIoXG5bISB_t6yRL8x4XkJdLuBFWZOgNlO_QSjstsvNAvoimHQ5b5Y2MSPrjhJE9tZmkp49rldhzqm0Nyl5jWpr4PNuJ7Gl3D720OXjnnHu2NgV-usA46Y-gJeqeHCdy11nINjA4y9A5SstcZ35Pm7hFQq8_M0xNEtiNyZDHwlA5VGpnR1wKtbsyrk0QavEvMbXpBDRtSnZx8HUPsqSAArQcoPajCfagveuCEnsap7glmVYb76TER2soA");

//        string url = "";

//        log.Info("WorkerConfig.MqAuth = " + WorkerConfig.MqAuth);

//        if (!string.IsNullOrEmpty(WorkerConfig.MqAuth))
//        {
//            url = WorkerConfig.MqAuth;
//        }
//        else
//        {
//            url = "https://oyehf1z2cg.execute-api.us-west-2.amazonaws.com/default/api/Broker";
//        }

//        var responsestr = client.GetStringAsync(url).Result;

//        log.Info("Broker Data found: " + responsestr);

//        var brokerData = JsonConvert.DeserializeObject<BrokerData>(responsestr);

//        WorkerConfig.BrokerData = brokerData;
//    }
//    catch (Exception xcp)
//    {
//        log.Error("Exception Inside GetBrokerData" + xcp);

//        log.Error("Configuring with hard-coded values");

//        WorkerConfig.BrokerData = new BrokerData { mq_username = "tee_lambda", mq_password = "NoneNoneNoneNone", mq_stomp_url = "stomp+ssl://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61614", mq_openwire_url = "ssl://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61617", mq_wss_url = "wss://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61619" };
//    }
//}

//if (mode == "2")
//{
//    s3DebugKitBucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/debug-kits/" + payload.DeploymentId + "/" + todayAsString + "_" + timeArgument + "/" + framesRange + "/?region=us-east-1&tab=overview";
//}
//else if (mode == "4")
//{
//    s3DebugKitBucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/debug-kits/" + payload.DeploymentId + "/" + todayAsString + "_" + timeArgument + "/" + framesRange + "/render_converted/?region=us-east-1&tab=overview";
//}
//else if (mode == "5")
//{
//    var args = payload.DynamicParameters.Split(" ");

//    if (args[args.Length - 1] == "0")
//    {
//        s3DebugKitBucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/debug-kits/" + payload.DeploymentId + "/" + todayAsString + "_" + timeArgument + "/" + framesRange + "/decode_converted/?region=us-east-1&tab=overview";
//    }
//    else
//    {
//        s3DebugKitBucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/debug-kits/" + payload.DeploymentId + "/" + todayAsString + "_" + timeArgument + "/" + framesRange + "/multiview_converted/?region=us-east-1&tab=overview";
//    }
//}


//}


//Alternative Way to download from S3
/*
public void DownloadObject(string imagename)
{
    RegionEndpoint bucketRegion = RegionEndpoint.USEast1;
    
    IAmazonS3 client = new AmazonS3Client(bucketRegion);

    string accessKey = System.Configuration.ConfigurationManager.AppSettings["AWSAccessKey"];
    string secretKey = System.Configuration.ConfigurationManager.AppSettings["AWSSecretKey"];
    AmazonS3Client s3Client = new AmazonS3Client(new BasicAWSCredentials(accessKey, secretKey), Amazon.RegionEndpoint.USEast1);
    string objectKey = "EMR" + "/" + imagename;
    //EMR is folder name of the image inside the bucket 
    GetObjectRequest request = new GetObjectRequest();
    request.BucketName = System.Configuration.ConfigurationManager.AppSettings["bucketname"];
    request.Key = objectKey;
    GetObjectResponse response = s3Client.GetObject(request);
    response.WriteResponseStreamToFile("D:\\Test\\" + imagename);
}
*/

//public DeploymentTask GetDeploymentTask(string taskId)
//{
//    // should be read from configuration
//    var AwsRegion = "eu-west-1";
//    var DynamoDbTable = "tasks2";

//    var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(AwsRegion));

//    Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
//    {
//        { TASK_ID_COL, new AttributeValue(taskId) }
//    };

//    GetItemResponse response = dynamoDbClient.GetItemAsync(DynamoDbTable, key).Result;

//    if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
//    {
//        DeploymentTask task = new DeploymentTask
//        {
//            Id = response.Item[TASK_ID_COL].S,
//            Name = response.Item[TASK_NAME_COL].S,
//            ProgramToExecute = response.Item[EXECUTED_PROGRAM_COL].S,
//        };

//        if (response.Item.ContainsKey(EXECUTED_PROGRAM_PARAMS_COL))
//        {
//            task.ProgramParameters = response.Item[EXECUTED_PROGRAM_PARAMS_COL].S;
//        }

//        if (response.Item.ContainsKey(TASK_DESCRIPTION_COL))
//        {
//            task.Description = response.Item[TASK_DESCRIPTION_COL].S;
//        }

//        if (response.Item.ContainsKey(WORKING_DIRECTORY_COL))
//        {
//            task.WorkingDirectory = response.Item[WORKING_DIRECTORY_COL].S;
//        }

//        //TODO could be true or True
//        task.ReportStandardOutput = response.Item[REPORT_STDOUT_COL].S.ToLower() == "true" ? true : false;

//        return task;
//    }
//    else
//        return null;
//}

//if (item.ContainsKey(Constants.COLUMN_PROGRAM_PREREQUISITES))
//{
//    var prereqisites = item[Constants.COLUMN_PROGRAM_PREREQUISITES].S;
//    var splits = prereqisites.Split(",");

//    if (splits != null)
//    {
//        odp.Prerequisites = new List<Prerequisite>();

//        foreach (string split in splits)
//        {
//            if (Enum.TryParse(split, out Prerequisite parsedPrerequisite))
//            {
//                odp.Prerequisites.Add(parsedPrerequisite);
//            }
//        }
//    }
//}

//private static void ParseDeploymentJsonConfigurations()
//{
//    log.Info("Inside ParseDeploymentJsonConfigurations");
//    Console.WriteLine("Inside ParseDeploymentJsonConfigurations");

//    try
//    {
//        var deploymentJsonPath = Environment.GetEnvironmentVariable("DEPLOYMENT_JSON");

//        var jsonData = File.ReadAllText(deploymentJsonPath);

//        var configFile = JObject.Parse(jsonData);

//        _flinkJobManagerEndpoint = configFile["compute_clusters"]["fd19_flink"]["flink_jobmanager"].ToString();

//        _deploymentId = configFile["deployment_id"].ToString();

//        _deploymentRegion = configFile["region"].ToString();
//    }
//    catch (Exception xcp)
//    {
//        log.Fatal(xcp.Message);
//        Console.WriteLine(xcp.Message);
//    }
//}

//if (task.ProgramParameters.Contains("$executerId"))
//{
//    task.ProgramParameters = task.ProgramParameters.Replace("$executerId", executerId);
//}

//if (task.ProgramParameters.Contains("$programsBucket"))
//{
//    task.ProgramParameters = task.ProgramParameters.Replace("$programsBucket", WorkerConfig.S3BucketForUploadDownloadPrograms);
//}

//if (task.ProgramParameters.Contains("$programsBucketRegion"))
//{
//    task.ProgramParameters = task.ProgramParameters.Replace("$programsBucketRegion", WorkerConfig.S3BucketRegionForUploadDownloadPrograms);
//}

//private void SetLogFileDetails(TaskPayload payload, string executerId)
//{
//    dynamic jsonObject = JObject.Parse(payload.JsonConfigDynamicParameters);

//    jsonObject["Logging"]["LogFileName"] = executerId + "-" + jsonObject["Logging"]["LogFileName"];
//    jsonObject["Logging"]["S3BucketPath"] = WorkerConfig.S3BucketForUploadDownloadPrograms;
//    jsonObject["Logging"]["S3BucketRegion"] = WorkerConfig.S3BucketRegionForUploadDownloadPrograms;
//    jsonObject["Logging"]["S3BaseKey"] = "Reports/Publishers/";

//    payload.LogFileDetails = new LogFileDetails() {
//        LogFileName = executerId + "-" + jsonObject["Logging"]["LogFileName"],
//        S3BucketName = jsonObject["Logging"]["S3BucketPath"].ToString(),
//        S3BucketRegion = jsonObject["Logging"]["S3BucketRegion"],
//        S3BaseKey = payload.DeploymentId + "/Logs/" + DateTime.Now.ToString("yyyy_MM_dd")
//    };    
//}

//public Task<ExecutingTaskStatus> RunDebugDecoders(TaskPayload payload, string serverHubURL)
//{
//    log.Info("Worker Received 'RunTask' of type: " + payload.TaskType);

//    var executerId = Guid.NewGuid().ToString();

//    DownloadDebugDecodersProgramAndUncompress();
//}

//public static Dictionary<String, String> Dyn2StringDict(dynamic dynObj)
//{
//    var dictionary = new Dictionary<string, string>();
//    foreach (PropertyDescriptor propertyDescriptor in TypeDescriptor.GetProperties(dynObj))
//    {
//        String obj = propertyDescriptor.GetValue(dynObj);
//        dictionary.Add(propertyDescriptor.Name, obj);
//    }
//    return dictionary;
//}
//public static Dictionary<String, String> Dyn2Dict(dynamic dynObj)
//{
//    var finalDictionary = new Dictionary<string, string>();

//    Dictionary<String, Object> firstDic = FirstDyn2Dict(dynObj);

//    foreach (string key in firstDic.Keys)
//    {
//        if (!(firstDic[key] is JObject))
//        {
//            finalDictionary.Add(key, firstDic[key].ToString());
//        }
//        else //this is JObject
//        {
//            //We have an assumption that only one inner object is allowed
//            Dictionary<String, String> innerDic = Dyn2StringDict(firstDic[key]);

//            foreach (var Key in innerDic.Keys)
//            {
//                finalDictionary.Add(Key, innerDic[Key]);
//            }
//        }
//    }
//    return finalDictionary;
//}


//private async void ReportFlinkListenerTaskIdToHub(string deploymentId, string executerId, string flowExecuterId)
//{
//    if (_workerHubClient.hubConnection.State == HubConnectionState.Connected)
//    {
//        log.Info(string.Format("ReportFlinkListenerTaskIdToHub - Worker Is Sending 'SendProgramMessage' to Flink, with ExecuterId = {0} and FlowExecuterId = {1}", executerId, flowExecuterId));

//        ProgramMessage msg = new ProgramMessage { MessageSource="FDC_WORKER", DeploymentId = deploymentId, ExecuterId = executerId, FlowExecuterId = flowExecuterId, MessageName = "SendFlinkListenerExecuterId" };

//        await _workerHubClient.hubConnection.InvokeAsync("SendProgramMessage", msg);
//    }
//}

//if (payload.TaskId == "7d0e6dc9-d2a0-4b86-a7cf-6b9b5ff9d8fb") //'Wait for clip creation to finish' task
//{
//    executerId = _waitForFlinkToStopExecuterID; //always override the executerId with _waitForFlinkToStopExecuterID for this particular task

//    log.Info(string.Format("RunTask - Worker Is Sending 'SendProgramMessage' to Flink, with DeploymentId = {0}, ExecuterId = {1} and FlowExecuterId = {2}", payload.DeploymentId, executerId, payload.FlowExecuterId));

//    ReportFlinkListenerTaskIdToHub(payload.DeploymentId, executerId, payload.FlowExecuterId);
//}


//private void FindBrokerData()
//{
//    try
//    {
//        Process process = new Process();
//        process.StartInfo.FileName = "python3";
//        process.StartInfo.Arguments = "/auth.py";
//        process.StartInfo.RedirectStandardOutput = true;
//        process.StartInfo.RedirectStandardError = true;
//        process.StartInfo.UseShellExecute = false;
//        process.EnableRaisingEvents = true;
//        process.OutputDataReceived += FindBrokerData_OutputDataReceived;
//        process.Start();

//        process.WaitForExit();
//    }
//    catch (Exception xcp)
//    {
//        log.Info("Exception occuured at FindV4VPodName: " + xcp.Message);
//    }
//}
//private void FindBrokerData_OutputDataReceived(object sender, DataReceivedEventArgs e)
//{

//}
