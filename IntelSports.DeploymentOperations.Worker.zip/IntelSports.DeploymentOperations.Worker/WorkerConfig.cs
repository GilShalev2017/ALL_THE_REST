﻿using Amazon.DynamoDBv2;
using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Worker
{
    public static class WorkerConfig
    {
        public static string FdControllerName { get; set; }
        public static string DeploymentOperationsServerHubURL { get; set; }
        public static int WaitBeforeRetryConnectingInMilliseconds { get; set; }      
        public static string CognitoRegion { get; set; }
        public static string CognitoPoolId { get; set; }
        public static string CognitoAppClientId { get; set; }
        public static string CognitoUserName { get; set; }
        public static string CognitoPassword { get; set; }
        public static string DynamoDBRegion { get; set; }     
        public static string StaicMetadataBucket { get; set; }
        public static string StaicMetadataBucketRegion { get; set; }
        public static string FlinkJobManagerEndpoint { get; set; }
        public static string DeploymentId { get; set; }
        public static string DeploymentRegion { get; set; }
        public static string PlayStatusQueue { get; set; }
        public static string PlayStatusTopic { get; set; }
        public static string MqAuth { get; set; }
        public static string S3BucketForUploadDownloadPrograms { get; set; }
        public static string S3BucketRegionForUploadDownloadPrograms { get; set; }
        public static string ProgramsTableName { get; set; }
        public static string TasksTableName { get; set; }
        public static string FlowsTableName { get; set; }
        public static string CompletedTasksTableName { get; set; }
        public static BrokerData BrokerData { get; set; }
        public static string CognitoIdToken { get; set; }
        public static string GetConfigurationString()
        {
            var result =
                "FdControllerName=" + FdControllerName + "\n" +
                "DeploymentOperationsServerHubURL=" + DeploymentOperationsServerHubURL + "\n" +
                "WaitBeforeRetryConnectingInMilliseconds=" + WaitBeforeRetryConnectingInMilliseconds + "\n" +
                "CognitoRegion=" + CognitoRegion + "\n" +
                "CognitoPoolId=" + CognitoPoolId + "\n" +
                "CognitoAppClientId=" + CognitoAppClientId + "\n" +
                "CognitoUserName=" + CognitoUserName + "\n" +
                "CognitoPassword=" + CognitoPassword + "\n" +
                "DynamoDBRegion=" + DynamoDBRegion + "\n" +
                "StaicMetadataBucket=" + StaicMetadataBucket + "\n" +
                "StaicMetadataBucketRegion=" + StaicMetadataBucketRegion + "\n" +
                "FlinkJobManagerEndpoint=" + FlinkJobManagerEndpoint + "\n" +
                "DeploymentId=" + DeploymentId + "\n" +
                "DeploymentRegion=" + DeploymentRegion + "\n" +
                "S3BucketForUploadDownloadPrograms=" + S3BucketForUploadDownloadPrograms + "\n" +
                "S3BucketRegionForUploadDownloadPrograms=" + S3BucketRegionForUploadDownloadPrograms + "\n" +
                "ProgramsTableName=" + ProgramsTableName + "\n" +
                "TasksTableName=" + TasksTableName + "\n" +
                "FlowsTableName=" + FlowsTableName + "\n" +
                "CompletedTasksTableName=" + CompletedTasksTableName;

            return result;
        }
    }
}
