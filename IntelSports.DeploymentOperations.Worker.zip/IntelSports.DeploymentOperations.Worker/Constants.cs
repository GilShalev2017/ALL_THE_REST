﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Worker
{
    public class Constants
    {
        public const string COLUMN_TASK_ID = "Id";
        public const string COLUMN_TASK_PROGRAM_ID = "ODProgramId";
        public const string COLUMN_TASK_PROGRAM_NAME = "ODProgramName";
        public const string COLUMN_TASK_NAME = "Name";
        public const string COLUMN_TASK_DESCRIPTION = "Description";
        public const string COLUMN_TASK_CATEGORY_GROUP = "CategoryGroup";
        public const string COLUMN_TASK_PROGRAM_TO_EXECUTE = "ProgramToExecute";
        public const string COLUMN_TASK_PROGRAM_PARAMETERS = "ProgramParameters";
        public const string COLUMN_TASK_PARAMS = "TaskParameters";
        public const string COLUMN_REPORT_STDOUT = "ReportStandardOutput";
        public const string COLUMN_WORKING_DIRECTORY = "WorkingDirectory";

        public const string COLUMN_PROGRAM_ID = "Id";
        public const string COLUMN_PROGRAM_NAME = "Name";
        public const string COLUMN_PROGRAM_DESCRIPTION = "Description";
        public const string COLUMN_PROGRAM_PACKAGE = "Package";
        public const string COLUMN_PROGRAM_CATEGORY_GROUP = "CategoryGroup";
        public const string COLUMN_PROGRAM_TYPE = "Type";
        public const string COLUMN_PROGRAM_CONFIG_FILE = "ConfigFile";
        public const string COLUMN_PROGRAM_PREREQUISITES = "Prerequisites";
        public const string COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED = "IsPackageCompressed";
        public const string COLUMN_PROGRAM_EXECUTED_PROGRAM = "ExecutedProgram";
        public const string COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS = "ExecutedProgramParams";

        //FLOWS
        public const string COLUMN_FLOW_ID = "Id";
        public const string COLUMN_FLOW_NAME = "Name";
        public const string COLUMN_FLOW_DESCRIPTION = "Description";
        public const string COLUMN_FLOW_TASKS = "Tasks";
        public const string COLUMN_RUN_IN_PARALLEL = "RunInParallel";

        //FLINK
        public const string FLINK = "Flink";
        public const string FLINK_TASKS = "flink_tasks";
        public const string FLINK_TASKS_ZIP = "flink_tasks.zip";
        public const string FLINK_JARS = "FlinkJars";

        //Publishers
        public const string PUBLISHERS = "Publishers";
        public const string KDS_PUBLISHER_TASKS = "kds_publisher_tasks";
        public const string KDS_PUBLISHER_TASKS_ZIP = "kds_publisher_tasks.zip";
        public const string DEBUG = "Debug";
        public const string DEBUG_KIT_TASKS = "debug_kit_tasks";
        public const string DEBUG_KIT_TASKS_ZIP = "debug_kit_tasks.zip";

        //LOGS 
        public const string MAJOR_ERROR_HAS_OCURRED_IN = "Major Error has ocurred in: ";

        public const string DEPLOYMENT_CONFIGURATION = "DeploymentConfiguration";
        public const string V4_PREPARE_CONFIGURATION = "V4_Prepare_configuration";
    }
}
