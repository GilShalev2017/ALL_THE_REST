#!/bin/sh
dotnet IntelSports.DeploymentOperations.Worker.dll
