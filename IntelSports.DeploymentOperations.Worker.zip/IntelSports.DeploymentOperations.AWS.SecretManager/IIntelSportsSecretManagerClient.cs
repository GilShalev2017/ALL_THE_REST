﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.AWS.SecretManager
{
    public interface IIntelSportsSecretManagerClient
    {
        Task<string> GetAWSSecretValue(string secretId);
        Task<JObject> GetAWSSecretValueAsJObject(string secretId);
    }
}
