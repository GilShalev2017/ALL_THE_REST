﻿using System;
using System.Threading.Tasks;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Newtonsoft.Json.Linq;

namespace IntelSports.DeploymentOperations.AWS.SecretManager
{
    public class IntelSportsSecretManagerClient: IIntelSportsSecretManagerClient
    {
        Amazon.SecretsManager.AmazonSecretsManagerClient client = null;    

        public IntelSportsSecretManagerClient()
        {
            client = new AmazonSecretsManagerClient();
        }

        public IntelSportsSecretManagerClient(string accessKey, string secretKey, Amazon.RegionEndpoint region)
        {
            client = new AmazonSecretsManagerClient(accessKey, secretKey, region);
        }

        public async Task<string> GetAWSSecretValue(string secretId)
        {
            GetSecretValueRequest request = new GetSecretValueRequest() { SecretId = secretId };
           var task = await client.GetSecretValueAsync(request);
            return task.SecretString;
        }

        public async Task<JObject> GetAWSSecretValueAsJObject(string secretId)
        {
            var result = await GetAWSSecretValue(secretId);
            return JObject.Parse(result);
        }

    }
}
