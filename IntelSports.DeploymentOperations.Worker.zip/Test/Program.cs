﻿using System;
using System.Collections.Generic;
using CommandLine;
using System.Linq;
using System.Diagnostics;
using IntelSports.DeploymentOperations.DataAcess.Mongo;
using IntelSports.DeploymentOperations.Model;
using IntelSports.DeploymentOperations.Model.DB;

namespace Test
{


    public class Program

    {
        public static void Main()
        {
            //   DeploymentTask task = new DeploymentTask(){  Description= "My first great task", Name="task1", ProgramToExecute="git", ProgramParameters= "clone https://github.com/necolas/normalize.css.git", ReportStandardOutput=true };

            //MongoDBModel db = new MongoDBModel("deployment");
            //db.InsertRecord("tasks", task);
            //Console.WriteLine("Starting the program");

            var executerId = Guid.NewGuid().ToString();

            var taskPayload = new TaskPayload() {TaskId="12234", DeploymentId="ascd" };
            ITaskExecuter taskExecuter = new SystemProcessTaskExecuter("https://localhost:44389/TaskProcessHub", taskPayload, executerId);

            ODTask deploymentTask = new ODTask();
            var task = taskExecuter.ExecuteTask(deploymentTask);// "100");
            //  Kill the process
            //deploymetnTask.Result.TaskProcess.Kill();
            task.Wait();

        }   
    }
}
