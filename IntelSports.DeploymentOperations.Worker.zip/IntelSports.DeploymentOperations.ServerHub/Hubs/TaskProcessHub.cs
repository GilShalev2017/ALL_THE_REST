﻿using IntelSports.DeploymentOperations.Model.DB;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.ServerHub.Hubs
{
    [Authorize]
    public class TaskProcessHub : Hub<IWorkerClient>
    {
        //static List<string> _connectedClientList = new List<string>();
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static Dictionary<string, List<FdController>> _opDockersPerDeployment = new Dictionary<string, List<FdController>>();

        public TaskProcessHub()
        {

        }

        #region Worker commands
        public async Task RegisterWorker(FdController fdController)
        {
            if (!string.IsNullOrEmpty(fdController.Name) && !string.IsNullOrEmpty(fdController.DeploymentId))
            {
                log.Info(string.Format("RegisterWorker - Worker client registering on Server. with Name = {0}, In deployment = {1}", fdController.Name, fdController.DeploymentId));
            }
            else
            {
                log.Info("RegisterWorker - Worker client registering on Server");
            }

            await Groups.AddToGroupAsync(Context.ConnectionId, "WorkerClients");
            // await Groups.AddToGroupAsync(Context.ConnectionId, fdController.DeploymentId);

            fdController.ConnectionStatus = "Success";
            fdController.ConnectionId = Context.ConnectionId;

            AddRegisteredWorkerToDictionary(fdController);

            //Notify clients and worker about new worker connection!
            await Clients.Caller.OnRegisteredWorkerStatus(fdController);
            await Clients.Group("UIClients").OnRegisteredWorkerStatus(fdController);

            List<string> workerConnectedDeployments = GetWorkerConnectedDeploymentsList();

            //Notify clients so they update their list
            await Clients.Group("UIClients").OnWorkerConnectedDeploymentsReceived(workerConnectedDeployments);
        }

        private void AddRegisteredWorkerToDictionary(FdController fdController)
        {
            if (!_opDockersPerDeployment.ContainsKey(fdController.DeploymentId))
            {
                List<FdController> dockers = new List<FdController>
                {
                    fdController
                };

                _opDockersPerDeployment.Add(fdController.DeploymentId, dockers);
            }
            else
            {
                _opDockersPerDeployment[fdController.DeploymentId].Add(fdController);
            }
        }

        #endregion Worker commands

        #region Worker Notifications To Propagate to client
        public async Task ExecutingTaskStatus(ExecutingTaskStatus executingTaskStatus)
        {
            log.Info("TaskExecuterHubClient sending executing task status.");

            // Notify all UIs
            //For the sake of the UI fill the status as String - remove later
            executingTaskStatus.StatusString = executingTaskStatus.Status.ToString();

            await Clients.Group("UIClients").OnTaskStatusReport(executingTaskStatus);

            //TODO is it really needed to send to calling client - like???
            //    await Clients.Caller.OnTaskXXX("Success");
            //await Clients.Caller.OnTaskStartingStatus("Success");
        }

        public async Task OutputDataReceived(ExecutingTaskData executingTaskData)
        {
            log.Info("Task Execution Process SignalR of receiving StdOut.");

            // Notify all UIs
            await Clients.Group("UIClients").OutputDataReceived(executingTaskData);
        }

        public async Task ExecutingFlowStatus(ExecutingFlowStatus executingFlowStatus)
        {
            log.Info("ExecutionManager sending executing flow status.");

            // Notify all UIs
            //For the sake of the UI fill the status as String - remove later
            executingFlowStatus.StatusString = executingFlowStatus.Status.ToString();

            await Clients.Group("UIClients").OnFlowStatusReport(executingFlowStatus);
        }

        #endregion Worker Notifications To Propagate to Client

        #region UI commands
        public async Task RegisterUI()
        {
            log.Info("Server Hub received request from UI client to Register UI ");

            await Groups.AddToGroupAsync(Context.ConnectionId, "UIClients");

            await Clients.Caller.OnUIRegisteredStatus("Success");
        }


        public async Task Test3()
        {
            log.Info("Test3 has been called");
            Console.WriteLine("Test3 has been called");
            await Task.FromResult("");
        }

        public async Task StartTask(TaskPayload payload)
        {
            log.Info("Server Hub received request from client to StartTask with id:" + payload.TaskId);

            log.Info("Server Hub received the following payload:\n");

            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(payload))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(payload);
                log.Info(string.Format("{0}={1}", name, value));
            }

            //  ToDo: What if the group "WorkerClients" is empty. Needs handling
            await Clients.Group("WorkerClients").StartTask(payload);

            //should be routed only to relevant workers!
            //await Clients.Group(payload.DeploymentId).StartTask(payload);
        }

        public async Task StopTask(TaskPayload payload)
        {
            log.Info("Server Hub received request from client to Stop Process through executer with Id:" + payload.ExecuterId);

            await Clients.Group("WorkerClients").StopTask(payload);

            //should be routed only to relevant workers!
            //await Clients.Group(payload.DeploymentId).StopTask(payload);
        }

        public async Task StartFlow(FlowPayload payload)
        {
            log.Info("Server Hub received request from client to Start a Flow with id:" + payload.FlowId);

            //  ToDo: What if the group "WorkerClients" is empty. Needs handling
            await Clients.Group("WorkerClients").StartFlow(payload);

            //should be routed only to relevant workers!
            //await Clients.Group(payload.DeploymentId).StartFlow(payload);
        }

        public async Task StopFlow(FlowPayload payload)
        {
            log.Info("Server Hub received request from client to Stop the Flow with Id:" + payload.FlowExecuterId);

            await Clients.Group("WorkerClients").StopFlow(payload);
            //await Clients.Group(payload.DeploymentId).StopFlow(payload);
        }

        public async Task GetFdControllerList(string deploymentId)
        {
            log.Info("Server Hub received request from client to return list of worker dockers");
            
            if (string.IsNullOrEmpty(deploymentId))
                return;

            if (_opDockersPerDeployment.ContainsKey(deploymentId))
            {
                await Clients.Group("UIClients").OnFdControllerListReceived(_opDockersPerDeployment[deploymentId]);
            }
            else
            {
                await Clients.Group("UIClients").OnFdControllerListReceived(null);
            }
        }

        public async Task GetWorkerConnectedDeployments()
        {
            List<string> workerConnectedDeployments = GetWorkerConnectedDeploymentsList();

            await Clients.Group("UIClients").OnWorkerConnectedDeploymentsReceived(workerConnectedDeployments);
        }

        private List<string> GetWorkerConnectedDeploymentsList()
        {
            var keyCollection = _opDockersPerDeployment.Keys;

            List<string> workerConnectedDeployments = keyCollection.Cast<string>().ToList();

            return workerConnectedDeployments;
        }

        public async Task StartFlinkTask(FlinkTaskPayload payload)
        {
            log.Info("Server Hub received request from client to StartFlinkTask of type: " + payload.FlinkTaskType);

            //  ToDo: What if the group "WorkerClients" is empty. Needs handling
            await Clients.Group("WorkerClients").StartFlinkTask(payload);

            //await Clients.Group(payload.DeploymentId).StartFlinkTask(payload);
        }
        //public async Task StopFlinkTask(string flinkExecuterId)
        //{
        //    Console.WriteLine("Server Hub received request from client to Stop the Flink task with id:" + flinkExecuterId);

        //    await Clients.Group("WorkerClients").StopFlow(flinkExecuterId);
        //}

        public async Task RefreshTasks()
        {
            log.Info("Server Hub received: RefreshTasks ");

            // Notify all UIs that Stop
            await Clients.Group("WorkerClients").RefreshTasks();
        }
        #endregion UI commands

        #region Task commands & notifications

        //public async Task RegisterProgram()
        //{
        //    log.Info("Server Hub received request from a Program to register itself ");

        //    await Groups.AddToGroupAsync(Context.ConnectionId, "ProgramClients");

        //    await Clients.Caller.OnProgramRegisteredStatus("Success");
        //}

        public async Task SendProgramMessage(ProgramMessage payload) //I think that we do want to expose only Program events to Programs and not worker events
        {
            if (!string.IsNullOrEmpty(payload.MessageSource))
            {
                log.Info(string.Format("SendProgramMessage - Server Hub received request from program = {0} to send message with the name = {1}, in deployment = {2}",payload.MessageSource, payload.MessageName, payload.DeploymentId));
            }
            else
            {
                log.Info(string.Format("SendProgramMessage - Server Hub received request to send message with the name = {0}, in deployment = {1}", payload.MessageName, payload.DeploymentId));
            }
            await Clients.Group("WorkerClients").SendProgramMessage(payload);
            //await Clients.Group("ProgramClients").SendProgramMessage(payload);
        }

        #endregion

        public async Task StopTaskCompleted()
        {
            log.Info("Server Hub received: StopTaskCompleted ");

            // Notify all UIs that Stop
            await Clients.Group("UIClients").StopTaskCompleted();
        }

        #region Hub inner notifications
        public override async Task OnConnectedAsync()
        {
            log.Info("Connection Id: " + Context.ConnectionId + " has been established");
          
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            log.Info("Connection Id: " + Context.ConnectionId + " has been disconnected");

            await Groups.RemoveFromGroupAsync(Context.ConnectionId, "WorkerClients");
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, "UIClients");

            //Remove op docker from list and update the clients
            foreach (var list in _opDockersPerDeployment.Values)
            {
                foreach (FdController docker in list)
                {
                    if (docker.ConnectionId == Context.ConnectionId)
                    {
                        list.Remove(docker);

                        await Clients.Group("UIClients").OnFdControllerListReceived(list);

                        break;
                    }
                }
            }

            List<string> workerConnectedDeployments = GetWorkerConnectedDeploymentsList();
            await Clients.Group("UIClients").OnWorkerConnectedDeploymentsReceived(workerConnectedDeployments);

            await base.OnDisconnectedAsync(exception);
        }
        #endregion
    }
}