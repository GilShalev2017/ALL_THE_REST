﻿using System;

namespace Intel.Freed.KinesisDataSream.Models
{
    public class KinesisDataStreamProcessRecordsResponse
    {
        public bool Status { get; set; }
        public int RecordsProcessed { get; set; }
    }
}
