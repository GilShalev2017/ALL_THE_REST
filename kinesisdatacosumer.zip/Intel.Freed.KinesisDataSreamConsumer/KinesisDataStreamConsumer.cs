﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Amazon.Kinesis;
using Amazon.Kinesis.Model;
using Intel.Freed.KinesisDataSream.Interfaces;
using Intel.Freed.KinesisDataSream.Models;

namespace Intel.Freed.KinesisDataSreamConsumer
{
    public class KinesisDataStreamConsumer : IKinesisDataStreamConsumer
    {
        protected AmazonKinesisClient client = null;
        public string StreamName { get; set; }
        public ShardIteratorType shardIteratorType { get; set; }

        public KinesisDataStreamConsumer(string awsAccessKeyId, string awsSecretAccessKey, Amazon.RegionEndpoint awsRegion, string streamName, ShardIteratorType shardIteratorType)
        {
            this.StreamName = streamName;
            this.shardIteratorType = shardIteratorType;
            client = new AmazonKinesisClient(awsAccessKeyId, awsSecretAccessKey, awsRegion);
        }

        private async Task<DescribeStreamResponse> GetShards()
        {
            DescribeStreamRequest describeRequest = new DescribeStreamRequest();
            describeRequest.StreamName = this.StreamName;
            return await client.DescribeStreamAsync(describeRequest);
        }

        public async Task<KinesisDataStreamProcessRecordsResponse> ProcessRecords(IKinesisDataStreamRecordProcessing iKinesisDataStreamRecordProcessing)
        {
            var shards = GetShards();
            return await ProcessRecords(shards.Result.StreamDescription.Shards, iKinesisDataStreamRecordProcessing);
        }


        private async Task<KinesisDataStreamProcessRecordsResponse> ProcessRecords(List<Shard> shards, IKinesisDataStreamRecordProcessing iKinesisDataStreamRecordProcessing)
        {
            KinesisDataStreamProcessRecordsResponse response = null;

            foreach (Shard s in shards)
            {
                GetShardIteratorRequest iteratorRequest = new GetShardIteratorRequest();
                iteratorRequest.StreamName = this.StreamName;
                iteratorRequest.ShardId = s.ShardId;
                iteratorRequest.ShardIteratorType = shardIteratorType;// ShardIteratorType.LATEST;
                GetShardIteratorResponse iteratorResponse = await client.GetShardIteratorAsync(iteratorRequest);
                response = await ProcessRecords(iteratorResponse.ShardIterator, 1000, iKinesisDataStreamRecordProcessing);               
            }
            return response;
        }

        public async Task<KinesisDataStreamProcessRecordsResponse> ProcessRecords(string shardIterator, int maximumRecordsToReturn, IKinesisDataStreamRecordProcessing iKinesisDataStreamRecordProcessing)
        {
            KinesisDataStreamProcessRecordsResponse response = null;
            while (!string.IsNullOrEmpty(shardIterator))
            {
                GetRecordsRequest newrequest = new GetRecordsRequest();
                newrequest.Limit = maximumRecordsToReturn;
                newrequest.ShardIterator = shardIterator;
                var getRecordsResponse = await client.GetRecordsAsync(newrequest);
                shardIterator = getRecordsResponse.NextShardIterator;
                response = await iKinesisDataStreamRecordProcessing.ProcessRecords(getRecordsResponse.Records);                
            }
            
            return response;
        }

    }
}
