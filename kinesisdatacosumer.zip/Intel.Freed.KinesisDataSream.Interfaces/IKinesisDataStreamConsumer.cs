﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Intel.Freed.KinesisDataSream.Models;

namespace Intel.Freed.KinesisDataSream.Interfaces
{
    public interface IKinesisDataStreamConsumer
    {
        Task<KinesisDataStreamProcessRecordsResponse> ProcessRecords(IKinesisDataStreamRecordProcessing iKinesisDataStreamRecordProcessing);
    }
}
