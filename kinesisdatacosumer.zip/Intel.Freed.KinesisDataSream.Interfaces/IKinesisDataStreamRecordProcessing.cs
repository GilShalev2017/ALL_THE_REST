﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Amazon.Kinesis.Model;
using Intel.Freed.KinesisDataSream.Models;

namespace Intel.Freed.KinesisDataSream.Interfaces
{
    public interface IKinesisDataStreamRecordProcessing
    {
        Task<KinesisDataStreamProcessRecordsResponse> ProcessRecords(List<Record> records);
    }
        
}
