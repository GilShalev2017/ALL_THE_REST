# Kinesis Data Consumer
This program allows you to read from Kinesis Data Streams.


## How to build on windows
1. Clone the repository : git clone https://jdaka@bitbucket.il.alm-sg.com/scm/rp/kinesisdatacosumer.git
1. cd KinesisDataCosumer
1. Execute the command : dotnet restore
1. Execute the command : dotnet publish -c release -r win10-x64      
1. Copy the entire folder ~\KinesisDataCosumer\bin\Release\netcoreapp2.1\win10-x64\publish to your desired location
1. To call the program, execute "KinesisDataCosumer.exe"
1. Note that KinesisDataCosumer.exe logs all erros in "KinesisDataCosumer.log"

## How to configure KinesisDataCosumer
To configure KinesisDataCosumer, open the Json file KinesisDataCosumer.json which should look like the following file and change the keys to your own keys. The keys are self-explanatory

{
    "AppSettings": {
        "FramesBaseDirectory": "D:\\MS01",
        "kinesisStreamName": "your stream name",
        "AWSAccessKey": "Your AWS Access Key",
        "AWSSecretkey": "Your AWS Secret Key",
        "AWSRegion": "eu-west-1",
        "LogFileName": "KinesisDataCosumer.log"
    }
}



## Ready Binaries
If you do not want to build the program, you can simply downlad the binaries from the S3 bucket named "fd-19-binaries" under the folder "KinesisDataCosumer" on AWS account number "753274046439" (Jay's account). Download all files to your desired location and simply execute "KinesisDataCosumer.exe"


