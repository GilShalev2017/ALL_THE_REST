﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Amazon.Kinesis;
using Amazon.Kinesis.Model;
using Amazon.Runtime.Internal.Util;
using Intel.Freed.KinesisDataSream.Interfaces;
using Intel.Freed.KinesisDataSreamConsumer;
using Intel.Freed.KinesisDataStreamRecordProcessor;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog;
using Logger = NLog.Logger;

namespace KinesisDataCosumer
{
    class Program
    {

        static void Main(string[] args)
        {

            Logger logger = null;

            try
            {
                //  Read Json Configuration file
                IConfiguration config = new ConfigurationBuilder().AddJsonFile("KinesisDataConsumer.json", true, true).Build();

                //  Add logging
                var logConfig = new NLog.Config.LoggingConfiguration();
                var logfile = new NLog.Targets.FileTarget("logfile")
                {
                    ArchiveAboveSize = 2 * 1024 * 1024,
                    FileName = config.GetSection("AppSettings")["LogFileName"],
                    ArchiveNumbering = NLog.Targets.ArchiveNumberingMode.DateAndSequence
                };

                logConfig.AddRule(LogLevel.Info, LogLevel.Fatal, logfile);
                NLog.LogManager.Configuration = logConfig;
                logger = NLog.LogManager.GetCurrentClassLogger();

                logger.Info("KinesisDataConsumer has launched");

                //  Read all configuration keys from Json File  
                string streamName = config.GetSection("AppSettings")["kinesisStreamName"];
                string accessKey = config.GetSection("AppSettings")["AWSAccessKey"];
                string secretKey = config.GetSection("AppSettings")["AWSSecretkey"];
                string outputBaseDirectory = config.GetSection("AppSettings")["OutputBaseDirectory"];
                string outputFileName = config.GetSection("AppSettings")["OutputFileName"];
                string startFrameIndex = config.GetSection("AppSettings")["StartFrameIndex"];
                string readFromStreamBeginning = config.GetSection("AppSettings")["ReadFromStreamBeginning"].ToLower();

                ShardIteratorType shardIteratorType = ShardIteratorType.TRIM_HORIZON;

                if(readFromStreamBeginning == "true")
                {
                    shardIteratorType = ShardIteratorType.LATEST;
                }

                Amazon.RegionEndpoint region = Amazon.RegionEndpoint.GetBySystemName(config.GetSection("AppSettings")["AWSRegion"].ToString());

                //  Consume records and process them
                IKinesisDataStreamConsumer iKinesisDataStreamConsumer = new KinesisDataStreamConsumer(accessKey, secretKey, region, streamName, shardIteratorType);
                IKinesisDataStreamRecordProcessing cvtRecordProcessor = new CVTDataStreamProcessor(outputBaseDirectory, startFrameIndex, outputFileName);
                var task = iKinesisDataStreamConsumer.ProcessRecords(cvtRecordProcessor);
                task.Wait();
            }
            catch (Exception exc)
            {
                logger.Error(exc);
            }
        }

    }
}
