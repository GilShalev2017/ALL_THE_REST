﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KinesisDataCosumer
{
    public class Item
    {
        public string Id;
        public string Name;
    }
}
