﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Amazon.Kinesis.Model;
using Intel.Freed.KinesisDataSream.Interfaces;
using Intel.Freed.KinesisDataSream.Models;
using Newtonsoft.Json.Linq;

namespace Intel.Freed.KinesisDataStreamRecordProcessor
{
    public class CVTDataStreamProcessor : IKinesisDataStreamRecordProcessing
    {
        protected string directory;
        protected string startFrameIndex;
        protected string outputFileName;

        public CVTDataStreamProcessor(string directory, string startFrameIndex, string outputFileName)
        {
            this.directory = directory;
            this.startFrameIndex = startFrameIndex;
            this.outputFileName = outputFileName;
        }
        protected int recordCount;
        public async Task<KinesisDataStreamProcessRecordsResponse> ProcessRecords(List<Record> records)
        {
            return await Task.Factory.StartNew(() =>
            {
                Console.WriteLine("Reading " + records.Count + " records");

                foreach (Record record in records)
                {
                    JObject jobject =  CleanJson(Encoding.UTF8.GetString(record.Data.ToArray()));

                    if (jobject["frameID"] != null)
                    {
                        string frameID = jobject["frameID"].ToString();

                        string frameDirectory = "F" + (Convert.ToInt32(frameID) - Convert.ToInt32(startFrameIndex)).ToString("D8");

                        string outputDirectory = Path.Join(directory, frameDirectory);

                        if(!Directory.Exists(outputDirectory))
                        {
                            Directory.CreateDirectory(outputDirectory);
                        }

                        File.WriteAllText(Path.Join(outputDirectory, outputFileName), jobject.ToString());
                    }
                    else if(jobject["frameId"] != null)
                    {
                        string frameID = jobject["frameId"].ToString();

                        string frameDirectory = "F" + (Convert.ToInt32(frameID) - Convert.ToInt32(startFrameIndex)).ToString("D8");

                        string outputDirectory = Path.Join(directory, frameDirectory);

                        if (!Directory.Exists(outputDirectory))
                        {
                            Directory.CreateDirectory(outputDirectory);
                        }

                        File.WriteAllText(Path.Join(outputDirectory, outputFileName), jobject.ToString());
                    }
                }

                return new KinesisDataStreamProcessRecordsResponse() { RecordsProcessed = records.Count, Status = true };
            }
            );


        }

        private JObject CleanJson(string json)
        {
            if (string.IsNullOrEmpty(json))
                return null;
           
            string val = Regex.Unescape(json).Trim();
            if (val.StartsWith("\""))
            {
                val = val.Substring(1).TrimEnd();
            }

            if (val.EndsWith("\""))
            {
                val = val.Substring(0, val.Length - 1);
            }

            return JObject.Parse(val);
        }
    }
}
