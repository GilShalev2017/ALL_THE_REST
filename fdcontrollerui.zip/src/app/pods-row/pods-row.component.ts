import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Pod } from "../models/Pod";
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { animate, state, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-pods-row',
  templateUrl: './pods-row.component.html',
  styleUrls: ['./pods-row.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class PodsRowComponent implements OnInit {

  displayedColumns: string[] = ['Name', 'Ready', 'Status', 'Restarts', 'Age', 'actions'];
  index: number;
  @ViewChild(MatSort, {static: true}) sorter1: MatSort;

  bindedDataSource;

  private _children: Pod[] = [];
  @Input() 
  get children(): Pod[] { return this._children; }
  set children(arr: Pod[]) {
    this._children = arr;
    this.bindedDataSource = new MatTableDataSource(arr);
    this.bindedDataSource.sort = this.sorter1;
  }
  
  expandedElement: Pod | null;

  ngOnInit(): void {
  }
}
