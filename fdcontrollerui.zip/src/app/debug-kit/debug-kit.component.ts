import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OperationsService } from "../services/operations.service";
import { DebugKitOperation } from "../models/DebugKitOperation";
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { MatRadioModule, MatRadioChange } from '@angular/material/radio';
import { UIExecutingTask } from "../models/UIExecutingTask";
import { faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye } from '@fortawesome/free-solid-svg-icons';
import { ODTask } from "../models/ODTask";
import { S3ImageViewerComponent } from '../s3-image-viewer/s3-image-viewer.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-debug-kit',
  templateUrl: './debug-kit.component.html',
  styleUrls: ['./debug-kit.component.css']
})
export class DebugKitComponent implements OnInit {
 
  public editorOptions: JsonEditorOptions;
  framesRangeGroup: FormGroup;
  additionalParameters: FormGroup;
  runDebugKitGroup: FormGroup;
  
  uploadModulesConfigsToS3: boolean;
  uploadInputMaterialsToS3: boolean;
  uploadAllPodsImagesFileToS3: boolean;
  uploadModulesOutputsToS3: boolean;
  uploadVenueFoldersToS3: boolean;
  copyToClipboardForForRender: string;

  _mode: string;
  _moduleToRunOn: string = "0";
  _moduleToRunOnString: string = "decode";
  _templateType: string = "1";
  _camera: string = "0";
  // _comment: string;
  faStop = faStop;
  selectedOperation: string;
  selectedTemplate: string = "root/frame/module";
  selectedIpModule;
  
  @ViewChild(JsonEditorComponent) editor: JsonEditorComponent;

  constructor(private _formBuilder: FormBuilder,
              public dialog: MatDialog,
              public operationsService: OperationsService) { 
                 this.editorOptions = new JsonEditorOptions();
                 this.editorOptions.modes = ['code', 'text', 'tree', 'view'];
  }

 
  ngOnInit() {

    if(this.operationsService.isTasksLoaded==false) {
      this.operationsService.getODTasks()
        .subscribe( (arrivedData: ODTask[]) => {
      });
    }

    this.framesRangeGroup = this._formBuilder.group({
      firstFrame: ['', Validators.required],
      endFrame: [''],
      jumps: [''],
      module: [''],
      comment:[''],
    });
  
    this.additionalParameters = this._formBuilder.group({
      localRootForOutputs: [''],
      cameraToRunOn: ['']
    });

    this.runDebugKitGroup = this._formBuilder.group({
    });

    if(this.operationsService.isDebuKitConfigLoaded==false) {

      this.operationsService.getDebugKitConfigContent()
        .subscribe( result2 => {
          
        });
    }

    //this.getImagePresignedUrl("vcam10_F00200200.jpg");
  }
 
  runDebugKit() {
   
    this.operationsService.DebugKitIsRunning = true;

    this.operationsService.debugKitTasks = [];

    let currentConfigDataObj = this.editor.get();
  
    let currentConfigDataString = JSON.stringify(currentConfigDataObj);
 
    let dynamicParameters = "--frame "  + this.framesRangeGroup.value['firstFrame'];

    if(this.framesRangeGroup.value['endFrame']) {
      dynamicParameters = dynamicParameters + " --endFrame " + this.framesRangeGroup.value['endFrame'];
    }

    if(this.selectedIpModule && this.selectedIpModule.length >= 1)
    {
      dynamicParameters = dynamicParameters + " --module " + this.selectedIpModule;
    }

    if(this.framesRangeGroup.value['jumps']!= "") {
      dynamicParameters = dynamicParameters + " --jumps " + this.framesRangeGroup.value['jumps'];
    }

    if(this.framesRangeGroup.value['comment'])
    {
      this.fixCommentString();
      dynamicParameters = dynamicParameters + " --c " + "\"" + this.framesRangeGroup.value['comment'] +"\"";
    }

    dynamicParameters = dynamicParameters + " --mode " + this._mode;

    if(this._mode == '2') {

      this.uploadModulesConfigsToS3 ? dynamicParameters = dynamicParameters + " y" : dynamicParameters = dynamicParameters + " n";
      this.uploadInputMaterialsToS3 ? dynamicParameters = dynamicParameters + " y" : dynamicParameters = dynamicParameters + " n";
      this.uploadAllPodsImagesFileToS3 ? dynamicParameters = dynamicParameters + " y" : dynamicParameters = dynamicParameters + " n";
      this.uploadModulesOutputsToS3 ? dynamicParameters = dynamicParameters + " y" : dynamicParameters = dynamicParameters + " n";
      this.uploadVenueFoldersToS3 ? dynamicParameters = dynamicParameters + " y" : dynamicParameters = dynamicParameters + " n";
    
      if(this.uploadModulesOutputsToS3) {
        dynamicParameters = dynamicParameters + " " + this._templateType;
      }
    }
    else if(this._mode == '5'){
      dynamicParameters = dynamicParameters + " " + this._camera + " " + this._moduleToRunOn;
    }

    this.operationsService.startDebugKit(currentConfigDataString, dynamicParameters, this.selectedOperation);
  }

  onChangeTemplate(mrChange: MatRadioChange) {
    this._templateType = mrChange.value;
    
    switch(this._templateType) { 
      case "1": { 
          this.selectedTemplate = "root/frame/module";
          break; 
      } 
      case "2": { 
          this.selectedTemplate = "root/module/frame"; 
          break; 
      } 
    }

  }
  onChange(mrChange: MatRadioChange) {
    if(mrChange.value == null)
      return;
      
    this.operationsService.debugKitTasks = [];

    console.log(mrChange.value);
    this._mode = mrChange.value;

    switch(this._mode) { 
      case "1": { 
          this.selectedOperation = "Render debug-kit";
          break; 
      } 
      case "2": { 
          this.selectedOperation = "Upload materials and configs"; 
          break; 
      } 
      case "3": { 
          this.selectedOperation = "Count outputs";
          break; 
      } 
      case "4": { 
          this.selectedOperation = "Convert raw to jpeg"; 
          break; 
      } 
      case "5": { 
          this.selectedOperation = "Convert yuv to jpeg"; 
          break; 
      } 
      case "6": { 
          this.selectedOperation = "Create video from renderer output"; 
          break; 
      } 
    } 
    
    // let mrButton: MatRadioButton = mrChange.source;
    // console.log(mrButton.name);
    // console.log(mrButton.checked);
    // console.log(mrButton.inputId);
    // console.log(mrButton.radioGroup.name);
  } 

  onChangeModuleToRunOn(mrChange: MatRadioChange) {
    console.log(mrChange.value);
    this._moduleToRunOn = mrChange.value;
      switch(this._moduleToRunOn) { 
        case "0": { 
            this._moduleToRunOnString = "decode";
            break; 
        } 
        case "1": { 
            this._moduleToRunOnString = "multiview"; 
            break; 
        } 
     }
  }

  stopTask(task: UIExecutingTask, event?: Event){
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.stopTask(task.ExecutingTaskStatus.executerId);
  }

  cleanHistory() {
    this.operationsService.debugKitTasks = [];
  }

  // getImagePresignedUrl(imgName) {
 
  //   this.operationsService.getProgramPresignedUrlForReport(imgName)
  //       .subscribe(result => {
  //         this.imgUrl = result['URL_STRING'];
   
  //         // window.open(this.imgUrl, "_blank");
  //       });
  // }

 
  getLog(executerId: string) {
   
    if (event) {
        event.stopPropagation();
    } 

    let reportName = "DebugKit/" + this.operationsService.selectedDeployment.deployment_id + "/" + executerId + "_debugKit.log";
    
    this.operationsService.getProgramPresignedUrlForReport(reportName)
        .subscribe(result => {
          let reportUrl = result['URL_STRING'];
          // location.go(reportUrl);
          window.open(reportUrl, "_blank");
        });
  }

  getImage(task: UIExecutingTask, event) {

    if (event) {
        event.stopPropagation();
    }

    //https://s3.console.aws.amazon.com/s3/buckets/debug-kits/e02v4402wul18nh/15102020_094808/F50100-50100/?region=us-east-1&tab=overview
        
    let segments = "https://s3.console.aws.amazon.com/s3/buckets/debug-kits/e02v4402wul18nh/15102020_094808/F50100-50100/?region=us-east-1&tab=overview".split("/");
    
    if(task!=null)
    {
      segments = task.ExecutingTaskStatus.s3DebugKitBucketUrl.split("/");
    }
        
    let bucketBaseKey = segments[6] + "/" + segments[7] + "/" + segments[8];
    
    let bucketName = 'debug-kits';
    let bucketRegion = 'us-east-1';
    
    this.operationsService.getBucketFileTree(bucketName,bucketBaseKey,bucketRegion)
      .subscribe(data => {

        let filesPrefix = segments[6] + "/" + segments[7];

        const dialogRef = this.dialog.open(S3ImageViewerComponent, {
          data: 
          {
            "filesPrefix": filesPrefix,
            "bucketName": "debug-kits",
            "bucketRegion": "us-east-1",
            "s3BucketUrl": task?.ExecutingTaskStatus?.s3DebugKitBucketUrl
          },
          maxWidth: '90vw',
          maxHeight: '90vh',
          height: '90%',
          width: '90%'
        });
       
      });
    
  }

  openS3Bucket(task: UIExecutingTask, event) {
    if (event) {
      event.stopPropagation();
    } 

    if(this._mode=="1") {
      //https://s3.console.aws.amazon.com/s3/buckets/production-v4/debug-kits/NFL/Arizona_Cardinals/orelAllMighty_1000-1000_08092020_125209/?region=us-east-1
      let url = "https://s3.console.aws.amazon.com/s3/buckets/production-v4/debug-kits/" + task.SportGroupInformation + "/" + task.VenueInformation + "/" + task.GameID + "_" + task.ExecutingTaskStatus.s3BucketUrl + "/?region=us-east-1";
      this.copyToClipboardForForRender = url;
      console.log(url);
      window.open(url, "_blank");
    }
    else{
      console.log(task.ExecutingTaskStatus.s3DebugKitBucketUrl);
      window.open(task.ExecutingTaskStatus.s3DebugKitBucketUrl, "_blank");
    }
  }

  stopIt(task: UIExecutingTask, event) {
    event.stopPropagation();
    if(this._mode=="1") {
      let url = "https://s3.console.aws.amazon.com/s3/buckets/production-v4/debug-kits/" + task.SportGroupInformation + "/" + task.VenueInformation + "/" + task.GameID + "_" + task.ExecutingTaskStatus.s3BucketUrl + "/?region=us-east-1";
      this.copyToClipboardForForRender = url;
    }
  }

  fixCommentString() {
    this.framesRangeGroup.value['comment'] = this.framesRangeGroup.value['comment'].replace(/\s+/g, '_');
  }

}
