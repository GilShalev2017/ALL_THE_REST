import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { ProgramsService } from "../services/programs.service";
import { FormControl, Validators } from '@angular/forms';
import { ODProgram, CategoryGroup, ProgramType } from "../models/ODProgram";

@Component({
  selector: 'app-edit-program',
  templateUrl: './edit-program.component.html',
  styleUrls: ['./edit-program.component.css']
})
export class EditProgramComponent  {

  _presignedUrl:string;
  _file;
  _isUploading:boolean = false;

  constructor(public dialogRef: MatDialogRef<EditProgramComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODProgram, 
              public dataService: ProgramsService) { }



  formControl = new FormControl('', [
    Validators.required
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  stopEdit(): void {

    switch(this.data.ProgramTypeString) { 
      case "dotnet": { 
          this.data.ProgramType = ProgramType.dotnet;
          break; 
      } 
      case "java": { 
          this.data.ProgramType = ProgramType.java;
          break; 
      } 
      case "python": { 
          this.data.ProgramType = ProgramType.python;
          break; 
      } 
      case "python3": { 
          this.data.ProgramType = ProgramType.python3;
          break; 
      } 
      case "bashScript": { 
          this.data.ProgramType = ProgramType.bashScript;
          break; 
      } 
      case "golang": { 
          this.data.ProgramType = ProgramType.golang;
          break; 
      } 
      case "windowsBatchScript": { 
          this.data.ProgramType = ProgramType.windowsBatchScript;
          break; 
      } 
    }

    if(this._file) { //do we need to upload a new package?
      this._isUploading = true;

      this.dataService.sendRefreshProgram(this.data.Id);
      
      this.dataService.deleteProgramFromS3(this.data)
        .subscribe( x => {
          // Get Presigned url
          this.dataService.getProgramPresignedUrl(this.data.Name, this.data.Package, this.data.CategoryGroupString)
            .subscribe( (url: string) => {
              this._presignedUrl = url['URL_STRING'];

              //  Upload to uploadFileToS3
              if(this.dataService.uploadFileToS3(this._presignedUrl, this._file) == true)
              {
                  //  Update in DynamoDB
                  this.dataService.updateProgram(this.data);
                  this._isUploading = false;
                  this.dialogRef.close(1);
              }
          });
        });
    }
    else{ //just update some of the fields, no upload file is needed
       this.dataService.updateProgram(this.data);
       this.dialogRef.close(1);
    }
  }

  getFiles(event) {
    this._file = event.target.files[0];
    this.data.Package = event.target.files[0].name;
  }
}
