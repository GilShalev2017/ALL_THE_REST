import { Component, OnInit } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { ODTask } from "../models/ODTask";

@Component({
  selector: 'app-prepare-deployment',
  templateUrl: './prepare-deployment.component.html',
  styleUrls: ['./prepare-deployment.component.css']
})
export class PrepareDeploymentComponent implements OnInit {

  _pathToVenueInS3: string;
  _pathToDataInS3: string;
  _dataStartFrame: string;
  _dataEndFrame: string;
  _useRealCVT: boolean;
  _selectedDeploymentType: string; //mini/full
  //_selectedDataStreamer: string;

  _copyDataSet= 1;
  _copyVenue  = 1;
  _configureLustre = 1;
  _configureCVT  = 0;
  _runAutoini = 1;
  _restartPods = 1;
  _deploymentInfraTool = 1;
  
  _selectedTeam: string;
  _teams: string[] = ['49ers', 'chiefs', 'patriots', 'titans', 'panthers', 'browns', 'redskins', 'ravens', 'falcons', 'cardinals', 'texans', 'vikings', 'colts', 'bills', 'dolphins', 'buccaneers'];

  _configObject;

  constructor(public operationsService: OperationsService) { }

  ngOnInit(): void {

    // if(this.operationsService.isPrepareDeploymentConfigLoaded==false) {

      this.operationsService.getPrepareDeploymentConfigContent()
        .subscribe( jsonObject => {
          this._configObject = jsonObject;
          this.initOptionals(jsonObject);
        });
    // }

     if(this.operationsService.isTasksLoaded==false) {
        this.operationsService.getODTasks()
          .subscribe( (arrivedData: ODTask[]) => {});
      };
  }

  initOptionals(currentConfigDataObj) {
 
      currentConfigDataObj["generalParams"]["miniDep"] == 1 ? this._selectedDeploymentType = "mini" : this._selectedDeploymentType = "full-scale";
      // currentConfigDataObj["generalParams"]["dataStrmPlayback"] == 1 ? this._selectedDataStreamer = "Playback" : this._selectedDataStreamer = "Publisher";

      this._pathToVenueInS3 = currentConfigDataObj["generalParams"]["venueS3Path"];
      this._pathToDataInS3 = currentConfigDataObj["generalParams"]["data_bucket"];
      this._dataStartFrame = currentConfigDataObj["generalParams"]["data_start_frame"];
      this._dataEndFrame = currentConfigDataObj["generalParams"]["data_end_frame"];
      this._useRealCVT = currentConfigDataObj["generalParams"]["realCvtFlag"];
      this._selectedTeam = currentConfigDataObj["generalParams"]["cvtTeam"];

      this._copyDataSet = 1;//currentConfigDataObj["prepDepStages"]["cpData"];
      this._copyVenue = 1;//currentConfigDataObj["prepDepStages"]["cpVenue"];
      this._configureLustre = 1;//currentConfigDataObj["prepDepStages"]["configLustre"];
      this._configureCVT = 1;//currentConfigDataObj["prepDepStages"]["configRealCvt"];
      this._runAutoini = 1;//currentConfigDataObj["prepDepStages"]["runAutoini"];
      this._restartPods = 1;//currentConfigDataObj["prepDepStages"]["resetPods"];
      this._deploymentInfraTool = 1;//currentConfigDataObj["prepDepStages"]["depInfrTool"];
  }

  getJsonConfigObjectWithUserSelections() {
     let currentConfigDataObj = this._configObject;

     currentConfigDataObj["generalParams"]["deployment_id"] = this.operationsService.selectedDeploymentString;
     this._selectedDeploymentType === "mini" ? currentConfigDataObj["generalParams"]["miniDep"] = 1 : currentConfigDataObj["generalParams"]["miniDep"] = 0;
    // this._selectedDataStreamer == "Playback" ? currentConfigDataObj["prepDepParams"]["dataStrmPlayback"] = 1 : currentConfigDataObj["prepDepParams"]["dataStrmPlayback"] = 0;
     currentConfigDataObj["generalParams"]["venueS3Path"] = this._pathToVenueInS3;
     currentConfigDataObj["generalParams"]["data_bucket"] = this._pathToDataInS3;
     currentConfigDataObj["generalParams"]["data_start_frame"] = this._dataStartFrame;
     currentConfigDataObj["generalParams"]["data_end_frame"] = this._dataEndFrame;
     this._useRealCVT ? currentConfigDataObj["generalParams"]["realCvtFlag"] = 1 : currentConfigDataObj["generalParams"]["realCvtFlag"] = 0;
     currentConfigDataObj["generalParams"]["cvtTeam"] = this._selectedTeam;

     this._copyDataSet ? currentConfigDataObj["prepDepStages"]["cpData"] = 1 : currentConfigDataObj["prepDepStages"]["cpData"] = 0;
     this._copyVenue ? currentConfigDataObj["prepDepStages"]["cpVenue"] = 1 : currentConfigDataObj["prepDepStages"]["cpVenue"] = 0;
     this._configureLustre ? currentConfigDataObj["prepDepStages"]["configLustre"] = 1 : currentConfigDataObj["prepDepStages"]["configLustre"] = 0;
     this._configureCVT ? currentConfigDataObj["prepDepStages"]["configRealCvt"] = 1 : currentConfigDataObj["prepDepStages"]["configRealCvt"] = 0;
     this._runAutoini ? currentConfigDataObj["prepDepStages"]["runAutoini"] = 1 : currentConfigDataObj["prepDepStages"]["runAutoini"] = 0;
     this._restartPods ? currentConfigDataObj["prepDepStages"]["resetPods"] = 1 : currentConfigDataObj["prepDepStages"]["resetPods"] = 0;
     this._deploymentInfraTool ? currentConfigDataObj["prepDepStages"]["depInfrTool"] = 1 :  currentConfigDataObj["prepDepStages"]["depInfrTool"] = 0;

     return currentConfigDataObj;
  }

  runPrepareDeployment() {

    this.operationsService.PrepareDeploymentIsRunning = true;

    this.operationsService.prepareDeploymentTasks = [];
   
    let currentConfigDataObj = this.getJsonConfigObjectWithUserSelections();

    let currentConfigDataString = JSON.stringify(currentConfigDataObj);
 
    this.operationsService.startPrepareDeployment(currentConfigDataString);
  }

}
