import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-flow',
  templateUrl: './edit-flow.component.html',
  styleUrls: ['./edit-flow.component.css']
})
export class EditFlowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
