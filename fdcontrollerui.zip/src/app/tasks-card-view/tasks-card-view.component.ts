import { Component, OnInit } from '@angular/core';
import {OperationsService} from "../services/operations.service";

@Component({
  selector: 'app-tasks-card-view',
  templateUrl: './tasks-card-view.component.html',
  styleUrls: ['./tasks-card-view.component.css']
})
export class TasksCardViewComponent implements OnInit {

  constructor(public operationsService: OperationsService) { }

  ngOnInit() {
  }

}
