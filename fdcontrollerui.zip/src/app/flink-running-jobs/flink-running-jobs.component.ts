import { Component, OnInit, OnDestroy } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { FlinkTaskPayload } from "../models/FlinkTaskPayload";
import { FlinkTaskType } from "../models/FlinkTaskPayload";
import { FlinkJob } from "../models/FlinkJob";

@Component({
  selector: 'app-flink-running-jobs',
  templateUrl: './flink-running-jobs.component.html',
  styleUrls: ['./flink-running-jobs.component.css']
})
export class FlinkRunningJobsComponent implements OnInit, OnDestroy {

  displayedColumns: string[] = ['jid', 'name', 'startTime', 'duration', 'endTime', 'tasks', 'state', 'actions' ];
  filteredData: FlinkJob[] = [];
  cancelButtonText: string = "Cancel Job";

  constructor(public operationsService: OperationsService) { }

  ngOnInit() {
    this.filteredData = this.operationsService.flinkJobs;
  }

  ngOnDestroy() {
    //this.operationsService.StopListenToFlinkJobs();
    console.log("ngOnDestroy called on FlinkRunningJobsComponent");
  }


  stopFlinkJob(job: FlinkJob) {
    //this.cancelButtonText = 'Cancelling';
 
    let flinkTaskPayload: FlinkTaskPayload = {
            FlinkTaskType: FlinkTaskType.StopJob,
            JobId: job.jid,
            DeploymentId: this.operationsService.selectedDeployment.deployment_id
        }

    this.operationsService.startFlinkTask(flinkTaskPayload);
  }

  showRunningJobs() {
    this.operationsService.startTask("11ce4446-5a7e-42cb-8023-95b614d77747");//11ce4446-5a7e-42cb-8023-95b614d77747
  }

}
