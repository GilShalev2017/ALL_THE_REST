import { Component, OnInit, ViewChild } from '@angular/core';
import { Cluster } from "../models/Cluster";
import { Pod } from "../models/Pod";
import { animate, state, style, transition, trigger } from '@angular/animations';
import { OperationsService } from "../services/operations.service";
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { of as observableOf, Subscription } from 'rxjs';

@Component({
  selector: 'app-clusters-pods-view',
  templateUrl: './clusters-pods-view.component.html',
  styleUrls: ['./clusters-pods-view.component.css'],
   animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ClustersPodsViewComponent implements OnInit {

  clusters: Cluster[] = [];
  dataSource: Cluster[] = this.clusters;
  expandedElement: Cluster | null;
  displayedColumns: string[] = ['ExpandIcon', 'Name', 'Component', 'Type', 'Size', 'ServerType', 'actions'];
  bindedDataSource;
  index: number;
  subscription: Subscription;

  @ViewChild(MatSort, {static: true}) sorter1: MatSort;

  constructor(public operationsService: OperationsService) {

     this.subscription = this.operationsService.clustersUpdated$.subscribe(
      data => {
        this.clustersUpdated();
    });

    this.subscription = this.operationsService.deploymentSelectionChangedSource$.subscribe(
      data => {
        this.bindedDataSource = null;
    });
  }

  ngOnInit(): void {
    
    if(this.operationsService.clusters==null) {
      this.getPodsStatus();
    }
    this.clustersUpdated();
  }

  getPodsStatus() {
    this.operationsService.getPodsStatus();
  }

  resetAllPods() {
    this.operationsService.resetAllPods();
  }

  clustersUpdated() {
    this.bindedDataSource = new MatTableDataSource(this.operationsService.clusters);
    this.bindedDataSource.sort = this.sorter1;
  }

  cleanClusterLustreFolders(row: Cluster, event) {
    if (event) {
        event.stopPropagation();
    } 
    if(row.Name == "decode") {
      this.operationsService.isCleanDecoderLustreFoldersOn = true;
      this.operationsService.cleanDecoderLustreFolders();
    }
  }
  refreshClusterPods(row: Cluster, event) {
    if (event) {
        event.stopPropagation();
    } 
  }
  resetClusterPods(row: Cluster, event) {
    if (event) {
        event.stopPropagation();
    } 
    if(row.Name == "decode") {
      // this.operationsService.isCleanDecoderLustreFoldersOn = true;
      this.operationsService.resetDecoderPods();
    }
  }

  // openChangeLog(row: Cluster, event) {
    
  // }
}
