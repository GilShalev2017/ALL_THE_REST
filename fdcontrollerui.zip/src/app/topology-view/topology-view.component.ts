import { Component, OnInit } from '@angular/core';
import {OperationsService} from "../services/operations.service";

@Component({
  selector: 'app-topology-view',
  templateUrl: './topology-view.component.html',
  styleUrls: ['./topology-view.component.css']
})
export class TopologyViewComponent implements OnInit {

  constructor(public operationsService: OperationsService) { }

  ngOnInit() {
    this.operationsService.getOPDockers();
  }
  resetFdController() {
    this.operationsService.resetFdController();
  }

  getFdControllerLog() {

  }
}
