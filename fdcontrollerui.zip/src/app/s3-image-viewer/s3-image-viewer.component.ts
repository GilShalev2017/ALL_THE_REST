import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
// ---- m3u8 -----
// import { Component, Inject, Input, Output, OnInit,ViewChild,EventEmitter, OnChanges, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { Component, Inject, Input, Output, OnInit,ViewChild,EventEmitter, OnChanges, ElementRef } from '@angular/core';
import { MatSelectionList, MatSelectionListChange, MatListOption } from '@angular/material/list';
import { SelectionModel } from '@angular/cdk/collections';
import { OperationsService } from "../services/operations.service";
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { of as observableOf, Subscription } from 'rxjs';
import { MatMenuTrigger } from '@angular/material/menu';
// import { faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye } from '@fortawesome/free-solid-svg-icons';

import videojs from 'video.js';
declare var require: any;
require('videojs-contrib-quality-levels');
require('videojs-hls-quality-selector');

export interface FileNode {
  name: string;
  fileType: string;
  children?: FileNode[];
  parent?: string;

  parentName?: string;
  folderPath?: string;
  parentFolderPath?: string;
}

/** Flat node with expandable and level information */
export interface TreeNode {
  name: string;
  fileType: string;
  level: number;
  expandable: boolean;
  parent?: string;
  isSelected?: boolean;

  parentName?: string;
  folderPath?: string;
  parentFolderPath?: string;
}

@Component({
  selector: 'app-s3-image-viewer',
  templateUrl: './s3-image-viewer.component.html',
  styleUrls: ['./s3-image-viewer.component.css']
})

//m3u8
//export class S3ImageViewerComponent implements OnInit, AfterViewInit, OnDestroy {

export class S3ImageViewerComponent implements OnInit {

//  imageObject: Array<object> = [{
//       image: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/5.jpg',
//       thumbImage: 'https://sanjayv.github.io/ng-image-slider/contents/assets/img/slider/5.jpg',
//       title: 'Hummingbirds are amazing creatures'
//];

  currentIndex: any = -1;
  showFlag: any = false;
 

  @ViewChild(MatMenuTrigger)
  contextMenu: MatMenuTrigger;
  contextMenuPosition = { x: '0px', y: '0px' };

  public previews: string[] = [];
  @ViewChild("videoRef") private videoRef: ElementRef<HTMLVideoElement>;

  @Output() fileSelected: EventEmitter<string> = new EventEmitter();
  _selectedFile: TreeNode;

  /** The TreeControl controls the expand/collapse state of tree nodes.  */
  treeControl: FlatTreeControl<TreeNode>;

  /** The TreeFlattener is used to generate the flat list of items from hierarchical data. */
  treeFlattener: MatTreeFlattener<FileNode, TreeNode>;

  /** The MatTreeFlatDataSource connects the control and flattener to provide data. */
  dataSource: MatTreeFlatDataSource<FileNode, TreeNode>;

  s3Bucket: string;
  imgUrl: string;
 
  public _isDirty: boolean = false;
  images: string [] = [];
  imageIndex;

  showVideo: boolean;
  showImage: boolean;
  showFiller = false;

  public player: videojs.Player;
  //url = 'https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8';
  //url = 'https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/1/10_55_10/index_0a10_55_10.m3u8?AWSAccessKeyId=ASIA26YVBY7TSNT3KD7F&Expires=1604939489&x-amz-security-token=IQoJb3JpZ2luX2VjEOD%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJHMEUCIG6FZ4ow6PcFdJfq9rxizztgPnEb1EQ8InzsxRfhOJeAAiEAstBxS7A6rwns487uh0L%2Fc%2F8ebarQY7DIbH8JeIJUOb8q2AEISRACGgw3NTMyNzQwNDY0MzkiDIC%2FDIbABagjH5ZWICq1Af%2Fc3J9STts0yJWZXMlKMRLGzSCQ5KDw3R7LTbD2Lm9ky7PZ62oC%2B6dXdWU5D%2F5l2NWqh1PeXob1RqMlG76155CYl73LkqhE10BHhwHLJbnJSQC%2B4XF8JrroDvtIyr1KBgny5mgsCl4S5%2FncLK9xi0vVJAZaNuZfE3pQ8s%2BFP7i%2B%2BpWnNsVIMxtA39iLbpxyqqIVBKgxn5n6n1NvVx5c7QUbP0qvVQr%2F9L4IG2CBVEicRRpjahIw2K2g%2FQU64AHX1NnHbycxbYwW3GUEwhbrcn8mNlMP2tHDYzpsBcTl11GxKj0hIoHux4UotaHvv70vMdFyUMXxnsOAQdiSkb8Mguhbx9ngjeF3ISGLVOpX1LJIQJ3wGLDKVIU3iFtJaRZUSGz4SLqEuqlHEy7qPfYSbyaQ%2Fn4h%2BZCOpVli6%2B4tOz4ZKO%2Bsg%2F2vZVfF6GQWVV9RWnnaMyr8hKFrIShrRdzGls4liUuTCNZRkpAlyOwoOmA3VLxpEAIKwt4ElOlpo0VyFf44VvgEfkESZS2ssBNpdA5aizeuj%2FYD7Fymq9R4LA%3D%3D&Signature=0K2Krv9fl8WhRw4nzsmll7YUODc%3D';
  //url = 'https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/1/10_55_10/index_0a10_55_10.m3u8';
  //url = 'https://gil-test-videos.s3.amazonaws.com/index_0a10_55_10.m3u8';
  url = "file:///C:/temp/VideoImages/index_0a10_55_10.m3u8";

  constructor(public dialogRef: MatDialogRef<S3ImageViewerComponent>,
              @Inject(MAT_DIALOG_DATA) public data: object,
              public operationsService: OperationsService) {
              this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
              this.treeControl = new FlatTreeControl<TreeNode>(this.getLevel, this.isExpandable);
              this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  }

  //---------   m3u8 -------------
  // ngAfterViewInit() {
  //   const options = {
  //     'sources': [{
  //       'src': this.url,
  //       'type': 'application/x-mpegURL'
  //     }
  //     ],
  //     // 'poster' : this.urlPoster
  //   };
  //   this.player = videojs('my-video', options, function onPlayerReady() {
  //     console.log('Player ready');
  //     var myPlayer = this, id = myPlayer.id();
  //     myPlayer.hlsQualitySelector();
  //   });
  // }

  // ngOnDestroy(): void {
  //   if (this.player != null) {
  //     this.player.dispose();
  //   }
  // }

  showLightbox(index) {
    this.currentIndex = index;
    this.showFlag = true;
  }

  closeEventHandler() {
    this.showFlag = false;
    this.currentIndex = -1;
  }

  filterMediaOnly(element, index, array) { 
    return (element.name.endsWith(".jpg") || element.name.endsWith(".mp4") || element.name.endsWith(".avi") || element.name.endsWith(".m3u8") || element.name.endsWith(".m4s")); 
  } 

  ngOnInit(): void {

      let results: FileNode[] = this.operationsService.bucketFileTree;
   
      if(this.data.hasOwnProperty("toolType"))
      {
        if(this.data["toolType"] == "v4v"){
          let filteredChildren = results[0].children[0].children.filter(this.filterMediaOnly);
          results[0].children[0].children = filteredChildren;
          this.dataSource.data = results;
        }
      }
      else {
        this.dataSource.data = results;
      }
   
      this.treeControl.expandAll();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  /** Transform the data to something the tree can read. */
  transformer(node: FileNode, level: number) {
    return {
      name: node.name,
      fileType: node.fileType,
      level: level,
      expandable: !!node.children,
      parent: node.parent,

      parentName: node.parentName,
      folderPath: node.folderPath,
      parentFolderPath: node.parentFolderPath
    };
  }

  /** Get the level of the node */
  getLevel(node: TreeNode) {
    return node.level;
  }

  /** Return whether the node is expanded or not. */
  isExpandable(node: TreeNode) {
    return node.expandable;
  };

  /** Get the children for the node. */
  getChildren(node: FileNode) {
    return observableOf(node.children);
  }

  /** Get whether the node has children or not. */
  hasChild(index: number, node: TreeNode){
    return node.expandable;
  }

  selectFile(selectedFile: any) {

    this.imgUrl = null;
    this.showVideo = false;
    this.showImage = false;

    //TODO temporarily this is good only for one level
    if(selectedFile.fileType == "file") {
    
      //let fullFilePath = "e02v4402wul18nh/15102020_094808/F50100-50100/render-360s_converted/" + selectedFile.name;
      let fullFilePath = "";

      if(this.data.hasOwnProperty("toolType")) {
         if(this.data["toolType"] == "v4v"){ // v4v
            fullFilePath = this.data["filesPrefix"] + "/" + selectedFile.parentName + "/" + selectedFile.name;
         }
      }
      else { // debugKit
        fullFilePath = this.data["filesPrefix"] + "/" + selectedFile.parentFolderPath + selectedFile.name;
      }

      let bucketName = this.data["bucketName"];
      let bucketRegion = this.data["bucketRegion"];

      this.operationsService.getS3FilePresignedUrl(fullFilePath,bucketName, bucketRegion)
        .subscribe(result => {
          let assetUrl = result['URL_STRING'];

          if(selectedFile.name.endsWith(".mp4")) {  //video->download
            this.imgUrl = assetUrl;
            
            //window.open(assetUrl, "_blank");

            this.showVideo = true;
            this.previews = [];
            this.previews.push(assetUrl);
            this.videoRef.nativeElement.load();
            this.videoRef.nativeElement.play();
           
          }
          else if(selectedFile.name.endsWith(".m3u8") || selectedFile.name.endsWith(".m4s")){
            this.url = assetUrl;
          }
          else if(selectedFile.name.endsWith(".jpg") || selectedFile.name.endsWith(".jpeg")) { //image->display
             this.imgUrl = assetUrl;
             this.images = [];
             this.images.push(assetUrl);
             this.imageIndex = this.images.length;
             this.showImage = true;

            //   let imgObj = {

            //    "image": this.imgUrl,
            //    "thumbImage": this.imgUrl,
            //    "title": 'Another One'
            //   }

            //  this.imageObject.push(imgObj);
             //window.open(assetUrl, "_blank");
          }
        });

      //unselect previous node
      if(this._selectedFile != null) {
        this._selectedFile.isSelected = false;
      }
      
      this._selectedFile = selectedFile;
      selectedFile.isSelected = true;
    
      let KeyName = "";
      
      if(selectedFile.parent != null) {
        KeyName = selectedFile.parent + "/" + selectedFile.name;
      }
      else {
        KeyName = selectedFile.name;
      }

      this.fileSelected.emit(KeyName);
    }
  }

  public openBucket(event) {
    if (event) {
        event.stopPropagation();
    } 

    window.open(this.data["s3BucketUrl"], "_blank");
  }

  onContextMenu(event: MouseEvent, item: TreeNode) {
    event.preventDefault();
    this.contextMenuPosition.x = event.clientX + 'px';
    this.contextMenuPosition.y = event.clientY + 'px';
    this.contextMenu.menuData = { 'item': item };
    this.contextMenu.menu.focusFirstItem('mouse');
    this.contextMenu.openMenu();
  }
 
  onContextMenuDownloadAvi(event: MouseEvent, selectedFile) {
    if (event) {  
        event.stopPropagation();
    } 

    let fullFilePath = this.data["filesPrefix"] + "/" + selectedFile.parentFolderPath + selectedFile.name;
    let bucketName2 = this.data["bucketName"];
    let bucketRegion2 = this.data["bucketRegion"];

    let bucketName = 'v4v';
    let bucketRegion = 'us-east-1';
    let fileKey = "e02v441rc5vxjjx/29-10-2020/18_26_55/Frames-170100-170105/Masks_Visualization/video_masks_frames_170100_170105.avi";

    this.operationsService.getS3FilePresignedUrl(fileKey, bucketName, bucketRegion)
        .subscribe(result => {
          let reportUrl = result['URL_STRING'];
          window.open(reportUrl, "_blank");
        });
  }
 
}
