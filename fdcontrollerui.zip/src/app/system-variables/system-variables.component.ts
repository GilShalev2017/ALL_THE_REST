import { Component, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AppConfigurationService } from '../services/app-configuration.service';

@Component({
  selector: 'app-system-variables',
  templateUrl: './system-variables.component.html',
  styleUrls: ['./system-variables.component.css']
})
export class SystemVariablesComponent implements OnInit {

   executerId: string = "$executerId";
   s3ProgramsBucket: string = "$s3ProgramsBucket";
   s3ProgramsBucketRegion: string = "$s3ProgramsBucketRegion";
   s3ConfigBucket: string = "$s3ConfigBucket";
   s3ConfigBucketRegion: string = "$s3ConfigBucketRegion";
   flinkJobManagerEndpoint: string = "$flinkJobManagerEndpoint";
   flowExecuterID: string = "$flowExecuterID";
   latestFlinkJar: string = "$latestFlinkJar";
   deploymentId: string = "$deploymentId";
   gameId: string = "$gameId";
   time: string = "$time";

   playStatusQueue: string = "$playStatusQueue";
   playStatusTopic: string = "$playStatusTopic";
   mqUserName: string = "$mqUserName";
   mqPassword: string = "$mqPassword";
   mqStompUrl: string = "$mqStompUrl";
   mqOpenwireUrl: string = "$mqOpenwireUrl";
   mqWssUrl: string = "$mqWssUrl";
   

   constructor(public dialogRef: MatDialogRef<SystemVariablesComponent>, public appconfig:AppConfigurationService)
   { }

  ngOnInit(): void {
  }

}
