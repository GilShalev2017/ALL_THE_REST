import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs'
import { fromPromise } from 'rxjs/observable/fromPromise';
import { map, tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import Amplify, { Auth } from 'aws-amplify';
import { environment } from './../../environments/environment';

import { AppConfigurationService } from '../services/app-configuration.service';

@Injectable()
export class AuthService {

  public loggedIn: BehaviorSubject<boolean>;
  public accessToken: string;
  public idToken: string;
  public isLoggedIn: boolean;
  public userGroups: string[] = [];
  public connectedUserName: string;
  constructor(private router: Router, private appconfig:AppConfigurationService) {

    //Based on Confoguration
    let amplify = {
      Auth: {
        region: appconfig.userPoolRegion,
        userPoolId: appconfig.userPoolId,
        userPoolWebClientId: appconfig.userPoolWebClientId
      }
    };

    Amplify.configure(amplify);

    this.loggedIn = new BehaviorSubject<boolean>(false);
  }

  /** signup */
  public signUp(email, password): Observable<any> {
    return fromPromise(Auth.signUp(email, password));
  }

  /** confirm code */
  public confirmSignUp(email, code): Observable<any> {
    return fromPromise(Auth.confirmSignUp(email, code));
  }

  /** signin */
  public signIn(email, password): Observable<any> {
    //return fromPromise(Auth.signIn("gil", "+25Up5v?g2g4t^L>"))
     return fromPromise(Auth.signIn(email, password))
      .pipe(
        tap(() => this.loggedIn.next(true))
      );
  }

  /** get authenticat state */
  public isAuthenticated(): Observable<boolean> {
    return fromPromise(Auth.currentAuthenticatedUser())
      .pipe(
        map(result => {
          this.loggedIn.next(true);
          this.accessToken = result.signInUserSession.accessToken.jwtToken;
          this.idToken = result.signInUserSession.idToken.jwtToken;
          this.userGroups = result.signInUserSession.idToken.payload['cognito:groups'];
          this.isLoggedIn = true;
          return true;
        }),
        catchError(error => {
          this.loggedIn.next(false);
          this.isLoggedIn = false;
          return of(false);
        })
      );
  }

  public getCurrentAuthenticatedUser():Observable<any> {
    return fromPromise(Auth.currentAuthenticatedUser())
          .pipe(
            map(result => {
              this.accessToken = result.signInUserSession.accessToken.jwtToken;
              this.connectedUserName = result.username;
              return result;
            }),
            catchError(error => {
              return of(null);
            })
          );
  }

  /** signout */
  public signOut() {
    fromPromise(Auth.signOut())
      .subscribe(
        result => {
          this.loggedIn.next(false);
          //this.router.navigate(['/login']);
          this.router.navigate(['/login-form']);
        },
        error => console.log(error)
      );
  }
  
  public isProductionUser() {
     if(this.userGroups == null) {
       return false;
     }
     if(this.userGroups.includes("production_users")) {
       return true;
     }
    return false;

  }
}
