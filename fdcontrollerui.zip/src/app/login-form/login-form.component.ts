import { Input, Component, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './../auth/auth.service';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent {

  constructor(private router: Router, private auth: AuthService) { }

  form: FormGroup = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });

  submit() {
    // if (this.form.valid) {
    //   this.submitEM.emit(this.form.value);
    // }
   
    const email = this.form.value.email, password = this.form.value.password;
    this.auth.signIn(email, password)
      .subscribe(
        result => {
          //TODO navigate to original requested page
          this.router.navigate(['/']);
        },
        error => {
          console.log(error);
          this.error = error.message;
        });
  }
 
  @Input() error: string | null;

  @Output() submitEM = new EventEmitter();
}
