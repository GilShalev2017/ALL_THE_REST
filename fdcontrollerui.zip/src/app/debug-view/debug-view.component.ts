import { Component, OnInit } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { ProgramsService } from "../services/programs.service";
import { AppConfigurationService } from '../services/app-configuration.service';
import { AuthService } from './../auth/auth.service';
import { TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { of as observableOf, Subscription } from 'rxjs';

@Component({
  selector: 'app-debug-view',
  templateUrl: './debug-view.component.html',
  styleUrls: ['./debug-view.component.css']
})
export class DebugViewComponent implements OnInit {

  modalRef: BsModalRef;
  _template: TemplateRef<any>;
  subscription: Subscription;
  public reportUrl: string;
  edit_hub: string = "kubectl edit deployments hub-hub";
  edit_fdcontroller: string = "kubectl edit statefulset fdcontroller";
  login_to_ecr: string = "aws ecr get-login --region eu-west-1 --no-include-email";
  build_hub_docker: string = "docker build -t deployment-operations-serverhub -f IntelSports.DeploymentOperations.ServerHub/Dockerfile .";
  build_worker_docker: string = "docker build -t worker -f IntelSports.DeploymentOperations.Worker/Dockerfile .";
  replicate_fdcontroller: string = "kubectl scale statefulset fdcontroller --replicas=1";

  constructor(public operationsService: OperationsService,
              public programsService: ProgramsService,
              public appconfig:AppConfigurationService,
              private modalService: BsModalService,
              public authService: AuthService) { 
    
     this.subscription = operationsService.logArrived$.subscribe(
      data => {
        this.modalRef = this.modalService.show(this._template);
    });
  }

  ngOnInit(): void {
   
  }
  
  openLogsModal(template: TemplateRef<any>) {
    // this._template = template;
    // this.modalRef = this.modalService.show(this._template);

    // this.operationsService.getFdControllerLog();

  }

  // toArray(value: string): void {
  //   this.lines = value.split(/[\r\n]+/);
  // }
}
