import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {ODTask} from "../models/ODTask";
import {BsModalRef} from "ngx-bootstrap";
import {OperationsService} from "../services/operations.service";
import {ODProgram} from "../models/ODProgram";
import { SystemVariablesComponent } from '../system-variables/system-variables.component';
import { MatDialog } from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-task-definition',
  templateUrl: './task-definition.component.html',
  styleUrls: ['./task-definition.component.css']
})
export class TaskDefinitionComponent implements OnInit {

  @Input() modalRef: BsModalRef;
  @Input() editedTask: ODTask;
  @Output() taskSaved: EventEmitter<ODTask> = new EventEmitter<ODTask>();
  @Output() taskDuplicated: EventEmitter<ODTask> = new EventEmitter<ODTask>();
  @Input() isEditMode: boolean;

  constructor(public operationsService: OperationsService){}
              // private modalService: BsModalService
              // public dialog: MatDialog) {}

  ngOnInit() {
    this.getODPrograms();
  }

  getODPrograms() {
    this.operationsService.getODPrograms()
      .subscribe( (odps: ODProgram[]) => {
    });
  }

  saveTask() {
    this.taskSaved.emit(this.editedTask);
    this.modalRef.hide();
  }

  duplicateTask() {
    this.taskDuplicated.emit(this.editedTask);
    this.modalRef.hide();
  }

  showSystemVariables() {
  
    // this.dialog.open(SystemVariablesComponent);
  }
}
