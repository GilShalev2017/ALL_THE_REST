import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { SystemVariablesComponent } from '../system-variables/system-variables.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-execution-parameters',
  templateUrl: './execution-parameters.component.html',
  styleUrls: ['./execution-parameters.component.css']
})
export class ExecutionParametersComponent implements OnInit {

  displayedColumns: string[] = ['key', 'value'];
  dataSource;
  _showAsJson: boolean = false;
  public editorOptions: JsonEditorOptions;
  _jsonObject = {};

  @ViewChild(JsonEditorComponent) editor: JsonEditorComponent;

  public orderByKey(a, b) {
    return a.key;
  }

  constructor( @Inject(MAT_DIALOG_DATA) public data: [],
              public dialogRef: MatDialogRef<ExecutionParametersComponent>,
              public dialog: MatDialog) { 
    
    this.dataSource = data;
   
    this.dataSource.forEach(element => {
      this._jsonObject[element['key']] = element['value'];
    });


    this.editorOptions = new JsonEditorOptions();
    this.editorOptions.modes = ['code', 'text', 'tree', 'view'];
  }

  ngOnInit(): void {
  }

  showAsJson() {
    //Sync between the 2 views
    this._showAsJson = !this._showAsJson;

    if(this._showAsJson) { //sync from table to json
          this._jsonObject = {};
          this.dataSource.forEach(element => {
          this._jsonObject[element['key']] = element['value'];
          });
    }
    else { //sync from json to table
          this._jsonObject = this.editor.get();
          this.dataSource.forEach(element => {
            element['value'] = this._jsonObject[element['key']];
          });
    }
  }

  // ConvertJson2FlattenObject(jsonObj, resultObject)
  // {
  //   if(jsonObj == null)
  //   {
  //       return;
  //   }

  //   for(let obj in jsonObj)
  //   {
  //       if (obj is string)
  //       {
  //           resultObject[]);
  //       }
  //       else //this is JObject
  //       {
  //           ConvertJson2FlattenObject(obj, resultObject);
  //       }
  //   }
  // }

  feedSelections() {

    if(this._showAsJson ) { // the dataSource will get its values from the json editor
      this._jsonObject = this.editor.get();

      let flattenObjectResult = {};

      //this.ConvertJson2FlattenObject(this._jsonObject, flattenObjectResult);

      this.dataSource.forEach(element => {
        if(this._jsonObject[element['key']]) { //only if the json has a value - assign it to the dataSource element
          element['value'] = this._jsonObject[element['key']];
        }
      });
    
      this.dialogRef.close({ feed: true, data: this.dataSource })
    }
    else { // the dataSource will get its values from the table view
      this.dialogRef.close({ feed: true, data: this.dataSource })
    }

  }

  showSystemVariables() {
    const dialogRef = this.dialog.open(SystemVariablesComponent);
  }

  getParametersAsStrigifiedJson() {
    
    let dataArray:[] = this.data;
    let jsonObject = {};

    dataArray.forEach(element => {
      jsonObject[element['key']] = element['value'];
    });

    return JSON.stringify(jsonObject);
  }
}
