import { Component, OnInit } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye } from '@fortawesome/free-solid-svg-icons';
import { UIExecutingTask } from "../models/UIExecutingTask";
import { ODTask } from "../models/ODTask";

@Component({
  selector: 'app-vv4',
  templateUrl: './vv4.component.html',
  styleUrls: ['./vv4.component.css']
})
export class Vv4Component implements OnInit {
   
  startTime = "10:10";
  startDate = new Date();
  todayStartDate = new Date();
  faStop = faStop;

  constructor(public operationsService: OperationsService) { }

  ngOnInit(): void {

      if(this.operationsService.isTasksLoaded==false) {
        this.operationsService.getODTasks()
          .subscribe( (arrivedData: ODTask[]) => {});
      };

      this.todayStartDate = new Date();
  }

  launchMvv() {
    let time= this.startTime;//"12:12";
    let splits = this.startDate.toString().split("-");
    let date = splits[1] + "/" + splits[2] + "/" + splits[0];

    let dynamicParams = date + " " + time;

    this.operationsService.startMVV(dynamicParams);
  }

  stopTask(task: UIExecutingTask, event?: Event){
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.stopTask(task.ExecutingTaskStatus.executerId);
  }

  cleanHistory() {
    this.operationsService.mvvTasks = [];
    this.operationsService.mvvObjects = null;
  }

  getUrlForCamera(cameraId) {
   let key = "mps" + cameraId;
   let url = this.operationsService.mvvObjects[key];
   return url;
  }

  showVideo(cameraId) {
    let url = this.getUrlForCamera(cameraId);
    window.open(url,"_blank");
  }

  showAllVideos() {
    for(let i=0; i<33; i++) {
      let url = this.getUrlForCamera(i);
      if (!!url) {
        window.open(url,"_blank");
      }
    }
  }
  
  copyAllVideoPaths() {

  }

  public loadDemoData() {
    this.operationsService.loadMvvDemoData();
  }

   openS3Bucket(task: UIExecutingTask, event) {
    if (event) {
      event.stopPropagation();
    } 

    // https://s3.console.aws.amazon.com/s3/buckets/isg-teecontrol-data-management-svc-dev?region=us-east-1&prefix=a01networkh2tj2/DUMMY_GAME_ID_a01networkh2tj2/MVV/
   
    let region = this.operationsService.selectedDeployment.deployment_region;
  
    let gameId = this.operationsService.selectedDeployment.game_id;

    let s3Link = "https://s3.console.aws.amazon.com/s3/buckets/isg-teecontrol-data-management-svc-dev?region=" + region + "&prefix=" + this.operationsService.selectedDeploymentString + "/" + gameId + "/MVV/";

    window.open(s3Link, "_blank");
  }
}
