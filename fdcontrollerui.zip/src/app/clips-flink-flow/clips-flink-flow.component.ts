import { Component, OnInit, ViewChild } from '@angular/core';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { OperationsService } from "../services/operations.service";
import { MatAccordion } from '@angular/material/expansion';
import { ODTask } from "../models/ODTask";
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';

import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';

@Component({
  selector: 'app-clips-flink-flow',
  templateUrl: './clips-flink-flow.component.html',
  styleUrls: ['./clips-flink-flow.component.css']
})
export class ClipsFlinkFlowComponent implements OnInit {

  public editorOptions: JsonEditorOptions;
  
  @ViewChild('selections') editorSelections: JsonEditorComponent;
 
  @ViewChild('mySelect') select: MatSelect;
  @ViewChild('myCvtSelect') cvt_select: MatSelect;
  @ViewChild('myDigzSelect') digz_select: MatSelect;
 
  myAllSelected=true;
  myCvtAllSelected=true;
  myDigzAllSelected=true;

  _flows: string[] = ['CameraControl','StreamAgg','MultiVew','CVT','DecoderWithMultiView','CleanBackground','Localization'
  , 'Association','Segmentation','Reconstruction','Dxt','Renderer','Digital Zoom'];
  _selectedFlows: string[] = [];
  _endFrame: number;
  _startFrame: number;
  _clipName: string;
  _flinkVersion: string;
  allSelected = false;
  allCameraSelected= false;
  _selectedCameras;
 
 
  //FlinkFlow
  _cameraControl: boolean;
  _streamAgg: boolean;
  _cvt: boolean;
  _multiVew: boolean;
  _decoderWithMultiView: boolean;
  _cleanBackground: boolean;
  _localization: boolean;
  _association: boolean;
  _segmentation: boolean;
  _reconstruction: boolean;
  _dxt: boolean;
  _renderer: boolean;
  _digitalZoom: boolean;
  //FeaturesPOC
  _checkpoints: boolean;
  _segRenderer: boolean;
  _cbgRenderer: boolean;
  _unityPMDStreams: boolean;
  //ROOT
  _pcamFlow: boolean;
  _vcamFlow: boolean;
  _realCvt: boolean;
  _cvtStreamToListen: string;
  _cvtProducerStream: string;
  _debug: boolean;
  _info: boolean;
  _monitorBi:  boolean;
  _stateTimeToLive;
  _parallelism: number;
  _region: string;
  _cameras: string [] = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38'];
  //FlinkRestartStrategy
  _restartDelay: number;
  _restartAttempts: number;
  //Checkpoints
  _intervalMS: number;
  _path: string;
  _async: boolean;
  //MultiView
  _mv_asyncTimeout: number;
  _mv_asyncStackSize: number;
  _mv_collectionTime: number;
  _mv_grpcDeadline: boolean; 
  _mv_bridge: boolean;
  _mv_fixedWindow: boolean;
  //CVT
  _cvt_cameras;
  _cvt_collectionTime: number;
  _cvt_fixedWindow;
  //StreamAggReal
  _sar_framesPerGop: number;
  _sar_collectionTime: number;
  _sar_asyncTimeout: number;
  _sar_asyncStackSize: number;
  _sar_grpcDeadline: boolean;
  _sar_bridge: boolean;
  _sar_fixedWindow: boolean;
  //StreamAggVirtual
  _sav_framesPerGop: number;
  _sav_collectionTime: number;
  _sav_asyncTimeout: number;
  _sav_asyncStackSize: number;
  _sav_grpcDeadline: boolean;
  _sav_bridge: boolean;
  _sav_fixedWindow: boolean;
  //Dxt
  _dxt_collectionTime: number;
  _dxt_asyncTimeout: number;
  _dxt_asyncStackSize: number;
  _dxt_grpcDeadline: number;
  _dxt_bridge: boolean;
  _dxt_fixedWindow: boolean;
  //CleanBackground
  _cbg_asyncTimeout: number;
  _cbg_asyncStackSize: number;
  _cbg_grpcDeadline: number;
  _cbg_bridge: boolean;
  //Localization
  _loc_asyncTimeout: number;
  _loc_asyncStackSize: number;
  _loc_grpcDeadline: number;
  _loc_bridge: boolean;
  //Association
  _association_asyncTimeout: number;
  _association_asyncStackSize: number;
  _association_collectionTime: number;
  _association_grpcDeadline: number;
  _association_bridge: boolean;
  _association_fixedWindow: boolean;
  //Segmentation
  _seg_asyncTimeout: number;
  _seg_asyncStackSize: number;
  _seg_grpcDeadline: number;
  _seg_bridge: boolean;
  //Reconstruction
  _recon_asyncTimeout: number;
  _recon_asyncStackSize: number;
  _recon_collectionTime: number;
  _recon_collectionTimeAllServices: number;
  _recon_grpcDeadline: number;
  _recon_bridge: boolean;
  _recon_fixedWindow: boolean;
  _recon_sidelines;
  _recon_ball;
  _recon_seats;
  _recon_basket;
  //CameraControl
  _camc_asyncTimeout: number;
  _camc_asyncStackSize: number;
  _camc_grpcDeadline: number;
  _camc_bridge: boolean;
  //Renderer
  _renderer_partition2d: number;
  _renderer_partition4k: number;
  _renderer_partitionPano: number;
  _renderer_asyncTimeout: number;
  _renderer_asyncStackSize: number;
  _renderer_grpcDeadline: number;
  _renderer_bridge: boolean;
  //DigitalZoom
  _digz_asyncTimeout: number;
  _digz_asyncStackSize: number;
  _digz_grpcDeadline: number;
  _digz_bridge: boolean;
  _digz_cameras;

  // _partition360: number;
  // _partitionHD: number;
  
  _checkpointsAsync: boolean;
  _kinesisParallelism: number;

  _configObject;
  step = -1;

  @ViewChild(MatAccordion) accordion: MatAccordion;

  constructor(public operationsService: OperationsService) { 
     this.editorOptions = new JsonEditorOptions();
     this.editorOptions.modes = ['code', 'text', 'tree', 'view'];
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  ngOnInit(): void {

     this.operationsService.getFlinkConfigContent()
              .subscribe( jsonObject => {
                  this._configObject = jsonObject;
                  this.initOptionals(jsonObject);
                });

    this._clipName = this.newGuid();

    if(this.operationsService.isTasksLoaded==false) {
        this.operationsService.getODTasks()
          .subscribe( (arrivedData: ODTask[]) => {});
      };

    if(this.operationsService.isFlinkJarsLoaded == false) {
      this.operationsService.getFlinkJars()
       .subscribe( (arrivedData: string[]) => {
      });
    }
  }

  initOptionals(currentConfigDataObj) {
    //FlinkFlow
    this._cameraControl = currentConfigDataObj["FlinkFlow"]["CameraEngine"];
    this._streamAgg = currentConfigDataObj["FlinkFlow"]["StreamAgg"];
    this._cvt = currentConfigDataObj["FlinkFlow"]["CVT"];
    this._multiVew = currentConfigDataObj["FlinkFlow"]["MultiView"];
    this._decoderWithMultiView = currentConfigDataObj["FlinkFlow"]["DecoderWithMultiView"];
    this._cleanBackground = currentConfigDataObj["FlinkFlow"]["CleanBackground"];
    this._localization = currentConfigDataObj["FlinkFlow"]["Localization"];
    this._association = currentConfigDataObj["FlinkFlow"]["Association"];
    this._segmentation = currentConfigDataObj["FlinkFlow"]["Segmentation"];
    this._reconstruction = currentConfigDataObj["FlinkFlow"]["Reconstruction"];
    this._dxt = currentConfigDataObj["FlinkFlow"]["Dxt"];
    this._renderer = currentConfigDataObj["FlinkFlow"]["Renderer"];
    this._digitalZoom = currentConfigDataObj["FlinkFlow"]["DigitalZoom"];
    //FeaturesPOC
    this._checkpoints = currentConfigDataObj["FeaturesPOC"]["Checkpoints"];
    this._segRenderer = currentConfigDataObj["FeaturesPOC"]["SegRender"];
    this._cbgRenderer = currentConfigDataObj["FeaturesPOC"]["CBGRender"];
    this._unityPMDStreams = currentConfigDataObj["FeaturesPOC"]["UnifyPMDStreams"];
    //ROOT
    this._pcamFlow = currentConfigDataObj["pcamFlow"];
    this._vcamFlow = currentConfigDataObj["vcamFlow"];
    this._realCvt = currentConfigDataObj["realCvt"];
    
    this._kinesisParallelism = currentConfigDataObj["sourceParl"];

    this._cvtStreamToListen = currentConfigDataObj["cvtStreamToListen"];
    this._cvtProducerStream = currentConfigDataObj["cvtProducerStream"];
    this._debug = currentConfigDataObj["DEBUG"];
    this._info = currentConfigDataObj["InfoLog"];
    this._monitorBi = currentConfigDataObj["MonitorLog"];
    this._stateTimeToLive = currentConfigDataObj["StateTimeToLive"];
    this._parallelism = currentConfigDataObj["parallelism"];
    this._region = currentConfigDataObj["Region"];
    this._selectedCameras = currentConfigDataObj["cameras"];
    //FlinkRestartStrategy
    this._restartAttempts = currentConfigDataObj["FlinkRestartStrategy"]["restartAttempts"];
    this._restartDelay = currentConfigDataObj["FlinkRestartStrategy"]["restartDelay"];
    //Checkpoints
    this._intervalMS = currentConfigDataObj["Checkpoints"]["intervalMS"];
    this._path = currentConfigDataObj["Checkpoints"]["path"];
    this._async = currentConfigDataObj["Checkpoints"]["async"];
    //MultiView
    this._mv_asyncTimeout = currentConfigDataObj["MultiView"]["asyncTimeout"];
    this._mv_asyncStackSize = currentConfigDataObj["MultiView"]["asyncStackSize"];
    this._mv_collectionTime = currentConfigDataObj["MultiView"]["collectionTime"];
    this._mv_grpcDeadline = currentConfigDataObj["MultiView"]["grpcDeadline"];
    this._mv_bridge = currentConfigDataObj["MultiView"]["bridge"];
    this._mv_fixedWindow = currentConfigDataObj["MultiView"]["fixedWindow"];
    //CVT
    this._cvt_collectionTime = currentConfigDataObj["Cvt"]["collectionTime"];
    this._cvt_cameras = currentConfigDataObj["Cvt"]["cameras"];
    this._cvt_fixedWindow = currentConfigDataObj["Cvt"]["fixedWindow"];
    //StreamAggReal
    this._sar_framesPerGop = currentConfigDataObj["StreamAggReal"]["framesPerGop"];
    this._sar_collectionTime = currentConfigDataObj["StreamAggReal"]["collectionTime"];
    this._sar_asyncTimeout = currentConfigDataObj["StreamAggReal"]["asyncTimeout"];
    this._sar_asyncStackSize = currentConfigDataObj["StreamAggReal"]["asyncStackSize"];
    this._sar_grpcDeadline = currentConfigDataObj["StreamAggReal"]["grpcDeadline"];
    this._sar_bridge = currentConfigDataObj["StreamAggReal"]["bridge"];
    this._sar_fixedWindow = currentConfigDataObj["StreamAggReal"]["fixedWindow"];
    //StreamAggReal
    this._sav_framesPerGop = currentConfigDataObj["StreamAggVirtual"]["framesPerGop"];
    this._sav_collectionTime = currentConfigDataObj["StreamAggVirtual"]["collectionTime"];
    this._sav_asyncTimeout = currentConfigDataObj["StreamAggVirtual"]["asyncTimeout"];
    this._sav_asyncStackSize = currentConfigDataObj["StreamAggVirtual"]["asyncStackSize"];
    this._sav_grpcDeadline = currentConfigDataObj["StreamAggVirtual"]["grpcDeadline"];
    this._sav_bridge = currentConfigDataObj["StreamAggVirtual"]["bridge"];
    this._sav_fixedWindow = currentConfigDataObj["StreamAggVirtual"]["fixedWindow"];
    //Dxt
    this._dxt_collectionTime = currentConfigDataObj["Dxt"]["collectionTime"];
    this._dxt_asyncTimeout = currentConfigDataObj["Dxt"]["asyncTimeout"];
    this._dxt_asyncStackSize = currentConfigDataObj["Dxt"]["asyncStackSize"];
    this._dxt_grpcDeadline = currentConfigDataObj["Dxt"]["grpcDeadline"];
    this._dxt_bridge = currentConfigDataObj["Dxt"]["bridge"];
    this._dxt_fixedWindow = currentConfigDataObj["Dxt"]["fixedWindow"];
    //CleanBackground
    this._cbg_asyncTimeout = currentConfigDataObj["CleanBackground"]["asyncTimeout"];
    this._cbg_asyncStackSize = currentConfigDataObj["CleanBackground"]["asyncStackSize"];
    this._cbg_grpcDeadline = currentConfigDataObj["CleanBackground"]["grpcDeadline"];
    this._cbg_bridge = currentConfigDataObj["CleanBackground"]["bridge"];
    //Localization
    this._loc_asyncTimeout = currentConfigDataObj["Localization"]["asyncTimeout"];
    this._loc_asyncStackSize = currentConfigDataObj["Localization"]["asyncStackSize"];
    this._loc_grpcDeadline = currentConfigDataObj["Localization"]["grpcDeadline"];
    this._loc_bridge = currentConfigDataObj["Localization"]["bridge"];
    //Association
    this._association_asyncTimeout = currentConfigDataObj["Association"]["asyncTimeout"];
    this._association_asyncStackSize = currentConfigDataObj["Association"]["asyncStackSize"];
    this._association_collectionTime = currentConfigDataObj["Association"]["collectionTime"];
    this._association_grpcDeadline = currentConfigDataObj["Association"]["grpcDeadline"];
    this._association_bridge = currentConfigDataObj["Association"]["bridge"];
    this._association_fixedWindow = currentConfigDataObj["Association"]["fixedWindow"];
    //Segmentation
    this._seg_asyncTimeout = currentConfigDataObj["Segmentation"]["asyncTimeout"];
    this._seg_asyncStackSize = currentConfigDataObj["Segmentation"]["asyncStackSize"];
    this._seg_grpcDeadline = currentConfigDataObj["Segmentation"]["grpcDeadline"];
    this._seg_bridge = currentConfigDataObj["Segmentation"]["bridge"];
    //Reconstruction
    this._recon_asyncTimeout = currentConfigDataObj["Reconstruction"]["asyncTimeout"];
    this._recon_asyncStackSize = currentConfigDataObj["Reconstruction"]["asyncStackSize"];
    this._recon_collectionTime = currentConfigDataObj["Reconstruction"]["collectionTime"];
    this._recon_collectionTimeAllServices = currentConfigDataObj["Reconstruction"]["collectionTimeAllServices"];
    this._recon_grpcDeadline = currentConfigDataObj["Reconstruction"]["grpcDeadline"];
    this._recon_bridge = currentConfigDataObj["Reconstruction"]["bridge"];
    this._recon_fixedWindow = currentConfigDataObj["Reconstruction"]["fixedWindow"];
    this._recon_sidelines = currentConfigDataObj["Reconstruction"]["services"]["Sidelines"];;
    this._recon_ball = currentConfigDataObj["Reconstruction"]["services"]["Ball"];;
    this._recon_seats = currentConfigDataObj["Reconstruction"]["services"]["Seats"];;
    this._recon_basket = currentConfigDataObj["Reconstruction"]["services"]["Basket"];;
    //CameraControl
    this._camc_asyncTimeout = currentConfigDataObj["CameraControl"]["asyncTimeout"];
    this._camc_asyncStackSize = currentConfigDataObj["CameraControl"]["asyncStackSize"];
    this._camc_grpcDeadline = currentConfigDataObj["CameraControl"]["grpcDeadline"];
    this._camc_bridge = currentConfigDataObj["CameraControl"]["bridge"];
    //Renderer
    this._renderer_partition2d = currentConfigDataObj["Renderer"]["partition2d"];
    this._renderer_partition4k = currentConfigDataObj["Renderer"]["partition4k"];
    this._renderer_partitionPano = currentConfigDataObj["Renderer"]["partitionPano"];
    this._renderer_asyncTimeout = currentConfigDataObj["Renderer"]["asyncTimeout"];
    this._renderer_asyncStackSize = currentConfigDataObj["Renderer"]["asyncStackSize"];
    this._renderer_grpcDeadline = currentConfigDataObj["Renderer"]["grpcDeadline"];
    this._renderer_bridge = currentConfigDataObj["Renderer"]["bridge"];
    //DigitalZoom
    this._digz_asyncTimeout = currentConfigDataObj["DigitalZoom"]["asyncTimeout"];
    this._digz_asyncStackSize = currentConfigDataObj["DigitalZoom"]["asyncStackSize"];
    this._digz_grpcDeadline = currentConfigDataObj["DigitalZoom"]["grpcDeadline"];
    this._digz_bridge = currentConfigDataObj["DigitalZoom"]["bridge"];
    this._digz_cameras = currentConfigDataObj["DigitalZoom"]["cameras"];
  }

  newGuid() {
    // return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    return 'xxxx-xxxx-4xxx-yxxx-xxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0, v = c === 'x' ? r : ( r & 0x3 | 0x8 );
        return v.toString(16);
    });
  }

  toggleAllSelection() {
      this.allSelected = !this.allSelected;  // to control select-unselect
      this._selectedFlows = this.allSelected ? this._flows : [];
  }

  copyFirstFrameToEndFrame() {
    this._endFrame = this._startFrame;
  }

  toggleAllCameraSelection() {
      this.allCameraSelected = !this.allCameraSelected;  // to control select-unselect
      this._selectedCameras = this.allCameraSelected ? this._cameras : [];
  }

  OnStepperSelectionChange($event?: StepperSelectionEvent) {

    if ($event.selectedIndex == 3) {
      
      let currentConfigDataObj = this.getJsonConfigObjectWithUserSelections();
 
      this.editorSelections.set(currentConfigDataObj);
    }
  }

   getJsonConfigObjectWithUserSelections() {
    let currentConfigDataObj = this._configObject;

   //FlinkFlow
    currentConfigDataObj["FlinkFlow"]["CameraEngine"] = this._cameraControl;
    currentConfigDataObj["FlinkFlow"]["StreamAgg"] = this._streamAgg;
    currentConfigDataObj["FlinkFlow"]["CVT"] = this._cvt;
    currentConfigDataObj["FlinkFlow"]["MultiView"] = this._multiVew;
    currentConfigDataObj["FlinkFlow"]["DecoderWithMultiView"] = this._decoderWithMultiView;
    currentConfigDataObj["FlinkFlow"]["CleanBackground"] = this._cleanBackground;
    currentConfigDataObj["FlinkFlow"]["Localization"] = this._localization;
    currentConfigDataObj["FlinkFlow"]["Association"] = this._association;
    currentConfigDataObj["FlinkFlow"]["Segmentation"] = this._segmentation;
    currentConfigDataObj["FlinkFlow"]["Reconstruction"] =  this._reconstruction; 
    currentConfigDataObj["FlinkFlow"]["Dxt"] = this._dxt;
    currentConfigDataObj["FlinkFlow"]["Renderer"] = this._renderer;
    currentConfigDataObj["FlinkFlow"]["DigitalZoom"] = this._digitalZoom;


    //FeaturesPOC
    currentConfigDataObj["FeaturesPOC"]["Checkpoints"] = this._checkpoints;
    currentConfigDataObj["FeaturesPOC"]["SegRender"] = this._segRenderer;
    currentConfigDataObj["FeaturesPOC"]["CBGRender"] = this._cbgRenderer;
    currentConfigDataObj["FeaturesPOC"]["UnifyPMDStreams"] = this._unityPMDStreams;
    //ROOT
    currentConfigDataObj["pcamFlow"] = this._pcamFlow;
    currentConfigDataObj["vcamFlow"] = this._vcamFlow;
    currentConfigDataObj["realCvt"] = this._realCvt;
    currentConfigDataObj["sourceParl"] =   this._kinesisParallelism;
    currentConfigDataObj["cvtStreamToListen"] = this._cvtStreamToListen;
    currentConfigDataObj["cvtProducerStream"] = this._cvtProducerStream ;
    currentConfigDataObj["DEBUG"] = this._debug;
    currentConfigDataObj["InfoLog"] = this._info;
    currentConfigDataObj["MonitorLog"] = this._monitorBi;
    currentConfigDataObj["StateTimeToLive"] = this._stateTimeToLive;
    currentConfigDataObj["parallelism"] = this._parallelism;
    currentConfigDataObj["Region"] = this._region;
    
    let selectedCamerasArr = [];
      this._selectedCameras.forEach(element => {
        selectedCamerasArr.push(element);
    });
    currentConfigDataObj["cameras"] = selectedCamerasArr;

    //FlinkRestartStrategy
    currentConfigDataObj["FlinkRestartStrategy"]["restartAttempts"] = this._restartAttempts;
    currentConfigDataObj["FlinkRestartStrategy"]["restartDelay"] = this._restartDelay;
    //Checkpoints
    currentConfigDataObj["Checkpoints"]["intervalMS"] = this._intervalMS;
    currentConfigDataObj["Checkpoints"]["path"] = this._path;
    currentConfigDataObj["Checkpoints"]["async"] = this._async;
    //MultiView
    currentConfigDataObj["MultiView"]["asyncTimeout"] = this._mv_asyncTimeout;
    currentConfigDataObj["MultiView"]["asyncStackSize"] = this._mv_asyncStackSize; 
    currentConfigDataObj["MultiView"]["collectionTime"] = this._mv_collectionTime; 
    currentConfigDataObj["MultiView"]["grpcDeadline"] = this._mv_grpcDeadline;
    currentConfigDataObj["MultiView"]["bridge"] = this._mv_bridge;
    currentConfigDataObj["MultiView"]["fixedWindow"] = this._mv_fixedWindow;
    //CVT
    currentConfigDataObj["Cvt"]["collectionTime"] = this._cvt_collectionTime;
    
    let selectedCvtCamerasArr = [];
      this._cvt_cameras.forEach(element => {
        selectedCvtCamerasArr.push(element);
    });
    currentConfigDataObj["Cvt"]["cameras"] = selectedCvtCamerasArr;
    currentConfigDataObj["Cvt"]["fixedWindow"] = this._cvt_fixedWindow;
    //StreamAggReal
    currentConfigDataObj["StreamAggReal"]["framesPerGop"] = this._sar_framesPerGop;
    currentConfigDataObj["StreamAggReal"]["collectionTime"] = this._sar_collectionTime;
    currentConfigDataObj["StreamAggReal"]["asyncTimeout"] = this._sar_asyncTimeout;
    currentConfigDataObj["StreamAggReal"]["asyncStackSize"] = this._sar_asyncStackSize;
    currentConfigDataObj["StreamAggReal"]["grpcDeadline"] = this._sar_grpcDeadline;
    currentConfigDataObj["StreamAggReal"]["bridge"] = this._sar_bridge;
    currentConfigDataObj["StreamAggReal"]["fixedWindow"] = this._sar_fixedWindow; 
    //StreamAggReal
    currentConfigDataObj["StreamAggVirtual"]["framesPerGop"] = this._sav_framesPerGop;
    currentConfigDataObj["StreamAggVirtual"]["collectionTime"] = this._sav_collectionTime;
    currentConfigDataObj["StreamAggVirtual"]["asyncTimeout"] = this._sav_asyncTimeout;
    currentConfigDataObj["StreamAggVirtual"]["asyncStackSize"] = this._sav_asyncStackSize;
    currentConfigDataObj["StreamAggVirtual"]["grpcDeadline"] = this._sav_grpcDeadline;
    currentConfigDataObj["StreamAggVirtual"]["bridge"] = this._sav_bridge;
    currentConfigDataObj["StreamAggVirtual"]["fixedWindow"] = this._sav_fixedWindow;
    //Dxt
    currentConfigDataObj["Dxt"]["collectionTime"] = this._dxt_collectionTime;
    currentConfigDataObj["Dxt"]["asyncTimeout"] = this._dxt_asyncTimeout;
    currentConfigDataObj["Dxt"]["asyncStackSize"] = this._dxt_asyncStackSize;
    currentConfigDataObj["Dxt"]["grpcDeadline"] = this._dxt_grpcDeadline; 
    currentConfigDataObj["Dxt"]["bridge"] = this._dxt_bridge;
    currentConfigDataObj["Dxt"]["fixedWindow"] = this._dxt_fixedWindow;
    //CleanBackground
    currentConfigDataObj["CleanBackground"]["asyncTimeout"] = this._cbg_asyncTimeout;
    currentConfigDataObj["CleanBackground"]["asyncStackSize"] = this._cbg_asyncStackSize; 
    currentConfigDataObj["CleanBackground"]["grpcDeadline"] = this._cbg_grpcDeadline;
    currentConfigDataObj["CleanBackground"]["bridge"] = this._cbg_bridge;
    //Localization
    currentConfigDataObj["Localization"]["asyncTimeout"] = this._loc_asyncTimeout;
    currentConfigDataObj["Localization"]["asyncStackSize"] = this._loc_asyncStackSize;
    currentConfigDataObj["Localization"]["grpcDeadline"] = this._loc_grpcDeadline;
    currentConfigDataObj["Localization"]["bridge"] = this._loc_bridge;
    //Association
    currentConfigDataObj["Association"]["asyncTimeout"] = this._association_asyncTimeout;
    currentConfigDataObj["Association"]["asyncStackSize"] = this._association_asyncStackSize;
    currentConfigDataObj["Association"]["collectionTime"] = this._association_collectionTime;
    currentConfigDataObj["Association"]["grpcDeadline"] = this._association_grpcDeadline;
    currentConfigDataObj["Association"]["bridge"] = this._association_bridge;
    currentConfigDataObj["Association"]["fixedWindow"] = this._association_fixedWindow;
    //Segmentation
    currentConfigDataObj["Segmentation"]["asyncTimeout"] = this._seg_asyncTimeout;
    currentConfigDataObj["Segmentation"]["asyncStackSize"] = this._seg_asyncStackSize; 
    currentConfigDataObj["Segmentation"]["grpcDeadline"] = this._seg_grpcDeadline;
    currentConfigDataObj["Segmentation"]["bridge"] = this._seg_bridge;
    //Reconstruction
    currentConfigDataObj["Reconstruction"]["asyncTimeout"] = this._recon_asyncTimeout;
    currentConfigDataObj["Reconstruction"]["asyncStackSize"] = this._recon_asyncStackSize;
    currentConfigDataObj["Reconstruction"]["collectionTime"] = this._recon_collectionTime;
    currentConfigDataObj["Reconstruction"]["collectionTimeAllServices"] = this._recon_collectionTimeAllServices; 
    currentConfigDataObj["Reconstruction"]["grpcDeadline"] = this._recon_grpcDeadline;
    currentConfigDataObj["Reconstruction"]["bridge"] = this._recon_bridge;
    currentConfigDataObj["Reconstruction"]["fixedWindow"] = this._recon_fixedWindow;
    currentConfigDataObj["Reconstruction"]["services"]["Sidelines"] = this._recon_sidelines;
    currentConfigDataObj["Reconstruction"]["services"]["Ball"] = this._recon_ball;
    currentConfigDataObj["Reconstruction"]["services"]["Seats"] = this._recon_seats;
    currentConfigDataObj["Reconstruction"]["services"]["Basket"] = this._recon_basket; 
    //CameraControl
    currentConfigDataObj["CameraControl"]["asyncTimeout"] = this._camc_asyncTimeout;
    currentConfigDataObj["CameraControl"]["asyncStackSize"] = this._camc_asyncStackSize; 
    currentConfigDataObj["CameraControl"]["grpcDeadline"] = this._camc_grpcDeadline; 
    currentConfigDataObj["CameraControl"]["bridge"] = this._camc_bridge;
    //Renderer
    currentConfigDataObj["Renderer"]["partition2d"] = this._renderer_partition2d;
    currentConfigDataObj["Renderer"]["partition4k"] = this._renderer_partition4k;
    currentConfigDataObj["Renderer"]["partitionPano"] = this._renderer_partitionPano;
    currentConfigDataObj["Renderer"]["asyncTimeout"] =this._renderer_asyncTimeout;
    currentConfigDataObj["Renderer"]["asyncStackSize"] = this._renderer_asyncStackSize;
    currentConfigDataObj["Renderer"]["grpcDeadline"] = this._renderer_grpcDeadline;
    currentConfigDataObj["Renderer"]["bridge"] = this._renderer_bridge;
    //DigitalZoom
    currentConfigDataObj["DigitalZoom"]["asyncTimeout"] = this._digz_asyncTimeout;
    currentConfigDataObj["DigitalZoom"]["asyncStackSize"] = this._digz_asyncStackSize;
    currentConfigDataObj["DigitalZoom"]["grpcDeadline"] = this._digz_grpcDeadline;
    currentConfigDataObj["DigitalZoom"]["bridge"] = this._digz_bridge;

    let selectedDigzCamerasArr = [];
      this._digz_cameras.forEach(element => {
        selectedDigzCamerasArr.push(element);
    });
    currentConfigDataObj["DigitalZoom"]["cameras"] = selectedDigzCamerasArr;

    return currentConfigDataObj;
   }

   runCustomFlow() {

    this.operationsService.CustomFlowIsRunning = true;

    let currentConfigDataObj = this.getJsonConfigObjectWithUserSelections();

    let currentConfigDataString = JSON.stringify(currentConfigDataObj);
 
    let dynamicParameters = this._flinkVersion + " $programsBucket $programsBucketRegion $flinkJobManagerEndpoint " + this._startFrame + " " + this._endFrame + " " + this._clipName + " " + currentConfigDataString + " $s3ConfigBucket $s3ConfigBucketRegion";

    this.operationsService.startCustomFlow(dynamicParameters);
   }

   myToggleAllSelection() {
    if (this.myAllSelected) {
      this.select.options.forEach((item: MatOption) => item.select());
    } else {
      this.select.options.forEach((item: MatOption) => item.deselect());
    }
   }
   
   cameraOptionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.myAllSelected = newStatus;
  }

  myCvtToggleAllSelection() {
    if (this.myCvtAllSelected) {
      this.cvt_select.options.forEach((item: MatOption) => item.select());
    } else {
      this.cvt_select.options.forEach((item: MatOption) => item.deselect());
    }
   }
   
   cameraCvtOptionClick() {
    let newStatus = true;
    this.cvt_select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.myCvtAllSelected = newStatus;
  }

  myDigzToggleAllSelection() {
    if (this.myDigzAllSelected) {
      this.digz_select.options.forEach((item: MatOption) => item.select());
    } else {
      this.digz_select.options.forEach((item: MatOption) => item.deselect());
    }
   }
   
   cameraDigzOptionClick() {
    let newStatus = true;
    this.digz_select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.myDigzAllSelected = newStatus;
  }
}
