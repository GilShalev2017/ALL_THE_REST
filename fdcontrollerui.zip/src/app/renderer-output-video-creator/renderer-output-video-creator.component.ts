import { Component, OnInit } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { UIExecutingTask } from '../models/UIExecutingTask';
import { S3ImageViewerComponent } from '../s3-image-viewer/s3-image-viewer.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatDialog } from '@angular/material/dialog';
import { faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye } from '@fortawesome/free-solid-svg-icons';
import { ODTask } from "../models/ODTask";

@Component({
  selector: 'app-renderer-output-video-creator',
  templateUrl: './renderer-output-video-creator.component.html',
  styleUrls: ['./renderer-output-video-creator.component.css']
})
export class RendererOutputVideoCreatorComponent implements OnInit {

  startFrame: string;
  endFrame: string;
  faStop = faStop;

  constructor(public operationsService: OperationsService, public dialog: MatDialog) { }

  ngOnInit(): void {

     if(this.operationsService.isTasksLoaded==false) {
        this.operationsService.getODTasks()
          .subscribe( (arrivedData: ODTask[]) => {});
      };
  }

  launcVideoCreation() {
  
    this.operationsService.rendererOutputVideoCreationTasks = [];
    //dyanamic Parameters: startFrame EndFrame
    this.operationsService.isVideoCreationRunning = true;

    this.operationsService.startRendererOutputVideoCreation(this.startFrame, this.endFrame);
  }

  stopTask(task: UIExecutingTask, event?: Event){
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.stopTask(task.ExecutingTaskStatus.executerId);
  }

  cleanHistory() {
    this.operationsService.rendererOutputVideoCreationTasks = [];
  }

      
  getLog(executerId: string) {
   
    if (event) {
        event.stopPropagation();
    } 
  }
  
  openS3Bucket(task: UIExecutingTask, event) {
    if (event) {
      event.stopPropagation();
    } 

    let bucketPlusRest = task.ResultsS3Bucket.split("s3://")[1];
  
    let bucket = bucketPlusRest.split("/")[0];

    let fixedS3prefix = "https://s3.console.aws.amazon.com/s3/buckets/";

    let objectPath = bucketPlusRest.split(bucket)[1];

    let folderPrefixSplits = objectPath.split("/");

    let folderPrefix = folderPrefixSplits[1];

    for(let i = 2; i < (folderPrefixSplits.length-1); i++) //without last 
    {
      folderPrefix = folderPrefix + "/" + folderPrefixSplits[i];
    }

    folderPrefix = folderPrefix + "/";

    let region = "us-east-1";

    let s3Link = fixedS3prefix + bucket + "?region=" + region + "&prefix=" + folderPrefix;

    window.open(s3Link, "_blank");
  }

  getImage(task: UIExecutingTask) {

    if (event) {
        event.stopPropagation();
    }

   let bucketPlusRest = task.ResultsS3Bucket.split("s3://")[1];
  
    let bucketName = bucketPlusRest.split("/")[0];

    let fixedS3prefix = "https://s3.console.aws.amazon.com/s3/buckets/";

    let objectPath = bucketPlusRest.split(bucketName)[1];

    let folderPrefixSplits = objectPath.split("/");

    let folderPrefix = folderPrefixSplits[1];
   
    let oneLevelUp = folderPrefixSplits[1];

    for(let i = 2; i < (folderPrefixSplits.length-1); i++) 
    {
      folderPrefix = folderPrefix + "/" + folderPrefixSplits[i];
    }

    for(let i = 2; i < (folderPrefixSplits.length-2); i++) //without last 
    {
      oneLevelUp = oneLevelUp + "/" + folderPrefixSplits[i];
    }

    folderPrefix = folderPrefix;

    let bucketRegion = 'us-east-1';
    let bucketBaseKey = oneLevelUp;
    
    folderPrefix = folderPrefix + "/";
    let s3BucketUrl = fixedS3prefix + bucketName + "?region=" + bucketRegion + "&prefix=" + folderPrefix;

    this.operationsService.getBucketFileTree(bucketName,bucketBaseKey,bucketRegion)
      .subscribe(data => {

       // let filesPrefix = "fd19-dep-video/a01ver445jykhy8/2020_11_24/16_26/mp4_30fps_";
    
        const dialogRef = this.dialog.open(S3ImageViewerComponent, {
          data: 
          {
            "toolType": "v4v",
            "filesPrefix": oneLevelUp,
            "bucketName": bucketName,
            "bucketRegion": bucketRegion,
            "s3BucketUrl": s3BucketUrl
          },
          maxWidth: '90vw',
          maxHeight: '90vh',
          height: '90%',
          width: '90%'
        });
       
      });
  }


  getFakeDemoMedia() {

    //https://s3.console.aws.amazon.com/s3/upload/4sasha?region=us-east-1&prefix=a01ver445jykhy8/2020_11_17/15_34/mp4/
    //https://s3.console.aws.amazon.com/s3/buckets/4sasha?region=us-east-1&prefix=fd19-dep-video/a01ver445jykhy8/2020_11_17/15_34/mp4/&showversions=false
    //FOR DEMO
    let folderPrefix = "fd19-dep-video/a01ver445jykhy8/2020_11_17/15_34/mp4/";
    let oneLevelUp = "fd19-dep-video/a01ver445jykhy8/2020_11_17/15_34";
    let bucketName = '4sasha';
    let bucketRegion = 'us-east-1';
    let bucketBaseKey = oneLevelUp;

    this.operationsService.getBucketFileTree(bucketName,bucketBaseKey,bucketRegion)
      .subscribe(data => {

       let s3BucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/4sasha?region=us-east-1&prefix=" + folderPrefix;

        const dialogRef = this.dialog.open(S3ImageViewerComponent, {
          data: 
          {
            "toolType": "v4v",
            "filesPrefix": oneLevelUp,
            "bucketName": bucketName,
            "bucketRegion": bucketRegion,
            "s3BucketUrl": s3BucketUrl
          },
          maxWidth: '90vw',
          maxHeight: '90vh',
          height: '90%',
          width: '90%'
        });
       
      });
  }
}
