import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { OperationsService } from "../services/operations.service";
import { ODTask } from "../models/ODTask";

@Component({
  selector: 'app-delete-task',
  templateUrl: './delete-task.component.html',
  styleUrls: ['./delete-task.component.css']
})
export class DeleteTaskComponent {

  constructor(public dialogRef: MatDialogRef<DeleteTaskComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODTask,
              public dataService: OperationsService)
  { }
  
  onNoClick(): void {
    this.dialogRef.close();
  }

  confirmDelete(): void {
    this.dataService.deleteODTask(this.data).
     subscribe((res: boolean) => {

    });
  }

}
