import {ODTask} from "./ODTask";

export class ODFlow {
  Id?: string;
  Name?: string;
  Description?: string;
  CreatedBy?: string;
  CreatedAt?: string;
  UpdatedBy?: string;
  UpdatedAt?: string;

  Tasks?: ODTask[];

  CleanupTasks?: ODTask[];

  TasksString?: string;
  IsFinished?: boolean;
  DurationInMillis?: number;
  RunInParallel?: string;
  IsFlinkFlow?: string;
 }