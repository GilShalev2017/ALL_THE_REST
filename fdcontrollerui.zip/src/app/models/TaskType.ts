// export enum TaskType{
//     General,
//     KDSPublisher,
//     Flink,
//     DebugKit,
//     V4V,
//     KdsInspecting,
//     MVV,
//     RendererOutputVideoCreator,
// }