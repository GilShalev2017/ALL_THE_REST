
export class ExecutingTaskStatus {
  taskId: string;
  executerId?: string;
  deploymentId?: string;
  startDateTime?: string;
  endDateTime?: string;
  taskStatus?: TaskStatus; 
  statusString?: string; 
  errorData?:string; 
  flowExecuterId? : string;
  flowId?: string;
  executerName?: string;
  fdControllerId?: string;
  taskType?: string;
  dynamicTaskName?: string;
  s3DebugKitBucketUrl?:string;
  s3BucketUrl?: string;
}

export enum TaskStatus {
  TaskStarting,
  TaskStarted,
  TaskCompleted,
  TaskCompletedWithError,
  ProcessExited,
  TaskStopped,
  TaskStoppedError,
}