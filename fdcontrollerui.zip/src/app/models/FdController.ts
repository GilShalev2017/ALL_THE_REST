export class FdController {
  name: string;
  connectionId?: string;
  connectionStatus?: string;
  groupName?: string;
  deploymentId?: string;
}