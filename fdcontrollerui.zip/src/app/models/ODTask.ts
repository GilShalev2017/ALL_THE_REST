import {ODProgram} from "./ODProgram";

export class ODTask {
  Id?: string;
  
  ODProgramId?: string;
  ODProgramName?: string;
  ODProgram?: ODProgram;
  
  CategoryGroup?: string;
  Name?: string;
  Description?: string;
  ProgramToExecute?: string;
  ProgramParameters?: string;
  TaskParameters?: string;
  ReportStandardOutput?: boolean;

  
  OverrideDefaultParameters?: boolean;
  OverridenTaskParameters?: string;

  CreatedBy?: string;
  CreatedAt?: string;
  UpdatedBy?: string;
  UpdatedAt?: string;
  
  // FinalizationTaskId?: string;
  // FinalizationTaskName?: string;
  // FinalizationTask?: ODTask;
  // WorkingDirectory?: string;
}
