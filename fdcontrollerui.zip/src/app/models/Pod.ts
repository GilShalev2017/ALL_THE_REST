export class Pod {
    Name?: string;
    Ready?: string;
    Status?: string;
    Restarts?: string;
    Age?: string;
}