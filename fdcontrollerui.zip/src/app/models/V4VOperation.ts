export class V4VOperation{
    IsSelected?: boolean;
    Name: string;
}   