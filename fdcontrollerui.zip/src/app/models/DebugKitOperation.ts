export class DebugKitOperation{
    IsSelected?: boolean;
    Name: string;
}   