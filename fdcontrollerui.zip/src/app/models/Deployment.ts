export class Deployment {
    deployment_status?: string;
    deployment_name?: string;
    deployment_id?: string;
    deployment_region?: string;
    default_game_id?: string;
    game_id?: string;
}