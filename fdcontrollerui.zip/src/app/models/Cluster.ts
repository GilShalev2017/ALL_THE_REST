import { Pod } from "./Pod";

export class Cluster{
    Name?: string;
    Component?: string;
    Type?: string;
    Size?: string;
    ServerType?: string;
    Pods?: Pod[];
    expanded? : boolean;
}