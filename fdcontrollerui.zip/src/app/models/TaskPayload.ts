export class TaskPayload {
    TaskId?: string;
    DeploymentId?: string;
    GameId?: string;
    ExecuterName?: string;
    ExecuterId?: string;
    JsonConfigDynamicParameters?: string;
    DynamicParameters?: string;
    DynamicTaskName?: string;
    TaskType?: string;
    AddAutoLogName?: boolean;
    LogName?: string;
    TargetPod?: string;
    AreParametersOverriden?: boolean;
    OverridingParameters?: string;
}