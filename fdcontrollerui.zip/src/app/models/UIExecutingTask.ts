import {ODTask} from "./ODTask";
import {ExecutingTaskStatus} from "./ExecutingTaskStatus";

export class UIExecutingTask
{
  ODTask: ODTask; //from DB
  DynamicTaskName?: string;
  ExecutingTaskStatus?: ExecutingTaskStatus; //from HUB

  StdOut?: string[]; //from Worker
  //Temporarily
  CurrentStatusLine?: string;
  CurrentAvgFps?: string;
  TotalAddedRecords?: string;

  SportGroupInformation?: string;
  VenueInformation?: string;
  GameID?: string;
  
  expanded?: boolean; //UI  

  ResultsS3Bucket?: string;
  FileUrl?: string;
}