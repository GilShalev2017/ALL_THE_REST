export class FlinkJob {
    jid?: string;
    name?: string;
    state?: string;
    startTime?: number;
    endTime?: number;
    duration?: string;
    lastModification?: number;
    tasks?: string;
    uiCancelOpertaionText?: string;
}

export class FlinkTasks {
    total?: number;
    created?: number;
    scheduled?: number;
    deploying?: number;
    running?: number;
    finished?: number;
    canceling?: number;
    canceled?: number;
    failed?: number;
    reconciling?: number;
}