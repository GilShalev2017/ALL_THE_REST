export class LogFileDetails [
   LogFileName?: string; 
   S3BucketName?: string; 
   S3BucketRegion?: string; 
   S3BaseKey ?: string; 
]