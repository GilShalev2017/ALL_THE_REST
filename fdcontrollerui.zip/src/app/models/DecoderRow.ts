export class DecoderRow{
 CameraId?: string;
 ScanType?: string;
 KvsStream?: string;
//  Region?: string;
 SaveEncodedFrames?: boolean;
 StopAtFrameId?: string;
 StopAfterTotalFrames?: string;
 Editable?: string;
}