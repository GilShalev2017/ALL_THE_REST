export class FlinkTaskPayload {
    FlinkTaskType?: FlinkTaskType;
    JarName?: string;
    DeploymentId?: string;
    JobId?: string;
}

export enum FlinkTaskType {
     UploadJar,
     RunJar,
     StopJob,
     GetDeployedJarList,
     GetDeployedJarPlan,
     JobsOverview,
}