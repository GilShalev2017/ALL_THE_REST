export class CompletedTask {
  Id: string;
  Name: string;
  CategoryGroup?: string;
  Description?: string;
  StartDateTime?: string;
  EndDateTime?: string;
  Status?: string; 
  Error?:string; 
  ExecuterName?: string;
  DeploymentId?: string;
  FdControllerId?: string;
}