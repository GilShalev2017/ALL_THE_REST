export class FlowPayload {
    FlowId?: string;
    DeploymentId?: string;
    FlowExecuterId?: string;
    ExecuterName?: string;
    FlowTaskParameters?: string;
    FlowJsonParameters?: string;

    // GameId?:string;
    // PlayId?:string;
    // RunId?: string;
}