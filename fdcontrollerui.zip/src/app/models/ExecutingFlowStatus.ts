import {TaskStatus} from "./ExecutingTaskStatus";

export class ExecutingFlowStatus {
  flowId: string;
  flowExecuterId?: string;
  fdControllerId?: string;
  deploymentId?: string;
  startDateTime?: string;
  endDateTime?: string; 
  status?: FlowStatus; 
  statusString?: string; 
  errorData? : string;
  executerName?: string;
  gameId?: string;
  playId?: string;
  runId?: string;
  jobId?: string;
  progress?: number;
  activity?: Activity;
}

export enum FlowStatus {
  FlowStarting,
  FlowStarted,
  FlowCompleted,
  FlowCompletedWithError,
  FlowStopped,
  FlowStoppedError,
}

export class Activity {
  runningTaskName?: string; 
  runningTaskStatus?: TaskStatus;
}