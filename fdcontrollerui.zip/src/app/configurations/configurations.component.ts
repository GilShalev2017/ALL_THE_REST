import { Component, OnInit, ViewChild } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { AuthService } from './../auth/auth.service';
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-configurations',
  templateUrl: './configurations.component.html',
  styleUrls: ['./configurations.component.css']
})
export class ConfigurationsComponent implements OnInit {

  public editorOptions: JsonEditorOptions;
  public _isDirty: boolean = false;
    
  @ViewChild(JsonEditorComponent) editor: JsonEditorComponent;

  constructor(public operationsService: OperationsService,
              public auth: AuthService) { 
                
    this.editorOptions = new JsonEditorOptions()
    this.editorOptions.modes = ['code', 'text', 'tree', 'view'];//, 'expandAll']; // set all allowed modes
    //this.options.mode = 'code'; //set only one mode
  }

  ngOnInit() {
  
  }

  onConfigFileSelected(event: any) {
    this._isDirty = false;
    this.operationsService.getConfigContent(event)
      .subscribe();
  }

  updateConfig() {
      let currentData = JSON.stringify(this.editor.get());
      this.operationsService.setConfigContent(currentData)
       .subscribe();
      this._isDirty = false;
  }
  
  getAllConfigurations() {
      this.operationsService.getConfigurations()
        .subscribe( result => {
            let res = result;
        });
  }

  getData(event) {
    this._isDirty = true;
  }
}
