import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UIExecutingFlow} from "../models/UIExecutingFlow";
import { UIExecutingTask} from "../models/UIExecutingTask";
import { FlowsService } from "../services/flows.service";
import { OperationsService } from "../services/operations.service";
import { MatDialog } from '@angular/material/dialog';
import { DeleteFlowComponent } from '../delete-flow/delete-flow.component';
import { FlinkRunningJobsComponent } from '../flink-running-jobs/flink-running-jobs.component';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AuthService } from './../auth/auth.service';
import { FlinkTaskPayload, FlinkTaskType } from "../models/FlinkTaskPayload";
import { AppConfigurationService } from '../services/app-configuration.service';
import { ExecutingFlowStatus, FlowStatus } from "../models/ExecutingFlowStatus";
import { ExecutionParametersComponent } from '../execution-parameters/execution-parameters.component';

@Component({
  selector: 'app-flow-details',
  templateUrl: './flow-details.component.html',
  styleUrls: ['./flow-details.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class FlowDetailsComponent implements OnInit {
  
  //displayedColumns: string[] = ['Status', 'Name', 'Description', 'TaskParameters', 'Duration', 'Finished', 'actions'];
  displayedColumns: string[] = ['Status', 'Name', 'TaskParameters', 'Duration', 'Finished', 'actions'];
  dataSource: UIExecutingTask[] = [];
  expandedElement: UIExecutingTask | null;
  _intervalId: number;
  reportsFolder: string;
  displayFlowFlag:boolean = false;

  @Input() activeFlow: UIExecutingFlow;
  @Output() flowDeleted: EventEmitter<UIExecutingFlow> = new EventEmitter<UIExecutingFlow>();

  constructor(public flowsService: FlowsService,
              public operationsService: OperationsService,
              public auth: AuthService,
              public dialog: MatDialog,
              public appconfig:AppConfigurationService) { 
                
     this.reportsFolder = this.appconfig.s3ProgramsBucket + "/Reports/";
  }

  ngOnInit() {

    if(this.activeFlow != null){
      this.dataSource = this.activeFlow.UITasks;
    }

    if(this.auth.isProductionUser()==true) {
      this.getJobsOverview();
      // this._intervalId = window.setInterval( () => 
      //       {
      //         this.getJobsOverview()
      //       }, 2000);
    }
 
  }

  buildTasksOverridingParametersPayload() {

    let parametersPayload = {};
    let flag: boolean = false;

    this.activeFlow.UITasks.forEach( task=> {
      if(task.ODTask.OverrideDefaultParameters) {
        parametersPayload[task.ODTask.Id] = task.ODTask.OverridenTaskParameters;
        flag = true;
      }
    });

    if(flag)
       return parametersPayload;

    return null;
  }

  startFlow() {
    let parametersPayload = this.buildTasksOverridingParametersPayload();

    if(parametersPayload != null) {
      let parametersPayloadString = JSON.stringify(parametersPayload);
      this.operationsService.startFlowWithTaskParameters(this.activeFlow, parametersPayloadString); //In case user edited tasks parameters
    }
    else {
      this.operationsService.startFlow(this.activeFlow); //In case user is running with default parameters
    }
  }

  stopFlow() {
    this.operationsService.stopFlow(this.activeFlow);
  }

  deleteFlow() {
     const dialogRef = this.dialog.open(DeleteFlowComponent, {
      data: this.activeFlow
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.flowDeleted.emit(this.activeFlow);
        this.flowsService.getAllFlows();
      }
    });
  }

  editFlow() {
      this.displayFlowFlag = true;
  }

  closeEditor(event) {
    this.displayFlowFlag = false;
  }

  onFlowEdited(event) {
    this.displayFlowFlag = false;
  }

   getJobsOverview(): void {
    let flinkTaskPayload: FlinkTaskPayload = {
            FlinkTaskType: FlinkTaskType.JobsOverview,
            DeploymentId: this.operationsService.selectedDeployment.deployment_id
          }
    this.operationsService.startFlinkTask(flinkTaskPayload);
  }

  runSingleTask(row: UIExecutingTask, event) {
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.startTask(row.ODTask.Id);
  }

  getLog(executerId: string) {
   
    if (event) {
        event.stopPropagation();
    } 

    let assetKey = "SanityTest/" + executerId + ".html";
    //let assetKey = "sanity_log_report.html";//executerId + "_report.html";
    
    this.operationsService.getProgramPresignedUrlForReport(assetKey)
        .subscribe(result => {
          let reportUrl = result['URL_STRING'];
          // location.go(reportUrl);
          window.open(reportUrl, "_blank");
        });
  }

  public isFlowRunning(): boolean {
    return true;
  }

  overrideDefaultParameters(task: UIExecutingTask) {
    
    if(!task.ODTask.TaskParameters) //return if there are no parameters set
      return;

    task.ODTask.OverrideDefaultParameters = !task.ODTask.OverrideDefaultParameters;

    if(!task.ODTask.OverridenTaskParameters)
    {
      task.ODTask.OverridenTaskParameters = task.ODTask.TaskParameters;
    }

    let taskParamsArray = this.getTaskParamsArray(task);
    
    if(task.ODTask.OverrideDefaultParameters)
    {
      const dialogRef = this.dialog.open(ExecutionParametersComponent, {
            data: taskParamsArray
      });

      dialogRef.afterClosed().subscribe(res => {
        // received data from ExecutionParametersComponent
        if (res.feed == true) {
            task.ODTask.OverrideDefaultParameters = true;
            task.ODTask.OverridenTaskParameters = this.GetTaskParametersFromFlowJson(task.ODTask.TaskParameters, res.data);
        }
      })
    }
  }

  findFlowParameters() {
    let parameters = {};

    this.activeFlow.UITasks.forEach(task => {
        if(task.ODTask.TaskParameters) {
          let taskParameters = task.ODTask.TaskParameters.split(" ");
          for(let i = 0; i < taskParameters.length; i+=2) {
            parameters[taskParameters[i]] = taskParameters[i+1];
          }
        }
    });

    return parameters;
  }


  findFlowParametersForJson() {
    let parameters = {};

    this.activeFlow.UITasks.forEach(task => {
        if(task.ODTask.TaskParameters) {
          let taskParameters = task.ODTask.TaskParameters.split(" ");
          for(let i = 0; i < taskParameters.length; i+=2) {
            let paramName = taskParameters[i].replace("--","");
            parameters[paramName] = taskParameters[i+1];
          }
        }
    });

    return parameters;
  }

  getTaskParamsArray(task: UIExecutingTask) {
    let paramArray = [];
    
    if(task.ODTask.TaskParameters) {
      
      let taskParameters = null;

      if(task.ODTask.OverrideDefaultParameters) {
          taskParameters = task.ODTask?.OverridenTaskParameters.split(" ");
      }
      else {
          taskParameters = task.ODTask.TaskParameters.split(" ");
      }

      for(let i = 0; i < taskParameters.length; i+=2) {
        let paramName = taskParameters[i].replace("--","");
        let paraValue = taskParameters[i+1];
        let paramKeyPair = {
          "key": paramName,
          "value": paraValue
        };
        paramArray.push(paramKeyPair);
      }
    }

    return paramArray;
  }

  getParamsArray() {
    let paramArray = [];

    this.activeFlow.UITasks.forEach(task => {
        if(task.ODTask.TaskParameters) {
          
          let taskParameters = null;

          if(task.ODTask.OverrideDefaultParameters) {
             taskParameters = task.ODTask.OverridenTaskParameters.split(" ");
          }
          else {
             taskParameters = task.ODTask.TaskParameters.split(" ");
          }

          for(let i = 0; i < taskParameters.length; i+=2) {
            let paramName = taskParameters[i].replace("--","");
            let paraValue = taskParameters[i+1];
            let paramKeyPair = {
              "key": paramName,
              "value": paraValue
            };
            paramArray.push(paramKeyPair);
          }
        }
    });

    return paramArray;
  }

  showExecutionParameters() {
    
    // let parameters = this.findFlowParametersForJson();
   
    let paramsArray = this.getParamsArray();

    const dialogRef = this.dialog.open(ExecutionParametersComponent, {
          //data: parameters
          data: paramsArray
    });

    dialogRef.afterClosed().subscribe(res => {
      // received data from ExecutionParametersComponent
      if (res.feed == true) {
        this.activeFlow.UITasks.forEach( task => {
          task.ODTask.OverrideDefaultParameters = true;
          task.ODTask.OverridenTaskParameters = this.GetTaskParametersFromFlowJson(task.ODTask.TaskParameters, res.data);
        });
      }
    })

  }

  GetTaskParametersFromFlowJson(taskParameters : string, flowParameters) {
    
    if(!taskParameters) {
     return;
    }

    let currentParams = taskParameters.split(" ");
    let finalParameters = "";

    for(let i=0; i < currentParams.length; i+=2) {      
      let paramNameWithoutPrefix = currentParams[i].replace("--", "");

      //when flowParameters is an array
      let keyValuePair = flowParameters.find(function (element) {
         return element.key == paramNameWithoutPrefix;
      });

      if(keyValuePair!=null) {
        if (!finalParameters)
        {
            finalParameters = "--" + paramNameWithoutPrefix + " " + keyValuePair["value"];
        }
        else
        {
            finalParameters = finalParameters + " --" + paramNameWithoutPrefix + " " + keyValuePair["value"];
        }
      }

    }

    return finalParameters;
  }

  testStop() {
    this.operationsService.testStop(this.activeFlow.ExecutingFlowStatus.flowExecuterId);
  }

  // getMode() {
  //   if(this.activeFlow.ExecutingFlowStatus.statusString == "FlowCompletedWithError" ||
  //      this.activeFlow.ExecutingFlowStatus.statusString == "FlowCompleted" ||
  //      this.activeFlow.ExecutingFlowStatus.statusString == "FlowStopped" ||
  //      this.activeFlow.ExecutingFlowStatus.statusString == "FlowStopping") {
  //        return null;
  //      }
  //    return "buffer"  ;
  // }
}

// let parameters = {
    //     "GameID": "998877",
    //     "PlayID": "778899",
    //     "RunId": "123456",
    //     "RunTimeStart": "1601830936165320",
    //     "RunTimeEnd": "1601841363631990",
    //     "RunMode": "runPclRender",
    //     "CamMode": "Auto",
    //     "ExecuterName": "Some-Cognito-User-Name",
    //     "StoragePath": {
    //       "SourceVcamConfigS3Bucket": "TBD",
    //       "SourceVcamConfigS3Prefix": "TBD",
    //       "sourceVenueStaticDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "sourceVenueStaticDataS3Prefix": "nfl/season2021/game20201228/staticData/",
    //       "sourceVenuePcamDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "sourceVenuePcamDataS3Prefix": "nfl/season2021/game20201228/PLAY123/pcams/",
    //       "destCvtTrackingDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "destCvtTrackingDataS3Prefix": "nfl/season2021/game20201228/PLAY123/trackingData/",
    //       "destCvtSkeletalDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "destCvtSkeletalDataS3Prefix": "nfl/season2021/game20201228/PLAY123/skeletalData/",
    //       "destPclDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "destPclDataS3Prefix": "nfl/season2021/game20201228/PLAY123/pclData/",
    //       "destPtzDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "destPtzDataS3Prefix": "nfl/season2021/game20201228/PLAY123/ptzData/",
    //       "destDepthMapsDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "destDepthMapsDataS3Prefix": "nfl/season2021/game20201228/PLAY123/depthMapData/",
    //       "destVcamDataS3Bucket": "isg-mam-data-management-svc-dev",
    //       "destVcamDataS3Prefix": "nfl/season2021/game20201228/PLAY123/runABC/vcamData/"
    //     }
    //   };