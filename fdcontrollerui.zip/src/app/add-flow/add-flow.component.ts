import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ODFlow} from "../models/ODFlow";
import { ODTask} from "../models/ODTask";
import { AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import { FlowsService} from "../services/flows.service";

import {SelectionModel} from '@angular/cdk/collections';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-add-flow',
  templateUrl: './add-flow.component.html',
  styleUrls: ['./add-flow.component.css']
})
export class AddFlowComponent implements OnInit {

   
  @Input() editedFlow: ODFlow;
  @Output() flowSaved: EventEmitter<ODFlow> = new EventEmitter<ODFlow>();
  @Output() closeEditor: EventEmitter<string> = new EventEmitter();
  
  isLinear :boolean;

  selectedTasks:ODTask[] = [];
  cleanupSelectedTasks:ODTask[] = [];

  nameDescriptionFormGroup: FormGroup;
  tasksFormGroup: FormGroup;
  cleanupTasksFormGroup: FormGroup;
  runInParallel : string = "false";
  
  constructor(private _formBuilder: FormBuilder,
              private flowsService: FlowsService) { }
  
  ngOnInit() {

    this.nameDescriptionFormGroup = this._formBuilder.group({
      nameCtrl: ['', Validators.required],
      descriptionCtrl: ['', Validators.required]
    });
    this.tasksFormGroup = this._formBuilder.group({
      
    });
    this.cleanupTasksFormGroup= this._formBuilder.group({
      
    });

    this.isLinear = true;
    //In case of edit - data bind to all the fields
    if(this.editedFlow){
        this.isLinear = false;

        let group = this.nameDescriptionFormGroup.value;
        group["nameCtrl"] = this.editedFlow.Name;
        group["descriptionCtrl"] = this.editedFlow.Description;

        this.selectedTasks = this.editedFlow.Tasks;
        this.cleanupSelectedTasks = this.editedFlow.CleanupTasks;
        this.runInParallel = this.editedFlow.RunInParallel;
       
        this.nameDescriptionFormGroup.patchValue({
            'nameCtrl': this.editedFlow.Name,
            'descriptionCtrl': this.editedFlow.Description
        })
    }
  }

  saveFlow() {
    
      let group = this.nameDescriptionFormGroup.value;
      let name = group["nameCtrl"];
      let description = group["descriptionCtrl"];

      let newFlow:ODFlow = {};
      newFlow.Name = name;
      newFlow.Description = description;
      newFlow.Tasks = this.selectedTasks;

      newFlow.CleanupTasks = this.cleanupSelectedTasks;

      newFlow.RunInParallel = this.runInParallel;
     
      newFlow.IsFlinkFlow = 'false';
      this.selectedTasks.forEach(task => {
        if(task.CategoryGroup=="Flink") {
          newFlow.IsFlinkFlow = 'true';
        }
      });
   
      this.flowsService.addFlowToDynamoDB(newFlow)
       .subscribe( elm => {
            this.flowSaved.emit(newFlow);
            this.flowsService.getAllFlows()
            .subscribe();
      });
  }
  
  updateFlow() {
      let group = this.nameDescriptionFormGroup.value;
      let name = group["nameCtrl"];
      let description = group["descriptionCtrl"];

      let newFlow:ODFlow = {};
      newFlow.Id = this.editedFlow.Id;
      newFlow.Name = name;
      newFlow.Description = description;
      newFlow.Tasks = this.selectedTasks;
      newFlow.CleanupTasks = this.cleanupSelectedTasks;
      newFlow.RunInParallel = this.runInParallel;
     
      newFlow.IsFlinkFlow = 'false';
      this.selectedTasks.forEach(task => {
        if(task.CategoryGroup=="Flink") {
          newFlow.IsFlinkFlow = 'true';
        }
      });
   
      this.flowsService.updateODFlow(newFlow)
       .subscribe( elm => {
            this.flowSaved.emit(newFlow);
            this.flowsService.getAllFlows()
            .subscribe();
      });
  }

  duplicateFlow() {
    this.saveFlow();
  }

  close() {
    this.closeEditor.emit("close");
  }

  onRunModeChange(value: string) {
    if(value =="1") {
      this.runInParallel = "true";
    }
    else {
      this.runInParallel = "false";
    }
  }

  drop(event: CdkDragDrop<string[]>) {

    moveItemInArray(this.selectedTasks, event.previousIndex, event.currentIndex);
  }

  cleanupDrop(event: CdkDragDrop<string[]>) {

    moveItemInArray(this.cleanupSelectedTasks, event.previousIndex, event.currentIndex);
  }
}
