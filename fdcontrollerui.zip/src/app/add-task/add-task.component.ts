import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { OperationsService } from "../services/operations.service";
import { ODTask } from "../models/ODTask";
import { SystemVariablesComponent } from '../system-variables/system-variables.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit  {

  constructor(public dialogRef: MatDialogRef<AddTaskComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODTask,
              public operationsService: OperationsService,
              public dialog: MatDialog) { }


  ngOnInit() {
    this.operationsService.getODPrograms()
          .subscribe();
  }

  submit() {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    
    this.data.ODProgramId = this.data.ODProgram.Id;
    this.data.ODProgramName = this.data.ODProgram.Name;
    this.data.ReportStandardOutput = true;

    this.operationsService.addODTask(this.data)
      .subscribe(result => {
        this.dialogRef.close(1);
    });
  }

  showSystemVariables() {
    const dialogRef = this.dialog.open(SystemVariablesComponent);
  }
}
