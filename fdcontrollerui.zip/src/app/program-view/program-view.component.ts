import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ProgramsService } from "../services/programs.service";
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ODProgram } from "../models/ODProgram";
import { DataSource } from '@angular/cdk/collections';
import { AddProgramComponent } from "../add-program/add-program.component";
import { EditProgramComponent } from '../edit-program/edit-program.component';
import { EditScriptComponent } from '../edit-script/edit-script.component';
import { DeleteProgramComponent } from '../delete-program/delete-program.component';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AuthService } from './../auth/auth.service';
import { AppConfigurationService } from '../services/app-configuration.service';
import { ToastrService} from 'ngx-toastr';
import { OperationsService} from "../services/operations.service";
import { ProgramType }  from "../models/ODProgram";

@Component({
  selector: 'app-program-view',
  templateUrl: './program-view.component.html',
  styleUrls: ['./program-view.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ProgramViewComponent implements OnInit {

  displayedColumns = ['Name', 'Description', 'ExecutedProgramParams', 'CategoryGroup', 'ProgramType', 'CreatedBy', 'CreatedAt','UpdatedBy','UpdatedAt','code','actions'];
  exampleDatabase: ProgramsService | null;
  dataSource: ProgramDataSource | null;
  index: number;
  id: string;
  expandedElement: ODProgram | null;
  public programType: typeof ProgramType = ProgramType;

  constructor(public httpClient: HttpClient,
              public dialog: MatDialog,
              public programsService: ProgramsService,
              public authService: AuthService, 
              public appconfig:AppConfigurationService,
              public operationsService: OperationsService,
              private toastr: ToastrService) {

              }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('filter',  {static: true}) filter: ElementRef;

  
  ngOnInit() {
      this.loadData();
   }
  
  refresh() {
    this.loadData();
  }

  addNew() {
    let oDProgram: ODProgram = {};
    const dialogRef = this.dialog.open(AddProgramComponent, {
      data: {oDProgram: ODProgram }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // After dialog is closed we're doing frontend updates
        // For add we're just pushing a new row inside DataService
        this.exampleDatabase.dataChange.value.push(this.programsService.getDialogData()); 
        this.refreshTable();
      }
    });
  }

  startEdit(i: number, row: ODProgram) {
  
    // const dialogRef = this.dialog.open(EditProgramComponent,{height:'800px',width:'1600px'}, {
    //   data: row
    // });
    //const dialogRef = this.dialog.open(EditProgramComponent,{height:'800px',width:'2000px', data: row  });
    const dialogRef = this.dialog.open(EditProgramComponent,{data: row  });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        // When using an edit things are little different, firstly we find record inside DataService by id
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.Id === row.Id);
        // Then you update that record using data from dialogData (values you enetered)
        this.exampleDatabase.dataChange.value[foundIndex] = this.programsService.getDialogData();
        // And lastly refresh table
        this.refreshTable();
      }
    });
  }

  deleteItem(i: number, row: ODProgram) {
    // this.index = i;
    // this.id = id;
    const dialogRef = this.dialog.open(DeleteProgramComponent, {
      // data: {Id: id, title: title, state: state, url: url}
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.Id === row.Id);
        // for delete we use splice in order to remove single object from DataService
        this.exampleDatabase.dataChange.value.splice(foundIndex, 1);
        this.refreshTable();
      }
    });
  }

  showScript(i: number, row: ODProgram) {
    let key = row.CategoryGroupString + "/" + row.Name + "/" + row.Package;

    this.programsService.getScriptContent(key)
      .subscribe(result=>{
     
        row.ScriptCode=result;

        const dialogRef = this.dialog.open(EditScriptComponent, {
              data: row
            });

          // dialogRef.afterClosed().subscribe(result => {
          //   if (result === 1) {
          //     // When using an edit things are little different, firstly we find record inside DataService by id
          //     const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.Id === row.Id);
          //     // Then you update that record using data from dialogData (values you enetered)
          //     this.exampleDatabase.dataChange.value[foundIndex] = this.programsService.getDialogData();
          //     // And lastly refresh table
          //     this.refreshTable();
          //   }
          // });
       });
  }
 
  private refreshTable() {
    // https://github.com/marinantonio/angular-mat-table-crud/issues/12
    this.paginator._changePageSize(this.paginator.pageSize);
  }

  public loadData() {
    this.exampleDatabase = new ProgramsService(this.httpClient, this.authService, this.appconfig, this.toastr, this.operationsService);
    
    this.dataSource = new ProgramDataSource(this.exampleDatabase, this.paginator, this.sort);
    
    fromEvent(this.filter.nativeElement, 'keyup')
      // .debounceTime(150)
      // .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}


export class ProgramDataSource extends DataSource<ODProgram> {
  _filterChange = new BehaviorSubject('');

  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: ODProgram[] = [];
  renderedData: ODProgram[] = [];

  constructor(public _exampleDatabase: ProgramsService,
              public _paginator: MatPaginator,
              public _sort: MatSort) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<ODProgram[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];

    this._exampleDatabase.getAllPrograms();


    return merge(...displayDataChanges).pipe(map( () => {
        // Filter data
        this.filteredData = this._exampleDatabase.data.slice().filter((odp: ODProgram) => {
          const searchStr = (odp.Id + odp.Name + odp.Description + odp.CategoryGroupString + odp.ProgramTypeString + odp.CreatedBy + odp.ExecutedProgramParams).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        // Sort filtered data
        const sortedData = this.sortData(this.filteredData.slice());

        // Grab the page's slice of the filtered sorted data.
        const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
        return this.renderedData;
      }
    ));
  }

  disconnect() {}


  /** Returns a sorted copy of the database data. */
  sortData(data: ODProgram[]): ODProgram[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';

      switch (this._sort.active) {
        // case 'Id': [propertyA, propertyB] = [a.Id, b.Id]; break;
        case 'Name': [propertyA, propertyB] = [a.Name, b.Name]; break;
        case 'Description': [propertyA, propertyB] = [a.Description, b.Description]; break;
        case 'CategoryGroup': [propertyA, propertyB] = [a.CategoryGroup, b.CategoryGroup]; break;
        case 'ProgramType': [propertyA, propertyB] = [a.ProgramType, b.ProgramType]; break;
        case 'ExecutedProgramParams': [propertyA, propertyB] = [a.ExecutedProgramParams, b.ExecutedProgramParams]; break;
        case 'CreatedBy': [propertyA, propertyB] = [a.CreatedBy, b.CreatedBy]; break;
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}
