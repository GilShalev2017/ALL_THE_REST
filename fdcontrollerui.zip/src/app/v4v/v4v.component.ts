import { Component, OnInit, ViewChild, QueryList, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OperationsService } from "../services/operations.service";
import { V4VOperation } from "../models/V4VOperation";
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { MatRadioModule, MatRadioChange } from '@angular/material/radio';
import { UIExecutingTask } from "../models/UIExecutingTask";
import { faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye } from '@fortawesome/free-solid-svg-icons';
import { ODTask } from "../models/ODTask";
import { MatAccordion } from '@angular/material/expansion';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { S3ImageViewerComponent } from '../s3-image-viewer/s3-image-viewer.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatDialog } from '@angular/material/dialog';
import { AddPublisherBotComponent } from '../add-publisher-bot/add-publisher-bot.component';
import { of as observableOf, Subscription } from 'rxjs';

@Component({
  selector: 'app-v4v',
  templateUrl: './v4v.component.html',
  styleUrls: ['./v4v.component.css']
})
export class V4vComponent implements OnInit {
  
  public editorOptions: JsonEditorOptions;
  faStop = faStop;

  //common Settings (1st step)
  _firstFrame;
  _endFrame;
  _framesJump;
  _fps: string;
  _pcams: string;
  _vcams: string;
  _selectedCameras;
  _selectedCamerasType = "0";
  _cameras: string [] = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38'];
  _selectedDeployment;
  //Advanced
  //Advanced - Slack
  _shareOnSlack: string;
  _channelName: string;
  _selectedShareOnAllVideos;
  _selectedShareOneFrame;
  //Advanced - Colors
  _colorLegend;
  _personInside;
  _personOutside;
  _ballInside;
  _ballOutside;
  _groundMasks;
  _groundFullMasks;
  _audienceMasks;
  //Advanced - GridProperties
  _gridRows:number;
  _gridColumns:number;
  _gridMargins:number;
  //Advanced - NumParallelThreads
  _numParallelThreads;
  //Advanced - TimeZone
   _timeZone;
  //Features (2nd step)
  _selectedFeature;
  _selectedFeatureString : string;
  //Feature 1
  _pcamMask;
  _multiViewFolder: string;
  _vcamsPath: string;
  _groundMasksPath_s3: string;
  _yuvWidth: string;
  _yuvHeight: string;
  _vcamImageWidth: string;
  _vcamImageHeight: string;
  //Feature 2
  _cBGPath: string;
  _cBGImageWidth: string;
  _cBGImageHeight: string;
  //Feature 3
  _selectedSegLocGM;
  _selectedSegLocFGM;
  _selectedSegLocAM;
  _Seg_Loc_MultiViewFolder;
  _Seg_Loc_SegPath;
  _Seg_Loc_GroundMasksPath_s3;
  _Seg_Loc_GroundFullMasksPath_s3;
  _Seg_Loc_AudienceMasksPath_s3;
  _Seg_Loc_YuvWidth;
  _Seg_Loc_YuvHeight;
  _Seg_Loc_SegImageWidth;
  _Seg_Loc_SegImageHeight;
  //Feature 4
  _pcl_MultiViewFolder;
  _pcl_ReconPath;
  _pcl_CalibarationTxtFolder_s3;
  _pcl_YuvWidth;
  _pcl_YuvHeight;
  _pcl_BallOnly;
  //Feature 5
  _selectedConvert;
  _converter_YuvPath;
  _converter_SegPath;
  _converter_YuvWidth;
  _converter_YuvHeight;
  _converter_SegImageWidth;
  _converter_SegImageHeight;
  
  _configObject;
  
  deploymentTypes: string[] = ['Full-Scale','Mini-Scale'];

  @ViewChild(JsonEditorComponent) editor: JsonEditorComponent;
  @ViewChild('selections') editorSelections: JsonEditorComponent;
 
  allSelected = false;
  subscription: Subscription;

  constructor(private _formBuilder: FormBuilder,
              public dialog: MatDialog,
              public operationsService: OperationsService) { 
                 this.editorOptions = new JsonEditorOptions();
                 this.editorOptions.modes = ['code', 'text', 'tree', 'view'];

      this.subscription = this.operationsService.deploymentSelectionChangedSource$.subscribe(
        data => {
          this.updateS3Paths();
        })
  }
  
  initOptionals(currentConfigDataObj) {

    this._framesJump = currentConfigDataObj["StepFrames"];

    //Basic Settings
    this._fps = currentConfigDataObj["Fps"];
    this._pcams = "38"; 
    this._vcams = "0"; 
    this._selectedCameras = this._cameras;
    this._selectedDeployment = "Full-Scale"
    //Get Feature1 Optionals
    this._pcamMask = "1";
    this._multiViewFolder = currentConfigDataObj["FeatureList"]["MulticamView"]["MultiViewFolder"];
    this._vcamsPath = currentConfigDataObj["FeatureList"]["MulticamView"]["VcamsPath"];
    this._groundMasksPath_s3 = currentConfigDataObj["FeatureList"]["MulticamView"]["GroundMasksPath_s3"];
    this._yuvWidth = currentConfigDataObj["FeatureList"]["MulticamView"]["YuvWidth"];
    this._yuvHeight = currentConfigDataObj["FeatureList"]["MulticamView"]["YuvHeight"];
    this._vcamImageWidth = currentConfigDataObj["FeatureList"]["MulticamView"]["VcamImageWidth"];
    this._vcamImageHeight = currentConfigDataObj["FeatureList"]["MulticamView"]["VcamImageHeight"];
    //Get Feature2 Optionals
    this._cBGPath = currentConfigDataObj["FeatureList"]["CBG"]["CBGPath"];
    this._cBGImageWidth = currentConfigDataObj["FeatureList"]["CBG"]["CBGImageWidth"];
    this._cBGImageHeight = currentConfigDataObj["FeatureList"]["CBG"]["CBGImageHeight"];
    //Get Feature3 Optionals
    this._selectedSegLocGM = "1";
    this._selectedSegLocFGM = "1";
    this._selectedSegLocAM= "1";
    this._Seg_Loc_MultiViewFolder = currentConfigDataObj["FeatureList"]["Seg_Loc"]["MultiViewFolder"];
    this._Seg_Loc_SegPath = currentConfigDataObj["FeatureList"]["Seg_Loc"]["SegPath"];
    this._Seg_Loc_GroundMasksPath_s3 = currentConfigDataObj["FeatureList"]["Seg_Loc"]["GroundMasksPath_s3"];
    this._Seg_Loc_GroundFullMasksPath_s3 = currentConfigDataObj["FeatureList"]["Seg_Loc"]["GroundFullMasksPath_s3"];
    this._Seg_Loc_AudienceMasksPath_s3 =  currentConfigDataObj["FeatureList"]["Seg_Loc"]["AudienceMasksPath_s3"];
    this._Seg_Loc_YuvWidth = currentConfigDataObj["FeatureList"]["Seg_Loc"]["YuvWidth"];
    this._Seg_Loc_YuvHeight = currentConfigDataObj["FeatureList"]["Seg_Loc"]["YuvHeight"];
    this._Seg_Loc_SegImageWidth = currentConfigDataObj["FeatureList"]["Seg_Loc"]["SegImageWidth"];
    this._Seg_Loc_SegImageHeight = currentConfigDataObj["FeatureList"]["Seg_Loc"]["SegImageHeight"];
    //Get Feature4 Optionals
    this._pcl_MultiViewFolder = currentConfigDataObj["FeatureList"]["PCL"]["MultiViewFolder"];
    this._pcl_ReconPath = currentConfigDataObj["FeatureList"]["PCL"]["ReconPath"];
    this._pcl_CalibarationTxtFolder_s3 = currentConfigDataObj["FeatureList"]["PCL"]["CalibarationTxtFolder_s3"];
    this._pcl_YuvWidth = currentConfigDataObj["FeatureList"]["PCL"]["YuvWidth"];
    this._pcl_YuvHeight = currentConfigDataObj["FeatureList"]["PCL"]["YuvHeight"];
    this._pcl_BallOnly = currentConfigDataObj["FeatureList"]["PCL"]["BallOnly"];
    //Get Feature5 Optionals
    this._selectedConvert ="1"; //default
    this._converter_YuvPath = currentConfigDataObj["FeatureList"]["Converter"]["YuvPath"];
    this._converter_SegPath = currentConfigDataObj["FeatureList"]["Converter"]["SegPath"];
    this._converter_YuvWidth = currentConfigDataObj["FeatureList"]["Converter"]["YuvWidth"];
    this._converter_YuvHeight = currentConfigDataObj["FeatureList"]["Converter"]["YuvHeight"];
    // this._converter_SegImageWidth = currentConfigDataObj["FeatureList"]["Converter"]["SegImageWidth"];
    // this._converter_SegImageHeight = currentConfigDataObj["FeatureList"]["Converter"]["SegImageHeight"];

    //Advanced
    //Slack
    this._shareOnSlack = currentConfigDataObj["Slack"]["Share"];
    this._channelName = currentConfigDataObj["Slack"]["Channel"]
    this._selectedShareOnAllVideos = currentConfigDataObj["Slack"]["AllVideos"];
    this._selectedShareOneFrame = currentConfigDataObj["Slack"]["ExampleFrame"];
    //Colors
    this._colorLegend = this.rgbToHex(currentConfigDataObj["Colors"]["ColorLegend"]);
    this._personInside = this.rgbToHex(currentConfigDataObj["Colors"]["PersonInside"]);
    this._personOutside = this.rgbToHex(currentConfigDataObj["Colors"]["PersonOutside"]);
    this._ballInside = this.rgbToHex(currentConfigDataObj["Colors"]["BallInside"]);
    this._ballOutside = this.rgbToHex(currentConfigDataObj["Colors"]["BallOutside"]);
    this._groundMasks = this.rgbToHex(currentConfigDataObj["Colors"]["GroundMasks"]);
    this._groundFullMasks = this.rgbToHex(currentConfigDataObj["Colors"]["GroundFullMasks"]);
    this._audienceMasks = this.rgbToHex(currentConfigDataObj["Colors"]["AudienceMasks"]);
    //GridProperties
    this._gridRows = currentConfigDataObj["GridProperties"]["GridRows"];
    this._gridColumns = currentConfigDataObj["GridProperties"]["GridColumns"];
    this._gridMargins = currentConfigDataObj["GridProperties"]["GridMargins"];
    // NumParallelThreads
    this._numParallelThreads = currentConfigDataObj["NumParallelThreads"];
    // TimeZone
    this._timeZone = currentConfigDataObj["TimeZone"];

    this.updateS3Paths();
  }

  toggleAllSelection() {
      this.allSelected = !this.allSelected;  // to control select-unselect
      this._selectedCameras = this.allSelected ? this._cameras : [];
  }

  ngOnInit(): void {
     
      this.operationsService.getV4VConfigContent()
              .subscribe( jsonObject => {
                  this._configObject = jsonObject;
                  this.initOptionals(jsonObject);
                });

      if(this.operationsService.isTasksLoaded==false) {
        this.operationsService.getODTasks()
          .subscribe( (arrivedData: ODTask[]) => {});
      };
  }
  
  updateS3Paths() {

    if(this.operationsService.selectedDeployment.deployment_region && this.operationsService.selectedDeployment.deployment_id) {
      
      this._groundMasksPath_s3 = "s3://intel-sports-" + this.operationsService.selectedDeployment.deployment_region + "-teecontrol-" + this.operationsService.selectedDeployment.deployment_id + "/Venue/Masks/Ground/";
      
      //s3://intel-sports-us-east-1-teecontrol-e02v441rc5vxjjx/Venue/Masks/Ground/
      //s3://intel-sports-us-east-1-teecontrol-e02v441rc5vxjjx/Venue/Masks/GroundFull/
      //s3://intel-sports-us-east-1-teecontrol-e02v441rc5vxjjx/Venue/Masks/Audience/
      this._Seg_Loc_GroundMasksPath_s3 = "s3://intel-sports-" + this.operationsService.selectedDeployment.deployment_region + "-teecontrol-" + this.operationsService.selectedDeployment.deployment_id + "/Venue/Masks/Ground/";
      this._Seg_Loc_GroundFullMasksPath_s3 = "s3://intel-sports-" + this.operationsService.selectedDeployment.deployment_region + "-teecontrol-" + this.operationsService.selectedDeployment.deployment_id + "/Venue/Masks/GroundFull/";
      this._Seg_Loc_AudienceMasksPath_s3 = "s3://intel-sports-" + this.operationsService.selectedDeployment.deployment_region + "-teecontrol-" + this.operationsService.selectedDeployment.deployment_id + "/Venue/Masks/Audience/";
      //s3://intel-sports-us-east-1-teecontrol-e02v441rc5vxjjx/Venue/Calibration/txt/
      this._pcl_CalibarationTxtFolder_s3 = "s3://intel-sports-" + this.operationsService.selectedDeployment.deployment_region + "-teecontrol-" + this.operationsService.selectedDeployment.deployment_id + "/Venue/Calibration/txt/";
    }
  }

  copyFirstFrameToEndFrame() {
    this._endFrame = this._firstFrame;
  }
 
  stopTask(task: UIExecutingTask, event?: Event){
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.stopTask(task.ExecutingTaskStatus.executerId);
  }

  cleanHistory() {
    this.operationsService.v4vTasks = [];
  }


  hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
   
    let finalResult = {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    };

    let finalResultAsString = "(" + finalResult['r'] + ", " + finalResult['g'] + ", "  + finalResult['b'] + ")";

    return finalResultAsString;
  }
  
  rgbToHex(rgbValue: string) {
    rgbValue = rgbValue.replace("(","").replace(")","").trim();
    let splits = rgbValue.split(",");
    let r = +splits[0];
    let g = +splits[1];
    let b = +splits[2];
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  runV4V() {

    // "python3.8 V4V.py --startFrame 6930 --endFrame 6930 --feature 2 --pcamMask 1 --segLocGM 0 --segLocFGM 0 --ConvertFeature 2" 
    this.operationsService.V4VIsRunning = true;

    this.operationsService.v4vTasks = [];
   
    let currentConfigDataObj = this.getJsonConfigObjectWithUserSelections();

    let currentConfigDataString = JSON.stringify(currentConfigDataObj);
 
    let dynamicParameters = this.getCommandLineParameters();

    let dynamicTaskName = this._selectedFeatureString;

    this.editorSelections.set(currentConfigDataObj);

    this.operationsService.startV4V(currentConfigDataString, dynamicParameters, dynamicTaskName);
  }

  getJsonConfigObjectWithUserSelections() {
    let currentConfigDataObj = this._configObject;

    //Set Basic Settings
    currentConfigDataObj["UI"] = "1";
    currentConfigDataObj["DeploymentId"] = this.operationsService.selectedDeployment.deployment_id;
    currentConfigDataObj["LustreParentFolder"] = "/mnt";
    currentConfigDataObj["Fps"] = this._fps;
    currentConfigDataObj["StepFrames"] = this._framesJump;
   
    if(this._selectedCamerasType == "0") {
      currentConfigDataObj["CamerasArray"] = [];
    }
    else {
      let arr = [];
      this._selectedCameras.forEach(element => {
        arr.push(element);
      });
      currentConfigDataObj["CamerasArray"] = arr;
    }
 
    //Set Features (Optionals)
    //Set MulticamView
    currentConfigDataObj["FeatureList"]["MulticamView"]["MultiViewFolder"] = this._multiViewFolder;
    currentConfigDataObj["FeatureList"]["MulticamView"]["VcamsPath"] = this._vcamsPath;
    currentConfigDataObj["FeatureList"]["MulticamView"]["GroundMasksPath_s3"] = this._groundMasksPath_s3;
    currentConfigDataObj["FeatureList"]["MulticamView"]["YuvWidth"] = this._yuvWidth; 
    currentConfigDataObj["FeatureList"]["MulticamView"]["YuvHeight"] = this._yuvHeight;
    currentConfigDataObj["FeatureList"]["MulticamView"]["VcamImageWidth"] = this._vcamImageWidth;
    currentConfigDataObj["FeatureList"]["MulticamView"]["VcamImageHeight"] = this._vcamImageHeight; 
    //Set CBG
    currentConfigDataObj["FeatureList"]["CBG"]["CBGPath"] = this._cBGPath;
    currentConfigDataObj["FeatureList"]["CBG"]["CBGImageWidth"] = this._cBGImageWidth;
    currentConfigDataObj["FeatureList"]["CBG"]["CBGImageHeight"] = this._cBGImageHeight;
    //Set Seg_Loc
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["MultiViewFolder"] = this._Seg_Loc_MultiViewFolder;
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["SegPath"] = this._Seg_Loc_SegPath;
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["GroundMasksPath_s3"] = this._Seg_Loc_GroundMasksPath_s3;
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["GroundFullMasksPath_s3"] = this._Seg_Loc_GroundFullMasksPath_s3;
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["AudienceMasksPath_s3"] = this._Seg_Loc_AudienceMasksPath_s3;

    currentConfigDataObj["FeatureList"]["Seg_Loc"]["YuvWidth"] = this._Seg_Loc_YuvWidth;
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["YuvHeight"] = this._Seg_Loc_YuvHeight;
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["SegImageWidth"] = this._Seg_Loc_SegImageWidth;
    currentConfigDataObj["FeatureList"]["Seg_Loc"]["SegImageHeight"] = this._Seg_Loc_SegImageHeight;
    //Set PCL
    currentConfigDataObj["FeatureList"]["PCL"]["MultiViewFolder"] = this._pcl_MultiViewFolder;
    currentConfigDataObj["FeatureList"]["PCL"]["ReconPath"] = this._pcl_ReconPath;
    currentConfigDataObj["FeatureList"]["PCL"]["CalibarationTxtFolder_s3"] = this._pcl_CalibarationTxtFolder_s3;
    currentConfigDataObj["FeatureList"]["PCL"]["YuvWidth"] = this._pcl_YuvWidth;
    currentConfigDataObj["FeatureList"]["PCL"]["YuvHeight"] = this._pcl_YuvHeight;
    currentConfigDataObj["FeatureList"]["PCL"]["BallOnly"] = this._pcl_BallOnly;
    //Set Converter
    currentConfigDataObj["FeatureList"]["Converter"]["YuvPath"] = this._converter_YuvPath;
    currentConfigDataObj["FeatureList"]["Converter"]["SegPath"] = this._converter_SegPath;
    currentConfigDataObj["FeatureList"]["Converter"]["YuvWidth"] = this._converter_YuvWidth;
    currentConfigDataObj["FeatureList"]["Converter"]["YuvHeight"] = this._converter_YuvHeight;
    // currentConfigDataObj["FeatureList"]["Converter"]["SegImageWidth"] = this._converter_SegImageWidth;
    // currentConfigDataObj["FeatureList"]["Converter"]["SegImageHeight"] = this._converter_SegImageHeight;
    //Set Advanced Settings
    //Set Slack
    currentConfigDataObj["Slack"]["Share"] = this._shareOnSlack;
    currentConfigDataObj["Slack"]["Channel"] = this._channelName;
    currentConfigDataObj["Slack"]["AllVideos"] = this._selectedShareOnAllVideos;
    currentConfigDataObj["Slack"]["ExampleFrame"] = this._selectedShareOneFrame;
    //Set Colors
    currentConfigDataObj["Colors"]["ColorLegend"] = this.hexToRgb(this._colorLegend);
    currentConfigDataObj["Colors"]["PersonInside"] = this.hexToRgb(this._personInside);
    currentConfigDataObj["Colors"]["PersonOutside"] = this.hexToRgb(this._personOutside);
    currentConfigDataObj["Colors"]["BallInside"] = this.hexToRgb(this._ballInside);
    currentConfigDataObj["Colors"]["BallOutside"] = this.hexToRgb(this._ballOutside);
    currentConfigDataObj["Colors"]["GroundMasks"] = this.hexToRgb(this._groundMasks);
    currentConfigDataObj["Colors"]["GroundFullMasks"] = this.hexToRgb(this._groundFullMasks);
    currentConfigDataObj["Colors"]["AudienceMasks"] = this.hexToRgb(this._audienceMasks);
    //Set GridProperties
    currentConfigDataObj["GridProperties"]["GridRows"] = this._gridRows;
    currentConfigDataObj["GridProperties"]["GridColumns"] = this._gridColumns;
    currentConfigDataObj["GridProperties"]["GridMargins"] = this._gridMargins;
    //Set NumParallelThreads
    currentConfigDataObj["NumParallelThreads"] = this._numParallelThreads;
    //Set TimeZone
    currentConfigDataObj["TimeZone"] = this._timeZone;

    return currentConfigDataObj;
  }

  getCommandLineParameters() {
    let dynamicParameters = "--startFrame "  + this._firstFrame + " --endFrame " + this._endFrame + " --feature " + this._selectedFeature; 

    if(this._selectedFeature == "1") {
      dynamicParameters = dynamicParameters + " --pcamMask " + this._pcamMask;
    }

    if(this._selectedFeature == "3") {
      dynamicParameters = dynamicParameters + " --segLocGM " + this._selectedSegLocGM + " --segLocFGM " + this._selectedSegLocFGM + " --segLocAM " + this._selectedSegLocAM;
    }

    if(this._selectedFeature == "5") {
      dynamicParameters = dynamicParameters + " --ConvertFeature " + this._selectedConvert;
    }

    return dynamicParameters;
  }

  OnStepperSelectionChange($event?: StepperSelectionEvent) {

    if ($event.selectedIndex == 2) {
      
      let currentConfigDataObj = this.getJsonConfigObjectWithUserSelections();
 
      this.editorSelections.set(currentConfigDataObj);
    }
      
  }

  getDisplayFeature()
  {
    switch(this._selectedFeature) { 
      case '1': { 
          let msg = "(1) Pcam, vcam and ground mask ";
          this._selectedFeatureString = "Pcam, vcam and ground mask";
          if(this._pcamMask == '1') {
            msg = msg + "with ground masks projected on frames"
          }
          else {
            msg = msg + "without ground masks projected on frames"
          }
          return msg;
          break; 
      } 
      case '2': { 
          this._selectedFeatureString = "CBG";
          return "(2) CBG";
          break; 
      } 
      case '3': { 
          let msg = "(3) Masks visualization- Seg & Loc ";
          this._selectedFeatureString = "Masks visualization- Seg & Loc";
          if(this._selectedSegLocGM == '1') {
            msg = msg + "with ground masks projected on frames"
          }
          else {
             msg = msg + "without ground masks projected on frames"
          }
          if(this._selectedSegLocFGM == '1') {
            msg = msg + " and with full ground masks projected on frames"
          }
          else {
             msg = msg + " and without full ground masks projected on frames"
          }
          return msg;

          break;  
      } 
       case '4': { 
          let msg = "(4) PCL ";
          this._selectedFeatureString = "PCL";
          if(this._pcl_BallOnly == "1") {
            msg = msg + "with only ball PCL projected on frames";
          }
          else {
            msg = msg + "without only ball PCL projected on frames";
          }
          return msg;
          break;  
      } 
       case '5': { 
          let converterMsg = "(5) Converter: ";
          this._selectedFeatureString = "Converter";
          if(this._selectedConvert == '1') {
            converterMsg = converterMsg + "Convert yuv to tiff";
          }
          else if(this._selectedConvert == '2') {
            converterMsg = converterMsg + "Convert yuv to jpg";
          }
          else if(this._selectedConvert == '3') {
            converterMsg = converterMsg + "Unpack segmentation files";
          }
          return converterMsg;
          break;  
      } 
       case '6': { 
          return "(6) Run features 1->4"; 
          break;  
      } 
    } 
  }

  openS3Bucket(task: UIExecutingTask, event) {
    if (event) {
      event.stopPropagation();
    } 

    let folderPrefix = task.ResultsS3Bucket.split("s3://v4v/")[1].replace("*",'');//this.operationsService.V4VS3Folder.split("s3://v4v/")[1].replace("*",'');
  
    let s3prefix = "https://s3.console.aws.amazon.com/s3/buckets/v4v";

    let region = "us-east-1";

    let s3Link = s3prefix + "?region=" + region + "&prefix=" + folderPrefix;

    window.open(s3Link, "_blank");
  }

  stopIt(task: UIExecutingTask, event) {
    event.stopPropagation();
  }

  getFakeImage() {
    
    // let folderPrefix = "e02v441rc5vxjjx/05-11-2020/12_45_00/Frames-102000-102100/Masks_Visualization/";//"e02v441rc5vxjjx/02-11-2020/17_23_17/Frames-107200-107200/Masks_Visualization/";
    // let oneLevelUp = "e02v441rc5vxjjx/05-11-2020/12_45_00/Frames-102000-102100";//"e02v441rc5vxjjx/02-11-2020/17_23_17/Frames-107200-107200";
   
    // let folderPrefix = "e02v4rc6fsyl3zu/08-11-2020/13_43_12/Frames-101500-101500/Masks_Visualization/";
    // let oneLevelUp = "e02v4rc6fsyl3zu/08-11-2020/13_43_12/Frames-101500-101500";
    // let folderPrefix = "e02v441rc5vxjjx/05-11-2020/14_44_24/Frames-180000-180080/Multicam_View/";
    // let oneLevelUp = "e02v441rc5vxjjx/05-11-2020/14_44_24/Frames-180000-180080";

    // let folderPrefix = "e02v441rc5vxjjx/05-11-2020/";
    // let oneLevelUp = "e02v441rc5vxjjx";

    //FOR DEMO
    let folderPrefix = "e02v441rc5vxjjx/05-11-2020/14_23_36/Frames-171000-171080/Masks_Visualization/";
    let oneLevelUp = "e02v441rc5vxjjx/05-11-2020/14_23_36/Frames-171000-171080";
    let bucketName = 'v4v';
    let bucketRegion = 'us-east-1';
    let bucketBaseKey = oneLevelUp;
    
    //FOR VV4
    // folderPrefix = "e02v4rc6fsyl3zu/v440rel/mp4_packager/1/10_55_10";
    // oneLevelUp = "e02v4rc6fsyl3zu/v440rel/mp4_packager/1";
    // bucketName = 'isg-teecontrol-data-management-svc-dev';//'gil-test-videos'
    // bucketRegion = 'us-east-1';
    // bucketBaseKey = folderPrefix;

    //For debug kit
    // bucketName = "debug-kits";
    // bucketBaseKey = "e02v4402wul18nh";

    this.operationsService.getBucketFileTree(bucketName,bucketBaseKey,bucketRegion)
    //this.operationsService.getAllBucketFileTree(bucketName,bucketBaseKey,bucketRegion)
      .subscribe(data => {

       let s3BucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/v4v?region=us-east-1&prefix=" + folderPrefix;

        const dialogRef = this.dialog.open(S3ImageViewerComponent, {
          data: 
          {
            "toolType": "v4v",
            "filesPrefix": oneLevelUp,
            "bucketName": bucketName,
            "bucketRegion": bucketRegion,
            "s3BucketUrl": s3BucketUrl
          },
          maxWidth: '90vw',
          maxHeight: '90vh',
          height: '90%',
          width: '90%'
        });
       
      });
  }

  getImage(task: UIExecutingTask) {

    if (event) {
        event.stopPropagation();
    }

    //TODO  real
    let folderPrefix = task.ResultsS3Bucket.split("s3://v4v/")[1].replace("*",'');//this.operationsService.V4VS3Folder.split("s3://v4v/")[1].replace("*",'').trim();
    
    let splits = folderPrefix.split("/");
    let oneLevelUp = "";
    oneLevelUp = splits[0] ;

    for(let i = 1; i < (splits.length-2); i++) //last split is ""!
    {
      oneLevelUp = oneLevelUp + "/" + splits[i];
    }

    let bucketName = 'v4v';
    let bucketRegion = 'us-east-1';
    let bucketBaseKey = oneLevelUp;//folderPrefix;
    
    this.operationsService.getBucketFileTree(bucketName,bucketBaseKey,bucketRegion)
      .subscribe(data => {

       // let filesPrefix = "e02v441rc5vxjjx/29-10-2020/18_26_55/Frames-170100-170105";
       let s3BucketUrl = "https://s3.console.aws.amazon.com/s3/buckets/v4v?region=us-east-1&prefix=" + folderPrefix;

        const dialogRef = this.dialog.open(S3ImageViewerComponent, {
          data: 
          {
            "toolType": "v4v",
            "filesPrefix": oneLevelUp,//folderPrefix,
            "bucketName": bucketName,
            "bucketRegion": bucketRegion,
            "s3BucketUrl": s3BucketUrl
          },
          maxWidth: '90vw',
          maxHeight: '90vh',
          height: '90%',
          width: '90%'
        });
       
      });
  }

  shareOnSlackChange(event ){
    let name = event.source.name;
    this._shareOnSlack = event.checked ? '1' : '0';
  }
  
  addPublisherBot(event) {
    if(event.clientX != 0 && event.clientY !=0) {
      this.dialog.open(AddPublisherBotComponent);
    }
  }

  downloadAviFile(event) {
    if (event) {  
        event.stopPropagation();
    } 

    let bucketName = 'v4v';
    let bucketRegion = 'us-east-1';
    let fileKey = "e02v441rc5vxjjx/29-10-2020/18_26_55/Frames-170100-170105/Masks_Visualization/video_masks_frames_170100_170105.avi";

    this.operationsService.getS3FilePresignedUrl(fileKey, bucketName, bucketRegion)
        .subscribe(result => {
          let reportUrl = result['URL_STRING'];
          window.open(reportUrl, "_blank");
        });
  }

  getLog(executerId: string) {
   
    if (event) {
        event.stopPropagation();
    } 

    // let reportName = "DebugKit/" + this.operationsService.selectedDeploymentId + "/" + executerId + "_debugKit.log";
    
    // this.operationsService.getProgramPresignedUrlForReport(reportName)
    //     .subscribe(result => {
    //       let reportUrl = result['URL_STRING'];
    //       // location.go(reportUrl);
    //       window.open(reportUrl, "_blank");
    //     });
  }

  getV4VK8SContext() {
    let context = "kubectl exec -it " + this.operationsService.V4VPod + " bash";
    return context;
  }
}
