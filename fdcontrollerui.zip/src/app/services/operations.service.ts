import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpErrorResponse, HttpParams, HttpEventType, HttpHeaders } from '@angular/common/http';
import { throwError, Observable, BehaviorSubject, Subject } from 'rxjs';
import { retry, catchError, tap, map, last } from 'rxjs/operators';
import * as signalR from "@aspnet/signalr";
import { TaskPayload } from "../models/TaskPayload";
import { FlowPayload } from "../models/FlowPayload";
import { ODTask } from "../models/ODTask";
import { FdController } from "../models/FdController";
import { ODFlow } from "../models/ODFlow";
import { FlinkTaskPayload, FlinkTaskType } from "../models/FlinkTaskPayload";
import { FlinkJar } from "../models/FlinkJar";
import { FlinkJob } from "../models/FlinkJob";
import { UIExecutingFlow } from "../models/UIExecutingFlow";
import { ExecutingTaskStatus } from "../models/ExecutingTaskStatus";
import { ExecutingFlowStatus } from "../models/ExecutingFlowStatus";
import { ExecutingTaskData } from "../models/ExecutingTaskData";
import { UIExecutingTask } from "../models/UIExecutingTask";
import { ODProgram } from "../models/ODProgram";
import { Deployment } from "../models/Deployment";
import { HubConnectionState } from "@aspnet/signalr/dist/esm/HubConnection";
import { CategoryGroup } from '../models/ODProgram';
import { FlowsService} from "../services/flows.service";
import { AuthService } from './../auth/auth.service';
import { Auth } from 'aws-amplify';
import { fromPromise } from 'rxjs/observable/fromPromise';
import { Cluster } from "../models/Cluster";
import { Pod } from "../models/Pod";
import { CompletedTask } from "../models/CompletedTask";
import { AppConfigurationService } from './app-configuration.service';
import { DebugKitOperation } from "../models/DebugKitOperation";
import {ToastrService} from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class OperationsService {

  public HUB_URL: string;
  public hubConnection: signalR.HubConnection;

  private baseApiUrl: string;
  private urlProgramsApi: string;
  private urlTasksApi: string;
  private urlCompletedTasksApi: string;
  private urlCompletedTasks2Api: string;
  private urlFlowsApi: string;
  private urlDeploymentsApi: string;
  private urlConfigurationsApi: string;
  private urlFlinkJarsApi: string;
  private urlGeneralServicesApi: string;
  private mqBorkerServicesApi: string;

  public connectedToHubServer: boolean = false;
  public registeredToHubServer: boolean = false;
  public availableTasks: ODTask[] = [];
  public availableSortedTasks: ODTask[] = [];
  public availableFlows: UIExecutingFlow[] = [];
  public activeTasks: UIExecutingTask[] = [];
  public publisherTasks: UIExecutingTask[] = [];
  public debugKitTasks: UIExecutingTask[] = [];
  public v4vTasks: UIExecutingTask[] = [];
  public mvvTasks: UIExecutingTask[] = [];
  public prepareDeploymentTasks: UIExecutingTask[] = [];
  public rendererOutputVideoCreationTasks: UIExecutingTask[] = [];
  public kdsInspectorTasks: UIExecutingTask[] = [];
  public completedTasks: CompletedTask[] = [];
  public odPrograms: ODProgram[] = [];
  public availableFdControllers: FdController[] = []; //per deployment
  public registeredWorkers: FdController[] = []; //not in use
  // public workerConnectedDeployments:  FdController[] = []; //all conneted deployments
  public configurations: any[] = [];
  public availableJars: string[];
  // public availableArtifactoryJars: string[];
  public deployedFlinkJars: string[] = [];
  public runningJobs: string[] = [];
  
  public selectedDeployment: Deployment;
  public selectedDeploymentString: string;

  public activeDeployments: Deployment[] = [];
  public currentRunningFlow: UIExecutingFlow;
  public flinkJobs: FlinkJob[] = [];
  public _isUploadingToFlink:boolean = false;
  public _isUploadedToFlink:boolean = false;
  public currentConfigContent:any;
  public currentConfigFileName: string;
  public S3ConfigurationsBucketUrl: string;
  public isPublisherConfigLoaded: boolean = false;
  public isConfigurationsLoaded: boolean = false;
  public isDebuKitConfigLoaded: boolean = false;
  public isV4VConfigLoaded: boolean = false;
  public isPrepareDeploymentConfigLoaded: boolean = false;
  public isflinkConfigLoaded: boolean = false;
  public isMvvRunning: boolean = false;
  public isVideoCreationRunning: boolean = false;
  public isTasksLoaded: boolean = false;
  public isCompletedTasksLoaded: boolean = false;
  public isProgramsLoaded: boolean = false;
  public isFlinkJarsLoaded: boolean = false;
  public clusters: Cluster[];
  public mvvObjects: [];
  public V4VPod: string = null;
  //public V4VS3Folder: string = null;
  // public availableDebugKitOperations: DebugKitOperation[] = [];

  dataChange: BehaviorSubject<ODProgram[]> = new BehaviorSubject<ODProgram[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  isRefreshPodStatusesOn: boolean = false;
  isResetPodsOn: boolean = false;
  isCleanDecoderLustreFoldersOn: boolean = false;
//  _intervalId: number;
 _publisherVersion: string;

  private deploymentSelectionChangedSource = new Subject<string>();
  deploymentSelectionChangedSource$ = this.deploymentSelectionChangedSource.asObservable();

  private clustersUpdated = new Subject<string>();
  clustersUpdated$ = this.clustersUpdated.asObservable();

  private logArrived = new Subject<string>();
  logArrived$ = this.logArrived.asObservable();
  
  grafanaLinkKvsInOut: string;
  grafanaLinkPodLevelMetrics: string;
  kibanaLogs: string;
  deploymentOverview: string;
  deploymentScaleUpDownOverview: string;
  deploymentStartStopServices: string;
  s3_backup_bucket: string;
  publisherConfigContent: string;
  debugKitConfigContent: string;
  prepareDeploymentConfig: string;
  v4vConfigContent: string;
  flinkConfigContent: string;
  public isDisabled: boolean = true;
  decodeChangeLog: string;
  public _publishersCredentialsObj;
  debugKitIpList: string[] = [];
  DebugKitIsRunning: boolean = false;
  V4VIsRunning: boolean = false;
  CustomFlowIsRunning: boolean = false;
  PrepareDeploymentIsRunning: boolean = false;
  KdsInspectorIsRunning: boolean = false;
  bucketFileTree;
  // _getJobsExecutingTaskId: string;
  _tmpFLinkListenerexecuterID: string;

  constructor(private httpClient: HttpClient, private authService: AuthService, private appconfig:AppConfigurationService, private toastr: ToastrService) {
    
    this.HUB_URL = appconfig.hubUrl;
    
    this.baseApiUrl = appconfig.apiUrl;
   
    this.urlProgramsApi = this.baseApiUrl + "api/Program";
  
    this.urlTasksApi = this.baseApiUrl + "api/Task";
    this.urlCompletedTasksApi = this.baseApiUrl + "api/Task/completed";
    this.urlCompletedTasks2Api = this.baseApiUrl + "api/CompletedTasks";
   
    this.urlFlowsApi = this.baseApiUrl + "api/Flows";
    this.urlDeploymentsApi = this.baseApiUrl + "api/Deployment";
    this.urlConfigurationsApi = this.baseApiUrl + "api/Config";

    this.urlFlinkJarsApi = this.baseApiUrl + "api/FlinkJars";

    this.urlGeneralServicesApi = this.baseApiUrl + "api/GeneralServices";

    this.mqBorkerServicesApi = this.baseApiUrl + "api/Broker";
  
  }

  announceDeploymentSelectionChanged(selectionItem: string) {
    this.deploymentSelectionChangedSource.next(selectionItem);
    this.isRefreshPodStatusesOn = false;
    this.isResetPodsOn = false;

    this.grafanaLinkKvsInOut =  "https://grafana.tee.sports.infra-host.com/d/duLoRdXZz/v4-kvs-inout?orgId=1&from=now-15m&to=now&refresh=5s&var-deployment_id=" + this.selectedDeployment.deployment_id +"&var-datasource=CloudWatch-us-east-1&var-streamname=All";
    this.grafanaLinkPodLevelMetrics = "https://grafana.tee.sports.infra-host.com/d/mag9bHBWz/v4-pod-level-infrastructure-metrics?orgId=1&from=now-15m&to=now&refresh=30s&var-datasource=" + this.selectedDeployment.deployment_id +"-system&var-cluster=decode";
    this.kibanaLogs = "https://search-isg-fd19-monit-es-sc5to55ef23pbjafusjr4xgmda.us-east-1.es.amazonaws.com/_plugin/kibana/app/kibana#/discover?_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-15m,mode:recent,to:now))&_a=(columns:!(_source),index:" + this.selectedDeployment.deployment_id + ",interval:auto,query:(language:lucene,query:''),sort:!('@timestamp',desc))";
    this.deploymentOverview = "https://www.fd19.sports.intel.com/undefined/deployments/" + this.selectedDeployment.deployment_id;
    this.deploymentScaleUpDownOverview = "https://www.fd19.sports.intel.com/daas/deployments/" + this.selectedDeployment.deployment_id + "/scaleUpDown";
    this.deploymentStartStopServices = "https://www.fd19.sports.intel.com/daas/deployments/" + this.selectedDeployment.deployment_id + "/systemLevelDashboard";
    this.s3_backup_bucket = "https://s3.console.aws.amazon.com/s3/buckets/isg-teecontrol-data-management-svc-dev/" + this.selectedDeployment.deployment_id + "/?region=us-east-1&tab=overview";

    this.decodeChangeLog = "https://bitbucket.il.alm-sg.com/projects/NEWARCH/repos/intel-cloudfreed-software-5k-decoder/browse/CHANGELOG.txt?at=refs%2Fheads%2Ffeature%2F5.0.6";
  }

  announceClustersUpdated(updated: string) {
    this.clustersUpdated.next(updated);
  }

  announceLogArrived(log: string) {
    this.logArrived.next(log);
  }

  public hubConnectionInit () {

    this.buildConnection();

    this.hubConnection.on("OnUIRegisteredStatus", (status: string) => {
      console.log("UI received 'OnUIRegisteredStatus': " + status);
      this.registeredToHubServer = true;

      // this.getOPDockers();
    });

    this.hubConnection.on("OnTaskStatusReport", (executingTaskStatus: ExecutingTaskStatus) => {
      this.updateReportedStatus(executingTaskStatus);

      //Temporarily
      if(executingTaskStatus.taskId == '7d0e6dc9-d2a0-4b86-a7cf-6b9b5ff9d8fb') {
        this._tmpFLinkListenerexecuterID = executingTaskStatus.executerId;
      }
    });

    this.hubConnection.on("OnFlowStatusReport", (executingFlowStatus: ExecutingFlowStatus) => {
      this.updateFlowReportedStatus(executingFlowStatus);
    });

    this.hubConnection.on("OutputDataReceived", (executingTaskData: ExecutingTaskData) => {
      this.updateStdoutData(executingTaskData);
    });

    this.hubConnection.on("OnRegisteredWorkerStatus", (worker: FdController) => {
      console.log("UI received 'OnRegisteredWorkerStatus'");
      this.registeredWorkers.push(worker);
    });

    this.hubConnection.on("OnFdControllerListReceived", (dockers: FdController[]) => {
      console.log("UI received 'OnFdControllerListReceived'");
      this.availableFdControllers = dockers;
    });
 
    // this.hubConnection.on("OnWorkerConnectedDeploymentsReceived", (workerConnectedDeployments: FdController[]) => {
    //   console.log("UI received 'OnWorkerConnectedDeploymentsReceived'");
    //   this.workerConnectedDeployments = workerConnectedDeployments;
      
    //   this.getOPDockers();
    // });
    
    this.hubConnection.onclose(() => {

      this.connectedToHubServer = false;
      this.registeredToHubServer = false;
      console.log("Connection to the HUB has closed. Connecting again !!!!!");
      this.startConnection();
      this.registerUI();
    });

    this.startConnection();

    this.registerUI();
  }

  private updateFlowReportedStatus(executingFlowStatus: ExecutingFlowStatus) {
     
     //Update Status only in case that it belongs to current selected deployment 
     if(executingFlowStatus.deploymentId != this.selectedDeployment.deployment_id)
      return;

    console.log("UI received 'OnFlowStatusReport' from flowExecuter: " + executingFlowStatus.flowExecuterId + "executingFlowStatus: " + executingFlowStatus);

    this.currentRunningFlow.ExecutingFlowStatus = executingFlowStatus;
  }

  private updateReportedStatus(executingTaskStatus: ExecutingTaskStatus) {

    //Update Status only in case that it belongs to current selected deployment 
    if(executingTaskStatus.deploymentId != this.selectedDeployment?.deployment_id)
      return;

    if (executingTaskStatus.statusString == "TaskCompletedWithError" || executingTaskStatus.statusString == "TaskStoppedError") {
      console.log("UI received: " + executingTaskStatus.statusString + " from executer: " + executingTaskStatus.executerId + " ErrorData was: " + executingTaskStatus.errorData);
    }
    else {
      console.log("UI received: " + executingTaskStatus.statusString + " from executer: " + executingTaskStatus.executerId);
    }

    this.HandleResetOrGetPodStatuses(executingTaskStatus);

    if (executingTaskStatus.statusString == "TaskStarting") { //this case is special

      let foundODTask = this.availableTasks.find(function (element) {
        return element.Id == executingTaskStatus.taskId;
      });

      if (foundODTask != null) {
        let uiExecutingTask = {
          "ODTask": foundODTask,
          "ExecutingTaskStatus": executingTaskStatus,
          "expanded": false,
          "StdOut": []
        }
        this.activeTasks.unshift(uiExecutingTask);

        if(executingTaskStatus.taskType=="KDSPublisher") {
          this.publisherTasks.unshift(uiExecutingTask);
        }
        else if(executingTaskStatus.taskType=="DebugKit") {
          //TODO make sure the LogFileDetails is being sent correctly
          this.DebugKitIsRunning = false;
          this.debugKitTasks.unshift(uiExecutingTask);
        }
        else if(executingTaskStatus.taskType=="V4V") {
          //TODO make sure the LogFileDetails is being sent correctly
          this.V4VIsRunning = false;
          this.v4vTasks.unshift(uiExecutingTask);
        }
        else if(executingTaskStatus.taskType=="CustomFlow") {
          //TODO make sure the LogFileDetails is being sent correctly
          this.CustomFlowIsRunning = false;
         // this.CustomFlowTasks.unshift(uiExecutingTask);
        }
        else if(executingTaskStatus.taskType=="MVV") {
          //TODO make sure the LogFileDetails is being sent correctly
          this.isMvvRunning = false;
          this.mvvTasks.unshift(uiExecutingTask);
        }
        else if(executingTaskStatus.taskType=="KdsInspecting") {
          //TODO make sure the LogFileDetails is being sent correctly
          this.KdsInspectorIsRunning = false;
          this.kdsInspectorTasks.unshift(uiExecutingTask);
        }
        else if(executingTaskStatus.taskType=="RendererOutputVideoCreator" || executingTaskStatus.taskId=="e09101c0-2c32-4b31-8b39-1ac4bf88351f") {
          //TODO make sure the LogFileDetails is being sent correctly
          this.isVideoCreationRunning = false;
          this.rendererOutputVideoCreationTasks.unshift(uiExecutingTask);
        }
      }

      // if(executingTaskStatus.taskId == "11ce4446-5a7e-42cb-8023-95b614d77747")
      //   this._getJobsExecutingTaskId = executingTaskStatus.executerId;

      // Find task of flow
      //if (this.currentRunningFlow != null && executingTaskStatus.flowExecuterId != null) {
      if (this.currentRunningFlow != null) {

        let foundTaskInFlow = this.currentRunningFlow.UITasks.find(function (element) {
          return element.ODTask.Id == executingTaskStatus.taskId;
        });

        if (foundTaskInFlow != null) {
          foundTaskInFlow.ExecutingTaskStatus = executingTaskStatus;
          foundTaskInFlow.StdOut = [];
        }
      }
    }
    else {
      let foundActiveTask = this.activeTasks.find(function (element) {
        return element.ExecutingTaskStatus.executerId == executingTaskStatus.executerId;
      });

      if (foundActiveTask != null) {

        let prevStatusString = foundActiveTask.ExecutingTaskStatus.statusString;

        foundActiveTask.ExecutingTaskStatus = executingTaskStatus;
        
        //PATCH FOR DEMO - V4V
        if(executingTaskStatus.taskType=="V4V") {
          if(executingTaskStatus.errorData == "Unable to use a TTY - input is not a terminal or the right kind of file") {
             if(foundActiveTask.ExecutingTaskStatus.statusString == "ProcessExited" ||  foundActiveTask.ExecutingTaskStatus.statusString == "TaskCompletedWithError") {
                  foundActiveTask.ExecutingTaskStatus.statusString = "TaskCompleted";
             }
             else {
                  foundActiveTask.ExecutingTaskStatus.statusString = "TaskStarted";
             }
          }
        }

        if (executingTaskStatus.statusString == "TaskCompletedWithError" || executingTaskStatus.statusString == "TaskStoppedError") {
          foundActiveTask.StdOut.unshift(executingTaskStatus.errorData);
        }
      }

      // Find task of flow
      //if (this.currentRunningFlow != null && executingTaskStatus.flowExecuterId != null) {
      if (this.currentRunningFlow != null) {

        let foundActiveTaskInFlow = this.currentRunningFlow.UITasks.find(function (element) {
          return element.ExecutingTaskStatus.executerId == executingTaskStatus.executerId;
        });

        if (foundActiveTaskInFlow != null) {
          foundActiveTaskInFlow.ExecutingTaskStatus = executingTaskStatus;

          if (executingTaskStatus.statusString == "TaskCompletedWithError" || executingTaskStatus.statusString == "TaskStoppedError") {
            foundActiveTaskInFlow.StdOut.unshift(executingTaskStatus.errorData);
          }
        }
      }
    }
  }

  private HandleResetOrGetPodStatuses(executingTaskStatus: ExecutingTaskStatus) {

    if(executingTaskStatus.statusString == "TaskStarting" || executingTaskStatus.statusString == "TaskStarted") {
        if(executingTaskStatus.taskId == "58502ff2-1851-4729-a9b0-50a3e35c344c") //specific taskId = "Get Pods Status"
          this.isRefreshPodStatusesOn = true;
        else if(executingTaskStatus.taskId == "5442b2b7-131f-463e-a0c0-4194d1800788") // reset all
          this.isResetPodsOn = true;
        else if(executingTaskStatus.taskId == "60b23667-e25a-4ac1-aeaf-b586d7b28199") {
            this.isCleanDecoderLustreFoldersOn = true;
        }
    }
    else {
        if(executingTaskStatus.taskId == "58502ff2-1851-4729-a9b0-50a3e35c344c") {
          this.isRefreshPodStatusesOn = false;
        }
        else if(executingTaskStatus.taskId == "5442b2b7-131f-463e-a0c0-4194d1800788") {
          this.isResetPodsOn = false;
          this.getPodsStatus();
        }
        else if(executingTaskStatus.taskId == "60b23667-e25a-4ac1-aeaf-b586d7b28199") {
            this.isCleanDecoderLustreFoldersOn = false;
        }
    }
    
  }

  private updateStdoutData(executingTaskData: ExecutingTaskData) {

    //Update Status only in case that it belongs to current selected deployment 
    if(executingTaskData.deploymentId != this.selectedDeployment?.deployment_id)
        return;

    console.log("UI received 'OutputDataReceived' from executer: " + executingTaskData.executerId + " message line was: " + executingTaskData.data);

    let foundActiveTask = this.activeTasks.find(function (element) {
      return element.ExecutingTaskStatus.executerId == executingTaskData.executerId;
    });

    if (foundActiveTask != null) {
      if(executingTaskData.data == null || executingTaskData.data == "" ){
        executingTaskData.data = " ";
      }
      foundActiveTask.StdOut.unshift(executingTaskData.data);

      //temporarily for publishers
      if(executingTaskData.taskType=="KDSPublisher") {
        foundActiveTask.CurrentStatusLine = executingTaskData.data;

        if(executingTaskData.data.includes('Average FPS is:')) {
          let index = executingTaskData.data.lastIndexOf('Average FPS is:');
          let remainingCharsCount = (executingTaskData.data.length - index -15) +1;
          let substr = executingTaskData.data.substr(index+16, remainingCharsCount);
          
          let avgNum1 = parseFloat(substr);
          let rounded2 = avgNum1.toFixed(3);
          foundActiveTask.CurrentAvgFps = rounded2;

          // let avgString = executingTaskData.data.replace('Average FPS is:','');
          // let avgNum = parseFloat(avgString);
          // let rounded = avgNum.toFixed(3);
          // foundActiveTask.CurrentAvgFps = rounded;
        }
        else if(executingTaskData.data.includes('Total records added is:')) {
          foundActiveTask.TotalAddedRecords =  executingTaskData.data.replace('Total records added is:','');
        }
      }
      else if(executingTaskData.taskType=="KdsInspecting") {
        foundActiveTask.CurrentStatusLine = executingTaskData.data;
        
        if(executingTaskData.data.includes('Reading')) {
          let readingRecordsLine = executingTaskData.data.replace('Reading','');
          readingRecordsLine = readingRecordsLine.replace('records','');
          foundActiveTask.TotalAddedRecords =  readingRecordsLine;
        }
      }
      else if(executingTaskData.taskType=="RendererOutputVideoCreator" || executingTaskData.taskId=="e09101c0-2c32-4b31-8b39-1ac4bf88351f") {
        foundActiveTask.CurrentStatusLine = executingTaskData.data;
        
        //upload: ../../mnt/lustre/Renderer/render_output/vcam29.mp4 to s3://4sasha/fd19-dep-video/a01ver445jykhy8/2020_11_24/12_05/mp4/vcam29.mp4
        if(executingTaskData.data.includes('upload:')) {
          let splits = executingTaskData.data.split('upload:');
          let splits2 = splits[1].split('to');
          let outputFolder = splits2[1].trim();
          this.AddResultsS3BucketToExecutingTask(this.rendererOutputVideoCreationTasks, outputFolder, executingTaskData.taskId);
        }
      }
      else if(executingTaskData.taskType=="V4V") {
        
        if(executingTaskData.data.includes('Files can be found on:')) {
          //** Files can be found on: s3://v4v/e02v441rc5vxjjx/29-10-2020/16_23_47/Frames-170100-170100/PCL/ **
          let splits = executingTaskData.data.split('Files can be found on:');
          let v4vS3Folder = splits[1].replace('Files can be found on:','').replace('*','').trim();
          this.AddResultsS3BucketToExecutingTask(this.v4vTasks, v4vS3Folder, executingTaskData.taskId);
          
          //TODO this data signals the end of the task - we should move the task into a TaskCompleted State
        }
      }
      else if(executingTaskData.taskType=="MVV") {

        //DEMO
        //executingTaskData.data =`{"mps13": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/13/10_01_29/index_0a10_01_29.m3u8", "mps22": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/22/10_01_30/index_0a10_01_30.m3u8", "mps12": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/12/10_01_25/index_0a10_01_25.m3u8", "mps1": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/1/10_01_31/index_0a10_01_31.m3u8", "mps16": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/16/10_01_27/index_0a10_01_27.m3u8", "mps10": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/10/10_01_33/index_0a10_01_33.m3u8", "mps18": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/18/10_01_33/index_0a10_01_33.m3u8", "mps11": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/11/10_01_28/index_0a10_01_28.m3u8", "mps0": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/0/10_01_26/index_0a10_01_26.m3u8", "mps24": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/24/10_01_39/index_0a10_01_39.m3u8", "mps14": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/14/10_01_36/index_0a10_01_36.m3u8", "mps2": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/2/10_01_26/index_0a10_01_26.m3u8", "mps25": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/25/10_01_34/index_0a10_01_34.m3u8", "mps3": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/3/10_01_30/index_0a10_01_30.m3u8", "mps17": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/17/10_01_26/index_0a10_01_26.m3u8", "mps19": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/19/10_01_26/index_0a10_01_26.m3u8", "mps20": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/20/10_01_37/index_0a10_01_37.m3u8", "mps29": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/29/10_01_28/index_0a10_01_28.m3u8", "mps33": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/33/10_01_56/index_0a10_01_56.m3u8", "mps30": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/30/10_01_31/index_0a10_01_31.m3u8", "mps15": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/15/10_01_30/index_0a10_01_30.m3u8", "mps6": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/6/10_01_33/index_0a10_01_33.m3u8", "mps28": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/28/10_01_36/index_0a10_01_36.m3u8", "mps8": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/8/10_01_37/index_0a10_01_37.m3u8", "mps32": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/32/10_01_32/index_0a10_01_32.m3u8", "mps4": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/4/10_01_34/index_0a10_01_34.m3u8", "mps26": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/26/10_01_32/index_0a10_01_32.m3u8", "mps31": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/31/10_01_37/index_0a10_01_37.m3u8", "mps23": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/23/10_01_38/index_0a10_01_38.m3u8", "mps5": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/5/10_01_28/index_0a10_01_28.m3u8", "mps21": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/21/10_01_36/index_0a10_01_36.m3u8", "mps9": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/9/10_01_29/index_0a10_01_29.m3u8", "mps7": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/7/10_01_33/index_0a10_01_33.m3u8", "mps27": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/27/10_01_39/index_0a10_01_39.m3u8"}`;
        if(executingTaskData.data.startsWith('{')) {

          // let tmpObj = {
          //              	"mps11": "https:\\isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/11/10_01_28/index_0a10_01_28.m3u8",
	        //               "mps14": "https:\\isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/14/10_01_36/index_0a10_01_36.m3u8",
	        //               "mps18": "https:\\isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/18/10_01_33/index_0a10_01_33.m3u8"
          // }

          // let tmpObjStringified = JSON.stringify(tmpObj);
          this.mvvObjects = JSON.parse(executingTaskData.data);
        }
        else if(executingTaskData.data.includes('S3_Path_To_File'))
        {
          //let s3Path = executingTaskData.data.splits('S3_Path_To_File = ')[1].trim();
          let pathLine = executingTaskData.data.replace(/\s/g, "");;
          let s3Path = pathLine.split('S3_Path_To_File=')[1];
          this.AddResultsS3BucketToExecutingTask(this.mvvTasks, s3Path, executingTaskData.taskId);
        }
      }
      else if(executingTaskData.taskType=="DebugKit") {
        foundActiveTask.CurrentStatusLine = executingTaskData.data;
        
        if(executingTaskData.data.includes('SportGroupInformation')) {
          let sportGroupInformation = executingTaskData.data.replace(/\s/g, "");
          sportGroupInformation = sportGroupInformation.replace('SportGroupInformation=','');
          foundActiveTask.SportGroupInformation =  sportGroupInformation;
        }
        else if(executingTaskData.data.includes('VenueInformation')) {
          let venueInformation = executingTaskData.data.replace(/\s/g, "");
          venueInformation = venueInformation.replace('VenueInformation=','');
          foundActiveTask.VenueInformation =  venueInformation;
        }
        else if(executingTaskData.data.includes('GameID')) {
          let gameId = executingTaskData.data.replace(/\s/g, "");
          gameId = gameId.replace('GameID=','');
          foundActiveTask.GameID =  gameId;
        }
      }
      else { //s3-comparing-tool
        if(executingTaskData.data.includes('Folder URL:')) {

          let splits = executingTaskData.data.split('Folder URL:');
          let folderUrl = splits[1].replace('Folder URL:','').trim();
          this.AddResultsS3BucketToExecutingTask(this.activeTasks, folderUrl, executingTaskData.taskId);
        }
        else if(executingTaskData.data.includes('File URL:')) {
          let splits = executingTaskData.data.split('File URL:');
          let fileUrl = splits[1].replace('File URL:','').trim();
          this.AddFileUrlToExecutingTask(this.activeTasks, fileUrl, executingTaskData.taskId);
        }
      }
    }
    else { 
      //Add "new found task" to activeTasks, publisherTasks, debugKitTasks
      let newFoundActiveTask = this.CreateNewFoundTask(executingTaskData);
      
      if(newFoundActiveTask != null) {
      
        this.activeTasks.unshift(newFoundActiveTask);
      
        if(executingTaskData.taskType=="KDSPublisher") {
          this.publisherTasks.unshift(newFoundActiveTask);
        }
        else if(executingTaskData.taskType=="DebugKit") {
          this.debugKitTasks.unshift(newFoundActiveTask);
        }
        else if(executingTaskData.taskType=="KdsInspecting") {
          this.kdsInspectorTasks.unshift(newFoundActiveTask);
        }
         else if(executingTaskData.taskType=="RendererOutputVideoCreator") {
          this.rendererOutputVideoCreationTasks.unshift(newFoundActiveTask);
        }
      }
    }

    // Find task of flow
    if (this.currentRunningFlow != null) {

      //if (this.currentRunningFlow.UITasks != null && executingTaskData.flowExecuterId != null) {
      if (this.currentRunningFlow.UITasks != null) {
        let foundActiveTaskInFlow = this.currentRunningFlow.UITasks.find(function (element) {
          if (element.ExecutingTaskStatus == null) {
            return null;
          }
          return element.ExecutingTaskStatus.executerId == executingTaskData.executerId;
        });

        if (foundActiveTaskInFlow != null) {
          if(executingTaskData.data == null || executingTaskData.data == ""){
            executingTaskData.data = " ";
          }
          foundActiveTaskInFlow.StdOut.unshift(executingTaskData.data);
        }
      }
    }
    else  //check out if task run under a flow and if flow doesn't exist create it
    {
      if (executingTaskData.flowExecuterId != null) { //running in context of a flow

        let foundUiFlow = this.availableFlows.find(function (element) {
          return element.ODFlow.Id == executingTaskData.flowId;
        });
    
        if(foundUiFlow != null) {

           this.currentRunningFlow = foundUiFlow;
           if(this.currentRunningFlow.ExecutingFlowStatus == null) {
            this.currentRunningFlow.ExecutingFlowStatus = new ExecutingFlowStatus();
            this.currentRunningFlow.ExecutingFlowStatus.flowExecuterId = executingTaskData.flowExecuterId;
          }
        } 
      }
    }

    this.HandleGetFlinkJobs(executingTaskData);

    this.HandleFlinkTasks(executingTaskData);

    this.HandleGetPodsStatusTask(executingTaskData);

    this.HandleGetFdControllerLogsTask(executingTaskData);

      //TODO temporarily
      //this.publishTaskStdOut.unshift(executingTaskData.data);
  }
 
  public loadMvvDemoData() {
    let mvvDemoData =`{"mps13": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/13/10_01_29/index_0a10_01_29.m3u8", "mps22": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/22/10_01_30/index_0a10_01_30.m3u8", "mps12": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/12/10_01_25/index_0a10_01_25.m3u8", "mps1": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/1/10_01_31/index_0a10_01_31.m3u8", "mps16": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/16/10_01_27/index_0a10_01_27.m3u8", "mps10": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/10/10_01_33/index_0a10_01_33.m3u8", "mps18": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/18/10_01_33/index_0a10_01_33.m3u8", "mps11": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/11/10_01_28/index_0a10_01_28.m3u8", "mps0": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/0/10_01_26/index_0a10_01_26.m3u8", "mps24": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/24/10_01_39/index_0a10_01_39.m3u8", "mps14": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/14/10_01_36/index_0a10_01_36.m3u8", "mps2": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/2/10_01_26/index_0a10_01_26.m3u8", "mps25": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/25/10_01_34/index_0a10_01_34.m3u8", "mps3": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/3/10_01_30/index_0a10_01_30.m3u8", "mps17": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/17/10_01_26/index_0a10_01_26.m3u8", "mps19": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/19/10_01_26/index_0a10_01_26.m3u8", "mps20": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/20/10_01_37/index_0a10_01_37.m3u8", "mps29": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/29/10_01_28/index_0a10_01_28.m3u8", "mps33": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/33/10_01_56/index_0a10_01_56.m3u8", "mps30": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/30/10_01_31/index_0a10_01_31.m3u8", "mps15": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/15/10_01_30/index_0a10_01_30.m3u8", "mps6": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/6/10_01_33/index_0a10_01_33.m3u8", "mps28": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/28/10_01_36/index_0a10_01_36.m3u8", "mps8": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/8/10_01_37/index_0a10_01_37.m3u8", "mps32": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/32/10_01_32/index_0a10_01_32.m3u8", "mps4": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/4/10_01_34/index_0a10_01_34.m3u8", "mps26": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/26/10_01_32/index_0a10_01_32.m3u8", "mps31": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/31/10_01_37/index_0a10_01_37.m3u8", "mps23": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/23/10_01_38/index_0a10_01_38.m3u8", "mps5": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/5/10_01_28/index_0a10_01_28.m3u8", "mps21": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/21/10_01_36/index_0a10_01_36.m3u8", "mps9": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/9/10_01_29/index_0a10_01_29.m3u8", "mps7": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/7/10_01_33/index_0a10_01_33.m3u8", "mps27": "https://isg-teecontrol-data-management-svc-dev.s3.amazonaws.com/e02v4rc6fsyl3zu/v440rel/mp4_packager/27/10_01_39/index_0a10_01_39.m3u8"}`;
    this.mvvObjects = JSON.parse(mvvDemoData);
  }

  private AddFileUrlToExecutingTask(tasks, fileUrl: string, taskId:string) {
      let foundTask = tasks.find(function (element) {
        return element.ExecutingTaskStatus.taskId == taskId;
      });
      if(foundTask!=null) {
        foundTask.FileUrl = fileUrl;
      }
  }

  private AddResultsS3BucketToExecutingTask(tasks, resultsS3Bucket: string, taskId:string) {
      let foundTask = tasks.find(function (element) {
        return element.ExecutingTaskStatus.taskId == taskId;
      });
      if(foundTask!=null) {
        foundTask.ResultsS3Bucket = resultsS3Bucket;
      }
  }

  private CreateNewFoundTask(executingTaskData: ExecutingTaskData) :UIExecutingTask  {

      let templateODTask = this.availableTasks.find(function (element) {
        return element.Id == executingTaskData.taskId;
      });

      if (templateODTask != null) {
        let newFoundActiveTask: UIExecutingTask = {
          "ODTask": templateODTask,
          "expanded": false,
          "StdOut": []
        }
        newFoundActiveTask.StdOut.unshift(executingTaskData.data);
      
        let foundExecutingTaskStatus: ExecutingTaskStatus = {
            taskId: executingTaskData.taskId,
            executerId: executingTaskData.executerId,
            deploymentId: executingTaskData.deploymentId,
            startDateTime: executingTaskData.startDateTime.toString(),
            dynamicTaskName: executingTaskData.dynamicTaskName,
            executerName: executingTaskData.executerName,
            // endDateTime?: string;
            //taskStatus: TaskStatus.TaskStarted,
            statusString: "TaskStarted",
            //errorData:executingTaskData.errorData, 
            flowExecuterId: executingTaskData.flowExecuterId
          }
        newFoundActiveTask.ExecutingTaskStatus = foundExecutingTaskStatus;

        return newFoundActiveTask;
      }
      return null;
  }

  private HandleGetFdControllerLogsTask(executingTaskData: ExecutingTaskData) {

    if(executingTaskData.data != null) {
      
      if(executingTaskData.data.includes('fdControllerLog')) {
        this.announceLogArrived("log");
      }
    }
  }

  private HandleGetPodsStatusTask(executingTaskData: ExecutingTaskData) {
    if(executingTaskData.data != null) {
      
      //if(executingTaskData.data.includes('{"clustersReport":[{"')) {
      if(executingTaskData.data.includes('clustersReport')) {
        let fullString = executingTaskData.data;
        let fullObject = JSON.parse(fullString);
        // let propertyString = executingTaskData.data['clustersReport'];
        // let propertyObject = JSON.parse(propertyString);
        const clusterPodsStatus = fullObject["clustersReport"];
        this.clusters = clusterPodsStatus;
        // this.clusters.forEach(item=>item.expanded="collapsed");

        //find V4V pod
        this.V4VPod = null;
        let foundAllTheRest = this.clusters.find(function (element) {
          return element.Name.startsWith("AllTheRest");
        });
        if(foundAllTheRest) {
       
          let pods = foundAllTheRest["Pods"];
          let foundV4V = pods.find(function (element) {
             return element.Name.startsWith('v4v');
          });
          if(foundV4V != null) {
            this.V4VPod = foundV4V.Name;
          }
        }
        this.announceClustersUpdated("updated");
      }

    }
  }
  private HandleGetFlinkJobs(executingTaskData: ExecutingTaskData) {
     if(executingTaskData.data?.includes('{"jobs":[{"')) {
          
          const jobsStatuses = JSON.parse(executingTaskData.data);
      
          if(jobsStatuses.jobs != null && executingTaskData.deploymentId == this.selectedDeployment.deployment_id) {
            
            //TODO add and update, not overrun

            this.flinkJobs = [];//jobsStatuses.jobs;
            
              jobsStatuses.jobs.forEach( arrivedJob => {
              
                let uiJob: FlinkJob = {
                  "jid": arrivedJob.jid,
                  "name": arrivedJob.name,
                  "state": arrivedJob.state,
                  "startTime": arrivedJob["start-time"],
                  "endTime": arrivedJob["end-time"],
                  "duration": this.msToTime(arrivedJob.duration),
                  "tasks": arrivedJob.tasks
                  // "tasks": arrivedJob.tasks.running + "/" + arrivedJob.tasks.total
                }
                
                if(uiJob.state === "RUNNING") {
                  uiJob.uiCancelOpertaionText = "Cancel Job" 
                }

                if(arrivedJob["end-time"] === -1) {
                  uiJob.endTime = null;
                }
                this.flinkJobs.push(uiJob);
              });
          }
     }
  }
  private HandleFlinkTasks(executingTaskData: ExecutingTaskData) {
    
    if(executingTaskData.data != null) {

      if(executingTaskData.flinkTaskType == FlinkTaskType.JobsOverview) {

        if(executingTaskData.data?.includes('{"jobs":[{"')) {
          
          const jobsStatuses = JSON.parse(executingTaskData.data);
      
          if(jobsStatuses.jobs != null && executingTaskData.deploymentId == this.selectedDeployment.deployment_id) {
            
            //TODO add and update, not overrun

            this.flinkJobs = [];//jobsStatuses.jobs;
            
              jobsStatuses.jobs.forEach( arrivedJob => {
              
                let uiJob: FlinkJob = {
                  "jid": arrivedJob.jid,
                  "name": arrivedJob.name,
                  "state": arrivedJob.state,
                  "startTime": arrivedJob["start-time"],
                  "endTime": arrivedJob["end-time"],
                  "duration": this.msToTime(arrivedJob.duration),
                  "tasks": arrivedJob.tasks
                  // "tasks": arrivedJob.tasks.running + "/" + arrivedJob.tasks.total
                }
                
                if(uiJob.state === "RUNNING") {
                  uiJob.uiCancelOpertaionText = "Cancel Job" 
                }

                if(arrivedJob["end-time"] === -1) {
                  uiJob.endTime = null;
                }
                this.flinkJobs.push(uiJob);
              });
          }
        }
      }
      else if(executingTaskData.flinkTaskType == FlinkTaskType.UploadJar) {
        if(executingTaskData.data.includes("file uploaded")) {
          this._isUploadingToFlink = false;
          this._isUploadedToFlink = true;
        }
      }
      else if(executingTaskData.flinkTaskType == FlinkTaskType.GetDeployedJarList)  {
        if(executingTaskData.data.includes("address")) {
            const jarFilesObjResponse = JSON.parse(executingTaskData.data);
            this.deployedFlinkJars = [];
            jarFilesObjResponse.files.forEach(x=> this.deployedFlinkJars.push(x.id));
          }
      }
      else if(executingTaskData.flinkTaskType == FlinkTaskType.RunJar) {
        if(executingTaskData.data.includes("jobid")) {
          const flinkJob = JSON.parse(executingTaskData.data);
          this.runningJobs.push(flinkJob.jobid); 
          }
        }
      }
      else {
        if(executingTaskData.data?.includes('{"jobs":[{"')) {
          const jobsStatuses = JSON.parse(executingTaskData.data);
      
           if(jobsStatuses.jobs != null && executingTaskData.deploymentId == this.selectedDeployment.deployment_id) {

               this.flinkJobs = [];
            
               jobsStatuses.jobs.forEach( arrivedJob => {
              
                  let uiJob: FlinkJob = {
                    "jid": arrivedJob.jid,
                    "name": arrivedJob.name,
                    "state": arrivedJob.state,
                    "startTime": arrivedJob["start-time"],
                    "endTime": arrivedJob["end-time"],
                    "duration": this.msToTime(arrivedJob.duration),
                    "tasks": arrivedJob.tasks
                  }
                    
                  if(uiJob.state === "RUNNING") {
                    uiJob.uiCancelOpertaionText = "Cancel Job" 
                  }

                  if(arrivedJob["end-time"] === -1) {
                    uiJob.endTime = null;
                  }
                
                  this.flinkJobs.push(uiJob);
               });
           }
        }
      }
  }
  msToTime(millis) {
    const hours = `0${new Date(millis).getHours() - 2}`.slice(-2);
    const minutes = `0${new Date(millis).getMinutes()}`.slice(-2);
    const seconds = `0${new Date(millis).getSeconds()}`.slice(-2);

    const time = `${hours}:${minutes}:${seconds}`
    return time;
  }

  private buildConnection = () => {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(this.HUB_URL, { accessTokenFactory: () => this.authService.accessToken }) //use your api adress here and make sure you use right hub name.
      .build();
  };

  public startConnection = () => {

    let self = this;

    this.hubConnection
      .start()
      .then(() => {
        console.log("UI succeeded to connect to HUB");
        this.connectedToHubServer = true;
        self.registerUI();
      })
      .catch(err => {
        self.connectedToHubServer = false;
        self.registeredToHubServer = false;
        console.log("Error while starting connection: " + err);
        //if you get error try to start connection again after 3 seconds.

        setTimeout(function() {
          self.startConnection();
          self.registerUI();
        }, 3000);
      });
  };

  public registerUI() {
    if (this.hubConnection.state == HubConnectionState.Connected) {
      this.hubConnection.invoke("RegisterUI")
        .then(() => {
        })
    }
  }

  resetDecoderPods() {
    if (confirm('Are you sure you want to reset/delete all decoder pods?')) {
     this.startTask("acf96955-2371-4f55-a9ac-b3a35a965e81"); //specific taskId = "reset decoder pods"
    }
  }

  startPrepareDeployment(currentConfigDataString: string) {
    let taskPayload: TaskPayload = {
      "TaskId": "114813a0-d149-4575-8857-12731be8490f",
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "JsonConfigDynamicParameters": currentConfigDataString,
      "TaskType": "PrepareDeployment"
    };

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub with dynamic parameters: " + currentConfigDataString);
    })    
  }

  startCustomFlow(dynamicParameters: string) {
    let taskPayload: TaskPayload = {
      "TaskId": "c1ea68e5-8cdf-4a5c-89b1-1a395b775fcb",
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "DynamicParameters": dynamicParameters,
      "TaskType": "CustomFlow"
    };

     this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub with dynamic parameters: " + dynamicParameters);
      })
  }

  startV4V(currentConfigData: string, dynamicParameters: string, dynamicTaskName: string) {

    let cluster = this.clusters;
    let targetPod = this.V4VPod;

    let taskPayload: TaskPayload = {
      "TaskId": "5a676750-e678-4dea-8fb4-cb02244e4632",
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "JsonConfigDynamicParameters": currentConfigData,
      "DynamicParameters": dynamicParameters,
      "DynamicTaskName": dynamicTaskName,
      "TaskType": "V4V",
      "TargetPod": targetPod
    };

     this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub with dynamic parameters: " + dynamicParameters);
      })
  }

  startMVV(dynamicParameters: string) {

    let taskPayload: TaskPayload = {
      "TaskId": "54638f14-da98-473e-8fb0-2efc4432a458",
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "GameId": this.selectedDeployment.game_id,
      "DynamicParameters": dynamicParameters,
      "TaskType": "MVV",
    };

    this.isMvvRunning = true;

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub with dynamic parameters: " + dynamicParameters);
      })
  }

  startDebugKit(currentConfigData: string, dynamicParameters: string, dynamicTaskName: string) {
      let taskPayload: TaskPayload = {
      "TaskId": "6a8056b7-3354-4485-990d-48cca2becf04",
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "JsonConfigDynamicParameters": currentConfigData,
      "DynamicParameters": dynamicParameters,
      "DynamicTaskName": dynamicTaskName,
      "TaskType": "DebugKit"
    };

     this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub with dynamic parameters: " + dynamicParameters);
      })
  }

  startKDSInspecting(KdsName:string, KdsRegion:string,readFrom: string, saveRecordsToDisk:string) {
    let dynamicParameters = KdsName + " " + KdsRegion + " " + readFrom;
    let taskPayload: TaskPayload = {
      "TaskId": "c4bc7c40-b9e8-46f6-8268-0b3eac19ca4f",
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "DynamicParameters": dynamicParameters,
      "DynamicTaskName": "Inspecting: " + KdsName,
      "TaskType": "KdsInspecting"
    };

     this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub with dynamic parameters: " + dynamicParameters);
      })
  }

  startRendererOutputVideoCreation(startFrame: string, endFrame: string) {
    let dynamicParameters = "$s3ConfigBucket " + startFrame + " " + endFrame;

    let taskPayload: TaskPayload = {
          "TaskId": "e09101c0-2c32-4b31-8b39-1ac4bf88351f",
          "DeploymentId": this.selectedDeployment.deployment_id,
          "ExecuterName": this.authService.connectedUserName,
          "DynamicParameters": dynamicParameters,
          "TaskType": "RendererOutputVideoCreator"
        };

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub with dynamic parameters: " + dynamicParameters);
      })
  }

  startKDSPublishing(currentConfigData: string, dynamicTaskname: string) {
    //this.publishTaskStdOut = [];
    this.startTaskWithDynamicParameters("b0c61d99-1318-4324-8682-5cdbb117f996",currentConfigData, dynamicTaskname);
  }

  cleanDecoderLustreFolders() {
    this.startTask("60b23667-e25a-4ac1-aeaf-b586d7b28199"); //specific taskId = "clean lustre folders"
  }

  getPodsStatus() {
    this.isRefreshPodStatusesOn = true;
    this.startTask("58502ff2-1851-4729-a9b0-50a3e35c344c"); //specific taskId = "Get Pods Status"
  }

  resetAllPods() {
    if (confirm('Are you sure you want to reset/delete all pods?')) {
     this.isResetPodsOn = true;
     this.startTask("5442b2b7-131f-463e-a0c0-4194d1800788"); //specific taskId = "Reset all pods"
    }
  }

  resetFdController() {
     if (confirm('Are you sure you want to reset/delete fdcontroller pod?')) {
      this.startTask("5af96270-f6f9-48f2-914c-aa6ed2d6a31e");
     }
  }
  
  getFdControllerLog() {
    this.startTask("f3ffd098-2e58-490b-8177-e81bdfca0623");
  }
  
  getBrokerData()
  {
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

     return this.httpClient.get(this.mqBorkerServicesApi, httpOptions)
    .pipe(
      tap((arrivedData) => {

        return arrivedData;
      }),
      catchError(this.handleError)
    );
  }

  getAllFlows() {
    
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.get(this.urlFlowsApi, httpOptions)
    .pipe(
      tap((arrivedData:ODFlow[]) => {

        this.availableFlows = [];

        arrivedData.forEach( flow => {
           
            let uIExecutingFlow: UIExecutingFlow = {
              "ODFlow": flow,
              "UITasks": []
            }

            flow.Tasks.forEach( task => {
              let uIExecutingTask = {
                ODTask:task,
                ExecutingTaskStatus: null,
                StdOut: null
              }
              uIExecutingFlow.UITasks.push(uIExecutingTask);
            });

            this.availableFlows.push(uIExecutingFlow);
        });

        return this.availableFlows;
      }),
      catchError(this.handleError)
    );
  }

  startFlowWithJsonParameters(flow: UIExecutingFlow, jsonParameters: object) { //user edited at flow level

    flow.UITasks.forEach( task=> {
      task.ExecutingTaskStatus = null;
    });

    this.currentRunningFlow = flow;

    let flowPayload: FlowPayload = {
      "FlowId": flow.ODFlow.Id,
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "FlowJsonParameters": JSON.stringify(jsonParameters)
    };

    this.hubConnection.invoke("StartFlow", flowPayload)
      .then(() => {
        console.log("UI Sent 'StartFlow' to hub");
      })
  }

  startFlowWithTaskParameters(flow: UIExecutingFlow, parametersPayloadString: string) { //user edited at task level
  
    flow.UITasks.forEach( task=> {
      task.ExecutingTaskStatus = null;
    });

    this.currentRunningFlow = flow;

    let flowPayload: FlowPayload = {
      "FlowId": flow.ODFlow.Id,
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "FlowTaskParameters": parametersPayloadString
    };

    this.hubConnection.invoke("StartFlow", flowPayload)
      .then(() => {
        console.log("UI Sent 'StartFlow' to hub");
      })
  }

  startFlow(flow: UIExecutingFlow) {

    flow.UITasks.forEach( task=> {
      task.ExecutingTaskStatus = null;
    });

    this.currentRunningFlow = flow;

    let flowPayload: FlowPayload = {
      "FlowId": flow.ODFlow.Id,
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName
    };

    this.hubConnection.invoke("StartFlow", flowPayload)
      .then(() => {
        console.log("UI Sent 'StartFlow' to hub");
      })
  }

  stopFlow(uIExecutingFlow: UIExecutingFlow) {

    let flowPayload: FlowPayload = {
      "FlowExecuterId": this.currentRunningFlow.ExecutingFlowStatus.flowExecuterId,
    };

    this.hubConnection.invoke("StopFlow", flowPayload)
      .then(() => {
        console.log("StopFlow...");
      })
  }

  startTask(taskId: string) {

    if(!this.selectedDeployment) {
      //alert("selectedDeployment is still not found!")
      return;
    }

    let taskPayload: TaskPayload = {
      "TaskId": taskId,
      "DeploymentId": this.selectedDeployment?.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "GameId": this.selectedDeployment.game_id,
    };

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub");
      })
  }

  startTaskWithOverridingParameters(taskId: string, overridingParameters: string) {

    let taskPayload: TaskPayload = {
      "TaskId": taskId,
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "OverridingParameters": overridingParameters,
      "AreParametersOverriden": true,
      "GameId": this.selectedDeployment.game_id,
    };

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub, with overriding parameters: " + overridingParameters);
      })
  }
    
  startTaskWithDynamicParameters(taskId: string, parameters: string, dynamicTaskName) {

    let taskPayload: TaskPayload = {
      "TaskId": taskId,
      "DeploymentId": this.selectedDeployment.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "JsonConfigDynamicParameters": parameters,
      "DynamicTaskName": dynamicTaskName,
      "TaskType": "KDSPublisher",
      "GameId": this.selectedDeployment.game_id,
    };

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'StartTask' to hub, with dynamic name: " + dynamicTaskName + ", with dynamic parameters: " + parameters);
      })
  }

  stopTask(executingTaskId: string) {

    let taskPayload: TaskPayload = {
      "ExecuterId": executingTaskId,
    };

    this.hubConnection.invoke("StopTask", taskPayload)
      .then(() => {
        console.log("StopTask...");
      })
  }

  // stopGetFlinkJobs() {
  //   if(this._getJobsExecutingTaskId != null) {
  //     this.stopTask(this._getJobsExecutingTaskId);
  //     // this._getJobsExecutingTaskId = null;
  //   }
  // }

  startGetFlinkJobs() {

     if(!this.selectedDeployment) {
      return;
    }
 
    let taskPayload: TaskPayload = {
      "TaskId": "11ce4446-5a7e-42cb-8023-95b614d77747", //Get Flink Running Jobs
      "DeploymentId": this.selectedDeployment?.deployment_id,
      "ExecuterName": this.authService.connectedUserName,
      "GameId": this.selectedDeployment.game_id,
    };

    this.hubConnection.invoke("StartTask", taskPayload)
      .then(() => {
        console.log("UI Sent 'startGetFlinkJobs' to hub");
      })
  }

  startFlinkTask(flinkTaskPaylod: FlinkTaskPayload) {

    if(this.hubConnection != null && this.hubConnection.state == HubConnectionState.Connected) {
    
      flinkTaskPaylod.DeploymentId = this.selectedDeployment.deployment_id;

      this.hubConnection.invoke("StartFlinkTask", flinkTaskPaylod)
        .then(() => {
          console.log("UI Sent 'StartFlinkTask' to hub");
        })
    }
  }
  
  // StopListenToFlinkJobs() {
  //   // window.clearInterval(this._intervalId);
  //   // this._intervalId = null;
  //   this.stopGetFlinkJobs();
  // }

  
  // ListenToFlinkJobs() {
  //       this.startGetFlinkJobs();
  //   // if(this._intervalId != null)    
  //   //   return;

  //   // this._intervalId = window.setInterval( () => 
  //   // {
  //   //       this.getJobsOverview()
  //   // }, 2000);
  // }

  // getJobsOverview(): void {
  //   let flinkTaskPayload: FlinkTaskPayload = {
  //           FlinkTaskType: FlinkTaskType.JobsOverview,
  //           DeploymentId: this.selectedDeployment.deployment_id
  //         }

  //   this.startFlinkTask(flinkTaskPayload);
  // }

  getCompletedTasks() {

    if(this.selectedDeployment.deployment_id == null)
      return;
      
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    let completedTaskPayload = {
      "deploymentId": this.selectedDeployment.deployment_id
    }

    return this.httpClient.post<CompletedTask[]>(this.urlCompletedTasksApi, completedTaskPayload, httpOptions)
      .pipe(
        tap((arrivedData:CompletedTask[]) => {

          this.completedTasks = arrivedData;
          this.isCompletedTasksLoaded = true;
          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  getODTasks() {

    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.get<ODTask[]>(this.urlTasksApi, httpOptions)
      .pipe(
        tap((arrivedData:ODTask[]) => {

          this.availableTasks = arrivedData;
          this.availableSortedTasks = arrivedData;
          this.isTasksLoaded = true;
          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  deleteODTask(task: ODTask) {

    // if (!confirm('Are you sure you want to delete the task ' + task.Name + ' ?')) {
    //   return;
    // }    

    let deleteTaskUrl = this.urlTasksApi + "/" + task.Id;
    
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.delete(deleteTaskUrl, httpOptions)
      .pipe(
        tap((res: boolean) => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  updateODTask(task: ODTask) {

    task.UpdatedBy = this.authService.connectedUserName;

    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.put(this.urlTasksApi, task, httpOptions)
      .pipe(
        tap((res: any) => {
          this.sendRefreshTasks();

          this.toastr.success('Task: ' + task.Name + ' updated successfully!', 'Updated Successfully!');

          return res;
        }),
        catchError(this.handleError)
      );
  }

  sendRefreshProgram(id: String) {
    this.hubConnection.invoke("RefreshProgram", id)
      .then(() => {
        console.log("RefreshProgram...");
      })
  }

  sendRefreshTasks() {
     this.hubConnection.invoke("RefreshTasks")
      .then(() => {
        console.log("RefreshTasks...");
      })
  }

  addODTask(newTask: ODTask) {
    if (newTask.ODProgram != null) {
      newTask.CategoryGroup = this.stringOfEnum(CategoryGroup, newTask.ODProgram.CategoryGroup);
      newTask.CreatedBy = this.authService.connectedUserName,
      newTask.UpdatedBy = this.authService.connectedUserName
    }

    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.post(this.urlTasksApi, newTask, httpOptions)
      .pipe(
        tap((res: ODTask) => {
  
          this.toastr.success('Task: ' + newTask.Name + ' saved successfully!', 'Saved Successfully!');
          return res;
        }),
        catchError(this.handleError)
      );
  }

  public getODPrograms() {
            
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.get(this.urlProgramsApi, httpOptions)
      .pipe(
        tap((arrivedData: ODProgram[]) => {

          this.odPrograms = arrivedData;
          this.isProgramsLoaded = true;
          return arrivedData;
        }),
        catchError(this.handleError)
      );

    //  this.httpClient.get<ODProgram[]>(this.urlProgramGetterApi).subscribe(data => {
    //     this.dataChange.next(data);
    //   },
    //   (error: HttpErrorResponse) => {
    //     console.log (error.name + ' ' + error.message);
    //   });   
  }

  // public getWorkerConnectedDeployments() {
  //   if (this.hubConnection == null)
  //     return;

  //   if (this.hubConnection.state == HubConnectionState.Connected) {

  //     this.hubConnection.invoke("GetWorkerConnectedDeployments")
  //     .then(() => {
  //         console.log("UI Sent 'GetWorkerConnectedDeployments' to hub");
  //      })
  //   }
  // }

  public getOPDockers() {

    if (this.hubConnection == null)
      return;

    if (this.hubConnection.state == HubConnectionState.Connected) {
      this.hubConnection.invoke("GetFdControllerList", this.selectedDeployment.deployment_id)
        .then(() => {
          console.log("UI Sent 'GetFdControllerList' to hub");
        })
    }
  }

  public getActiveDeployments() {

     let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.get(this.urlDeploymentsApi, httpOptions)
      .pipe(
        tap((arrivedData: Deployment[]) => {

          this.activeDeployments = arrivedData;

          //TODO select the first as a default
          if(this.activeDeployments != null && arrivedData && arrivedData?.length > 0) {
            this.selectedDeployment = arrivedData[0];//null;//arrivedData[0];
            this.selectedDeploymentString = arrivedData[0].deployment_id;//"";//arrivedData[0].deployment_id;
            this.announceDeploymentSelectionChanged("changed");
            // this.getCompletedTasks().subscribe();
          }

          // let tempDeployment: Deployment = {
          //   deployment_id: 'a01fdcontr26j7q'
          // }
          // this.activeDeployments.push(tempDeployment);

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getS3StaticBucket() {

     let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    let deploymentUrl = this.urlDeploymentsApi + "/" + this.selectedDeployment.deployment_id;

    return this.httpClient.get(deploymentUrl, httpOptions)
      .pipe(
        tap((arrivedData: any) => {
         
          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getAllBucketFileTree(bucketName:string, bucketBaseKey: string, bucketRegion: string) {
   
    let payload = {
      "BucketName": bucketName,
      "BucketBaseKey": bucketBaseKey,
      "BucketRegion": bucketRegion
    }

    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    let url = this.urlGeneralServicesApi + "/all";

    return this.httpClient.post(url, payload, httpOptions)
      .pipe(
        tap((arrivedData: any[]) => {

          this.bucketFileTree = arrivedData;
          
          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getBucketFileTree(bucketName:string, bucketBaseKey: string, bucketRegion: string) {
   
    let payload = {
      "BucketName": bucketName,
      "BucketBaseKey": bucketBaseKey,
      "BucketRegion": bucketRegion
    }

    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.post(this.urlGeneralServicesApi, payload, httpOptions)
      .pipe(
        tap((arrivedData: any[]) => {

          this.bucketFileTree = arrivedData;
          
          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getConfigurations() {

    let payload = {
      "DeploymentId": this.selectedDeployment.deployment_id,
      "DeploymentRegion": this.selectedDeployment.deployment_region//'us-east-1'
    }

    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    // let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': this.authService.idToken }), responseType: 'text' as 'json' };

    return this.httpClient.post(this.urlConfigurationsApi, payload, httpOptions)
      .pipe(
        tap((arrivedData: any[]) => {

          this.configurations = arrivedData;
          this.isConfigurationsLoaded = true;
          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getFlinkJars() {

     //"https://artifactory.il.alm-sg.com/artifactory/libs-release-local/intelsports/flinkflow/")
     let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

     return this.httpClient.get(this.urlFlinkJarsApi, httpOptions)
      .pipe(
        tap((arrivedData: string[]) => {

          this.availableJars = arrivedData;
          this.isFlinkJarsLoaded = true;
          return this.availableJars;
        }),
        catchError(this.handleError)
      );
  
    // return this.httpClient.get("https://artifactory.il.alm-sg.com/artifactory/libs-release-local/intelsports/flinkflow/")
    //    .pipe(
    //     tap((arrivedData) => {

    //       this.flinkJars = arrivedData;
    //       return arrivedData;
    //     }),
    //     catchError(this.handleError)
    //   );
  }

  public getPublisherConfigContent() {

    let payload = {
          "ConfigType": "Publisher",
          "KeyName": "Publishers/fd19publisher.json"
        }
    
    let configContent = this.urlConfigurationsApi +"/content";

     let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.post(configContent, payload, httpOptions)
      .pipe(
        tap((arrivedData: string) => {

           let configObject = arrivedData;//JSON.parse(arrivedData);
           this._publisherVersion = configObject["Publisher"]["PublisherVersion"];
           delete configObject["Publisher"]["PublisherVersion"];

           this._publishersCredentialsObj = configObject["AWSCredentials"];
           delete configObject["AWSCredentials"];

           this.publisherConfigContent = JSON.stringify(configObject);
           this.publisherConfigContent = arrivedData;
           this.isPublisherConfigLoaded = true;
           return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getFlinkConfigContent() {
      let payload = {
            "ConfigType": "DebugKit",
            "KeyName": "Flink/fd-core-flink-paralelism-config.json"
          }
      
      let configContent = this.urlConfigurationsApi +"/content";

      let httpOptions = {
        headers: new HttpHeaders({
          'Authorization': this.authService.idToken
        })
      };

      return this.httpClient.post(configContent, payload, httpOptions)
        .pipe(
          tap((arrivedData: string) => {

            this.flinkConfigContent = arrivedData;
            this.isflinkConfigLoaded = true;

            return arrivedData;
          }),
          catchError(this.handleError)
        );
  }

  public getV4VConfigContent() {
      let payload = {
            "ConfigType": "DebugKit",
            "KeyName": "Debug/V4VConfig.json"
          }
      
      let configContent = this.urlConfigurationsApi +"/content";

      let httpOptions = {
        headers: new HttpHeaders({
          'Authorization': this.authService.idToken
        })
      };

      return this.httpClient.post(configContent, payload, httpOptions)
        .pipe(
          tap((arrivedData: string) => {

            this.v4vConfigContent = arrivedData;

            delete arrivedData["DeploymentId"];

            delete arrivedData["UI"];
            
            delete arrivedData["LustreParentFolder"];
            
            this.isV4VConfigLoaded = true;

            return arrivedData;
          }),
          catchError(this.handleError)
        );
  }

  public getPrepareDeploymentConfigContent() {
      let payload = {
            "ConfigType": "DebugKit",
            "KeyName": "DeploymentConfiguration/prepDepUiConfig.json"
          }
      
      let configContent = this.urlConfigurationsApi +"/content";

      let httpOptions = {
        headers: new HttpHeaders({
          'Authorization': this.authService.idToken
        })
      };

    return this.httpClient.post(configContent, payload, httpOptions)
      .pipe(
        tap((arrivedData: string) => {

          this.prepareDeploymentConfig = arrivedData;
        
          this.isPrepareDeploymentConfigLoaded = true;

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getDebugKitConfigContent() {
      let payload = {
            "ConfigType": "DebugKit",
            "KeyName": "Debug/debugKitConfig.json"
          }
      
      let configContent = this.urlConfigurationsApi +"/content";

      let httpOptions = {
        headers: new HttpHeaders({
          'Authorization': this.authService.idToken
        })
      };

    return this.httpClient.post(configContent, payload, httpOptions)
      .pipe(
        tap((arrivedData: string) => {

          this.debugKitConfigContent = arrivedData;
          
          let list = arrivedData["IpsParams"];
      
          for (let entry in list) {
            this.debugKitIpList.push(entry);
          };
         
          // delete arrivedData["Logging"];

          this.isDebuKitConfigLoaded = true;
          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public getConfigContent(fileKey: string) {

    let payload = {
          "DeploymentId": this.selectedDeployment.deployment_id,
          "KeyName": fileKey
        }
    this.currentConfigFileName = fileKey;

    let configContent = this.urlConfigurationsApi +"/content";

     let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.post(configContent, payload, httpOptions)
      .pipe(
        tap((arrivedData: string) => {

          this.currentConfigContent = arrivedData;//JSON.stringify(arrivedData);
          // this.currentConfigContent = JSON.parse(arrivedData);

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public setConfigContent(contentBody: string) {

    if (!confirm('Are you sure you want to override the configuration file content?')) {
      return;
    }

    let payload = {
      "DeploymentId": this.selectedDeployment.deployment_id,
      "DeploymentRegion": 'us-east-1',//this.selectedDeploymentRegion
      "KeyName": this.currentConfigFileName,
      "ContentBody": contentBody
    }

    let configContent = this.urlConfigurationsApi +"/content";

    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': this.authService.idToken }), responseType: 'text' as 'json' };

    return this.httpClient.put(configContent, payload, httpOptions)
      .pipe(

        tap((arrivedData) => {
          
          this.toastr.success('Configuration file: ' + this.currentConfigFileName + ' saved successfully!', 'Saved Successfully!');

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  getS3FilePresignedUrl(fileKey: string, bucketName: string, bucketRegion: string) {

    if(!bucketRegion) {
      bucketRegion = "us-east-1"
    }

    let payload = {
      "BucketName": bucketName,
      "BucketRegion": bucketRegion,
      "FileKey": fileKey,
      "HttpVerb": "GET"
    }
   
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    let presignedUrl = this.urlGeneralServicesApi + "/presignedUrl";
    
    return this.httpClient.post(presignedUrl, payload, httpOptions) 
      .pipe(
        tap((urlObject:any) => {
           let result = urlObject['URL_STRING'];
           return result;
        }),
        catchError(this.handleError)
      );
  }


  getProgramPresignedUrlForReport(assetKey: string) {
    let payload = {
      "ProgramName": assetKey,
      "Package":"",
      "CategoryGroup": "Reports",
      "HttpVerb": "GET"
    }
   
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    let presignedUrl = this.urlProgramsApi + "/uploader";
    
    return this.httpClient.put(presignedUrl, payload, httpOptions) 
      .pipe(
        tap((urlObject:any) => {
          let result = urlObject['URL_STRING'];
          return result;
        }),
        catchError(this.handleError)
      );
  }

  stringOfEnum(myEnum, enumValue) {
    for (var k in myEnum) {
      if (myEnum[k] == enumValue) {
        return k;
      }
    }
    return null;
  }

  signup() {
     return Auth.signUp("gilshalev2003@yahoo.com", "3456ertydfgh()G");
  }
 
  public mySignUp(email, password): Observable<any> {
    return fromPromise(Auth.signUp(email, password));
  }

  testStop(flowExecuterId: string) {
    let programMessage= {
        "DeploymentId": this.selectedDeployment.deployment_id,
        "MessageName": "StopFlinkListener",
        "ExecuterId": this._tmpFLinkListenerexecuterID,
        "FlowExecuterId": flowExecuterId,
        "MessageSource": "FDC_UI"
    };

     this.hubConnection.invoke("SendProgramMessage", programMessage)
      .then(() => {
        console.log("UI Sent 'SendProgramMessage' to hub");
      })
  }
  
  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;

    if (!(error instanceof Response)) {
      errMsg = error.message ? error.message : error.toString();
    } else {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    }
    console.error(errMsg);

    return Observable.throw(errMsg);
  }
}
 // showProgress(message) {
  //      console.log (message);
  // }

//   private getEventMessage(event: HttpEvent<any>, file: File) {
//     switch (event.type) {
//       case HttpEventType.Sent:
//          return `Uploading file "${file.name}" of size ${file.size}.`;

//       case HttpEventType.UploadProgress:
//         // Compute and show the % done:
//         const percentDone = Math.round(100 * event.loaded / event.total);
//         return `File "${file.name}" is ${percentDone}% uploaded.`;

//         case HttpEventType.Response:
//           return `File "${file.name}" was completely uploaded!`;

//         default:
//           return `File "${file.name}" surprising upload event: ${event.type}.`;
//    }
// }

      //  const index = this.activeTasks.indexOf(foundActiveTask);
      //     if (index > -1) {
      //       this.activeTasks.splice(index, 1);
      //     }
      //    this.completedTasks.push(foundActiveTask);

       // if(foundActiveTask !=null) {
      //    foundActiveTask.ExecutingTaskStatus = executingTaskStatus;
      //    this.completedTasks.push(foundActiveTask);
      // }



  
  // private AddV4VResultsBucketToExecutingTask(resultsS3Bucket: string, taskId:string) {
  //     let foundV4VTask = this.v4vTasks.find(function (element) {
  //       return element.ExecutingTaskStatus.taskId == taskId;
  //     });
  //     if(foundV4VTask!=null) {
  //       foundV4VTask.ResultsS3Bucket = resultsS3Bucket;
  //     }
  // }
