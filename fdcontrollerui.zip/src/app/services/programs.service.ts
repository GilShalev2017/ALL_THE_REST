import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { ODProgram, CategoryGroup, ProgramType } from '../models/ODProgram';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { AuthService } from './../auth/auth.service';
import { AppConfigurationService } from './app-configuration.service';
import { ToastrService } from 'ngx-toastr';
import { OperationsService } from "../services/operations.service";

@Injectable()
export class ProgramsService {
 
  dataChange: BehaviorSubject<ODProgram[]> = new BehaviorSubject<ODProgram[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  private baseApiUrl: string;
  private urlProgramsApi: string;
  public currentScriptContent: string[] = [];
  
  httpOptions = {
    headers: new HttpHeaders({
      // 'Content-Type':  'application/json',
    })
  };

  constructor (private httpClient: HttpClient, private authService: AuthService, private appconfig:AppConfigurationService, private toastr: ToastrService, public operationsService: OperationsService) {

    this.baseApiUrl = appconfig.apiUrl;
    this.urlProgramsApi = this.baseApiUrl + "api/Program";

    //this.httpOptions.headers = this.httpOptions.headers.set('accept', 'text/plain');
    this.httpOptions.headers =  this.httpOptions.headers.set('Authorization', this.authService.idToken);
  }

  get data(): ODProgram[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  getAllPrograms(): void {

    // if(this.operationsService.isProgramsLoaded==true) {
    //    let dataCopy: ODProgram[]=  this.operationsService.odPrograms;
    //      dataCopy.forEach((item) => {
    //         item.ProgramTypeString = this.stringOfEnum(ProgramType,item.ProgramType);
    //         item.CategoryGroupString = this.stringOfEnum(CategoryGroup,item.CategoryGroup);
    //      });

    //     this.dataChange.next(dataCopy);
    // }
    // else
    {
      this.httpClient.get<ODProgram[]>(this.urlProgramsApi, this.httpOptions)
        .subscribe(data => {
    
          let dataCopy: ODProgram[]=  data;
          dataCopy.forEach((item) => {
              item.ProgramTypeString = this.stringOfEnum(ProgramType,item.ProgramType);
              item.CategoryGroupString = this.stringOfEnum(CategoryGroup,item.CategoryGroup);
          });

          this.dataChange.next(dataCopy);
        },
        (error: HttpErrorResponse) => {
          console.log (error.name + ' ' + error.message);
        });
    }
  }

  stringOfEnum(myEnum,enumValue) 
  {
    for (var k in myEnum) {
      if (myEnum[k] == enumValue) { 
        return k;
      }
    }
    return null;
  }
  
  addProgram (oDProgram: ODProgram): void {
    this.dialogData = oDProgram;
  }

  updateProgram (oDProgram: ODProgram): void {
    
    this.updateODProgram(oDProgram)
     .subscribe( (res) => {
        if(res === true) {
          this.dialogData = oDProgram;
        }
     });
  }
 
  updateODProgram(program: ODProgram) {
   
    program.UpdatedBy = this.authService.connectedUserName;
    
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.put(this.urlProgramsApi, program, httpOptions)
      .pipe(
        tap((res:ODProgram) => {

          this.operationsService.sendRefreshTasks();

          this.toastr.success('Task: ' + program.Name + ' updated successfully!', 'Updated Successfully!');

          return res;
        }),
        catchError(this.handleError)
      );
  }

  deleteProgramFromS3(program: ODProgram) {
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    let deleteS3Url = this.urlProgramsApi + "/delete-from-s3";

    return this.httpClient.post(deleteS3Url, program, httpOptions)
      .pipe(
        tap(res => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  sendRefreshProgram(id : string) {
    this.operationsService.sendRefreshProgram(id);
  }

  deleteODProgram (oDProgram: ODProgram) {
    
    // if (!confirm('Are you sure you want to delete the program ' + oDProgram.Name +' ?')) {
    //   return;
    // }
    let deletePath = this.urlProgramsApi + "/" + oDProgram.Id;

    return this.httpClient.delete(deletePath, this.httpOptions)
      .pipe(
        tap((res:boolean) => {
          return res;
        }),
        catchError(this.handleError)
      );
  }

  getProgramPresignedUrl(programName: string, programPackage: string, categoryGroup: string) {
    let payload = {
      "ProgramName": programName,
      "Package":programPackage,
      "CategoryGroup": categoryGroup,
    }
   
    let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    let presignedUrl = this.urlProgramsApi + "/uploader";

    //return this.httpClient.put(presignedUrl, payload, {responseType:'text'}) //CORS Error
    return this.httpClient.put(presignedUrl, payload, httpOptions) //PARSING ERROR
      .pipe(
        tap((urlObject:any) => {
          let result = urlObject['URL_STRING'];
          return result;
        }),
        catchError(this.handleError)
      );
  }

  uploadFileToS3(url :string, file): boolean{

    //  const req = new HttpRequest('POST', url, file, {
    //     reportProgress: true
    //  });

    //  this.httpClient.request(req).pipe(
    //     map(event => this.getEventMessage(event, file)),
    //     tap(message => this.showProgress(message)),
    //     // last(), // return last (completed) message to caller
    //     // catchError(this.handleError(file))
    //   ).subscribe(data => {
    //     let i= data;
    //     return true
    //   },
    //   (error: HttpErrorResponse) => {
    //     console.log (error.name + ' ' + error.message);
    //     return false;
    //   });

    //  return false;

      var xhr = new XMLHttpRequest();

      // Used to be false=sync
      xhr.open('PUT', url, false);
      //xhr.open('PUT', url, true);

      xhr.setRequestHeader('Content-Type', 'application/octet-stream');

      xhr.onload = (event) => {

         var prog = Math.round(event.loaded * 100 / event.total); 
         console.log("inside onload callback of uploadFileToS3: xhr.status=" + xhr.status);
         if (xhr.status === 200) {
           console.log(event);
         }
      };
      
      xhr.onerror = (errorEvent) => {
         console.log("inside onerror callback of uploadFileToS3: errorEvent=" + errorEvent);
      };

      xhr.onprogress = function (event) {
            var prog = Math.round(event.loaded * 100 / event.total); 
            console.log("inside onprogress callback of uploadFileToS3: xhr.status=" + xhr.status);
            console.log("event.loaded" + event.loaded);
            console.log("event.total" + event.total);
      };

      // var formData = new FormData();
      // formData.append("thefile", file);
      // xhr.send(formData);

      xhr.send(file);

      return true;
  }

  addProgramToDynamoDB(newProgram: ODProgram) {

    let odp = {
      "Name" : newProgram.Name,
      "Description": newProgram.Description,
      "Package":newProgram.Package,
      "IsPackageCompressed": newProgram.IsPackageCompressed,
      "ExecutedProgram": "temp",
      "ExecutedProgramParams":newProgram.ExecutedProgramParams,
      "CategoryGroup": newProgram.CategoryGroup,
      "ProgramType": newProgram.ProgramType,
      "ConfigurationFile": newProgram.ConfigurationFile,
      "CreatedBy": this.authService.connectedUserName,
      "UpdatedBy": this.authService.connectedUserName,
    }     
    
    //var progTypeInt: number = parseInt(newProgram.ProgramType.toString(), 10);
    let progTypeString = newProgram.ProgramType.toString();
    // let programTypeString = this.stringOfEnum(ProgramType,newProgram.ProgramType);

    // let progType:ProgramType = ProgramType[programTypeString];

    if(progTypeString == 'dotnet') {
      odp.ExecutedProgram = "dotnet";
    }
    else if(progTypeString == 'java') {
      odp.ExecutedProgram = "java";
    }
    else if(progTypeString == 'python') {
      odp.ExecutedProgram = "python";
    }
    else if(progTypeString == 'python3') {
      odp.ExecutedProgram = "python3";
    }
    else if(progTypeString == 'bashScript') {
      odp.ExecutedProgram = "/bin/bash";
    }
    else if(progTypeString == 'golang') {
      odp.ExecutedProgram = "golang";
    }
    else if(progTypeString == 'windowsBatchScript') {
      odp.ExecutedProgram = "C:\\Windows\\System32\\cmd.exe";
      odp.ExecutedProgramParams = "/C " + odp.ExecutedProgramParams;
    }
    else if(progTypeString == 'none') {
      odp.ExecutedProgram = "";
    }

  
    return this.httpClient.post(this.urlProgramsApi, odp, this.httpOptions)
      .pipe(
        tap((res:ODProgram) => {

          return res;
        }),
        catchError(this.handleError)
      );
  }

  public getScriptContent(fileKey: string) {

    let payload = {
          "fileKey": fileKey
        }
 
    let scriptContentUrl = this.urlProgramsApi +"/content";

     let httpOptions = {
      headers: new HttpHeaders({
        'Authorization': this.authService.idToken
      })
    };

    return this.httpClient.post(scriptContentUrl, payload, httpOptions)
      .pipe(
        tap((arrivedData: string[]) => {

          this.currentScriptContent = arrivedData;

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }

  public saveScriptContent(fileKey: string, content:string) {

     let payload = {
      "fileKey": fileKey,
      "scriptContent": content
     }

    let scriptContentUri = this.urlProgramsApi +"/content";

    //  let httpOptions = {
    //   headers: new HttpHeaders({
    //     'Authorization': this.authService.idToken
    //   })
    // };

    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Authorization': this.authService.idToken }), responseType: 'text' as 'json' };

    return this.httpClient.put(scriptContentUri, payload, httpOptions)
      .pipe(
        tap((arrivedData: any) => {

          this.toastr.success('Script file: ' + fileKey + ' saved successfully!', 'Saved Successfully!');

          return arrivedData;
        }),
        catchError(this.handleError)
      );
  }
  
  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (!(error instanceof Response)) {
      errMsg = error.message ? error.message : error.toString();
    } else {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}