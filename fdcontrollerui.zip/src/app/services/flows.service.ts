import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {ODFlow} from '../models/ODFlow';
import {UIExecutingFlow} from '../models/UIExecutingFlow';
import {UIExecutingTask} from '../models/UIExecutingTask';
import {ODTask} from '../models/ODTask';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {OperationsService} from "../services/operations.service";
import {AuthService } from './../auth/auth.service';
import {AppConfigurationService } from './app-configuration.service';
import {ToastrService} from 'ngx-toastr';

@Injectable()
export class FlowsService {

  httpOptions = {
    headers: new HttpHeaders({
      // 'Content-Type':  'application/json'
      //'accept':  'application/json'
    })
  };

  private baseApiUrl: string;
  private urlFlowsApi: string; 
  
  dataChange: BehaviorSubject<ODFlow[]> = new BehaviorSubject<ODFlow[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;
  filteredText: string;

  public availableFlows: UIExecutingFlow[];
  public filteredFlows: UIExecutingFlow[] = [];
  public isLoaded: boolean = false;

  constructor (private httpClient: HttpClient,
               private authService: AuthService,
               private operationsService: OperationsService,
               private appconfig:AppConfigurationService,
               private toastr: ToastrService) {

    this.baseApiUrl = appconfig.apiUrl;
    this.urlFlowsApi = this.baseApiUrl + "api/Flows";

    this.httpOptions.headers =  this.httpOptions.headers.set('Authorization', this.authService.idToken);
  }

  get data(): ODFlow[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  getAllFlows() {
      
    return this.httpClient.get(this.urlFlowsApi, this.httpOptions) 
        .pipe(
        tap((arrivedData:ODFlow[]) => {

          this.availableFlows = [];
          
          this.isLoaded = true;
          
          arrivedData.forEach( flow => {
             
              let uIExecutingFlow: UIExecutingFlow = {
                "ODFlow": flow,
                "UITasks": []
              }

              flow.Tasks.forEach( task => {
                let uIExecutingTask = {
                  ODTask:task,
                  ExecutingTaskStatus: null,
                  StdOut: null
                }
                uIExecutingFlow.UITasks.push(uIExecutingTask);
              });

              this.availableFlows.push(uIExecutingFlow);
          });
 
          this.filteredFlows = this.availableFlows;
          return this.availableFlows;
        }),
        catchError(this.handleError)
      );
  }

  stringOfEnum(myEnum,enumValue) 
  {
    for (var k in myEnum) {
      if (myEnum[k] == enumValue) { 
        return k;
      }
    }
    return null;
  }
  
  addFlow (oDFlow: ODFlow): void {
    this.dialogData = oDFlow;
  }

  updateFlow (oDFlow: ODFlow): void {
    this.updateODFlow(oDFlow)
     .subscribe( (res) => {
        if(res === true) {
          this.dialogData = oDFlow;
        }
     });
  }
 
  updateODFlow(flow: ODFlow) {

    flow.UpdatedBy = this.authService.connectedUserName;
    
    return this.httpClient.put(this.urlFlowsApi, flow, this.httpOptions)
      .pipe(
        tap((res:ODFlow) => {
          this.toastr.success('Flow: ' + flow.Name + ' saved successfully!', 'Saved Successfully!');
          this.operationsService.sendRefreshTasks();
          return res;
        }),
        catchError(this.handleError)
      );
  }

  deleteODFlow (uiExecutingFlow: UIExecutingFlow) {
   
   let deleteFlowUrl = this.urlFlowsApi + "/" + uiExecutingFlow.ODFlow.Id;
    
    return this.httpClient.delete(deleteFlowUrl, this.httpOptions)
      .pipe(
        tap((res:boolean) => {
          this.toastr.success('Flow: ' + uiExecutingFlow.ODFlow.Name + ' deleted successfully!', 'Deleted Successfully!');
          return res;
        }),
        catchError(this.handleError)
      );
   }

   addFlowToDynamoDB(newFlow: ODFlow) {
   
    newFlow.CreatedBy = this.authService.connectedUserName;
    newFlow.UpdatedBy = this.authService.connectedUserName;

    return this.httpClient.post(this.urlFlowsApi, newFlow, this.httpOptions)

      .pipe(
        tap((res:ODFlow) => {
          this.toastr.success('Flow: ' + newFlow.Name + ' saved successfully!', 'Saved Successfully!');
          this.operationsService.sendRefreshTasks();
          return res;
        }),
        catchError(this.handleError)
      );
  }

  handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (!(error instanceof Response)) {
      errMsg = error.message ? error.message : error.toString();
    } else {
      const body = error.json() || '';
      const err = body || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
}