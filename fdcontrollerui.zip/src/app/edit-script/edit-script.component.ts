import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject, Input } from '@angular/core';
import { ProgramsService } from "../services/programs.service";
import { FormControl, Validators } from '@angular/forms';
import { ODProgram } from "../models/ODProgram";

export interface CodeModel {
  language: string;
  value: string;
  uri: string;
 
  dependencies?: Array<string>;
  schemas?: Array<{
    uri: string;
    schema: Object;
  }>;
}

@Component({
  selector: 'app-edit-script',
  templateUrl: './edit-script.component.html',
  styleUrls: ['./edit-script.component.css']
})
export class EditScriptComponent {

  theme = 'hc-black';
  editedContent: string;
  //'vs';
  //'hc-black';
  //'vs-dark';

  codeModel: CodeModel = {
    language: 'python',
    uri: 'main.json',
    value: this.data.ScriptCode.join('\n'),
    dependencies: ['@types/node', '@ngstack/translate', '@ngstack/code-editor']
  };
 
  options = {
    lineNumbers: true,
    contextmenu: true,
    minimap: {
      enabled: false
    }
  };
 
  onCodeChanged(value) {
    console.log('CODE', value);
    this.editedContent = value;
  }

  constructor(public dialogRef: MatDialogRef<EditScriptComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODProgram, 
              public programsService: ProgramsService) { }

 formControl = new FormControl('', [
    Validators.required

  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  saveScriptContent() {

    let fileKey = this.data.CategoryGroupString + "/" + this.data.Name + "/" + this.data.Package;

    if (confirm('Are you sure you want to override this code?')) {
        this.programsService.saveScriptContent(fileKey, this.editedContent)
          .subscribe( res=>{
              this.dialogRef.close();
          });
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  stopEdit(): void {
    this.programsService.updateProgram(this.data);
  }
}
