import { Component, ViewChild, OnInit } from '@angular/core';
import { MatSelectionList, MatSelectionListChange, MatListOption } from '@angular/material/list';
import { SelectionModel } from '@angular/cdk/collections';
import { Router } from '@angular/router';
import { OperationsService } from "../services/operations.service";

@Component({
  selector: 'app-debug-tools',
  templateUrl: './debug-tools.component.html',
  styleUrls: ['./debug-tools.component.css']
})
export class DebugToolsComponent implements OnInit {
  
  typesOfTools: string[] = ['Debug Links', 'Debug Kit', 'Debug PMD', 'V4V',  'KVS Streamer', 'KVS Inspector', 'KDS Publisher', 'KDS Inspector',];
  
  @ViewChild(MatSelectionList, {static: true}) tools: MatSelectionList;

  constructor(public router: Router,
              public operationsService: OperationsService) { }

  ngOnInit() {

     this.tools.selectionChange.subscribe((s: MatSelectionListChange) => {          
        
          this.tools.deselectAll();
          s.option.selected = true;
      });

      console.log(this.router.url)
  }

}
