import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-production-flows',
  templateUrl: './production-flows.component.html',
  styleUrls: ['./production-flows.component.css']
})
export class ProductionFlowsComponent implements OnInit {


  on1: boolean;
  on2: boolean;
  on3: boolean;
  on4: boolean;
  on5: boolean;
  on6: boolean;
  on: boolean;

  constructor() { }

  ngOnInit(): void {
  }

  selectFlow(onFlag: string) {
    this.on1 = false;
    this.on2 = false;
    this.on3 = false;
    this.on4 = false;
    this.on5 = false;
    this.on6 = false;
    this.on = false;

    if(onFlag=="on1") {
      this.on1 = true;
    }
    else if(onFlag=="on2") {
      this.on2 = true;
    }
    else if(onFlag=="on3") {
      this.on3 = true;
    }
    else if(onFlag=="on4") {
      this.on4 = true;
    }
    else if(onFlag=="on5") {
      this.on5 = true;
    }
    else if(onFlag=="on6") {
      this.on6 = true;
    }
    else if(onFlag=="on") {
      this.on = true;
    }
  }
}
