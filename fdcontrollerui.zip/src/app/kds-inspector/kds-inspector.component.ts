import { Component, OnInit } from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye } from '@fortawesome/free-solid-svg-icons';
import { UIExecutingTask } from "../models/UIExecutingTask";
import { MatRadioModule, MatRadioChange } from '@angular/material/radio';
import { ODTask } from "../models/ODTask";
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-kds-inspector',
  templateUrl: './kds-inspector.component.html',
  styleUrls: ['./kds-inspector.component.css']
})
export class KdsInspectorComponent implements OnInit {

  KdsName: string;
  KdsRegion: string;
  readFromBeginningOfStream: string = "true";
  regions: string[] = ['us-east-1','us-east-2', 'us-west-1','us-west-2','eu-west-1', 'eu-west-2','eu-west-3','eu-central-1','eu-south-1','eu-north-1'];
  faStop = faStop;
  saveRecordsToDisk: boolean = false;

  constructor(public operationsService: OperationsService) {

    // formControl = new FormControl('', [
    //     Validators.required
    // ]);
  }

  // getErrorMessage() {
  //   return this.formControl.hasError('required') ? 'Required field' :
  //     this.formControl.hasError('email') ? 'Not a valid email' :
  //       '';
  // }

  ngOnInit(): void {
    if(this.operationsService.isTasksLoaded==false) {
      this.operationsService.getODTasks()
        .subscribe( (arrivedData: ODTask[]) => {
      });
    }
  }

  onReadFromChange(mrChange: MatRadioChange) {
   
    let readFromValue = mrChange.value;
      switch(readFromValue) { 
        case "1": { 
            this.readFromBeginningOfStream = "true"
            break; 
        } 
        case "2": { 
            this.readFromBeginningOfStream = "false"; 
            break; 
        } 
      }
  }

  startInspceting() {
     this.operationsService.kdsInspectorTasks = [];
    //dyanamic Parameters: KdsName KdsRegion readFrom
    this.operationsService.KdsInspectorIsRunning = true;

    this.operationsService.startKDSInspecting(this.KdsName, this.KdsRegion, this.readFromBeginningOfStream, this.saveRecordsToDisk.toString());
  }

  stopTask(task: UIExecutingTask, event?: Event){
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.stopTask(task.ExecutingTaskStatus.executerId);
  }

  cleanHistory() {
    this.operationsService.kdsInspectorTasks = [];
  }

   submit() {
    // emppty stuff
  }
}
