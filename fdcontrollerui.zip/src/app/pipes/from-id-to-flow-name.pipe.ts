import { Pipe, PipeTransform } from '@angular/core';
import { OperationsService } from "../services/operations.service";

@Pipe({
  name: 'fromIdToFlowName'
})
export class FromIdToFlowNamePipe implements PipeTransform {

 /**
  *
  */
 constructor(public operationsService: OperationsService) {
    
 }

  transform(value: string): string {
    if (!value) {
      return 'Standalone Task';
    }
   
    let foundFlow = this.operationsService.availableFlows.find(function (element) {
      return element.ODFlow.Id == value;
    });

    if(foundFlow) {
      return foundFlow.ODFlow.Name;
    }

    return '';
  }

}
