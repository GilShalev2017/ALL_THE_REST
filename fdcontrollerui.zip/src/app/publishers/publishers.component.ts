import { Component, OnInit, ViewChild} from '@angular/core';
import { OperationsService } from "../services/operations.service";
import { JsonEditorComponent, JsonEditorOptions } from 'ang-jsoneditor';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UIExecutingTask } from "../models/UIExecutingTask";
import { faEdit, faFileArchive, faStop, faPlay,faCalendar, faRecycle, faEye } from '@fortawesome/free-solid-svg-icons';
import { ODTask } from "../models/ODTask";

@Component({
  selector: 'app-publishers',
  templateUrl: './publishers.component.html',
  styleUrls: ['./publishers.component.css']
})
export class PublishersComponent implements OnInit  {

  public editorOptions: JsonEditorOptions;
  public configurationSettings: any;
  public PublisherType:any;
  public PublisherToExecute:string;
  
  faStop = faStop;

  @ViewChild(JsonEditorComponent) editor: JsonEditorComponent;
 
  constructor(public operationsService: OperationsService) { 

    this.editorOptions = new JsonEditorOptions();
    this.editorOptions.modes = ['code', 'text', 'tree', 'view'];
  }

  ngOnInit() {

    //this.operationsService.StopListenToFlinkJobs();
    
    if(this.operationsService.isTasksLoaded==false) {
      this.operationsService.getODTasks()
        .subscribe( (arrivedData: ODTask[]) => {
      });
    }

    if(this.operationsService.isPublisherConfigLoaded==false) {

      this.operationsService.getPublisherConfigContent()
      .subscribe( result2 => {
         this.configurationSettings = this.editor.get();
         //this.PublisherToExecute = this.configurationSettings['Publisher']['PublisherToExecute'];
      });
    }
  }
  
  getData(event) {
    this.configurationSettings = this.editor.get();
    this.PublisherToExecute = this.configurationSettings['Publisher']['PublisherToExecute'];
    this.operationsService.publisherConfigContent = this.configurationSettings;
    this.editor.expandAll();
  }

  updatePublisherConfig() {

  }

  publishData() {
    this.configurationSettings = this.editor.get();
    this.PublisherToExecute = this.configurationSettings['Publisher']['PublisherToExecute'];
  
    this.configurationSettings["AWSCredentials"] = this.operationsService._publishersCredentialsObj;
    let currentConfigData = JSON.stringify(this.configurationSettings);//this.editor.get());
    
    let dynamicTaskName = this.PublisherToExecute + " Publisher";
    this.operationsService.startKDSPublishing(currentConfigData, dynamicTaskName);
  }
 

   stopTask(task: UIExecutingTask, event?: Event){
      if (event) {
        event.stopPropagation();
      } 
      this.operationsService.stopTask(task.ExecutingTaskStatus.executerId);
  }

  cleanHistory() {
    this.operationsService.publisherTasks = [];
  }

      
  getLog(executerId: string) {
   
    if (event) {
        event.stopPropagation();
    } 

    let reportName = "Publishers/" + executerId + "-" + "fd19-publisherlog.log";
    //let reportName = "Publishers/fd19-publisherlog.log";
    
    this.operationsService.getProgramPresignedUrlForReport(reportName)
        .subscribe(result => {
          let reportUrl = result['URL_STRING'];
          // location.go(reportUrl);
          window.open(reportUrl, "_blank");
        });
  }
  
}
