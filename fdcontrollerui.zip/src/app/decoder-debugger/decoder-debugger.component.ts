import { Component, OnInit } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { DecoderRow } from "../models/DecoderRow";
import { OperationsService } from "../services/operations.service";

@Component({
  selector: 'app-decoder-debugger',
  templateUrl: './decoder-debugger.component.html',
  styleUrls: ['./decoder-debugger.component.css']
})
export class DecoderDebuggerComponent implements OnInit {

  ELEMENT_DATA: DecoderRow[] = [];
 
  constructor(public operationsService: OperationsService) { 
    
   for (let i = 0; i < 38; i++) {
     this.ELEMENT_DATA.push( {CameraId: i.toString(), ScanType: 'NOW', KvsStream: this.operationsService.selectedDeployment.deployment_id + '_stadium_cameras_'+ i.toString(), SaveEncodedFrames: false, StopAtFrameId: '123', StopAfterTotalFrames: '456'});//, Editable: 'yyy'});
    }
  }

  ngOnInit(): void {
  }

  displayedColumns: string[] = ['select','CameraId', 'ScanType', 'KvsStream', 'SaveEncodedFrames', 'StopAtFrameId','StopAfterTotalFrames'];//,'Editable'];
  dataSource = new MatTableDataSource<DecoderRow>(this.ELEMENT_DATA);
  selection = new SelectionModel<DecoderRow>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: DecoderRow): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.CameraId + 1}`;
  }

  runDebuggers() {

  }

  stopDebuggers() {

  }
}
