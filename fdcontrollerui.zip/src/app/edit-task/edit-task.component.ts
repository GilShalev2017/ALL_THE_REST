import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { OperationsService } from "../services/operations.service";
import { ODTask } from "../models/ODTask";
import { SystemVariablesComponent } from '../system-variables/system-variables.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent {

   constructor(public dialogRef: MatDialogRef<EditTaskComponent>,
              @Inject(MAT_DIALOG_DATA) public data: ODTask, 
              public dataService: OperationsService,
              public dialog: MatDialog) { }
  
  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
 
  updateTask(): void {
    this.dataService.updateODTask(this.data)
      .subscribe( result => {
        this.dialogRef.close();
      });
  }
  
  duplicateTask() : void {

    this.dataService.addODTask(this.data)
    .subscribe( result => {
        this.dialogRef.close();
      });
  }

  showSystemVariables() {
    const dialogRef = this.dialog.open(SystemVariablesComponent);
  }
}
