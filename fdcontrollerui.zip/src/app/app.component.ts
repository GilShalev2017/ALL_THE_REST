import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { AuthService } from './auth/auth.service';
import { OperationsService } from "./services/operations.service";

import { TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { AppConfigurationService } from './services/app-configuration.service';
import { PersistanceService } from "./services/persistance.service";
import { CommonModule } from '@angular/common';
import { Deployment } from "./models/Deployment";

import { Router } from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'operation-client-app';
  subscription: Subscription;
  public loggedIn: boolean;
  clientHeight: number;
  
  connectedUserName: string;

  modalRef: BsModalRef;
  _selectedButton: string;
  
  constructor(public operationsService: OperationsService, 
              public auth: AuthService,
              private modalService: BsModalService,
              private appconfig:AppConfigurationService,
              public persistanceService: PersistanceService,
              private router: Router) {

    this.clientHeight = window.innerHeight; 

    this.operationsService.getActiveDeployments()
     .subscribe(result => {
        let res = result;
      });
  }

  ngOnInit() {
  
    this.subscription = this.auth.isAuthenticated()
      .subscribe(result => {
        this.loggedIn = result;
      });

    this.subscription = this.auth.getCurrentAuthenticatedUser()
      .subscribe(result => {
        this.connectedUserName = result.username;
      });

    window.setTimeout(() => {
       this.init();
    }, 2000);
   
     this.auth.loggedIn.subscribe(data => {
      //do what ever needs doing when data changes
      this.loggedIn = data;

     });

    this.operationsService.getActiveDeployments()
     .subscribe(result => {
        let res = result;
      });

    this.operationsService.getPublisherConfigContent()
      .subscribe( result2 => {
        let res2 = result2;
      });

  }

  init() {

    this.selectLinkButton()

    this.operationsService.hubConnectionInit();

    // this.operationsService.getWorkerConnectedDeployments();

    this.operationsService.getActiveDeployments()
     .subscribe(result => {

        const persistantDeployment: Deployment = this.persistanceService.get("SelectedDeployment") as Deployment;

        if(persistantDeployment != null) {
          
           this.operationsService.selectedDeployment = persistantDeployment;
           this.operationsService.selectedDeploymentString = persistantDeployment.deployment_id;
            
           this.operationsService.getOPDockers();
          
           this.operationsService.announceDeploymentSelectionChanged("deploymentChanged");
        }
      });

  }

  onOff() {
   
    // this.operationsService.startConnection();
    this.operationsService.registerUI();
   
    // this.operationsService.connectedToSignalServer = !(this.operationsService.connectedToSignalServer);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  onClickLogout() {
    this.auth.signOut();
    this.connectedUserName = "";
    this.loggedIn = false;
  }

  onSelectDeploymentChange() {

    let selectedDeploymentString =  this.operationsService.selectedDeploymentString;
    let foundSelectedDeployment: Deployment = this.operationsService.activeDeployments.find(function (element) {
      return element.deployment_id == selectedDeploymentString;
    });

    this.operationsService.selectedDeployment = foundSelectedDeployment;

    this.persistanceService.set("SelectedDeployment", foundSelectedDeployment);

    this.operationsService.V4VPod = null;
    
    this.operationsService.getOPDockers();

    this.operationsService.flinkJobs = [];

    this.operationsService.currentConfigFileName = null;
    this.operationsService.currentConfigContent = null;
    this.operationsService.configurations = null;
    this.operationsService.announceDeploymentSelectionChanged("deploymentChanged");

    this.operationsService.S3ConfigurationsBucketUrl = this.getS3StaticBucketUrl();
    this.operationsService.clusters = [];

    this.operationsService.activeTasks = [];
    this.operationsService.publisherTasks = [];

    this.operationsService.getCompletedTasks()
      .subscribe();

    this.operationsService.getPodsStatus();
  }

   openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  getS3StaticBucketUrl() {
    //TODO temporarily until we get the deployment region
    //let region= "us-east-1";
    let url = "https://s3.console.aws.amazon.com/s3/buckets/intel-sports-" + this.operationsService.selectedDeployment?.deployment_region + "-teecontrol-" + this.operationsService.selectedDeployment?.deployment_id;
    return url;
  }

  getAllActiveDeployments() {
    this.operationsService.getActiveDeployments()
    .subscribe(result => {
          let res = result;
        });
  }

  getSelectedDeploymentIdK8SContext() {
    //aws eks update-kubeconfig --name fd19_e02v441rc5vxjjx --region us-east-1 --role arn:aws:iam::753274046439:role/fd19_e02v441rc5vxjjx_eks_user
    return "aws eks update-kubeconfig --name fd19_" + this.operationsService.selectedDeployment?.deployment_id + " --region " + this.operationsService.selectedDeployment?.deployment_region + " --role arn:aws:iam::753274046439:role/fd19_" + this.operationsService.selectedDeployment?.deployment_id + "_eks_user";
  }

  selectLinkButton() {
      console.log("this.router.url = " + this.router.url);

      if(this.router.url.includes("debug-tools")){
        this.selectButton("debug-tools");
      }
      else if(this.router.url.includes("program")){
        this.selectButton("programs");
      }
      else if(this.router.url.includes("task")){
        this.selectButton("tasks");
      }
      else if(this.router.url.includes("flink-flow")){
        this.selectButton("flink-tasks");
      }
      else if(this.router.url.includes("flow-view")){
        this.selectButton("flows");
      }
      else if(this.router.url.includes("configurations")){
        this.selectButton("configurations");
      }
      else if(this.router.url.includes("topology")){
        this.selectButton("topology");
      }
      else if(this.router.url.includes("production-flow")){
        this.selectButton("production-flows");
      }
  }

  selectButton(buttonName: string) {
    this._selectedButton = buttonName;
  }
}
