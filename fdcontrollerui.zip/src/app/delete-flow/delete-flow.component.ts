import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FlowsService } from "../services/flows.service";
import { UIExecutingFlow } from "../models/UIExecutingFlow";

@Component({
  selector: 'app-delete-flow',
  templateUrl: './delete-flow.component.html',
  styleUrls: ['./delete-flow.component.css']
})
export class DeleteFlowComponent {

  constructor(public dialogRef: MatDialogRef<DeleteFlowComponent>,
              @Inject(MAT_DIALOG_DATA) public data: UIExecutingFlow,
              public dataService: FlowsService)
  { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  confirmDelete(): void {
    this.dataService.deleteODFlow(this.data).
     subscribe((res: boolean) => {

    });
  }

}
