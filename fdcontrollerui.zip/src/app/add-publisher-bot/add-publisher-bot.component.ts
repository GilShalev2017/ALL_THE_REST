import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-publisher-bot',
  templateUrl: './add-publisher-bot.component.html',
  styleUrls: ['./add-publisher-bot.component.css']
})
export class AddPublisherBotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
