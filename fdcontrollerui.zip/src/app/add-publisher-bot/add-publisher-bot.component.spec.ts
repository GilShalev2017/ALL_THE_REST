import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPublisherBotComponent } from './add-publisher-bot.component';

describe('AddPublisherBotComponent', () => {
  let component: AddPublisherBotComponent;
  let fixture: ComponentFixture<AddPublisherBotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPublisherBotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPublisherBotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
