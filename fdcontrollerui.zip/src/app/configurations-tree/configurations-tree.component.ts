import { Component, OnInit, Output, EventEmitter, OnChanges } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { OperationsService } from "../services/operations.service";
import { of as observableOf, Subscription } from 'rxjs';
import { AuthService } from './../auth/auth.service';

/** File node data with nested structure. */
export interface FileNode {
  name: string;
  fileType: string;
  children?: FileNode[];
  parent?: string;
}

/** Flat node with expandable and level information */
export interface TreeNode {
  name: string;
  fileType: string;
  level: number;
  expandable: boolean;
  parent?: string;
  isSelected?: boolean;
}

@Component({
  selector: 'app-configurations-tree',
  templateUrl: './configurations-tree.component.html',
  styleUrls: ['./configurations-tree.component.css']
})
export class ConfigurationsTreeComponent implements OnInit {

  @Output() configFileSelected: EventEmitter<string> = new EventEmitter();
  _selectedFile: TreeNode;

  /** The TreeControl controls the expand/collapse state of tree nodes.  */
  treeControl: FlatTreeControl<TreeNode>;

  /** The TreeFlattener is used to generate the flat list of items from hierarchical data. */
  treeFlattener: MatTreeFlattener<FileNode, TreeNode>;

  /** The MatTreeFlatDataSource connects the control and flattener to provide data. */
  dataSource: MatTreeFlatDataSource<FileNode, TreeNode>;

  subscription: Subscription;

  constructor(public operationsService: OperationsService) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
    this.treeControl = new FlatTreeControl<TreeNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    
    this.subscription = operationsService.deploymentSelectionChangedSource$.subscribe(
      data => {
           this.getConfigurationsPerDeployment();
      });

  }


 /** Transform the data to something the tree can read. */
  transformer(node: FileNode, level: number) {
    return {
      name: node.name,
      fileType: node.fileType,
      level: level,
      expandable: !!node.children,
      parent: node.parent
    };
  }

 /** Get the level of the node */
  getLevel(node: TreeNode) {
    return node.level;
  }

  /** Return whether the node is expanded or not. */
  isExpandable(node: TreeNode) {
    return node.expandable;
  };

  /** Get the children for the node. */
  getChildren(node: FileNode) {
    return observableOf(node.children);
  }

  /** Get whether the node has children or not. */
  hasChild(index: number, node: TreeNode){
    return node.expandable;
  }

  getConfigurationsPerDeployment() {
    this.operationsService.getConfigurations()
      
        .subscribe( (results: FileNode[]) => {
        
          let resultsWithParent = this.setFileNodeParent(results);
          this.dataSource.data = resultsWithParent;
          //this.treeControl.expandAll();
        });
  }
  
  ngOnInit() {
    
      if(this.operationsService.isConfigurationsLoaded == false) {

          this.getConfigurationsPerDeployment();
      }
      
      let results: FileNode[] = this.operationsService.configurations;
      let resultsWithParent = this.setFileNodeParent(results);
      this.dataSource.data = resultsWithParent;
  }
 
  selectFile(selectedFile: any) {
    //TODO temporarily this is good only for one level

    if(selectedFile.fileType == "file") {
    
      //unselect previous node
      if(this._selectedFile != null) {
        this._selectedFile.isSelected = false;
      }
      
      this._selectedFile = selectedFile;
      selectedFile.isSelected = true;
    
      let KeyName = "";
      
      if(selectedFile.parent != null) {
        KeyName = selectedFile.parent + "/" + selectedFile.name;
      }
      else {
        KeyName = selectedFile.name;
      }

      this.configFileSelected.emit(KeyName);
    }
  }

  setFileNodeParent(results: FileNode[]): FileNode[]{
 
    results.forEach(element => {
      
      if(element.fileType === 'folder')
      {
        if(element.children != null) {
        
          element.children.forEach(elementChild => {
          
            elementChild.parent = element.name;
          });
        }
      }
    });

    return results;
  }

  public openBucket(event) {
    if (event) {
        event.stopPropagation();
    } 
    this.operationsService.getS3StaticBucket()
       .subscribe( url => {
          let fullUrl = "https://s3.console.aws.amazon.com/s3/buckets/" + url + "/";
          window.open(fullUrl, "_blank");
       });
  }
}
