import { Component, OnInit,Injectable, ViewChild } from '@angular/core';
import {OperationsService} from "../services/operations.service";
import {FlowsService} from "../services/flows.service";
import {ProgramsService} from "../services/programs.service";
import {Subscription} from "rxjs";
import {ODTask} from "../models/ODTask";
import {ODProgram} from "../models/ODProgram";
import {ODFlow} from "../models/ODFlow";
import {UIExecutingFlow} from "../models/UIExecutingFlow";
import {CategoryGroup} from '../models/ODProgram';
import {BehaviorSubject, Observable, of as observableOf} from 'rxjs';
import {MatListModule, MatSelectionList, MatListOption} from '@angular/material/list';
import {SelectionModel} from '@angular/cdk/collections';
import { AuthService } from './../auth/auth.service';
import { FlinkTaskPayload, FlinkTaskType } from "../models/FlinkTaskPayload";

@Component({
  selector: 'app-flow-view',
  templateUrl: './flow-view.component.html',
  styleUrls: ['./flow-view.component.css']
})
export class FlowViewComponent implements OnInit {
  @ViewChild(MatSelectionList, {static: true})
  private selectionList: MatSelectionList;

  displayFlowFlag:boolean = false;
  displayWizardFlag:boolean = false;
  selectedFlow:UIExecutingFlow;
  newFlow:ODFlow;
  
  constructor(public flowsService: FlowsService,
              public programsService: ProgramsService,
              public auth: AuthService,
              public operationsService: OperationsService) { }

  ngOnInit()  {

    if(this.flowsService.isLoaded==false) {
      this.refresh();
    }

    if(this.operationsService.activeDeployments.length == 0) {
      this.operationsService.getActiveDeployments()
        .subscribe(result=>{
            console.log("deployments loaded from API") 
        });
    }
    else {
       console.log("deployments already exist") 
    }

    let selectedFlow:UIExecutingFlow = this.FindSelectedFlow();
    if(selectedFlow != null) {
      this.displayFlow(selectedFlow)
    }
  }

  addNewFlow() {
    this.displayWizardFlag = true;
    this.displayFlowFlag = false;
    this.newFlow={};
  }

  refresh() {
    this.flowsService.getAllFlows()
       .subscribe( res =>{
          this.selectedFlow = null;
          this.displayFlowFlag = false;
        });

    //TODO remove it later
   
   // this.operationsService.getFilteredFlows()
    this.operationsService.getAllFlows()
       .subscribe( res =>{
          
          // this.selectedFlow = this.flowsService.availableFlows[0];
          // this.displayFlow(this.selectedFlow); 
        });
  }

  displayFlow(flow: UIExecutingFlow) {
      this.displayFlowFlag = true;
      this.displayWizardFlag = false;
      this.selectedFlow = flow;

      this.UnselectAll();
      flow.IsSelected=true;

      // if(this.selectedFlow.ODFlow.IsFlinkFlow =="true") {

      //   this.operationsService.ListenToFlinkJobs();
      // }
      // else {
      //   this.operationsService.StopListenToFlinkJobs();
      // }
      
      //If flow is running display its current status
      if( this.operationsService.currentRunningFlow != null) {
        if(this.selectedFlow.ODFlow.Id === this.operationsService.currentRunningFlow.ODFlow.Id)

        this.selectedFlow = this.operationsService.currentRunningFlow;
      }
  }

  FindSelectedFlow():UIExecutingFlow {
   
    let foundFlow = null;    
    
    if(this.flowsService.availableFlows) {

      this.flowsService.availableFlows.forEach(flow => { 
          
          if(flow.IsSelected === true) {
              foundFlow = flow;
          }
      });
    }

    return foundFlow;
  }


  UnselectAll() {
    this.flowsService.availableFlows.forEach(flow => { 
      flow.IsSelected = false;
    });
  }

  onFlowDeleted(flow: UIExecutingFlow) {
    this.refresh();
  }

  onFlowSaved(flow: ODFlow) {
    this.refresh();
  }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.toLowerCase();

    const filteredResult = this.flowsService.availableFlows.filter(flowItem => flowItem.ODFlow.Name.toLowerCase().includes(filterValue));

    this.flowsService.filteredText = (event.target as HTMLInputElement).value;

    this.flowsService.filteredFlows = filteredResult;
  }
}