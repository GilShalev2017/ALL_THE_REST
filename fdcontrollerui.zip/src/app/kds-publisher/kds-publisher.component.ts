import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kds-publisher',
  templateUrl: './kds-publisher.component.html',
  styleUrls: ['./kds-publisher.component.css']
})
export class KdsPublisherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
