import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-s3-comparing-tool',
  templateUrl: './s3-comparing-tool.component.html',
  styleUrls: ['./s3-comparing-tool.component.css']
})
export class S3ComparingToolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
