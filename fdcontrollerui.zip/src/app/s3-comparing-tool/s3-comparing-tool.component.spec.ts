import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { S3ComparingToolComponent } from './s3-comparing-tool.component';

describe('S3ComparingToolComponent', () => {
  let component: S3ComparingToolComponent;
  let fixture: ComponentFixture<S3ComparingToolComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ S3ComparingToolComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(S3ComparingToolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
