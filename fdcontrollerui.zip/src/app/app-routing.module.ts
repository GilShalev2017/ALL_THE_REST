import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { TaskViewComponent } from "./task-view/task-view.component";
import { ProgramViewComponent } from './program-view/program-view.component';
import { TopologyViewComponent } from './topology-view/topology-view.component';
import { FlowViewComponent } from './flow-view/flow-view.component';
import { FlowsViewComponent } from './flows-view/flows-view.component';
import { FlinkFlowComponent } from './flink-flow/flink-flow.component';
import { FlinkRunningJobsComponent } from './flink-running-jobs/flink-running-jobs.component';
import { ConfigurationsComponent } from './configurations/configurations.component';
import { SignupComponent } from './signup/signup.component';
import { AuthGuard } from './auth/auth.guard';
import { LoginFormComponent } from './login-form/login-form.component';
import { PublishersComponent } from './publishers/publishers.component';

import { DebugToolsComponent } from './debug-tools/debug-tools.component';
import { DebugViewComponent } from './debug-view/debug-view.component';
import { DebugKitComponent } from './debug-kit/debug-kit.component';
import { V4vComponent } from './v4v/v4v.component';
import { KdsInspectorComponent } from './kds-inspector/kds-inspector.component';
import { DecoderDebuggerComponent } from './decoder-debugger/decoder-debugger.component';
import { ProductionFlowsComponent } from './production-flows/production-flows.component';
import { Vv4Component } from './vv4/vv4.component';
import { RendererOutputVideoCreatorComponent } from './renderer-output-video-creator/renderer-output-video-creator.component';
import { PrepareDeploymentComponent } from './prepare-deployment/prepare-deployment.component';
import { ClipsFlinkFlowComponent } from './clips-flink-flow/clips-flink-flow.component';

const routes: Routes = [
  { path: '', redirectTo: 'flow-view', pathMatch: 'full'},
  { path: 'configurations', component: ConfigurationsComponent, canActivate: [AuthGuard] },
  { path: 'task-view', component: TaskViewComponent, canActivate: [AuthGuard] },
  { path: 'program-view', component: ProgramViewComponent, canActivate: [AuthGuard] },
  { path: 'topology-view', component: TopologyViewComponent, canActivate: [AuthGuard] },
  { path: 'flows-view', component: FlowsViewComponent, canActivate: [AuthGuard] },
  { path: 'flow-view', component: FlowViewComponent, canActivate: [AuthGuard] },
  { path: 'flink-running-jobs', component: FlinkRunningJobsComponent, canActivate: [AuthGuard] },
  { path: 'flink-flow', component: FlinkFlowComponent, canActivate: [AuthGuard] },
  { path: 'signup', component: SignupComponent },
  { path: 'login-form', component: LoginFormComponent },
  { path: 'debug-kit', component: DebugKitComponent, canActivate: [AuthGuard]},
  { path: 'publishers-view', component: PublishersComponent, canActivate: [AuthGuard]},
  { path: 'production-flows', component: ProductionFlowsComponent, canActivate: [AuthGuard],
  
      children: [
          {
            path: 'prepare-deployment',
            component: PrepareDeploymentComponent, 
          },
          {
            path: 'start-auto-flow',
            component: ClipsFlinkFlowComponent, 
          },
          {
            path: 'start-custom-flow',
            component: ClipsFlinkFlowComponent, 
          },
      ],
  },
  
  { path: 'debug-tools', component: DebugToolsComponent, canActivate: [AuthGuard],
  
      children: [
          {
            path: 'debug-links',
            component: DebugViewComponent, 
          },
          {
            path: 'debug-kit', 
            component: DebugKitComponent, 
          },
          {
            path: 'v4v',
            component: V4vComponent, 
          },
          {
            path: 'kds-inspector',
            component: KdsInspectorComponent, 
          },
          {
            path: 'kds-publisher',
            component: PublishersComponent, 
          },
           {
            path: 'kvs-inspector',
            component: DecoderDebuggerComponent, 
          },
           {
            path: 'mvv',
            component: Vv4Component, 
          }
          ,
           {
            path: 'renderer-video-creator',
            component: RendererOutputVideoCreatorComponent, 
          }
        ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
