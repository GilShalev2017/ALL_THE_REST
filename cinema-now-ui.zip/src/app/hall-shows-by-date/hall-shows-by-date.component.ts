import {Component, OnInit} from '@angular/core';
import {HallDailyShows} from '../models/hallDailyShows';

export interface Tile {
  color: string;
  cols: number;
  rows: number;
  text: string;
}

@Component({
  selector: 'app-hall-shows-by-date',
  templateUrl: './hall-shows-by-date.component.html',
  styleUrls: ['./hall-shows-by-date.component.css']
})
export class HallShowsByDateComponent implements OnInit {

  breakpoint: number;
  dateFilter: string;

  hallDailyShows: HallDailyShows[] = [
    {
      hall: 'Hall-1',
      shows: [{id: 'aaa', movie: {id: 123, title: 'Superman', overview: 'overview123'}, date: '02-02-2020', time: '10:00', hall: 'Hall-1'},
        {id: 'bbb', movie: {id: 456, title: 'Justice League', overview: 'overview456'}, date: '02-02-2020', time: '12:00', hall: 'Hall-1'}]
    },
    {
      hall: 'Hall-2',
      shows: [{id: 'aaa', movie: {id: 123, title: 'Batman', overview: 'overview123'}, date: '02-02-2020', time: '10:00', hall: 'Hall-2'},
              {id: 'bbb', movie: {id: 456, title: 'Wonder Womann', overview: 'overview456'}, date: '02-02-2020', time: '12:00', hall: 'Hall-2'},
              {id: 'bbb', movie: {id: 456, title: 'Bob Sponge', overview: 'overview456'}, date: '02-02-2020', time: '12:00', hall: 'Hall-2'},
             ]
    },
    {
      hall: 'Hall-3',
      shows: [{
        id: 'aaa',
        movie: {id: 123, title: 'James Bond', overview: 'overview123'},
        date: '02-02-2020',
        time: '10:00',
        hall: 'Hall-1'
      },
        {id: 'bbb', movie: {id: 456, title: 'bbb', overview: 'overview456'}, date: '02-02-2020', time: '12:00', hall: 'Hall-1'}]
    },
    {
      hall: 'Hall-4',
      shows: [{
        id: 'aaa',
        movie: {id: 123, title: 'James Bond', overview: 'overview123'},
        date: '02-02-2020',
        time: '10:00',
        hall: 'Hall-1'
      },
        {id: 'bbb', movie: {id: 456, title: 'bbb', overview: 'overview456'}, date: '02-02-2020', time: '12:00', hall: 'Hall-4'}]
    },
    {
      hall: 'Hall-5',
      shows: [{
        id: 'aaa',
        movie: {id: 123, title: 'James Bond', overview: 'overview123'},
        date: '02-02-2020',
        time: '10:00',
        hall: 'Hall-1'
      },
        {id: 'bbb', movie: {id: 456, title: 'bbb', overview: 'overview456'}, date: '02-02-2020', time: '12:00', hall: 'Hall-4'}]
    },
    {
      hall: 'Hall-6',
      shows: [{
        id: 'aaa',
        movie: {id: 123, title: 'James Bond', overview: 'overview123'},
        date: '02-02-2020',
        time: '10:00',
        hall: 'Hall-1'
      },
        {id: 'bbb', movie: {id: 456, title: 'bbb', overview: 'overview456'}, date: '02-02-2020', time: '12:00', hall: 'Hall-4'}]
    }
  ];


  constructor() {
    this.dateFilter = new Date().toISOString().slice(0, 10);
  }

  ngOnInit() {
    this.breakpoint = (window.innerWidth <= 400) ? 1 : 6;
  }

  onResize(event) {
    this.breakpoint = (event.target.innerWidth <= 400) ? 1 : 6;
  }
}
