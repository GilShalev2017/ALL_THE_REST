export class Movie {
  id:number;
  title:string;
  overview:string;
  posterPath?:string;
  backdropPath?:string;
}
