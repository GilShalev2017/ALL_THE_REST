import {Show} from './show';

export class HallDailyShows{
  hall: string;
  shows: Show[];
}
