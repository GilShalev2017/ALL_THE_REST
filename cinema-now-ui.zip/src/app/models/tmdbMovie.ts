export class TmdbMovie {
  id:number;
  title:string;
  overview:string;
  poster_path?:string;
  backdrop_path?:string;
}
