import {Component, OnInit, ViewChild, ElementRef, OnDestroy} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatDialog} from '@angular/material/dialog';
import {switchMap, tap, debounceTime, distinctUntilChanged} from 'rxjs/operators';
import {Subscription, Subject} from 'rxjs';
import {ToastrService} from 'ngx-toastr';
import {Movie} from '../models/movie';
import {MoviesService} from '../services/movies.service';
import {ShowsService} from '../services/shows.service';

@Component({
  selector: 'app-search-movie',
  templateUrl: './search-movie.component.html',
  styleUrls: ['./search-movie.component.css']
})
export class SearchMovieComponent implements OnInit {

  searchQuery$ = new Subject<string>();
  private searchSubscription: Subscription;
  busy = false;
  totalMovies = 0;
  pageIndex = 0;

  displayedColumns: string[] = ['Title', 'Overview', 'ReleaseDate', 'Popularity', 'Poster', 'actions'];
  dataSource: Movie[] = [];
  filteredData: Movie[] = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(public moviesService: MoviesService,
              private showsService: ShowsService,
              public dialog: MatDialog,
              private toastr: ToastrService) {
  }

  ngOnInit(): void {

    this.searchSubscription = this.searchQuery$.pipe(
      debounceTime(700),
      distinctUntilChanged(),
      tap(() => this.busy = true),
      switchMap((text: string) => this.moviesService.searchMovies(text, this.pageIndex + 1)),
      tap(() => this.busy = false)
    )
      .subscribe((movies: any) => {
        this.dataSource = movies.results;
        this.filteredData = movies.results;
        this.totalMovies = movies.total_results;
        this.pageIndex = movies.page - 1;
      });

    this.showCurrentPlayingMovies();
  }

  showCurrentPlayingMovies() {
    this.moviesService.getCurrentPlayingMovies()
      .subscribe((movies: any) => {
        this.dataSource = movies.results;
        this.filteredData = movies.results;
      });
  }

  ngOnDestroy() {
    this.searchSubscription?.unsubscribe();
    this.searchSubscription = undefined;
  }

  searchMovies(query: string) {
    this.searchQuery$.next(query);
  }

  getSavedMovies() {
    this.moviesService.getSavedMovies()
      .subscribe((arrivedData: Movie[]) => {
        let i = 5;
      });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    // this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  saveMovie(movie: Movie) {
    this.moviesService.saveMovie(movie).subscribe();
  }

}
