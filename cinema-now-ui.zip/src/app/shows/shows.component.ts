import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {ShowsService} from '../services/shows.service';
import {Show} from '../models/show';
import {DeleteShowComponent} from '../delete-show/delete-show.component';
import {MatDialog} from '@angular/material/dialog';
import {EditShowComponent} from '../edit-show/edit-show.component';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';
import {MatPaginator} from '@angular/material/paginator';

@Component({
  selector: 'app-shows',
  templateUrl: './shows.component.html',
  styleUrls: ['./shows.component.css']
})
export class ShowsComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['date', 'time', 'movieTitle', 'hall', 'actions'];
  dataSource: MatTableDataSource<Show>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(public showsService: ShowsService, public dialog: MatDialog) {
  }

  ngOnInit(): void {
    this.loadShows();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  ngAfterViewInit() {

    if(this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  loadShows() {
    this.showsService.getShows()
      .subscribe( () => {
        this.dataSource = new MatTableDataSource(this.showsService.currentShows);
        this.ngAfterViewInit();
      });
  }

  editShow(show: Show) {
    const dialogRef = this.dialog.open(EditShowComponent, {data: show});

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.loadShows();
      }
    });
  }

  deleteShow(row: Show) {

    const dialogRef = this.dialog.open(DeleteShowComponent, {
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.loadShows();
      }
    });
  }
}
