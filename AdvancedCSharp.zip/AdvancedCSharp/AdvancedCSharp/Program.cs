﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AdvancedCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            FuncB();

            Console.WriteLine("Continue immedaitely!!!!");

            var tokenSource = new CancellationTokenSource();
            CancellationToken ct = tokenSource.Token;

            var task = Task.Run(() =>
            {
                // Were we already canceled?
                //ct.ThrowIfCancellationRequested();

                bool moreToDo = true;
                while (moreToDo)
                {
                    // Poll on this property if you have to do
                    // other cleanup before throwing.
                    //if (ct.IsCancellationRequested)
                    //{
                    //    // Clean up here, then...
                    //    ct.ThrowIfCancellationRequested();
                    //}
                    Console.WriteLine("Still here");
                }
            }, tokenSource.Token); // Pass same token to Task.Run.

            tokenSource.Cancel();

            Console.ReadLine();
        }

        public static Task<int> FuncA(int [] arr)
        {
            int sum = 0;

            foreach(int number in arr)
            {
                sum += number;
            }

            Task.Delay(2000);

            return Task.FromResult(sum);
        }

        public static async void FuncB()
        {
            int[] arr = new int[] { 99, 98, 92, 97, 95 };

            var res = await FuncA(arr);

            await Task.Delay(1000);

            Console.WriteLine(res);

        }
    }
}
