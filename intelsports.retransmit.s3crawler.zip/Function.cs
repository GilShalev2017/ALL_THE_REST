using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.Lambda.APIGatewayEvents;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json.Linq;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace NewS3Crawler
{
    public class NewS3CrawlerFunction
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public APIGatewayProxyResponse NewS3CrawlerFunctionHandler(APIGatewayProxyRequest request, ILambdaContext context)
        {
            context.Logger.Log("Lambda execution has started");            

            RetreiveGameAndDeployemntAndCameraIds(request, out string gameId, out string cameraId, out string deploymentId);
            context.Logger.Log("Received  Request for GameId: " + gameId + ", CameraId: " + cameraId + ", deploymentId: " + deploymentId);

            var bucket = Environment.GetEnvironmentVariable("decoder_backup_bucket");

            string frameRangesString = GetFrameRanges(gameId, cameraId, bucket, deploymentId, context);
            if(string.IsNullOrEmpty(frameRangesString))
            {
                frameRangesString = "{\"frames\": []}";
            }

            var response = new APIGatewayProxyResponse
            {
                StatusCode = 200,// HttpStatusCode.OK,
                Body = frameRangesString,//dbgString
                Headers = new Dictionary<string, string> { { "Content-Type", "application/json" }, { "Access-Control-Allow-Origin", "*" } }
            };
            context.Logger.Log("Response: " + response.Body);
            context.Logger.Log("Lambda execution has completed");
            return response;
        }


        private void RetreiveGameAndDeployemntAndCameraIds(APIGatewayProxyRequest request, out string gameId, out string cameraId, out string deploymentId)
        {
            gameId = cameraId = deploymentId = string.Empty;

            if (request.PathParameters != null && request.PathParameters.Any())
            {
                gameId = request.PathParameters["game_id"];
                cameraId = request.PathParameters["camera_id"];
                deploymentId = request.PathParameters["deployment_id"];
                
            }
        }

        private string GetFrameRanges(string gameId, string cameraId, string bucket, string deploymentId, ILambdaContext context)
        {
            try
            {
                //  Bucket: "isg-teecontrol-data-management-svc-dev"
                //  prefix: "smallinfrafhbjg/small_infra/venue_cameras/camera-0/H264/frame"
                //  NumberOfFramesToConsider: 30*60*60*4 = 432000
                //  StratFromFrameId 

                int maxFramesToRetreive = 432000;
                int? stratFromFrameId = null;

                Task<string> task = null;

                string prefix = string.Format("{0}/{1}/venue_cameras/camera-{2}/H264/frame", deploymentId, gameId, cameraId);

                RetransmitOperations retransmitOperations = new RetransmitOperations();

                task = retransmitOperations.GetRanges(bucket, prefix, maxFramesToRetreive, stratFromFrameId);

                task.Wait();

                return task.Result;
            }
            catch (Exception exc)
            {
                context.Logger.LogLine("An exception occurred at GetFrameRanges" + exc);

                Console.WriteLine(exc.Message);

                if (exc.InnerException != null)
                    Console.WriteLine(exc.InnerException.Message);

            }

            return "";
        }
    }
}


