'use strict';

var fs = require('fs');
let request = require('request');
const { exec } = require("child_process");


if (process.argv[2] === '-h' || process.argv[2] === '--help') {
    let scriptName = process.argv[1].split('/');
    scriptName = scriptName[scriptName.length-1];
    console.log(`Usage: node ${scriptName} [email] [password] [deviceId] [certsPath] [url]`);
    console.log('The Vision Platform enrollment and provisioning tool is used to ' +
                'register and provision a device with the Vision Platform system\n' +
                '* This tool is used to register a device to Vision Platform account managed by AWS Backend.\n' +
                '* Default test parameters will be used if none are given.')
    return;
}

// Local BE credentials
// const url = 'http://localhost:3070';

const email = process.argv[2] ?  process.argv[2] : 'roymichau@gmail.com';
// Options
const password = process.argv[3] ? process.argv[3] : 'A123456789';
// Device unique identifier and certificates
var registrationId = process.argv[4] ? process.argv[4] : 'roy-test-11';

const certsPath = process.argv[5] ? process.argv[5] : process.cwd() + '/certs';

const url = process.argv[6] ? process.argv[6] :  'http://a3e25ae371754479eae8255868ce0b05-7d5adcec3f2cd793.elb.us-east-1.amazonaws.com/'
// const url = 'http://localhost:3070';



async function login(email, password) {
    console.log('===> Logging in...');
    let requestUrl = url + '/users/login';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'POST',
            body: {
                email: email,
                password: password
            },
            json: true,
            url: requestUrl
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    console.log(error);
                    reject('===> Login failed:', error);
                }
                resolve(body);
            })
    });
}

async function enrollDevice(deviceId, token) {
    console.log(`===> Enrolling device ${deviceId}...`);
    const certificate = fs.readFileSync(`${certsPath}/device.crt`).toString()
    let requestUrl = url + '/devices/enroll';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'POST',
            body: {
                deviceId: deviceId,
                certificate: certificate,
            },
            json: true,
            url: requestUrl,
            headers: {
                'Authorization':'Bearer ' + token
            }
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    // reject('===> Enroll device failed: ', error);
                    resolve('===> Enroll failed', error)
                }
                resolve(body);
            })
    });
}

function saveCerts(certRes) {
    const certPem = certRes.certificatePem;
    const certKey = certRes.keyPair.PrivateKey;

    fs.writeFile(`${certsPath}/device.crt`, certPem, function (err) {
        if (err) return console.log(err);
        console.log(`certPem > ${certsPath}/device.crt`);
    });

    fs.writeFile(`${certsPath}/device.key`, certKey, function (err) {
        if (err) return console.log(err);
        console.log(`certPem > ${certsPath}/device.key`);
    });
}

function provisionDevice(deviceId, endpoints) {
    console.log(`===> Provisioning device ${deviceId}...`);

    exec(`./device_provision_no_ca.sh ${deviceId} ${certsPath}/device.crt ${certsPath}/device.key ${certsPath}/AmazonRootCA1.pem \
     ${endpoints.dataEndpoint} ${endpoints.credEndpoint}`, (error, stdout, stderr) => {
        if (error) {
            console.log(`error: ${error.message}`);
        }
        if (stderr) {
            console.log(`stderr: ${stderr}`);
        }
        console.log(`Provisioning output: ${stdout}`);
        console.log(`===> Device ${deviceId} provisioning finished`)
    });
}


async function start() {
    console.log('===> Vision Platform Device Enrollment and Provisioning');
    try {
        const token = (await login(email, password)).token.accessToken;
        console.log(token);
        const enrollment = await enrollDevice(registrationId, token);
        console.log(enrollment);
        saveCerts(enrollment.certRes);
        provisionDevice(registrationId, enrollment);
    } catch (e) {
        console.log(e);
    }
}

start();

