#!/bin/bash

display_usage() {

	echo -e "\nUsage: $0 <thing_name> <certificate_path> <key_path> <rootca_path> <data_endpoint> <credentials_endpoint> \n"
        echo "Vision Platform AWS IoT Installer configures and installs the AWS IoT core according to given inputs"
	}

# if less than two arguments supplied, display usage
	if [  $# -le 5 ]
	then
		display_usage
		exit 1
	fi

# check whether user had supplied -h or --help . If yes display usage
	if [[ ( $# == "--help") ||  $# == "-h" ]]
	then
		display_usage
		exit 0
	fi

export NAME=$1
export CERT=$2
export KEY=$3
export ROOTCA=$4
export DATA_ENDPOINT=$5
export CRED_ENDPOINT=$6

export CORE_CONFIG="$PWD/GreengrassCore/config.yaml"

# Clean Environment


systemctl stop greengrass.service && sudo systemctl disable greengrass.service
rm /etc/systemd/system/greengrass.service
systemctl daemon-reload && systemctl reset-failed
rm -rf ./GreengrassCore/
rm -rf /greengrass/v2/

echo ""
echo "==> Downloading and unzipping core software"
# Download and unzip core software
curl -s https://d2s8p88vqu9w66.cloudfront.net/releases/greengrass-nucleus-latest.zip > greengrass-nucleus-latest.zip
unzip greengrass-nucleus-latest.zip -d GreengrassCore && rm greengrass-nucleus-latest.zip

echo "==> Writing configuration"
echo "---" > $CORE_CONFIG
echo "system:" >> $CORE_CONFIG
echo "  certificateFilePath: \"$CERT\"" >> $CORE_CONFIG
echo "  privateKeyPath: \"$KEY\"" >> $CORE_CONFIG
echo "  rootCaPath: \"$ROOTCA\"" >> $CORE_CONFIG
echo "  rootpath: \"/greengrass/v2\"" >> $CORE_CONFIG
echo "  thingName: \"$NAME\"" >> $CORE_CONFIG
echo "services:" >> $CORE_CONFIG
echo "  aws.greengrass.Nucleus:" >> $CORE_CONFIG
echo "    componentType: \"NUCLEUS\"" >> $CORE_CONFIG
echo "    version: \"2.1.0\"" >> $CORE_CONFIG
echo "    configuration:" >> $CORE_CONFIG
echo "      awsRegion: \"us-east-1\"" >> $CORE_CONFIG
echo "      iotRoleAlias: \"GreengrassCoreTokenExchangeRoleAlias\"" >> $CORE_CONFIG
echo "      iotDataEndpoint: \"$DATA_ENDPOINT\"" >> $CORE_CONFIG
echo "      iotCredEndpoint: \"$CRED_ENDPOINT\"" >> $CORE_CONFIG

echo "==> Configuration written to $CORE_CONFIG"

# Start provisioning process
echo "==> Strating installation and provisioning process..."
sudo -E java -Droot="/greengrass/v2" -Dlog.store=FILE   -jar ./GreengrassCore/lib/Greengrass.jar  \
 --init-config $CORE_CONFIG  --component-default-user ggc_user:ggc_group   --setup-system-service true

sudo usermod -aG docker ggc_user

