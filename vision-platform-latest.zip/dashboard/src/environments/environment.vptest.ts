export const environment = {
  version: '0.0.1',
  production: true,
  serverUrl: 'http://a07d75045c53d41bf87c6ac12ff94b3e-44d6cf4b428d89e8.elb.us-east-1.amazonaws.com/'
};
