export const environment = {
  version: '0.0.1',
  production: true,
  serverUrl: 'http://ac5cd08d986c543c98c371191b6cf86e-533c8fa361c58ff5.elb.us-east-2.amazonaws.com/'
};
