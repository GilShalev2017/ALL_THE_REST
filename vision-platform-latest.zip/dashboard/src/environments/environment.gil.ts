export const environment = {
  version: '0.0.1',
  production: true,
  serverUrl: 'http://a4382b6007d9c4112b0ae8d71168b2f1-065c0b13b90446d2.elb.us-east-1.amazonaws.com/'
};
