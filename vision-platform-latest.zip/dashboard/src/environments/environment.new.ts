export const environment = {
  version: '0.0.<<version>>',
  production: true,
  serverUrl: 'http://a3e25ae371754479eae8255868ce0b05-7d5adcec3f2cd793.elb.us-east-1.amazonaws.com/'
};
