import {Component, Inject, OnChanges, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {LoadingProgress} from '../../models/interfaces';

@Component({
  selector: 'app-charts',
  templateUrl: './chartsDialog.component.html',
  styleUrls: ['./chartsDialog.component.css']
})
export class ChartsDialogComponent implements OnInit, OnChanges {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;
  error: string;
  okString = 'Save';
  cancelString = 'Cancel';
  canvasWidth: number;


  constructor(
    public dialogRef: MatDialogRef<ChartsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.canvasWidth = screen.width > 1600 ? 700 : 400;

    if (data.okString) {
      this.okString = data.okString;
    }
    if (data.cancelString) {
      this.cancelString = data.cancelString;
    }

  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
  }

  ngOnInit(): void {
  }


  ok() {
    this.error = null;
    this.state = LoadingProgress.LOADING;
    const $action = this.data.doAction();
    if (!$action) {
      this.dialogRef.close('success');
      return;
    }

    if (this.data.dontWaitForAsyncResults) {
      this.dialogRef.close();
    }

    $action.subscribe(response => {
      if (response?.error) {
        this.state = LoadingProgress.ERROR;
        this.error = response.error;
      } else {
        this.state = LoadingProgress.DONE;
        this.dialogRef.close('success');
      }
    }, e => {
      this.state = LoadingProgress.ERROR;
      this.error = e.message;
    });
  }


  cancel() {
    this.dialogRef.close();
  }


}
