import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MaterialModule} from './material/angular-material.module';
import {NavbarComponent} from './framework/navbar/navbar.component';
import {LayoutModule} from '@angular/cdk/layout';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import {AppRoutingModule} from './app-routing.module';
import {AuthenticationModule} from './framework/authentication/authentication.module';
import {FullScreenComponent} from './framework/layouts/full-screen.component';
import {SidebarComponent} from './framework/layouts/sidebar.component';
import {HttpClientModule} from '@angular/common/http';
import {ConfirmComponent} from './dialogs/confirm/confirm.component';
import {UsersComponent} from './demo/users/users.component';
import {FormsModule} from '@angular/forms';
import {SelectorCreatorComponent} from './framework/utils/selector-creator/selector-creator.component';
import {InchesPipe, PoundsPipe} from './pipes/inches.pipe';
import {EntityTableComponent} from './demo/entity-table/entity-table.component';
import {SingleEntityComponent} from './demo/entity-table/single-entity/single-entity.component';
import {MonacoEditorModule, NgxMonacoEditorConfig} from 'ngx-monaco-editor';
import {FileEditorComponent} from './demo/editor/file-editor.component';
import {NgTerminalModule} from 'ng-terminal';
import {FileTreeComponent} from './demo/editor/file-tree/file-tree.component';
import {FileTabsComponent} from './demo/editor/file-tabs/file-tabs.component';
import {DevicesComponent} from './demo/devices/devices.component';
import {MatRippleModule} from '@angular/material/core';
import {DeviceModulesComponent} from './demo/devices/device-modules/device-modules.component';
import {DeployDialogComponent} from './demo/devices/deploy-dialog/deploy-dialog.component';
import {SelectCloudProviderComponent} from './demo/select-cloud-provider/select-cloud-provider.component';
import {SocketIoModule} from 'ngx-socket-io';
import {StreamEventsComponent} from './demo/stream-events/stream-events.component';
import {DeviceComponent} from './demo/device/device.component';
import {DeviceLogsComponent} from './demo/device-logs/device-logs.component';
import {AccountComponent} from './demo/account/account.component';
import {ChartsModule} from 'ng2-charts';
import {DeviceStreamComponent} from './demo/device-stream/device-stream.component';
import {MockdevicesComponent} from './demo/mockdevices/mockdevices.component';
import {GroupsComponent} from './demo/groups/groups.component';
import {GroupComponent} from './demo/group/group.component';
import {WidgetComponent} from './framework/widget/widget.component';
import {ProfileWidgetComponent} from './framework/navbar/profile-widget/profile-widget.component';
import {PageTitleComponent} from './framework/navbar/page-title/page-title.component';
import {CustomSnackBarComponent} from './custom-snack-bar/custom-snack-bar.component';
import {FeaturesComponent} from './demo/features/features.component';
import {AddEditComponentComponent} from './demo/features/add-edit-component/add-edit-component.component';
import {NgJsonEditorModule} from 'ang-jsoneditor';
import {ChartsDialogComponent} from './dialogs/charts/chartsDialog.component';
import {ChartComponent} from './demo/chart/chart.component';
import {MatSortModule} from '@angular/material/sort';
import { CodeEditorComponent } from './demo/code-editor/code-editor.component';

const monacoConfig: NgxMonacoEditorConfig = {
  onMonacoLoad: () => {
    console.log((window as any).monaco);
    window.monaco.editor.defineTheme('myTheme', {
      base: 'vs',
      inherit: true,
      rules: [
        {
          background: 'FFFFFF',
          token: ''
        },
        {
          foreground: '919191',
          token: 'comment'
        },
        {
          foreground: '00a33f',
          token: 'string'
        },
        {
          foreground: 'a535ae',
          token: 'constant.language'
        },
        {
          foreground: 'ff5600',
          token: 'keyword'
        },
        {
          foreground: 'ff5600',
          token: 'storage'
        },
        {
          foreground: '21439c',
          token: 'entity.name.type'
        },
        {
          foreground: '21439c',
          token: 'entity.name.function'
        },
        {
          foreground: 'a535ae',
          token: 'support.function'
        },
        {
          foreground: 'a535ae',
          token: 'support.constant'
        },
        {
          foreground: 'a535ae',
          token: 'support.type'
        },
        {
          foreground: 'a535ae',
          token: 'support.class'
        },
        {
          foreground: 'a535ae',
          token: 'support.variable'
        },
        {
          foreground: 'ffffff',
          background: '990000',
          token: 'invalid'
        },
        {
          foreground: '990000',
          token: 'constant.other.placeholder.py'
        }
      ],
      colors: {
        'editor.foreground': '#000000',
        'editor.background': '#FFFFFF',
        'editor.selectionBackground': '#BAD6FD',
        'editor.lineHighlightBackground': '#00000012',
        'editorCursor.foreground': '#000000',
        'editorWhitespace.foreground': '#BFBFBF',
        'editorLineNumber.foreground': '#C9CACE',
        'editorLineNumber.activeForeground': '#585A62',
      }
    });
    window.monaco.editor.setTheme('myTheme');
  }
};


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FullScreenComponent,
    SidebarComponent,
    ConfirmComponent,
    UsersComponent,
    SelectorCreatorComponent,
    InchesPipe,
    PoundsPipe,
    EntityTableComponent,
    SingleEntityComponent,
    FileEditorComponent,
    FileTreeComponent,
    FileTabsComponent,
    DevicesComponent,
    DeviceModulesComponent,
    DeployDialogComponent,
    SelectCloudProviderComponent,
    StreamEventsComponent,
    DeviceComponent,
    DeviceLogsComponent,
    AccountComponent,
    DeviceStreamComponent,
    MockdevicesComponent,
    GroupsComponent,
    GroupComponent,
    WidgetComponent,
    ProfileWidgetComponent,
    PageTitleComponent,
    CustomSnackBarComponent,
    FeaturesComponent,
    AddEditComponentComponent,
    ChartsDialogComponent,
    ChartComponent,
    CodeEditorComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MaterialModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    AppRoutingModule,
    AuthenticationModule,
    FormsModule,
    MonacoEditorModule.forRoot(monacoConfig),
    NgTerminalModule,
    MatRippleModule,
    SocketIoModule.forRoot({url: 'http://mes-moshe-ubuntu.jer.intel.com', options: {path: '/socket'}}),
    ChartsModule,
    MatSortModule,
    ChartsModule,
    NgJsonEditorModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule {
}
