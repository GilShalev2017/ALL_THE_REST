import {Observable} from 'rxjs';
import {FormGroup} from '@angular/forms';
import {Device} from 'azure-iothub/dist/device';
import {Input} from '@angular/core';
import {Feature} from '../demo/features/features.service';

export enum LoadingProgress {
  INITIAL,
  LOADING,
  ERROR,
  DONE
}

export enum AuthLevel {
  USER = 'USER',
  ADMIN = 'ADMIN',
  SUPER = 'SUPER'
}

export enum USER_ACTIONS {
  USER_EDIT = 'USER_EDIT',
  USER_ADD = 'USER_ADD'
}

export enum Auth {
  LOGIN = 'LOGIN',
  REGISTER = 'REGISTER',
  PASSWORD_RESET = 'PASSWORD_RESET',
  PASSWORD_UPDATE = 'PASSWORD_UPDATE',
  ADMIN_CONFIRMATION = 'ADMIN_CONFIRMATION',
}

export interface Entity {
  id: string;
}

export interface CustomAction {
  name: string;
  icon: string;
  tooltip: string;
  action: (...args) => void;
}

export abstract class EntityService {
  displayName: string;
  fields: { [key: string]: EntityFieldMetadata; };
  actions?: Set<string>;
  customActions?: CustomAction[];
  deleteByField?: string;

  abstract delete(id: string): Observable<void>;

  abstract get(page: number, pageSize: number, refresh?: boolean): Observable<Entity[]>;

  abstract getCount(): Observable<number>;

  abstract getSingleForm(entity?: Entity): FormGroup;

  abstract save(id: string, entity: Entity): Observable<Entity>;

  abstract click?(entity: Entity): void;
}

export interface EntityFieldMetadata {
  displayName: string;
  type?: 'text' | 'boolean';
  isPicture?: boolean;
  isHidden?: boolean;
  enumValues?: object;
  isEnum?: boolean;
}


export interface FileNode {
  name: string;
  children?: FileNode[];
}

export interface UserCloudProvider {
  intelManaged: boolean;
  connectionString?: string;
  clientId?: string;
  secret?: string;
  tenantId?: string;
  subscriptionId?: string;
  eventsHubConnectionString?: string;
  iotDomainName?: string;
  provider?: 'AZURE' | 'AWS';
  dpsServiceOperationsHostName?: string;
}

export interface DeviceRequest {
  deviceId: string;
  authType?: string;
  autoGenKeys?: boolean;
  primaryKey?: string;
  secondaryKey?: string;
  edgeEnabled?: boolean;
  hubEnabled?: boolean;
}

export interface DeviceDescription {
  deviceId: string;
  capabilities?: Device.Capabilities;

  [x: string]: any;
}

export const awsStatusSymbols = {
  RUNNING: {style: 'color:gray', icon: 'pending', class: 'material-icons-outlined'},
  NEW: {icon: 'pending'},
  INSTALLED: {style: 'color:green', icon: 'pending', class: 'material-icons-outlined'},
  STARTING: {style: 'color:green', icon: 'pending', class: 'material-icons-outlined'},
  STOPPING: {style: 'color:red', icon: 'schedule'},
  ERRORED: {style: 'color:red', icon: 'highlight_off'},
  BROKEN: {style: 'color:red', icon: 'highlight_off'},
  FINISHED: {style: 'color:green', icon: 'check_circle_outline'},
  ACTIVE: {style: 'color:green', icon: 'pending', class: 'material-icons-outlined'},
  COMPLETED: {style: 'color:green', icon: 'check_circle_outline'},
  CANCELED: {style: 'color:red', icon: 'highlight_off'},
  FAILED: {style: 'color:red', icon: 'highlight_off'},
  INACTIVE: {style: 'color:red', icon: 'highlight_off'},
  IN_PROGRESS: {
    style: 'color:green',
    icon: 'pending',
    class: 'icon_animation material-icons-outlined',
    text: 'In Progress'
  },
};

export enum DeploymentType {
  DELETION = 'DELETION',
  DEPLOYMENT = 'DEPLOYMENT'
}

export interface Widget {
  label: string;
  icon: string;
  value: string;
  action?: () => void;
  labelClass?: string;
  dataClass?: string;
}

export interface GetFeaturesResponse {
  features: Feature[];
  count: number;
}

export interface AssetUrlResponse {
  assetUrl: string;
}

export const chartColors = ['#EFADF9', '#F9ADC2', '#F9D9AD', '#D8F9AD', '#FFB700', '#00FFB7', '#0048FF', '#ADEDF9', '#AEADF9', '#FF0048'];


export const chartPallets = [
    ['#EFADF9', '#F9ADC2', '#F9D9AD', '#D8F9AD', '#FFB700', '#00FFB7', '#0048FF', '#ADEDF9', '#AEADF9', '#FF0048'],
    ['#ff6384', '#ff6384', '#ff9f40', '#ffcd56', '#4bc0c0', '#36a2eb', '#9966ff', '#c9cbcf'],
    ['#f2e9d0', '#eaceb4', '#e79e85', '#bb5a5a', '#fffe9f', '#ffd480', '#fca180', '#f56262', '#ff5959', '#ffad5a'],
    ['#4f9da6', '#1a841', '#2d4059', '#ffb40', '#f6f6f6', '#ea5455', '#e2431', '#fc3a52', '#f9b248', '#e8d5b7', '#ea5959'],
    ['#f98b60', '#ffc057', '#ffe084', '#581845', '#90c3f', '#c7039', '#ff5733'],
    ['#FE4A49', '#2AB7CA', '#fed766', '#3131b8', '#f4f4f8', '#f98b60', '#ffc057', '#ffe084'],
    ['#a1d9ff', '#ca82f8', '#ed93cb', '#f2bbbb', '#e4fffe', '#a4f6f9', '#ff99fe', '#ba52ed', '#ffffc1', '#ffd2a5'],
    ['#364f6b', '#3fc1c9', '#f5f5f5', '#fc5185', '#48466d', '#3d84a8', '#46cdcf', '#abedd8', '#6fe7dd', '#3490de', '#6639a6'],
    ['#521262', '#15b7b9', '#10ddc2', '#f5f5f5', '#f57170', '#cefff1', '#ace7ef', '#a6acec', '#a56cc1', '#ebfffa', '#c6fce5'],
    ['#6ef3d6', '#dceda', '#71a52', '#86972', '#17b978', '#a7ff83', '#011f4b', '#03396c', '#005b96', '#6497b1', '#b3cde0'],
    ['#e4fffe', '#a4f6f9', '#ff99fe', '#ba52ed', '#ffffc1', '#ffd2a5', '#ffa8b8', '#d988bc', '#3965a', '#6a572', '#9af98', '#ea599'],
    ['#ffe6eb', '#ffcdcd', '#6a65d8', '#1d2786', '#56764', '#913175', '#dd5b82', '#fe9797', '#ff9898', '#cf455c', '#971549', '#47031', '#ffabe5', '#c7f5ff', '#d89fff', '#f6fcae'],
    ['#c7f3ff', '#fdc7ff', '#ffdcf5', '#f2f4c3', '#ffa5a5', '#ffffc2', '#c8e7ed', '#bfcfff', '#c7f5fe'],
    ['#fcc8f8', '#eab4f8', '#f3f798', '#9ddcdc', '#fff4e1', '#ffebb7', '#e67a7a', '#f47c7c', '#f7f48b'],
    ['#a1de93', '#70a1d7', '#f06868', '#fab57a', '#edf798', '#80d6ff', '#ffdede', '#f7f3ce', '#c5ecbe', '#4797b1'],
    ['#66bfbf', '#eaf6f6', '#fcfefe', '#f76b8a', '#f2f2f2', '#ebd5d5', '#ea8a8a', '#685454', '#fafafa', '#ffe9e3', '#c4c1e0', '#7c73e6'],
    ['#881a3', '#fffdfb', '#fde9df', '#ffd6a4', '#fffafa', '#ffe0e0', '#ffc0d0', '#efdfbf', '#fbf7f7', '#f1e9e3', '#ee712b', '#dc4712'],
    ['#fff6f6', '#ffe5ab', '#a1c45a', '#ffcdb5', '#ff6464', '#ffbd67', '#f8fe85', '#5be7a9'],
    ['#9bb899', '#fcceaa', '#f5827d', '#ea4961', '#28544b', '#acbd86', '#ffd6a0', '#ffa06f', '#a9eca2', '#f5ffcb', '#ffe3b0', '#f5c8bd'],
    ['#fffcef', '#d2ebcd', '#ff7f5b', '#393939', '#f2d1a8', '#ebebeb', '#669b7c', '#557669', '#f8b40', '#faf5e4', '#2c786c', '#04445'],
    ['#ff6464', '#ffbd67', '#f8fe85', '#5be7a9'],
    ['#ffffff', '#d0e1f9', '#4d648d', '#283655', '#1e1f26'],
    ['#eeeeee', '#dddddd', '#cccccc', '#bbbbbb', '#aaaaaa'],
    ['#ffe9dc', '#fce9db', '#e0a899', '#dfa290', '#c99789'],
    ['#96ceb4', '#ffeead', '#ff6f69', '#ffcc5c', '#88d8b0'],
    ['#6e7f80', '#536872', '#708090', '#536878', '#36454f'],
    ['#4b3832', '#854442', '#fff4e6', '#3c2f2f', '#be9b7b'],
    ['#3b5998', '#8b9dc3', '#dfe3ee', '#f7f7f7', '#ffffff'],
    ['#008744', '#0057e7', '#d62d20', '#ffa700', '#ffffff'],
    ['#3385c6', '#4279a3', '#476c8a', '#49657b', '#7f8e9e'],
    ['#d2d4dc', '#afafaf', '#f8f8fa', '#e5e6eb', '#c0c2ce'],
    ['#a8e6cf', '#dcedc1', '#ffd3b6', '#ffaaa5', '#ff8b94'],
    ['#d11141', '#00b159', '#00aedb', '#f37735', '#ffc425'],
    ['#6f7c85', '#75838d', '#7e8d98', '#8595a1', '#8c9da9'],
    ['#ebf4f6', '#bdeaee', '#76b4bd', '#58668b', '#5e5656'],
    ['#ff77aa', '#ff99cc', '#ffbbee', '#ff5588', '#ff3377'],
    ['#eeeeee', '#dddddd', '#cccccc', '#bbbbbb', '#29a8ab'],
    ['#fff6e9', '#ffefd7', '#fffef9', '#e3f0ff', '#d2e7ff'],
    ['#edc951', '#eb6841', '#cc2a36', '#4f372d', '#00a0b0'],
    ['#84c1ff', '#add6ff', '#d6eaff', '#eaf4ff', '#f8fbff'],
    ['#2e003e', '#3d2352', '#3d1e6d', '#8874a3', '#e4dcf1'],
    ['#8d5524', '#c68642', '#e0ac69', '#f1c27d', '#ffdbac'],
    ['#343d46', '#4f5b66', '#65737e', '#a7adba', '#c0c5ce'],
    ['#bfd6f6', '#8dbdff', '#64a1f4', '#4a91f2', '#3b7dd8'],
    ['#fdfbfb', '#d6ddd6', '#8a8a9f', '#c17f7f', '#fdfbfb'],
    ['#e3c9c9', '#e3c9c9', '#f4e7e7', '#d66868', '#cf2828', '#cbdadb', '#cbdadb', '#D66868']
  ]
;

export interface Chart {

  chartId?: string;
  xAxis?: string;
  chartDescription?: string;
  colorPallete?: number;
  dataFields: string[];
  module?: string;
}
