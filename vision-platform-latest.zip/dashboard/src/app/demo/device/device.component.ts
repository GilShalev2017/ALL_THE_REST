import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Device, DevicesService} from '../devices/devices.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import {LoadingProgress, DeviceRequest, DeviceDescription, Widget} from '../../models/interfaces';
import {Observable} from 'rxjs';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {ConfirmComponent} from '../../dialogs/confirm/confirm.component';
import {MatDialog} from '@angular/material/dialog';
import {Location} from '@angular/common';
import {PageTitleService} from '../../framework/navbar/page-title/page-title.service';

@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.css']
})
export class DeviceComponent implements OnInit {
  id: string;
  device: DeviceDescription;
  error: string;
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;
  hubEnabled;
  changed = false;
  primaryConnectionString: string;
  secondaryConnectionString: string;
  widgets: Widget[];
  eventsDropDownState = '';
  eventsItem: number;

  constructor(
    private route: ActivatedRoute,
    private devicesService: DevicesService,
    private snackBar: MatSnackBar,
    private httpClient: HttpClient,
    private dialog: MatDialog,
    private router: Router,
    private location: Location,
    private pageTitleService: PageTitleService,
  ) {
  }

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    this.pageTitleService.setTitle(this.id, true);
    this.devicesService.getDeviceMetadata(this.id).subscribe(device => {
      this.device = device;
      console.log(this.device);
      this.hubEnabled = device.status === 'enabled';

      console.log(this.device);
      this.getConStrings();
      this.widgets = [
        { label: 'Current state', value: this.device.status === 'HEALTHY' ? 'Connected' : 'Error', icon: 'cloud_queue',
          dataClass: this.device.status === 'HEALTHY' ? 'healthy-color' : 'healthy-error-color' },
        { label: 'Daily events recorded', value: '24,600', icon: 'timeline' },
        { label: 'Recent activity', value: 'Today, 14:02', icon: 'access_time' }
      ];
    });
  }

  copySnackBar(key: string) {
    this.snackBar.open(key + ' copied to clipboard', null, {
      duration: 2000,
    });
  }

  _delete(deviceId): Observable<any> {
    return this.httpClient.delete<any>(environment.serverUrl + 'devices/' + deviceId);
  }

  _save(id: string, entity: DeviceRequest, update = false): Observable<Device> {
    console.log(entity);
    // Remove null fields
    for (const key in entity) {
      if (entity[key] === null) {
        delete entity[key];
      }
    }
    return this.httpClient.put<Device>(environment.serverUrl + 'devices/' + id, entity);
  }

  back() {
    this.location.back();
    if (this.changed) {
      setTimeout(() => this.devicesService.getUpdatedSubject().next(), 0);
    }
  }

  save() {
    this.state = LoadingProgress.LOADING;
    const saveDev: DeviceRequest = {
      edgeEnabled: true,
      hubEnabled: this.hubEnabled,
      deviceId: this.device.deviceId
    };
    console.log('Saving device ' + this.device.deviceId, saveDev);
    this._save(this.device.deviceId, saveDev).subscribe(entity => {
      this.snackBar.open('Configuration saved', null, {
        duration: 2000,
      });
      this.changed = true;
      this.state = LoadingProgress.DONE;
    }, err => {
      this.error = err;
      this.snackBar.open('Failed to save: ' + this.error, null, {
        duration: 2000,
      });
      this.state = LoadingProgress.ERROR;
    });
  }

  deleteSuccess() {
    this.snackBar.open('Device deleted', null, {
      duration: 2000,
    });
    this.state = LoadingProgress.DONE;
    this.router.navigateByUrl('devices').then(() => {
      setTimeout(() => this.devicesService.getUpdatedSubject().next(), 0);
    });
  }

  delete() {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete ${this.device.deviceId}?`,
        doAction: () => {
          this.state = LoadingProgress.LOADING;
          this._delete(this.device.deviceId).subscribe(() => {
            this.deleteSuccess();
          }, err => {
            if (err.code === 'ResourceNotFoundException') {
              this.deleteSuccess();
            } else {
              this.error = err;
              this.snackBar.open('Failed to delete: ' + this.error, null, {
                duration: 2000,
              });
              this.state = LoadingProgress.ERROR;
            }
          });
        }
      }
    });

  }

  async getConStrings() {
    if (this.device?.authentication?.symmetricKey) {
      this.primaryConnectionString = await this.devicesService.buildConString(this.device.deviceId, this.device.authentication.symmetricKey.primaryKey).toPromise();
      this.secondaryConnectionString = await this.devicesService.buildConString(this.device.deviceId, this.device.authentication.symmetricKey.secondaryKey).toPromise();
    }
  }

  toggleHide(input) {
    input.type === 'password' ? input.type = 'text' : input.type = 'password';
  }


}
