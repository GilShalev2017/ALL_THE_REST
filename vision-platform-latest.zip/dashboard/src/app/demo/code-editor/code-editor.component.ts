import { Component, OnInit } from '@angular/core';
import {ComponentResponse, CreateVersionRequest, DevicesService} from '../devices/devices.service';
import {BehaviorSubject} from 'rxjs';
import {CodeEditorService} from './code-editor.service';
import {PageTitleService} from '../../framework/navbar/page-title/page-title.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import {FeaturesService} from '../features/features.service';
import {Location} from '@angular/common';

export interface CodeEditorFiles {
  [key: string]: string;
}

@Component({
  selector: 'app-code-editor',
  templateUrl: './code-editor.component.html',
  styleUrls: ['./code-editor.component.css']
})
export class CodeEditorComponent implements OnInit {

  component: ComponentResponse;
  component$: BehaviorSubject<ComponentResponse>;
  recipe;
  deviceId;

  editorOptions = {theme: 'myTheme', language: 'python', baseUrl: 'assets/monaco/vs', renderLineHighlight: 'all'};
  code;
  // openedFiles: CodeEditorFiles;

  openedFiles = new Set<string>();

  loadingCode = true;
  loadingDeploy = false;

  constructor(private codeEditorService: CodeEditorService, private pageTitle: PageTitleService,
              private snackBar: MatSnackBar, private devicesService: DevicesService,
              private featuresService: FeaturesService, private location: Location) { }

  ngOnInit(): void {
    this.component$ = this.codeEditorService.getComponentSubject();
    this.component$.subscribe(component => {
      if ( component === null || component === undefined) {
        this.location.back();
      }
      this.component = component;
      if (this.component.deviceId) {
        this.deviceId = this.component.deviceId;
      }
      this.devicesService.getModuleVersions(this.component.arn).subscribe(vers => {
        this.component.componentVersion = vers[0].componentVersion;
      });
      this.pageTitle.setTitle(component.componentName, true);
      this.devicesService.getModuleRecipe(this.component.arn).subscribe(res => {
        console.log(res);
        const utf8recipe = new Uint8Array(Object.values(res.recipe));
        const utf8decoder = new TextDecoder();
        const data = JSON.parse(utf8decoder.decode(utf8recipe));
        this.recipe = data;
        console.log(this.recipe);
        console.log(this.recipe.Manifests[0].Artifacts[0].Uri);
        const uri = this.recipe.Manifests[0].Artifacts[0].Uri;
        this.loadCode(uri);
      });
    });
  }

  loadCode(uri) {
    this.loadingCode = true;
    const split = uri.split('/');
    const fileName = split[split.length - 1];
    this.devicesService.getModuleArtifact(uri).subscribe(file => {
      file.text().then( code => {
        this.code = code;
        this.openedFiles.add(fileName);
        this.loadingCode = false;
      });
    });
  }

  saveCode() {
    this.loadingDeploy = true;
    const uri = this.recipe.Manifests[0].Artifacts[0].Uri;
    const split = uri.split('/');
    const bucket = split[2];
    const key = uri.split(bucket + '/')[1];
    const fileName = split[split.length - 1];
    const componentName = this.component.componentName;
    // Set a new version - increment patch
    const componentVersionArray = this.component.componentVersion.split('.');
    const componentVersion = `${componentVersionArray[0]}.${componentVersionArray[1]}.${+componentVersionArray[2] + 1}`;
    // Update Recipe
    this.recipe.ComponentVersion = componentVersion;
    this.recipe.Manifests[0].Artifacts[0] = { Uri: `s3://${bucket}/artifacts/${componentName}/${componentVersion}/${fileName}` };
    const createVersionRequest: CreateVersionRequest = {
      componentVersion,
      code: this.code,
      componentName,
      key: `artifacts/${componentName}/${componentVersion}/${fileName}`,
      bucket,
      recipe: JSON.stringify(this.recipe)
    };
    this.devicesService.saveModule(createVersionRequest).subscribe(() => {
      console.log('Artifacts uploaded and component version created');
      if (!this.deviceId) {
        this.loadingDeploy = false;
        this.snackBar.open(`New version created: ${componentVersion}` , 'OK', {
          duration: 5000,
        });
      } else {
        this.devicesService.deploy(this.deviceId, componentName, '', componentVersion, '').subscribe(() => {
          console.log('Deployment finished');
          this.loadingDeploy = false;
          this.snackBar.open(`New version created: ${componentVersion}, deploying to device...` , 'OK', {
            duration: 5000,
          });
        });
      }
      this.component.componentVersion = componentVersion;
      this.component.feature.componentVersion = componentVersion;
      this.component.feature.recipe = JSON.stringify(this.recipe);
      console.log('Saving feature ', this.component.feature);
      this.featuresService.save(this.component.feature.id, this.component.feature);
    });
  }

  toArray(set: Set<string>) {
    return Array.from(set);
  }
}
