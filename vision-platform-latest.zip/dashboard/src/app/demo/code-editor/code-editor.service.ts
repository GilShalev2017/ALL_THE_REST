import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {ComponentResponse} from '../devices/devices.service';

@Injectable({
  providedIn: 'root'
})
export class CodeEditorService {

  componentSubject = new BehaviorSubject<ComponentResponse>(null);

  constructor() { }

  getComponentSubject() {
    return this.componentSubject;
  }

  setComponent(component: ComponentResponse, deviceId?: string) {
    if (deviceId) {
      component.deviceId = deviceId;
    }
    this.componentSubject.next(component);
  }
}
