import {Component, Input, OnInit} from '@angular/core';
import {Mockdevice, MockdevicesService} from './mockdevices.service';
import {Entity, EntityService, Widget} from '../../models/interfaces';
import {MatTableDataSource} from '@angular/material/table';
import {LoadingProgress} from 'src/app/models/interfaces';
import {ConfirmComponent} from '../../dialogs/confirm/confirm.component';
import {tap} from 'rxjs/operators';
import {SingleEntityComponent} from '../entity-table/single-entity/single-entity.component';
import {PageEvent} from '@angular/material/paginator';
import {MatDialog} from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';
import {environment} from '../../../environments/environment';
import { sumBy } from 'lodash';
import {PageTitleService} from '../../framework/navbar/page-title/page-title.service';

@Component({
  selector: 'app-mockdevices',
  templateUrl: './mockdevices.component.html',
  styleUrls: ['./mockdevices.component.css']
})
export class MockdevicesComponent implements OnInit {
  resource: MockdevicesService;

  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  entities: Mockdevice[] = [];
  entityColumns: string[];
  displayedColumns: string[];
  dataSource = new MatTableDataSource<Mockdevice>();
  page = 0;
  pageSize = 50;
  count = 0;
  error: string;
  widgets: Widget[];

  constructor(private mockdevicesService: MockdevicesService, public dialog: MatDialog,
              private snackBar: MatSnackBar, private pageTitleService: PageTitleService
  ) {
    this.resource = mockdevicesService;
  }

  ngOnInit(): void {
    this.get();
    this.pageTitleService.setTitle('Developer tools');
    this.entityColumns = Object.keys(this.resource.fields);
    this.displayedColumns = this.entityColumns.concat(['actions']);
    this.resource.enrollComplete.subscribe(mockdevice => {
      this.get();
    });
    this.resource.virtualDeviceCreated.subscribe(mockdevice => {
      this.get();
    });

  }

  countStatus(): { running: number, enrolled: number } {
    const running = sumBy(this.dataSource.data,
      (d) =>  Number(d.state === 'RUNNING' ? 1 : 0)
    );
    const enrolled = sumBy(this.dataSource.data,
      (d) =>  Number(d.enrollmentState === 'Enrolled' ? 1 : 0)
    );
    return {running, enrolled};
  }

  get() {
    this.state = LoadingProgress.LOADING;
    this.resource.get(this.page, this.pageSize)
      .subscribe(entitiesResponse => {
        this.state = LoadingProgress.DONE;
        this.entities = entitiesResponse;
        this.dataSource = new MatTableDataSource<Mockdevice>(entitiesResponse);
        const {running, enrolled} = this.countStatus();
        this.widgets = [
          { label: 'Available Virtual devices', value: running.toString(), icon: 'devices' },
          { label: 'Enrolled devices', value: enrolled.toString(), icon: 'network_wifi' },
          { label: 'Show API Explorer', value: '', icon: 'explore', action: () => {
              window.open(environment.serverUrl, '_blank');
            } },
        ];
      }, err => {
        this.state = LoadingProgress.ERROR;
      });
  }

  refresh() {
    this.get();
  }

  reboot(entity: Mockdevice) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Reboot',
        name: `Are you sure you would like to reboot this ${this.resource.displayName}?`,
        doAction: () => {
          return this.resource.reboot(entity.id).pipe(tap(() => {
            this.entities.splice(this.entities.indexOf(entity), 1);
            this.dataSource.data = this.entities;
            this.snackBar.open(this.resource.displayName + ' rebooted successfully!', null, {
              duration: 2000,
            });
            this.refresh();
          }));
        }
      }
    });
  }

  delete(entity: Mockdevice) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this ${this.resource.displayName}?`,
        dontWaitForAsyncResults: true,
        doAction: () => {
          const deviceIdAndName = `instanceId:${entity.id}-deviceName:${entity.deviceName}`;
          this.snackBar.open(this.resource.displayName + ' delete process started...', null, {
            duration: 5000,
          });
          return this.resource.delete(deviceIdAndName).pipe(tap(() => {
            this.entities.splice(this.entities.indexOf(entity), 1);
            this.dataSource.data = this.entities;
            this.snackBar.open(this.resource.displayName + ' deleted successfully!', null, {
              duration: 2000,
            });
            this.refresh();
          }));
        }
      }
    });

  }

  enroll(mockdevice: Mockdevice) {
    mockdevice.enrollmentState = 'Enrolling';
    this.mockdevicesService.enroll(mockdevice)
      .subscribe(() => {
        mockdevice.enrollmentState = 'Enrolled';
      }, err => {
        this.error = err;
        mockdevice.enrollmentState = 'NotEnrolled';
        this.state = LoadingProgress.ERROR;
      });
  }

  edit(entity: Mockdevice) {
    this.dialog.open(SingleEntityComponent, {
      width: '600px',
      data: {
        entity,
        service: this.resource,
        warningMessage: 'This can take up to a minute, please be patient.',
        dontWaitForAsyncResults: true
      }
    });
    //   .afterClosed().subscribe(() => {
    //   this.get();
    // });
  }

  changePage($event: PageEvent) {
    this.page = $event.pageIndex;
    this.get();
  }
}
