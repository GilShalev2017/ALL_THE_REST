import {Injectable} from '@angular/core';
import {CustomAction, Entity, EntityService} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of, Subject} from 'rxjs';
import {FormControl, FormGroup} from '@angular/forms';
import {tap} from 'rxjs/operators';
import {MatSnackBar} from "@angular/material/snack-bar";
import {MatSnackBarHorizontalPosition} from "@angular/material/snack-bar/snack-bar-config";
import {CustomSnackBarComponent} from "../../custom-snack-bar/custom-snack-bar.component";

export interface Mockdevice extends Entity {
  deviceName: string;
  publicDns?: string;
  instanceId?: string;
  state?: string;
  stateReason?: string;
  enrollmentState?: string;
} // entity

@Injectable({
  providedIn: 'root'
})
export class MockdevicesService implements EntityService {

  displayName = 'mockdevice';
  fields = {
    deviceName: {displayName: 'Device Name'},
    instanceId: {displayName: 'Instance ID'},
    publicDns: {displayName: 'Public DNS'},
    state: {displayName: 'State'},
    stateReason: {displayName: 'State Reason'},
    enrollmentState: {displayName: 'Enrollment State'},
  }; // fields

  newEc2fields = {
    deviceName: {displayName: 'Device Name'},
  }; // create new EC2 field

  enrollComplete = new Subject<Mockdevice>();
  virtualDeviceCreated = new Subject<Mockdevice>();
  creatingNewDevice = false;

  constructor(private httpClient: HttpClient, private snackBar: MatSnackBar) {
  }

  actions?: Set<string>;
  customActions?: CustomAction[];
  deleteByField?: string;

  getCount(): Observable<number> {
    throw new Error('Method not implemented.');
  }

  click?(entity: Entity): void {
    throw new Error('Method not implemented.');
  }

  getSingleForm(mockdevice: Mockdevice): FormGroup {
    const controls = Object.keys(this.newEc2fields).reduce((controlMap, field) => {
      controlMap[field] = new FormControl(mockdevice ? mockdevice[field] : '');
      return controlMap;
    }, {});
    return new FormGroup(controls);
  }

  get(page: number, pageSize: number): Observable<Mockdevice[]> {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };
    return this.httpClient.get<Mockdevice[]>(environment.serverUrl + 'mockdevices/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getMockdeviceById(id: string) {
    return this.httpClient.get<Mockdevice>(environment.serverUrl + 'mockdevices/' + id);
  }

  reboot(mockdeviceId: string): Observable<void> {
    return this.httpClient.get<void>(environment.serverUrl + `mockdevices/reboot/${mockdeviceId}`, {});
  }

  delete(mockdeviceId: string): Observable<void> {
    return this.httpClient.delete<void>(environment.serverUrl + `mockdevices/${mockdeviceId}`, {});
  }

  save(id: string, entity: Mockdevice): Observable<Mockdevice> {
    this.snackBar.openFromComponent(CustomSnackBarComponent,
      {
        verticalPosition: 'bottom',
        horizontalPosition: 'center',
        data: {snackBarMessage: `Creating virtual device '${entity.deviceName}' ...`}
      });

    this.creatingNewDevice = true;

    if (id) {
      return this.httpClient.put<Mockdevice>(environment.serverUrl + 'mockdevices/' + id, entity);
    } else {
      const postObservable = this.httpClient.post<Mockdevice>(environment.serverUrl + 'mockdevices', entity);
      postObservable.subscribe((arrivedData) => {
        this.snackBar.open(`Virtual device '${entity.deviceName}' was created`, 'Dismiss', {
          horizontalPosition: 'center',
          verticalPosition: 'bottom'
        });
        this.virtualDeviceCreated.next(arrivedData);
        this.creatingNewDevice = false;
      }, err => {
        this.snackBar.open(`Virtual device '${entity.deviceName}' failed to create`, 'Dismiss', {
          horizontalPosition: 'center',
          verticalPosition: 'bottom'
        });
        this.creatingNewDevice = false;
      });
      return postObservable;
    }
  }

  enroll(mockdevice: Mockdevice): Observable<Mockdevice> {
    return this.httpClient.post<Mockdevice>(environment.serverUrl + 'mockdevices/enroll', mockdevice)
      .pipe(
        tap(arrivedData => {
          // console.log(arrivedData);
          this.enrollComplete.next(arrivedData);
        }));
  }
}
