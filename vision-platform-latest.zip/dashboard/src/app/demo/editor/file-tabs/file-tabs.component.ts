import {Component, Input, OnInit} from '@angular/core';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-file-tabs',
  templateUrl: './file-tabs.component.html',
  styleUrls: ['./file-tabs.component.css']
})
export class FileTabsComponent implements OnInit {

  active = 'example.py';

  @Input('fileList')
  fileList = [
    'example.py',
    'README.md',
  ];

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.fileList, event.previousIndex, event.currentIndex);
  }

  ngOnInit(): void {
  }
}

