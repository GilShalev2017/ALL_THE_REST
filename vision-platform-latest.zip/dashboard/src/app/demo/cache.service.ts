import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CacheService {

  cache: { [key: string]: {
    timestamp: Date;
    data: any;
    } } = {};

  constructor() { }

  get(key: string) {
    return this.cache[key]?.data;
  }

  getIfNotExpired(key: string, expirationTime: number) {
    const entry = this.cache[key];
    if (!entry) {
      return null;
    }
    const expiration = new Date().getTime() - expirationTime;
    if (entry.timestamp.getTime() < expiration) {
      return null;
    }
    return entry;
  }

  set(key: string, data: any) {
    this.cache[key] = {
      timestamp: new Date(),
      data
    };
  }
}
