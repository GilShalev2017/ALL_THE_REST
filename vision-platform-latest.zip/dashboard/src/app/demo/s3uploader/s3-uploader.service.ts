import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {AssetUrlResponse} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {Feature} from "../features/features.service";

@Injectable({
  providedIn: 'root'
})
export class S3UploaderService {

  constructor(private httpClient: HttpClient) { }

  uploadFileToS3(fileToUpload: File): Observable<AssetUrlResponse> {
    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    const endpoint = environment.serverUrl + 'files/uploadToS3';
    return this.httpClient.post<AssetUrlResponse>(endpoint, formData);
  }

  uploadComponentImageFileToS3(fileToUpload: File, imageFileName: string, name: string, version: string, fileType: string): Observable<AssetUrlResponse> {
    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    formData.append('imageFileName', imageFileName);
    formData.append('componentName', name);
    formData.append('componentVersion', version);
    formData.append('saveFileType', fileType);
    const endpoint = environment.serverUrl + 'files/uploadToS3';
    return this.httpClient.post<AssetUrlResponse>(endpoint, formData);
  }

  removeFileFromS3(s3ObjectFullPath: string) {
    if (s3ObjectFullPath) {
      const s3ObjectKey = s3ObjectFullPath.split('/components/')[1];
      const endpoint = environment.serverUrl + 'files/deleteFromS3/' + s3ObjectKey;
      return this.httpClient.get(endpoint);
    }
  }
}
