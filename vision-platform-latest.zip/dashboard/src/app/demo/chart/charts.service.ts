import {Injectable} from '@angular/core';
import {Chart} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of, Subject} from 'rxjs';
import {CacheService} from '../cache.service';
import {map, tap} from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class ChartsService {


  constructor(private httpClient: HttpClient, private cache: CacheService) {
  }

  getChart(chartId: string): Observable<Chart> {
    return this.httpClient.get<Chart>(`${environment.serverUrl}chart/${chartId}`)
      .pipe(tap(chart => {
        return chart;
      }));
  }

  getUserCharts(queryPrm?: { [key: string]: string }): Observable<Chart[]> {
    const filter = {
      offset: 0,
      limit: 150,
      skip: 0,
      where: queryPrm ?? {}
    };
    return this.httpClient.get<Chart[]>(`${environment.serverUrl}chart/user?filter=` + encodeURI(JSON.stringify(filter)))
      .pipe(tap(charts => {
        return charts;
      }));
  }

  updateChart(args): Observable<{ success: boolean }> {
    const {chartId, chart} = args;
    return this.httpClient.put<{ success: boolean }>(`${environment.serverUrl}chart/${chartId}`, chart)
      .pipe(tap(response => {
        return !!response?.success;
      }));
  }

  createNewChart(args): Observable<{ chartId: string }> {
    const {newChart} = args;
    return this.httpClient.post<{ chartId: string }>(`${environment.serverUrl}chart`, newChart).pipe(tap(response => {
      return response;
    }));
  }

  removeChart(chartId: string): Observable<{ success: boolean }> {
    return this.httpClient.delete<{ success: boolean }>(`${environment.serverUrl}chart/${chartId}`).pipe(tap(response => {
      return response;
    }));
  }

}
