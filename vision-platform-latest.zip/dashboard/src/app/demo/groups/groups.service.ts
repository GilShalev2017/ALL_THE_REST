import {Injectable} from '@angular/core';
import {CustomAction, Entity, EntityService} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of, Subject} from 'rxjs';
import {FormControl, FormGroup} from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';
import {Router} from '@angular/router';

export interface Group extends Entity {
  groupArn: string;
  groupName: string;
} // entity

@Injectable({
  providedIn: 'root'
})
export class GroupsService implements EntityService {

  displayName = 'group';
  updated$: Subject<null> = new Subject<null>();

  fields = {
    groupName: {displayName: 'Name'},
  }; // fields
  actions = new Set(['delete']);
  deleteByField = 'groupName';
  // customActions: CustomAction[] = [
  //   {
  //     name: 'someAction',
  //     icon: 'devices',
  //     tooltip: 'Add devices',
  //     action: (group: Group) => { console.log('test some action' + group.groupName); }
  //   }
  // ];


  constructor(private httpClient: HttpClient, public dialog: MatDialog, private snackBar: MatSnackBar, private router: Router) {
  }

  customActions?: CustomAction[];


  getSingleForm(group: Group): FormGroup {
    const controls = Object.keys(this.fields).reduce((controlMap, field) => {
      controlMap[field] = new FormControl(group ? group[field] : '');
      return controlMap;
    }, {});
    return new FormGroup(controls);
  }

  getCount(): Observable<number> {
    return this.httpClient.get<number>(environment.serverUrl + 'groups/count');
  }

  get(page: number, pageSize: number): Observable<Entity[]> {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };
    return this.httpClient.get<Group[]>(environment.serverUrl + 'groups/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getGroupById(id: string) {
    return this.httpClient.get<Group>(environment.serverUrl + 'groups/' + id);
  }

  delete(groupId: string): Observable<void> {
    return this.httpClient.delete<void>(environment.serverUrl + `groups/${groupId}`, {});
  }

  save(id: string, entity: Group): Observable<Group> {
    if (id) {
      return this.httpClient.put<Group>(environment.serverUrl + 'groups/' + id, entity);
    } else {
      return this.httpClient.post<Group>(environment.serverUrl + 'groups', entity);
    }
  }

  click(group: Group) {
    this.router.navigateByUrl('/group/' + group.groupName);
  }

  getUpdatedSubject() {
    return this.updated$;
  }

  getGroupMetadata(name: string) {
    return this.httpClient.get<Group>(environment.serverUrl + 'groups/' + name);
  }

  getGroupDevices(name: string) {
    return this.httpClient.get<string[]>(environment.serverUrl + 'groups/' + name + '/devices');
  }

}
