import {Component, OnInit} from '@angular/core';
import {UsersService} from './users.service';

@Component({
  selector: 'app-users',
  template: '<app-entity-table [resource]="userResource"></app-entity-table>',
  styleUrls: []
})
export class UsersComponent implements OnInit {
  userResource: any;

  constructor(private usersService: UsersService) {
    this.userResource = usersService;
  }

  ngOnInit(): void {
  }

}
