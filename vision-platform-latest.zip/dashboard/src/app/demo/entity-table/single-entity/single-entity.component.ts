import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {LoadingProgress} from 'src/app/models/interfaces';
import {Entity, EntityService} from '../../../models/interfaces';
import {AbstractControl, FormGroup, ValidatorFn, Validators} from '@angular/forms';
import * as isBase64 from 'is-base64';
import {S3UploaderService} from '../../s3uploader/s3-uploader.service';

export function base64Validator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    // Keys must be a base64 with length between 16 bytes and 64 bytes.
    const base64 = !control.value || (control.value.length >= 16 && control.value.length <= 64 && isBase64(control.value));
    return !base64 ? {keyInvalid: true} : null;
  };
}

@Component({
  selector: 'app-single-entity',
  templateUrl: './single-entity.component.html',
  styleUrls: ['./single-entity.component.css']
})
export class SingleEntityComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;

  state: LoadingProgress = LoadingProgress.DONE;
  imageState: LoadingProgress = LoadingProgress.DONE;
  error: string;
  form: FormGroup;
  autoGenKeys = true;

  // Device related
  symAuth = true;
  public imagePath;
  imgURL: any;
  public message: string;
  fileToUpload: File | null = null;
  currentPictureUrl: string;

  constructor(
    private s3UploaderService: S3UploaderService,
    public dialogRef: MatDialogRef<SingleEntityComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      entity: Entity,
      service: EntityService,
      warningMessage?: string,
      dontWaitForAsyncResults?: boolean
    }) {
    this.form = this.data.service.getSingleForm(this.data.entity);
  }

  ngOnInit(): void {
    if (this.data.service.displayName === 'device') {
      console.log(this.data.entity);
      this.form.controls.primaryKey.disable();
      this.form.controls.secondaryKey.disable();
      if (this.form.controls.autoGenKeys.value === false) {
        this.form.controls.primaryKey.enable();
        this.form.controls.secondaryKey.enable();
      }
      // Map Device Entity form to Azure Device Entity
      this.mapDeviceEntity();
      this.form.controls.deviceId.setValidators(Validators.required);
      this.form.controls.primaryKey.setValidators(base64Validator());
      this.form.controls.secondaryKey.setValidators(base64Validator());

      // this.form.valueChanges.subscribe((val) => {
      //   console.log(this.form.controls.primaryKey.value);
      //   if (this.form.controls.primaryKey.value) {
      //     if (isBase64(this.form.controls.primaryKey.value)) {
      //       console.log('Primary key is valid');
      //     } else {
      //       console.log('Primary key is invalid');
      //     }
      //   }
      // });
    }

  }

  mapDeviceEntity() {
    if (!this.data.entity) {
      return;
    }
    const azureDevice = this.data.entity as any;
    this.form.controls.primaryKey.setValue(azureDevice.authentication?.symmetricKey.primaryKey);
    this.form.controls.secondaryKey.setValue(azureDevice.authentication?.symmetricKey.secondaryKey);
    this.form.controls.hubEnabled.setValue(azureDevice.status === 'enabled');
  }

  toggleHubEnabled() {

  }


  cancel() {
    this.dialogRef.close();
  }

  returnZero() {
    return 0;
  }

  toggleAuth() {
    this.symAuth = !this.symAuth;
    if (this.symAuth) {
      this.form.controls.authType.setValue('sym');
    } else {
      this.form.controls.authType.setValue('x509');
    }
  }

  toggleAutoGen() {
    console.log('toggleAutoGen');
    if (!this.autoGenKeys) {
      console.log('disable');
      this.form.controls.primaryKey.disable();
      this.form.controls.secondaryKey.disable();
      this.form.controls.autoGenKeys.setValue(true);
    } else {
      console.log('enable');
      this.form.controls.primaryKey.enable();
      this.form.controls.secondaryKey.enable();
      this.form.controls.autoGenKeys.setValue(false);
    }
  }

  // save() {
  //   this.state = LoadingProgress.LOADING;
  //
  //   if (this.data.dontWaitForAsyncResults) {
  //     this.data.service.save(this.data.entity?.id, this.form.value);
  //     this.dialogRef.close();
  //   } else {
  //
  //     if (this.fileToUpload) {
  //       this.saveSingleEntityWithFile();
  //     } else {
  //       this.data.service.save(this.data.entity?.id, this.form.value).subscribe(entity => {
  //         this.state = LoadingProgress.DONE;
  //         this.dialogRef.close();
  //       }, err => {
  //         this.error = err;
  //         this.state = LoadingProgress.ERROR;
  //       });
  //     }
  //   }
  // }

  save() {
    if (this.data.dontWaitForAsyncResults) {
      //save and close immediately
      this.data.service.save(this.data.entity?.id, this.form.value);
      this.dialogRef.close();
    } else {
      if (this.fileToUpload) {
        this.saveSingleEntityWithFile();
      } else {
        this.saveSingleEntity();
      }
    }
  }

  saveSingleEntity() {
    this.state = LoadingProgress.LOADING;
    this.data.service.save(this.data.entity?.id, this.form.value).subscribe(entity => {
      this.state = LoadingProgress.DONE;
      this.dialogRef.close();
    }, err => {
      this.error = err;
      this.state = LoadingProgress.ERROR;
    });
  }

  saveSingleEntityWithFile() {
    this.imageState = LoadingProgress.LOADING;

    this.s3UploaderService.removeFileFromS3(this.currentPictureUrl).subscribe(result => {
      this.s3UploaderService.uploadFileToS3(this.fileToUpload).subscribe(response => {
        this.form.controls.picture.setValue(response?.assetUrl);
        this.imageState = LoadingProgress.DONE;
        this.saveSingleEntity();
      }, error => {
        console.log(error);
      });
    }, errorOuter => {
      console.log(errorOuter);
    });
  }

  handleFileInput(files: FileList) {
    if (files.length === 0) {
      return;
    }
    const mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = 'Only images are supported.';
      return;
    }
    this.currentPictureUrl = this.form.controls.picture.value;

    this.fileToUpload = files.item(0);
    const reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]);
    reader.onload = (event) => {
      this.imgURL = reader.result;
      this.form.controls.picture.setValue(this.imgURL);
    };
  }
}
