import {Component, Input, OnInit} from '@angular/core';
import {LoadingProgress, Widget} from 'src/app/models/interfaces';
import {Entity, EntityService} from '../../models/interfaces';
import {Router} from '@angular/router';
import {ConfirmComponent} from '../../dialogs/confirm/confirm.component';
import {tap} from 'rxjs/operators';
import {MatDialog} from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatTableDataSource} from '@angular/material/table';
import {PageEvent} from '@angular/material/paginator';
import {SingleEntityComponent} from './single-entity/single-entity.component';

@Component({
  selector: 'app-entity-table',
  templateUrl: './entity-table.component.html',
  styleUrls: ['./entity-table.component.css']
})
export class EntityTableComponent implements OnInit {
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  entities: Entity[] = [];
  entityColumns: string[];
  displayedColumns: string[];
  dataSource = new MatTableDataSource<Entity>();
  page = 0;
  pageSize = 50;
  count = 0;
  deleteByField = 'id';
  widgets: Widget[];

  @Input()
  resource: EntityService;

  constructor(private router: Router, public dialog: MatDialog, private snackBar: MatSnackBar) {
  }

  ngOnInit(): void {
    this.get();
    this.getCount();
    this.entityColumns = Object.keys(this.resource.fields);
    this.displayedColumns = this.entityColumns.concat(['actions']);
    this.deleteByField = this.resource.deleteByField ? this.resource.deleteByField : 'id';
  }

  getCount() {
    this.resource.getCount().subscribe(totalItems => {
      this.count = totalItems;
    });
  }

  get() {
    this.resource.get(this.page, this.pageSize).subscribe(entitiesResponse => {
      this.state = LoadingProgress.DONE;
      this.entities = entitiesResponse;
      this.dataSource.data = entitiesResponse;
    }, err => {
      this.state = LoadingProgress.ERROR;
    });
  }

  delete(entity) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this ${this.resource.displayName}?`,
        doAction: () => {
          return this.resource.delete(entity[this.deleteByField]).pipe(tap(() => {
            this.entities.splice(this.entities.indexOf(entity), 1);
            this.dataSource.data = this.entities;

            this.snackBar.open(this.resource.displayName + ' deleted successfully!', null, {
              duration: 2000,
            });
          }));
        }
      }
    });
  }

  edit(entity: Entity) {
    this.dialog.open(SingleEntityComponent, {
      width: '600px',
      data: {
        entity,
        service: this.resource
      }
    }).afterClosed().subscribe(() => {
      this.get();
    });
  }

  displayAction(action: string) {
    if (this.resource.actions) {
      return this.resource.actions.has(action);
    } else {
      return true;
    }
  }

  changePage($event: PageEvent) {
    this.page = $event.pageIndex;
    this.pageSize = $event.pageSize;
    this.get();
  }
}
