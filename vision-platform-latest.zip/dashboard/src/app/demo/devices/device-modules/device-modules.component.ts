import {Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges} from '@angular/core';
import {awsStatusSymbols, DeploymentType, Entity, LoadingProgress} from 'src/app/models/interfaces';
import {ComponentResponse, Device, DevicesService, Modules} from '../devices.service';
import {MatDialog} from '@angular/material/dialog';
import {DeployDialogComponent} from '../deploy-dialog/deploy-dialog.component';
import {StreamEventsComponent} from '../../stream-events/stream-events.component';
import {ConfirmComponent} from '../../../dialogs/confirm/confirm.component';
import {tap} from 'rxjs/operators';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatTableDataSource} from "@angular/material/table";
import {PageEvent} from "@angular/material/paginator";
import {animate, style, transition, trigger} from '@angular/animations';
import {CodeEditorService} from "../../code-editor/code-editor.service";
import {Router} from "@angular/router";
import {FeaturesService} from '../../features/features.service';


@Component({
  selector: 'app-device-modules',
  templateUrl: './device-modules.component.html',
  styleUrls: ['./device-modules.component.css'],
  animations: [
    trigger(
      'inOutAnimation',
      [
        transition(
          ':enter',
          [
            style({ width: 0, opacity: 0 }),
            animate('0.3s ease-out',
              style({ width: 300, opacity: 1 }))
          ]
        ),
        transition(
          ':leave',
          [
            style({ width: 300, opacity: 1 }),
            animate('0.3s ease-in',
              style({ width: 0, opacity: 0 }))
          ]
        )
      ]
    )
  ]
})
export class DeviceModulesComponent implements OnInit, OnChanges, OnDestroy {
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  awsSymbols: typeof awsStatusSymbols;
  disableDeployment = false;

  @Input()
  device: Device;
  entities: Entity[] = [];
  entityColumns: string[];
  displayedColumns: string[];
  dataSource = new MatTableDataSource<Modules>();
  page = 0;
  pageSize = 50;
  count = 0;


  modules: Modules[];
  moduleKeys: string[] = [];
  selectedModule: ComponentResponse;
  deploymentType: DeploymentType;
  isPolling = false;
  deploymentId: string;
  deploymentStatus: string;
  private deploymentInterval: ReturnType<typeof setTimeout>;
  fetchingModule = true;

  constructor(private snackBar: MatSnackBar, public dialog: MatDialog, public resource: DevicesService,
              private codeEditorService: CodeEditorService, public router: Router, public featuresService: FeaturesService) {
    this.deploymentStatus = '';
    this.awsSymbols = awsStatusSymbols;
  }

  ngOnInit(): void {
    this.entityColumns = ['select', 'key', 'version', 'status', 'actions'];
    this.displayedColumns = ['select', 'key', 'version', 'status', 'actions'];
  }

  ngOnDestroy() {
    clearInterval(this.deploymentInterval);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (!this.modules && this.device) {
      this.get(true);
      this.getDeviceDeployment();
    }
  }

  getDeviceDeployment() {
    this.resource.getDeviceDeployment(this.device.deviceId).subscribe(data => {
      if (data.deploymentId && data.deploymentId.toString().length > 5) {
        this.deploymentId = data.deploymentId;
        this.deploymentStatus = data.deploymentStatus === 'ACTIVE' ? 'IN_PROGRESS' : data.deploymentStatus;
        this.pollDeploymentStatus();
      }
    });
  }

  pollDeploymentStatus() {
    if (!this.isPolling) {
      this.isPolling = true;
    }
    if (!this.deploymentId || this.deploymentId.toString().length < 5) {
      console.log('deploymentId is invalid!');
      return;
    }
    this.getDeploymentsStatus();
    this.deploymentInterval = setInterval(() => this.getDeploymentsStatus(), 10000);
  }

  getDeploymentsStatus() {
    this.resource.getDeploymentsStatus(this.deploymentId).subscribe(data => {
      if (data?.deploymentStatus) {
        this.deploymentStatus = data.deploymentStatus === 'ACTIVE' ? 'IN_PROGRESS' : data.deploymentStatus;
      }
      if (data.deploymentStatus !== 'ACTIVE') {
        const text = this.deploymentType === 'DELETION' ? ' deleted ' : ' deployed';
        if (data.deploymentStatus === 'COMPLETED') {
          this.snackBar.open(this.deploymentId + ` was  ${text} successfully!`, null, {
            duration: 6000,
          });
        } else if (data.deploymentStatus === 'CANCELED' || data.deploymentStatus === 'FAILED') {
        } else {
          this.snackBar.open(this.deploymentId + ` was not ${text} successfully with status: ${data.deploymentStatus}`, null, {
            duration: 6000,
          });
        }
        clearInterval(this.deploymentInterval);
        this.deploymentStatus = undefined;
        this.deploymentId = undefined;
        this.isPolling = false;
        this.get(true);
      }
    });
  }

  get(refresh: boolean) {
    if (!this.isPolling) {
      this.state = LoadingProgress.LOADING;
    }
    this.resource.getModulesById(this.device.deviceId, refresh).subscribe(modules => {
      this.modules = Object.keys(modules).map(cK => ({key: cK, ...modules[cK]}));
      this.state = LoadingProgress.DONE;
      this.moduleKeys = modules ? Object.keys(modules) : [];

      if (!this.moduleKeys.includes('aws.greengrass.Nucleus')) {
        this.disableDeployment = true;
      }
      else {
        this.disableDeployment = false;
      }
    });
  }

  deploy() {
    this.featuresService.getCount().subscribe( response => {
      this.dialog.open(DeployDialogComponent, {
        width: '1100px',
        data: {
          device: this.device,
          totalLength: response,
          moduleKeys: this.moduleKeys
        }
      }).afterClosed().subscribe((data) => {
        this.getDeviceDeployment();
        console.log('closed', data);
      });
    });
  }

  refresh() {
    this.get(true);
  }

  monitor() {
    this.dialog.open(StreamEventsComponent, {
      height: '700px',
      width: '700px',
      data: {
        device: this.device
      }
    });
  }

  deleteModule(moduleKey: string) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this module?`,
        doAction: () => {
          return this.resource.deleteModule(this.device.deviceId, moduleKey).pipe(tap((data) => {
            console.log(data);
            this.deploymentType = DeploymentType.DELETION;
            this.deploymentId = data.deploymentId;
            this.deploymentStatus = 'IN_PROGRESS';
          }));
        }
      }
    }).afterClosed().subscribe(data => {
      console.log(data);
      if (data === undefined) { return; }

      this.snackBar.open(`Delete process started...`, null, {
        duration: 6000,
      });
      if (this.deploymentId && !this.isPolling && this.deploymentStatus !== 'FINISHED' && this.deploymentStatus !== 'COMPLETED') {
        this.pollDeploymentStatus();
      }
    });
  }

  changePage($event: PageEvent) {
    this.page = $event.pageIndex;
    this.get(true);
  }

  selectModule(module: Modules) {
    if (this.selectedModule && this.selectedModule.componentName === module.key) {
      this.selectedModule = undefined;
      return;
    }
    this.selectedModule = {
      componentName: module.key,
      componentVersion: module.componentVersion
    };
    this.fetchingModule = true;
    console.log(module);
    this.resource.getModuleData(module.key, module.componentVersion).subscribe(async (mod) => {
      this.selectedModule = {...mod};
      this.featuresService.getFeatureByArn(this.selectedModule.arn).subscribe( (features) => {
        this.selectedModule.logo = features[0].picture;
        this.selectedModule.feature = features[0];
        console.log(this.selectedModule);
      });
      this.fetchingModule = false;
    });
  }

  isAwsComponent(module: Modules) {
    return module.key.includes('aws.greengrass');
  }

  code() {
    this.codeEditorService.setComponent(this.selectedModule, this.device.deviceId);
    this.router.navigateByUrl('/code');
  }
}
