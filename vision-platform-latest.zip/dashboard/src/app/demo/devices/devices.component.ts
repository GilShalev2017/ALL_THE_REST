import {ChangeDetectorRef, Component, NgZone, OnInit} from '@angular/core';
import {DevicesService} from './devices.service';
import {Entity, LoadingProgress, Widget} from '../../models/interfaces';
import {MatTableDataSource} from '@angular/material/table';
import {ConfirmComponent} from '../../dialogs/confirm/confirm.component';
import {tap} from 'rxjs/operators';
import {SingleEntityComponent} from '../entity-table/single-entity/single-entity.component';
import {PageEvent} from '@angular/material/paginator';
import {Router} from '@angular/router';
import {MatDialog} from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {SocketService} from './socket.service';
import {NavbarService} from '../../framework/navbar/navbar.service';
import {PageTitleService} from '../../framework/navbar/page-title/page-title.service';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class DevicesComponent implements OnInit {
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  entities: Entity[] = [];
  entityColumns: string[];
  displayedColumns: string[];
  dataSource = new MatTableDataSource<Entity>();
  page = 0;
  pageSize = 50;
  count = 0;
  expandedElement;
  widgets: Widget[];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private snackBar: MatSnackBar,
    public resource: DevicesService,
    private pageTitleService: PageTitleService,
    public cd: ChangeDetectorRef,
    public zone: NgZone) {
  }

  ngOnInit(): void {
    this.get(true);
    this.pageTitleService.setTitle('My Devices');
    this.entityColumns = Object.keys(this.resource.fields);
    this.entityColumns.splice(this.entityColumns.indexOf('authType'));
    this.displayedColumns = this.entityColumns;
    this.resource.getUpdatedSubject().subscribe(() => {
      this.get(true);
    });
  }

  get(refresh = false) {
    this.state = LoadingProgress.LOADING;
    this.resource.get(this.page, this.pageSize, refresh).subscribe(entitiesResponse => {
      this.zone.run(() => {
        this.state = LoadingProgress.DONE;
        this.entities = entitiesResponse;
        this.dataSource.data = entitiesResponse;
        if (refresh) {
          const currentPage: PageEvent = {
            length: 0,
            pageIndex: this.page,
            pageSize: this.pageSize
          };
          this.changePage(currentPage);
        }
      });
      this.widgets = [
        { label: 'registered devices', value: this.dataSource.data.length.toString(), icon: 'devices' },
        { label: 'Device Groups', value: '2', icon: 'devices_other', action: () => {
            console.log('Pressed device groups');
            this.router.navigateByUrl('groups');
          } },
        { label: 'Daily events recorded', value: '24,600', icon: 'timeline' },
        { label: 'Recent activity', value: 'Today, 14:02', icon: 'access_time' }
      ];
    }, err => {
      this.state = LoadingProgress.ERROR;
    });
  }

  delete(entity: Entity) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this ${this.resource.displayName}?`,
        doAction: () => {
          return this.resource.delete(entity.id).pipe(tap(() => {
            this.entities.splice(this.entities.indexOf(entity), 1);
            this.dataSource.data = this.entities;

            this.snackBar.open(this.resource.displayName + ' deleted successfully!', null, {
              duration: 2000,
            });
          }));
        }
      }
    });
  }

  edit(entity: Entity) {
    this.dialog.open(SingleEntityComponent, {
      width: '600px',
      data: {
        entity,
        service: this.resource
      }
    }).afterClosed().subscribe(() => {
      this.get(true);
    });
  }

  changePage($event: PageEvent) {
    this.page = $event.pageIndex;
    this.get();
  }

  gotoDevice(device) {
    this.router.navigateByUrl('/device/' + device.name);
  }
}
