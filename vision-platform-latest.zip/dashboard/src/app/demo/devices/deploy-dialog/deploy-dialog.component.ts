import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {LoadingProgress} from 'src/app/models/interfaces';
import {Device, DevicesService} from '../devices.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatTableDataSource} from '@angular/material/table';
import {Feature, FeaturesService} from '../../features/features.service';
import {MatPaginator, PageEvent} from '@angular/material/paginator';
import {Subject, Subscription} from 'rxjs';
import {debounceTime, distinctUntilChanged, switchMap, tap} from 'rxjs/operators';

@Component({
  selector: 'app-deploy-dialog',
  templateUrl: './deploy-dialog.component.html',
  styleUrls: ['./deploy-dialog.component.css']
})
export class DeployDialogComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;
  error: string;
  moduleName: string;
  dockerImage: string;
  dataSource: MatTableDataSource<Feature>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  page = 0;
  filterText: string;
  maxPageSize = 12;
  pageSize = 12;
  totalLength = 0;
  pageEvent: PageEvent;
  selectedModulesMap = new Map();
  searchQuery$ = new Subject<string>();
  private searchSubscription: Subscription;
  busy = false;

  constructor(
    private snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<DeployDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      device: Device,
      totalLength: number,
      moduleKeys: string[]
    },
    public devicesService: DevicesService,
    public featuresService: FeaturesService) {
    this.totalLength = this.data.totalLength;
  }

  searchFeatures() {
    if (!this.filterText) {
      this.getAllFeatures();
    } else {
      this.getFilteredFeatures();
    }
  }

  setSelection(featuresArray: Feature[]) {
    featuresArray.forEach(element => {
      const nameAndVersion = element.name + element.componentVersion;
      if (this.selectedModulesMap.has(nameAndVersion)) {
        element.selected = true;
      }
    });
  }

  setDeployed(featuresArray: Feature[]) {
    featuresArray.forEach(element => {
      if (this.data.moduleKeys.some(e => e.includes(element.name))) {
        element.deployed = true;
      }
    });
  }

  applyFilter() {
    this.page = 0;
    this.searchQuery$.next(this.filterText);
  }

  configureDataSourceSelectionAndDeployment(features: Feature[]) {
    this.dataSource = new MatTableDataSource(features);
    this.setSelection(features);
    this.setDeployed(features);
  }

  getFilteredFeatures() {
    this.featuresService.getFilteredFeatures(this.page, this.pageSize, this.filterText).subscribe(filteredFeatures => {
      this.configureDataSourceSelectionAndDeployment(filteredFeatures);
    });
  }

  getAllFeatures() {
    this.featuresService.get(this.page, this.pageSize).subscribe((features: Feature[]) => {
      console.log('Got features', features);
      this.configureDataSourceSelectionAndDeployment(features);
    });
  }

  ngOnInit(): void {
    this.getAllFeatures();

    this.searchSubscription = this.searchQuery$.pipe(
      debounceTime(700),
      distinctUntilChanged(),
      tap(() => this.busy = true),
      switchMap((text: string) => this.featuresService.getFilteredFeatures(this.page, this.pageSize, this.filterText)),
      tap(() => this.busy = false))
      .subscribe((features: Feature[]) => {
        this.configureDataSourceSelectionAndDeployment(features);
      });
  }

  onPageChange(event?: PageEvent) {
    if (this.pageSize < this.maxPageSize) {
      this.paginator.pageIndex = event.previousPageIndex;
      return event;
    }
    this.page = event.pageIndex;
    this.searchFeatures();
    return event;
  }

  cancel() {
    this.dialogRef.close();
  }

  save() {
    this.state = LoadingProgress.LOADING;
    const selectedFeatures = Array.from(this.selectedModulesMap.values());
    this.devicesService.deployMultiple(this.data.device.deviceId, selectedFeatures, this.data.device.authentication?.symmetricKey.primaryKey)
      .subscribe(() => {
        this.state = LoadingProgress.DONE;
        this.dialogRef.close(true);
        this.snackBar.open('Deploying to device started...', null, {
          duration: 3000
        });
      }, (err) => {
        console.log('error deploying', err);
        this.state = LoadingProgress.ERROR;
        this.error = err?.error?.error?.message || err?.statusText;
      });
  }

  select(item) {
    const nameAndVersion = item.name + item.componentVersion;
    if (this.selectedModulesMap.has(nameAndVersion)) {
      this.selectedModulesMap.delete(nameAndVersion);
    } else {
      this.selectedModulesMap.set(nameAndVersion, item);
    }
  }
}


//
// marketplace = [{
//   name: 'Scene Understanding',


//   image: 'docker.io/danielpiro/realsense-ai:latest',
//   moduleName: 'realsense-ai',
//   picture: 'assets/scene_algo.png',
//   selected: false
// }, {
//   name: 'SQL Server',
//   image: 'docker.io/mosheshaham/pub:baremin',
//   moduleName: 'sql-server',
//   picture: 'https://i0.wp.com/learn.onemonth.com/wp-content/uploads/2019/07/image2-1.png',
//   selected: false
// }, {
//   name: 'Face Recognition',
//   image: 'docker.io/mosheshaham/pub:baremin',
//   moduleName: 'face-recognition',
//   picture: 'https://www.cometaspa.com/_files/uploads/facial-recognition-technology-for-high-security-level-03.jpg',
//   selected: false
// }, {
//   name: 'Object Detection',
//   image: 'docker.io/mosheshaham/pub:baremin',
//   moduleName: 'object-detection',
//   picture: 'https://cdn.analyticsvidhya.com/wp-content/uploads/2018/12/Screenshot-from-2018-11-29-13-03-17.png',
//   selected: false
// }, {
//   name: 'Emotion Detection',
//   image: 'docker.io/mosheshaham/pub:baremin',
//   moduleName: 'emotion-detection',
//   picture: 'https://acart.com/wp-content/uploads/2017/04/facial-recognition-img2.jpg',
//   selected: false
// }, {
//   name: 'Environment Measurement',
//   image: 'docker.io/mosheshaham/pub:baremin',
//   moduleName: 'com.intel.environment',
//   picture: 'https://www.micro-epsilon.co.il/applications/img/apps_picto/Messgroessen-Temperatur.svg',
//   selected: false
// }];
