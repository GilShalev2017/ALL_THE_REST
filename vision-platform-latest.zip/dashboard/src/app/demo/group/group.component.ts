import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Device, DevicesService} from '../devices/devices.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import {LoadingProgress, DeviceRequest, DeviceDescription} from '../../models/interfaces';
import {Observable} from 'rxjs';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {ConfirmComponent} from '../../dialogs/confirm/confirm.component';
import {MatDialog} from '@angular/material/dialog';
import {Group, GroupsService} from '../groups/groups.service';
import {NavbarService} from "../../framework/navbar/navbar.service";
import {PageTitleService} from "../../framework/navbar/page-title/page-title.service";

@Component({
  selector: 'app-device',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
  name: string;
  group: Group;
  error: string;
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;
  hubEnabled;
  changed = false;
  primaryConnectionString: string;
  secondaryConnectionString: string;
  devices: string[];
  displayedColumns = ['name'];

  constructor(
    private route: ActivatedRoute,
    private groupsService: GroupsService,
    private snackBar: MatSnackBar,
    private httpClient: HttpClient,
    private dialog: MatDialog,
    private router: Router,
    private pageTitleService: PageTitleService,
  ) { }

  ngOnInit(): void {
    this.state = LoadingProgress.LOADING;
    this.name = this.route.snapshot.paramMap.get('name');
    this.pageTitleService.setTitle(this.name, true);
    this.groupsService.getGroupMetadata(this.name).subscribe(group => {
      this.group = group;
      console.log(this.group);
      this.state = LoadingProgress.DONE;
    }, err => {
      this.state = LoadingProgress.ERROR;
    });
    this.groupsService.getGroupDevices(this.name).subscribe(devices => {
      this.devices = devices;
      console.log('devices', this.devices);
    }, err => {
      this.state = LoadingProgress.ERROR;
    });
  }

  copySnackBar(key: string) {
    this.snackBar.open(key + ' copied to clipboard', null, {
      duration: 2000,
    });
  }
  openSnackBar(msg: string) {
    this.snackBar.open(msg, null, {
      duration: 2000,
    });
  }

  _delete(deviceId): Observable<any> {
    return this.httpClient.delete<any>(environment.serverUrl + 'devices/' + deviceId);
  }

  _save(id: string, entity: DeviceRequest, update = false): Observable<Device> {
    console.log(entity);
    // Remove null fields
    for (const key in entity) {
      if (entity[key] === null) {
        delete entity[key];
      }
    }
    return this.httpClient.put<Device>(environment.serverUrl + 'devices/' + id, entity);
  }

  back() {
    this.router.navigateByUrl('groups');
  }

  save() {
    this.state = LoadingProgress.LOADING;
    const saveDev: DeviceRequest = {
      deviceId: this.group.groupName
    };
    console.log('Saving device ' + this.group.groupName, saveDev);
    this._save(this.group.groupName, saveDev).subscribe(entity => {
      this.openSnackBar('Configuration saved');
      this.changed = true;
      this.state = LoadingProgress.DONE;
    }, err => {
      this.error = err;
      this.openSnackBar('Failed to save: ' + this.error);
      this.state = LoadingProgress.ERROR;
    });
  }

  deleteSuccess() {
    this.openSnackBar('Device deleted');
    this.state = LoadingProgress.DONE;
    this.router.navigateByUrl('devices');
  }

  delete() {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete ${this.group.groupName}?`,
        doAction: () => {
          this.state = LoadingProgress.LOADING;
          this._delete(this.group.groupName).subscribe(() => {
            this.deleteSuccess();
          }, err => {
            if (err.code === 'ResourceNotFoundException') {
              this.deleteSuccess();
            } else {
              this.error = err;
              this.openSnackBar('Failed to delete: ' + this.error);
              this.state = LoadingProgress.ERROR;
            }
          });
        }
      }
    });

  }

  toggleHide(input) {
    input.type === 'password' ? input.type = 'text' : input.type = 'password';
  }

  gotoDevice(device) {
    console.log(device);
    this.router.navigateByUrl('/device/' + device);
  }
}
