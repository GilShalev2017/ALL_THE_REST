import {Injectable} from '@angular/core';
import {AuthLevel, Entity, EntityService, GetFeaturesResponse} from '../../models/interfaces';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {FormControl, FormGroup} from '@angular/forms';
import {UserService} from '../../framework/authentication/user.service';

// export enum SharingType {
//   PRIVATE = 'PRIVATE',
//   PUBLIC = 'PUBLIC',
// }

export interface Feature extends Entity {
  name: string;
  description?: string;
  componentVersion?: string;
  picture?: string;
  // artifactUri?: string;
  // runScript?: string;
  recipe?: string;
  componentVersionARN?: string;
  selected?: boolean;
  deployed?: boolean;
} // entity

@Injectable({
  providedIn: 'root'
})
export class FeaturesService implements EntityService {

  displayName = 'feature';
  count = 0;
  fields = {
    name: {displayName: 'Name', isHidden: true},
    description: {displayName: 'Description', isHidden: true},
    componentVersion: {displayName: 'Version', isHidden: true},
    picture: {displayName: 'Picture', isHidden: true, isPicture: true},
    // artifactUri: {displayName: 'Artifact URI', isHidden: true},
    // runScript: {displayName: 'Script Run Command', isHidden: true},
    // recipe: {displayName: 'Recipe', isHidden: true},
  }; // fields

  constructor(private httpClient: HttpClient, private userService: UserService) {

  }

  getSingleForm(feature: Feature): FormGroup {
    const controls = Object.keys(this.fields).reduce((controlMap, field) => {
      controlMap[field] = new FormControl(feature ? feature[field] : '');
      if (field === 'owner') {
        controlMap[field].value = this.userService.getUserEmail();
      }
      return controlMap;
    }, {});
    return new FormGroup(controls);
  }

  getCount(): Observable<number> {
    return this.httpClient.get<number>(environment.serverUrl + 'features/count');
  }

  get(page: number, pageSize: number): Observable<Feature[]> {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };
    return this.httpClient.get<Feature[]>(environment.serverUrl + 'features/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getFilteredFeatures(page: number, pageSize: number, filterText: string) {
    const likeFilterText = `%${filterText}%`;
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ],
      where: {
        name: {
          ilike: likeFilterText,
        }
      }
    };

    return this.httpClient.get<Feature[]>(environment.serverUrl + 'features/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getFeatures(page: number, pageSize: number) {
    const filter = {
      offset: 0,
      limit: pageSize,
      skip: page * pageSize,
      order: [
        'name ASC'
      ]
    };
    return this.httpClient.get<GetFeaturesResponse>(environment.serverUrl + 'features/?filter=' + encodeURI(JSON.stringify(filter)));
  }

  getFeatureById(id: string) {
    return this.httpClient.get<Feature>(environment.serverUrl + 'features/' + id);
  }

  getFeatureByArn(arn: string) {
    const filter = {
      where: {
        componentArn: arn
      }
    };
    return this.httpClient.get<Feature>(environment.serverUrl + 'features?filter=' + JSON.stringify(filter));
  }

  delete(featureId: string): Observable<void> {
    return this.httpClient.delete<void>(environment.serverUrl + `features/${featureId}`, {});
  }

  save(id: string, entity: Feature): Observable<Feature> {
    if (id) {
      if (!entity.picture) {
        entity.picture = '';
      }
      return this.httpClient.put<Feature>(environment.serverUrl + 'features/' + id, entity);
    } else {
      return this.httpClient.post<Feature>(environment.serverUrl + 'features', entity);
    }
  }

  enumSelector(definition) {
    return Object.keys(definition)
      .map(key => ({value: definition[key], title: key}));
  }
}
