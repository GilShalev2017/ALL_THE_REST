import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {LoadingProgress} from 'src/app/models/interfaces';
import {S3UploaderService} from '../../s3uploader/s3-uploader.service';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {Feature, FeaturesService} from '../features.service';
import {JsonEditorComponent, JsonEditorOptions} from 'ang-jsoneditor';
import {MatSelectChange} from '@angular/material/select';
import {MatSnackBar} from '@angular/material/snack-bar';
import {
  dockerComposeAmazonEcrAndHubTemplate,
  nodeJsRecipeTemplate, privateAmazonECRTemplate,
  pythonRecipeTemplate, pythonRuntimeTemplate, s3BucketDockerTemplate,
  severalFieldsRecipeTemplate
} from './recipe-templates';

interface Template {
  value: string;
  viewValue: string;
}

interface TemplateGroup {
  name: string;
  template: Template[];
}

@Component({
  selector: 'app-add-edit-component',
  templateUrl: './add-edit-component.component.html',
  styleUrls: ['./add-edit-component.component.css'],
})
export class AddEditComponentComponent implements OnInit {
  LoadingProgress: typeof LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.DONE;
  imageState: LoadingProgress = LoadingProgress.DONE;
  artifactState: LoadingProgress = LoadingProgress.DONE;
  error: string;
  form: FormGroup;
  autoGenKeys = true;
  // Device related
  symAuth = true;
  public imagePath;
  artifactURL: any;
  imgURL: any;
  public message: string;
  fileToUpload: File | null = null;
  artifactFileToUpload: File | null = null;
  currentPictureUrl: string;
  componentName: string;
  componentVersion: string;
  public editorOptions: JsonEditorOptions;
  @ViewChild(JsonEditorComponent, {static: false}) editor: JsonEditorComponent;
  public isDirty = false;
  recipeTemplates = new FormControl();
  recipeTemplateList: string[] = [
    'Template to run python script',
    'Template to run Node.js',
    'Template with component dependencies and several recipe fields',
    'Template to run python runtime',
    'Template that uses Docker Compose to run images from public Amazon ECR and Docker Hub',
    'Template that runs a Docker container from a private Amazon ECR image',
    'Template that runs a Docker container from an image in an S3 bucket'];
  selectedRecipe = 'Python';
  recipeTemplate;
  s3ArtifactsBucket = 'https://s3.console.aws.amazon.com/s3/buckets/ati-vp-components/artifacts/';
  templateGroups: TemplateGroup[] = [
    {
      name: 'Runtime Templates',
      template: [
        {
          value: 'pythonRuntime',
          viewValue: 'Template to run python runtime'
        },
      ]
    },
    {
      name: 'Single File Templates',
      template: [
        {
          value: 'pythonRecipe',
          viewValue: 'Template to run python script'
        },
        {
          value: 'nodeJsRecipe',
          viewValue: 'Template to run Node.js'
        },
        {
          value: 'severalFieldsRecipe',
          viewValue: 'Template with component dependencies and several recipe fields'
        },
      ]
    },
    {
      name: 'Docker Templates',
      template: [
        {
          value: 'dockerComposeAmazonEcrAndHub',
          viewValue: 'Template that uses Docker Compose to run images from public Amazon ECR and Docker Hub'
        },
        {
          value: 'privateAmazonECR',
          viewValue: 'Template that runs a Docker container from a private Amazon ECR image'
        },
        {
          value: 's3BucketDocker',
          viewValue: 'Template that runs a Docker container from an image in an S3 bucket'
        },
      ]
    }
  ];

  constructor(private s3UploaderService: S3UploaderService,
              public dialogRef: MatDialogRef<AddEditComponentComponent>,
              @Inject(MAT_DIALOG_DATA) public data: {
                entity: Feature,
                service: FeaturesService
              }) {
    this.form = this.data.service.getSingleForm(this.data.entity);
    this.editorOptions = new JsonEditorOptions();
    this.editorOptions.modes = ['code', 'tree', 'view'];
    if (this.data?.entity?.recipe) {
      this.recipeTemplate = JSON.parse(this.data.entity.recipe);
      this.componentName = this.recipeTemplate.ComponentName;
      this.componentVersion = this.recipeTemplate.ComponentVersion;
    } else {
      this.componentName = 'com.intel.HelloWorld';
      this.componentVersion = '1.0.0';
      this.isDirty = true;
    }
  }

  ngOnInit(): void {
  }

  cancel() {
    this.dialogRef.close();
  }

  returnZero() {
    return 0;
  }

  save() {
    if (this.fileToUpload) {
      this.saveSingleEntityWithFile();
    } else {
      this.saveSingleEntity();
    }
  }

  saveSingleEntity() {
    this.state = LoadingProgress.LOADING;
    const currentDataString = JSON.stringify(this.editor.get());
    const currentDataJson = this.editor.get();
    this.form.value.recipe = currentDataString;
    this.form.value.name = currentDataJson['ComponentName'];
    this.form.value.description = currentDataJson['ComponentDescription'];
    this.form.value.componentVersion = currentDataJson['ComponentVersion'];
    this.data.service.save(this.data.entity?.id, this.form.value).subscribe(entity => {
      this.state = LoadingProgress.DONE;
      this.dialogRef.close(true);
    }, err => {
      this.state = LoadingProgress.ERROR;
      this.error = err.error.error.message;
    });
  }

  saveSingleEntityWithFile() {
    this.imageState = LoadingProgress.LOADING;
    if (this.currentPictureUrl) {
      this.s3UploaderService.removeFileFromS3(this.currentPictureUrl).subscribe(result => {
        this.s3UploaderService.uploadComponentImageFileToS3(this.fileToUpload, this.fileToUpload.name, this.form.controls.name.value,
          this.form.controls.componentVersion.value, 'ASSET')
          .subscribe(response => {
            this.form.controls.picture.setValue(response?.assetUrl);
            this.imageState = LoadingProgress.DONE;
            //if (this.isDirty) {
            this.saveSingleEntity();
            //}
          }, error => {
            console.log(error);
          });
      }, errorOuter => {
        console.log(errorOuter);
      });
    } else {
      this.s3UploaderService.uploadComponentImageFileToS3(this.fileToUpload, this.fileToUpload.name, this.form.controls.name.value,
        this.form.controls.componentVersion.value, 'ASSET')
        .subscribe(response => {
          this.form.controls.picture.setValue(response?.assetUrl);
          this.imageState = LoadingProgress.DONE;
          this.saveSingleEntity();
        }, error => {
          console.log(error);
        });
    }
  }

  handleImageFileInput(files: FileList) {
    if (files.length === 0) {
      return;
    }
    const mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = 'Only images are supported.';
      return;
    }
    this.currentPictureUrl = this.form.controls.picture.value;

    this.fileToUpload = files.item(0);
    const reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]);
    reader.onload = (event) => {
      this.imgURL = reader.result;
      this.currentPictureUrl = this.imgURL;
      this.form.controls.picture.setValue(this.imgURL);
    };
  }

  handleArtifactFileInput(files: FileList) {
    if (files.length === 0) {
      return;
    }
    const mimeType = files[0].type;
    this.artifactFileToUpload = files.item(0);
    const reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]);
    reader.onload = (event) => {
      this.artifactURL = reader.result;
    };
  }

  getData(jsonObject) {
    this.isDirty = true;
    this.componentName = jsonObject.ComponentName;
    this.componentVersion = jsonObject.ComponentVersion;
  }

  uploadArtifact() {
    this.artifactState = LoadingProgress.LOADING;
    this.s3UploaderService.uploadComponentImageFileToS3(this.artifactFileToUpload, this.artifactFileToUpload.name, this.componentName,
      this.componentVersion, 'ARTIFACT')
      .subscribe(response => {
        this.artifactState = LoadingProgress.DONE;
        this.artifactFileToUpload = undefined;
      }, error => {
        this.artifactState = LoadingProgress.ERROR;
        console.log(error);
      });
  }

  recipeChanged($event: MatSelectChange) {
    const selectedOption = $event.value;
    switch (selectedOption) {
      case 'dockerComposeAmazonEcrAndHub': {
        this.recipeTemplate = dockerComposeAmazonEcrAndHubTemplate;
        break;
      }
      case 'privateAmazonECR': {
        this.recipeTemplate = privateAmazonECRTemplate;
        break;
      }
      case 's3BucketDocker': {
        this.recipeTemplate = s3BucketDockerTemplate;
        break;
      }
      case 'pythonRuntime': {
        this.recipeTemplate = pythonRuntimeTemplate;
        break;
      }
      case 'nodeJsRecipe': {
        this.recipeTemplate = nodeJsRecipeTemplate;
        break;
      }
      case 'pythonRecipe': {
        this.recipeTemplate = pythonRecipeTemplate;
        break;
      }
      case 'severalFieldsRecipe': {
        this.recipeTemplate = severalFieldsRecipeTemplate;
        break;
      }
    }
    this.componentVersion = this.recipeTemplate.ComponentVersion;
    this.componentName = this.recipeTemplate.ComponentName;
  }
}

