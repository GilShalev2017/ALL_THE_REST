import {Component, OnInit} from '@angular/core';
import {Feature, FeaturesService} from './features.service';
import {MatTableDataSource} from '@angular/material/table';
import {LoadingProgress} from 'src/app/models/interfaces';
import {Widget} from '../../models/interfaces';
import {MatDialog} from '@angular/material/dialog';
import {MatSnackBar} from '@angular/material/snack-bar';
import {PageTitleService} from '../../framework/navbar/page-title/page-title.service';
import {ConfirmComponent} from '../../dialogs/confirm/confirm.component';
import {tap} from 'rxjs/operators';
import {PageEvent} from '@angular/material/paginator';
import {AddEditComponentComponent} from './add-edit-component/add-edit-component.component';

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css']
})
export class FeaturesComponent implements OnInit  {
  resource: FeaturesService;
  LoadingProgress = LoadingProgress;
  state: LoadingProgress = LoadingProgress.LOADING;
  entities: Feature[] = [];
  entityColumns: string[];
  displayedColumns: string[];
  dataSource = new MatTableDataSource<Feature>();
  page = 0;
  pageSize = 9;
  count = 100;
  error: string;
  widgets: Widget[];

  constructor(private featuresService: FeaturesService, public dialog: MatDialog,
              private snackBar: MatSnackBar, private pageTitleService: PageTitleService) {
    this.resource = featuresService;
  }

  ngOnInit(): void {
    this.get();
    this.getCount();
    this.pageTitleService.setTitle('Market Manager');
    this.entityColumns = Object.keys(this.resource.fields);
    this.displayedColumns = this.entityColumns.concat(['actions']);
  }

  getCount() {
    this.resource.getCount().subscribe(totalItems => {
      this.count = totalItems;
    });
  }

  get() {
    this.state = LoadingProgress.LOADING;
    this.resource.get(this.page, this.pageSize)
      .subscribe(entitiesResponse => {
        this.state = LoadingProgress.DONE;
        this.entities = entitiesResponse;
        this.dataSource.data = entitiesResponse;
      }, err => {
        this.state = LoadingProgress.ERROR;
      });
  }

  refresh() {
    this.get();
  }

  delete(entity: Feature) {
    this.dialog.open(ConfirmComponent, {
      width: '600px',
      data: {
        action: 'Confirm Delete',
        name: `Are you sure you would like to delete this IoT Component?`,
        doAction: () => {
          const imageName = entity.picture.split('/components/')[1];
          const featureAndImageIds = `feature_id:${entity.id}_image_id:${imageName}_component_arn:${entity.componentVersionARN}`;
          return this.resource.delete(featureAndImageIds/*entity.id*/).pipe(tap(() => {
            this.entities.splice(this.entities.indexOf(entity), 1);
            this.dataSource.data = this.entities;
            this.snackBar.open(this.resource.displayName + ' deleted successfully!', null, {
              duration: 2000,
            });
          }));
        }
      }
    });
  }

  edit(entity: Feature) {
    this.dialog.open(AddEditComponentComponent, {
      width: '60vw',
      data: {
        entity,
        service: this.resource
      }
    }).afterClosed().subscribe((data) => {
      if (data) {
        this.get();
      }
    });
  }

  changePage($event: PageEvent) {
    this.page = $event.pageIndex;
    this.pageSize = $event.pageSize;
    this.get();
  }
}
