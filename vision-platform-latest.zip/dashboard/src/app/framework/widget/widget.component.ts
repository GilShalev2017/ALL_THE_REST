import {AfterViewInit, Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {Widget} from '../../models/interfaces';

@Component({
  selector: 'app-widget',
  templateUrl: './widget.component.html',
  styleUrls: ['./widget.component.css']
})
export class WidgetComponent implements AfterViewInit {

  @Input()
  data: Widget;

  @ViewChild('labelDiv')
  labelDiv: ElementRef;

  @ViewChild('dataDiv')
  dataDiv: ElementRef;

  constructor() { }

  ngAfterViewInit(): void {
    if (this.data.labelClass) {
      this.labelDiv.nativeElement.classList.toggle(this.data.labelClass);
    }
    if (this.data.dataClass) {
      console.log(this.data.dataClass);
      this.dataDiv.nativeElement.classList.toggle(this.data.dataClass);
    }
  }

}
