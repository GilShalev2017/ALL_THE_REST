import {Router} from '@angular/router';
import {Injectable} from '@angular/core';
import {UserService} from './user.service';

@Injectable()
export class IsLoggedIn {
  constructor(
    private router: Router,
    private userService: UserService) {
  }

  resolve(): void {
    if (this.userService.isAuthenticated()) {
      this.router.navigate([this.userService.getConfig().appHome]);
    }
  }
}
