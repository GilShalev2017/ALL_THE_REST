export interface AuthenticationConfig {
  appHome: string;
}
