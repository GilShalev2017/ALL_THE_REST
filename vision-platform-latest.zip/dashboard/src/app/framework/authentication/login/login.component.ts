import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';
import {ActivatedRoute, Router} from '@angular/router';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {finalize} from 'rxjs/operators';
import {MatSnackBar} from '@angular/material/snack-bar';
import {FormValiations} from './validations';
import {Auth} from '../../../models/interfaces';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form: FormGroup;
  loginToggle: Auth = Auth.LOGIN;
  loading: boolean;
  error: string;
  message: string;
  confirmationCode: string;
  signupCredentials: {};

  constructor(
    private userService: UserService,
    private fb: FormBuilder,
      private router: Router, private activeRoute: ActivatedRoute, private snackBar: MatSnackBar) {
  }

  getButtonText(loginToggle: Auth) {
    switch (loginToggle) {
      case Auth.LOGIN:
        return 'LOGIN';
      case Auth.REGISTER:
        return 'SIGN UP';
      case Auth.ADMIN_CONFIRMATION:
        return 'CONFIRM EMAIL';
      case Auth.PASSWORD_UPDATE:
        return 'UPDATE PASSWORD';
      case Auth.PASSWORD_RESET:
        return 'RESET PASSWORD';
      default:
        return '';
    }
  }

  openSnackBar(message: string) {
    this.snackBar.open(message, null, {
      duration: 1000

    });

  }

  ngOnInit() {

    if (this.activeRoute?.snapshot?.queryParams?.cc && this.router?.url) {
      const query = this.activeRoute.snapshot.queryParams;
      this.confirmationCode = query.cc
      const currUrl = this.router.url.toString();

      if (currUrl.indexOf("passwordReset") > -1) {
        this.toggle(Auth.PASSWORD_UPDATE);
      } else if (currUrl.indexOf("adminLogin") > -1) {
        this.toggle(Auth.ADMIN_CONFIRMATION);
      }
    }

    this.setupForm();
  }


  submit() {
    if (this.form.valid) {
      let value = this.form.value;
      Object.keys(value).map(k => value[k] = value[k].trim());
      let func: any = this.userService.login;
      switch (this.loginToggle) {
        case 'ADMIN_CONFIRMATION':
          func = this.userService.signup;
          value = {
            verificationToken: value.confirmationCode,
            ...this.signupCredentials
          }
          break;
        case 'REGISTER':
          func = this.userService.signup;
          this.signupCredentials = this.form.value;
          break;
        case 'PASSWORD_RESET':
          func = this.userService.passwordReset;
          this.signupCredentials = this.form.value;
          break;
        case 'PASSWORD_UPDATE':
          value = {
            ...value,
            ...this.signupCredentials
          };
          func = this.userService.passwordUpdate;
          break;
      }


      this.loading = true;

      func.call(this.userService, {...value})
        .pipe(finalize(() => {
          this.loading = false;

        }))
        .subscribe((response) => {
            const {identifier} = response;
            if (!identifier) {
              throw new Error('Global error occurred.please contact us.');

            }
            switch (identifier) {
              case 'login':
                this.router.navigateByUrl('/devices').then();
                break;

              case 'firstLogin':
              case 'confirmationCodeValidation':
              case  'signUp':
                this.router.navigateByUrl('/select-cloud-provider').then();
                break;

              case 'confirmationCodeRequired':
                this.toggle(Auth.ADMIN_CONFIRMATION);
                break;

              case 'passwordReset':
                this.toggle(Auth.PASSWORD_UPDATE);
                this.openSnackBar('Confirmation code has been sent successfully');
                break;

              case 'passwordUpdate':
                this.toggle(Auth.LOGIN);
                break;


            }


            this.loading = false;
          }, err => {
            console.log(err);
            this.error = err?.error?.error?.message || err?.statusText;
            this.loading = false;
          }
        );
    }
  }


  setupForm() {
    if (this.form) {
      this.form.reset();
      this.form.clearValidators();
      this.form.clearAsyncValidators();
      this.form.markAsUntouched();
      this.form.markAsPristine();
      this.error = null;
    }

    const fields = FormValiations.getFields(this.loginToggle);
    const options = FormValiations.getOptions(this.loginToggle);
    this.form = this.fb.group({}, {...options});
    if (options) {
    }
    fields.forEach(cF => {

      this.form.addControl(cF, new FormControl(this[cF] ? this[cF].toString() : '', [...FormValiations.getValidation(cF)]));

    });


  }


  toggle(mode) {

    switch (mode) {
      case 'LOGIN':
        this.loginToggle = Auth.LOGIN;
        break;
      case 'REGISTER':
        this.loginToggle = Auth.REGISTER;
        break;
      case 'PASSWORD_RESET':
        this.loginToggle = Auth.PASSWORD_RESET;
        break;
      case 'PASSWORD_UPDATE':
        this.loginToggle = Auth.PASSWORD_UPDATE;
        break;
      case 'ADMIN_CONFIRMATION':
        this.loginToggle = Auth.ADMIN_CONFIRMATION;
        break;
    }
    this.error = null;


    this.setupForm();
  }
}



