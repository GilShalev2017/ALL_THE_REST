import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginComponent} from './login/login.component';
import {IsLoggedIn} from './is-logged-in';
import {FullScreenComponent} from '../layouts/full-screen.component';


const routes: Routes = [
  {
    path: '',
    component: FullScreenComponent,
    pathMatch: 'full',
    resolve: [IsLoggedIn],
    children: [
      {
        path: '',
        component: LoginComponent
      }
    ]
  },
  {path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule],
  providers: [IsLoggedIn]
})

export class AuthenticationRoutingModule {
}
