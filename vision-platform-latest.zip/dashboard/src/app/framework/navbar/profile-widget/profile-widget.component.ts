import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {ProfileWidgetService} from './profile-widget.service';
import {UserService} from '../../authentication/user.service';

@Component({
  selector: 'app-profile-widget',
  templateUrl: './profile-widget.component.html',
  styleUrls: ['./profile-widget.component.css']
})
export class ProfileWidgetComponent implements OnInit {

  name = '';
  email = '';

  constructor(private profileWidgetService: ProfileWidgetService, private cd: ChangeDetectorRef, private userService: UserService) { }

  ngOnInit(): void {
    this.profileWidgetService.profileLabel.subscribe(label => {
      this.name = label.name;
      this.email = label.email;
    });
    this.userService.getUserDetails().subscribe((me) => {
      this.name = me.firstName + ' ' + me.lastName;
      this.email = me.email;
    });
  }

}
