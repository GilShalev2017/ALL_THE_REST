import {ChangeDetectorRef, Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild} from '@angular/core';
import {BreakpointObserver, Breakpoints} from '@angular/cdk/layout';
import {Observable} from 'rxjs';
import {map, shareReplay} from 'rxjs/operators';
import {NavbarConfig, NavbarItem} from './navbar-config';
import {MatSidenav} from '@angular/material/sidenav';
import {NavbarService} from './navbar.service';
import {UserService} from '../authentication/user.service';
import {Router} from '@angular/router';
import {environment} from '../../../environments/environment';
import {Location} from '@angular/common';
import {ChangeDetection} from '@angular/cli/lib/config/schema';
import {DevicesService} from '../../demo/devices/devices.service';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnChanges {
  options: NavbarConfig;
  menuItems: NavbarItem[] = [];
  version: string = environment.version;

  @ViewChild('drawer') public sidenav: MatSidenav;

  showIconsOnCollapse = false;

  admin = false;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private router: Router,
              private breakpointObserver: BreakpointObserver,
              private navbarService: NavbarService,
              private userService: UserService, private devicesService: DevicesService) {}

  ngOnInit(): void {
    this.options = this.navbarService.getConfig();
    this.showIconsOnCollapse = this.options.showIconsOnCollapse;
    if (!this.showIconsOnCollapse && this.options.openOnStart === undefined) {
      this.options.openOnStart = true;
    }
    this.admin = this.userService.isAdmin();
    this.filterOptions();
    // const SenseItArn = 'arn:aws:greengrass:us-east-1:435076512082:components:SenseIt';
    // this.devicesService.getModuleVersions(SenseItArn).subscribe(vers => {
    //   this.devicesService.marketplace[this.devicesService.marketplace.length - 1].moduleVersion = vers[0].componentVersion;
    // });
  }

  filterOptions() {
    this.menuItems = [];
    if (this.admin) {
      this.menuItems = this.options.items;
      return;
    }
    for (const item of this.options.items) {
      if (!item.onlyAdmin) {
        this.menuItems.push(item);
      }
    }
  }

  overSidenav() {
    this.sidenav.open();
  }

  outSidenav() {
    if (this.showIconsOnCollapse || !this.options.openOnStart) {
      this.sidenav.close();
    }
  }

  toggleCollapse() {
    // this.showIconsOnCollapse = !this.showIconsOnCollapse;
    // if (this.showIconsOnCollapse) {
    //   this.sidenav.open();
    // }
    if (this.sidenav.opened) {
      this.sidenav.close();
      this.showIconsOnCollapse = true;
    } else {
      this.sidenav.open();
      this.showIconsOnCollapse = false;
    }
  }

  handleMenuClick(item: NavbarItem) {
    if (item.displayName === 'Logout') {
      this.userService.logout();
      return false;
    }
    if (!item.target) {
      this.router.navigateByUrl(item.path);
      return false;
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.admin = this.userService.isAdmin();
    this.filterOptions();
  }
}
