pwd
export VERSION=0.0.$CI_PIPELINE_IID
aws s3 sync dist/ s3://$S3_BUCKET_NAME/ --exclude "*.js"
aws s3 sync dist/ s3://$S3_BUCKET_NAME/ --exclude "*" --include "*.js" --content-type application/javascript
aws cloudfront create-invalidation --distribution-id $CLOUDFRONT_DIST --paths "/*"

sed -i "s/<base href=\"\/\">/<base href=\"\/${VERSION}\/\">/" dist/index.html
aws s3 sync dist/ s3://$S3_BUCKET_NAME/$VERSION --exclude "*.js"
aws s3 sync dist/ s3://$S3_BUCKET_NAME/$VERSION --exclude "*" --include "*.js" --content-type application/javascript
aws cloudfront create-invalidation --distribution-id $CLOUDFRONT_DIST --paths "/*"

#if [[ "$CI_PUBLISH" == "true" || "$CI_COMMIT_BRANCH" == "production" ]]
#then
#  aws s3 sync dist/ s3://vision-platform-stable/ --exclude "*.js"
#  aws s3 sync dist/ s3://vision-platform-stable/ --exclude "*" --include "*.js" --content-type application/javascript
#  aws cloudfront create-invalidation --distribution-id E15TBCSSLZGVMK --paths "/*"
#fi
#
#if [[ "$CI_COMMIT_BRANCH" == "master" ]]
#then
#  aws s3 sync dist/ s3://vision-platform-vpdev/ --exclude "*.js"
#  aws s3 sync dist/ s3://vision-platform-vpdev/ --exclude "*" --include "*.js" --content-type application/javascript
#  aws cloudfront create-invalidation --distribution-id E3F1EK4RR9KJ4T --paths "/*"
#
#  sed -i "s/<base href=\"\/\">/<base href=\"\/${VERSION}\/\">/" dist/index.html
#  aws s3 sync dist/ s3://vision-platform-vpdev/$VERSION --exclude "*.js"
#  aws s3 sync dist/ s3://vision-platform-vpdev/$VERSION --exclude "*" --include "*.js" --content-type application/javascript
#  aws cloudfront create-invalidation --distribution-id E3F1EK4RR9KJ4T --paths "/*"
#fi

