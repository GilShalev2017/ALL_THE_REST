'use strict';

var fs = require('fs');
let request = require('request');
const { exec } = require("child_process");
var iotHubTransport = require('azure-iot-device-mqtt').Mqtt;
var Client = require('azure-iot-device').Client;
var Message = require('azure-iot-device').Message;

// You can change the following using statement if you would like to try another protocol.
var Transport = require('azure-iot-provisioning-device-mqtt').Mqtt;
// var Transport = require('azure-iot-provisioning-device-amqp').Amqp;
// var Transport = require('azure-iot-provisioning-device-amqp').AmqpWs;
// var Transport = require('azure-iot-provisioning-device-http').Http;
// var Transport = require('azure-iot-provisioning-device-mqtt').MqttWs;

// Local BE credentials
// const url = 'http://localhost:3070';
const url = 'http://a60bef7aff0a144e5a557bcef46d2992-1168452b97545ef0.elb.us-east-1.amazonaws.com'
const email = process.argv[2] ?  process.argv[2] : 'roy.gilmilel@gmail.com';
// Options
const password = process.argv[3] ? process.argv[3] : 'A123456789';

var X509Security = require('azure-iot-security-x509').X509Security;
var ProvisioningDeviceClient = require('azure-iot-provisioning-device').ProvisioningDeviceClient;


let provisioningHost = "global.azure-devices-provisioning.net";
// let idScope = "0ne0029217F";


// Device unique identifier and certificates
var registrationId = "roy-x509";
var deviceCert = {
    cert: fs.readFileSync("./certificates/device.cert.pem").toString(),
    key: fs.readFileSync("./certificates/device.key.pem").toString()
};

var transport = new Transport();
var securityClient = new X509Security(registrationId, deviceCert);


console.log('Registering...');

async function login(email, password) {
    console.log('===> Logging in...');
    let requestUrl = url + '/users/login';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'POST',
            body: {
                email: email,
                password: password
            },
            json: true,
            url: requestUrl
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    console.log(error);
                    reject('===> Login failed:', error);
                }
                resolve(body);
            })
    });
}

async function getUserDetails(token) {
    console.log('===> Getting user details ...');
    let requestUrl = url + '/users/me';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'GET',
            json: true,
            url: requestUrl,
            headers: {
                'Authorization':'Bearer ' + token
            }
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    reject('===> Get user failed: ', error);
                }
                console.log(body);
                resolve(body);
            })
    });
}

async function enrollDevice(deviceId, token) {
    console.log(`===> Enrolling device ${deviceId}...`);
    const certificate = fs.readFileSync("./certificates/device.cert.pem").toString()
    let requestUrl = url + '/devices/enroll';
    return new Promise((resolve, reject) => {
        var options = {
            method: 'POST',
            body: {
                deviceId: deviceId,
                certificate: certificate
            },
            json: true,
            url: requestUrl,
            headers: {
                'Authorization':'Bearer ' + token
            }
        };
        request(options,
            function (error, response, body) {
                if (error) {
                    // reject('===> Enroll device failed: ', error);
                    resolve('===> Enroll failed', error)
                }
                resolve(body);
            })
    });
}

async function registerDevice(idScope) {
    let deviceClient = ProvisioningDeviceClient.create(provisioningHost, idScope, transport, securityClient);

    try {
        // Register the device.  Do not force a re-registration.
        const res = await deviceClient.register();
        console.log('Registration succeeded');
        console.log('assigned hub=' + res.assignedHub);
        console.log('deviceId=' + res.deviceId);
        var connectionString = 'HostName=' + res.assignedHub + ';DeviceId=' + res.deviceId + ';x509=true';
        var hubClient = Client.fromConnectionString(connectionString, iotHubTransport);
        hubClient.setOptions(deviceCert);
        hubClient.open(function(err) {
            if (err) {
                console.error('Failure opening iothub connection: ' + err.message);
            } else {
                console.log('Client connected');
                var message = new Message('Hello world');
                hubClient.sendEvent(message, function(err, res) {
                    if (err) console.log('send error: ' + err.toString());
                    if (res) console.log('send status: ' + res.constructor.name);
                    process.exit(1);
                });
            }
        });
    } catch(e) {
        console.log('failed to register device', e)
    }

}

async function start() {
    try {
        const token = (await login(email, password)).token.accessToken;
        console.log(token);

        // Get user details
        const user = await getUserDetails(token);
        console.log(user);
        const idScope = user.cloudProvider.dpsIdScope;
        console.log('===> DPS idScope: ' + idScope);
        const enrollment = await enrollDevice(registrationId, token);
        console.log(enrollment);

        const edgeConfig = fs.readFileSync("/etc/aziot/config.toml").toString()
        fs.writeFile('/etc/aziot/config.toml.cp.' + new Date(), edgeConfig, function (err) {
            if (err) return console.log(err);
            console.log('===> Backed up Azure config');
        });

        const config = `
    [provisioning]
    source = "dps"
    global_endpoint = "https://global.azure-devices-provisioning.net"
    id_scope = "${idScope}"
    [provisioning.attestation]
    method = "x509"
    registration_id = "${registrationId}"
    identity_cert = "file:///home/ubuntu/enroll/certificates/device.cert.pem"
    identity_pk = "file:///home/ubuntu/enroll/certificates/device.key.pem"
    `
        fs.writeFile('/etc/aziot/config.toml', config, function (err) {
            if (err) return console.log(err);
            console.log('===> Azure Config updated');
        });

        console.log('===> Applying new configuration to edgeClient and provisioning device ...')

        exec("iotedge config apply", (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
                return;
            }
            if (stderr) {
                console.log(`stderr: ${stderr}`);
                return;
            }
            console.log(`stdout: ${stdout}`);
            console.log(`===> Device ${registrationId} provisioning finished`)
        });
        // const register = await registerDevice(idScope);

    } catch (e) {
        console.log(e);
    }
}

start();
