#!/bin/sh

export AWS_PROFILE=vision
kubectl config use-context arn:aws:eks:us-east-1:739177214603:cluster/vpdev
