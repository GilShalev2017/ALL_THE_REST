import {exec, spawn} from "child_process";
import * as util from "util";
// import {debug} from "../index";
//
// export const debug = async () => {
//     const all_args = await parsePromise;
//     // @ts-ignore
//     return all_args.debug;
// };

export class RunShellCommand {
    static async asPromise(command: string, args: string[], cwd: string = "") {
        const commandStr = command + ' ' + args.join(' ');

        const {stdout, stderr} = await util.promisify(exec)(commandStr, cwd ? {
            cwd: cwd
        } : {});
        console.log("$ ", commandStr);
        console.log('stdout:', stdout);

        if (stderr) {
            console.error('stderr:', stderr);
        }
        return stdout;
    }

    static async spawnAsPromise(command: string, args: string[], cwd: string = "", output = false): Promise<void> {
        return new Promise<void>(async (resolve, reject) => {
            console.log("$ ", command, args.join(' '));
            const child = spawn(command, args, cwd ? {
                cwd,
                shell: true
            } : {});

            //if (output || await debug()) {
            if (output) {
                child.stdout.setEncoding('utf8').on('data', (chunk) => {
                    console.log(`[${command}]`, chunk);
                });
            }
            child.stderr.setEncoding('utf8').on('data', (chunk) => {
                console.log(`[${command} error]`, chunk);
            });

            child.on('close', (code) => {
                // @ts-ignore
                if (code > 0) {
                    console.log(`[${command}] child process exited with code ${code}`);
                    reject();
                } else {
                    resolve();
                }
            });
        });

    }

}
