import {UserServiceApplication} from '../..';
import {
    createRestAppClient,
    givenHttpServerConfig,
    Client,
} from '@loopback/testlab';
import {AwsUtilsService} from "../../services/aws-utils.service"
import {FileSystem} from "../../services/file-system"

const fs = require('fs')


const sendEmail = async () => {
    // const report = await fs.readFileSync("service/src/__tests__/report.txt");
    // console.log("send email test-helper")
    // await AwsUtilsService.sendEmail("snir.pern@intel.com", "Tests", report.toString());
}

let counter = 0;
let testsAmount: number;

export async function setupApplication(): Promise<AppWithClient> {
    if (!testsAmount) {
        const filesList = FileSystem.getFilesInFolder("service/src/__tests__/unit", []);
        testsAmount = filesList.length;
        console.log(testsAmount)

    }

    ++counter;
    const restConfig = givenHttpServerConfig({
        // Customize the server configuration here.
        // Empty values (undefined, '') will be ignored by the helper.
        //
        // host: process.env.HOST,
        // port: +process.env.PORT,
    });

    const app = new UserServiceApplication({
        rest: restConfig,
    });
    app.onStop(async () => {
        console.log("counter ----->" + counter)
        if (counter === testsAmount) {
            await sendEmail();
        }
    })
    await app.boot();


    await app.migrateSchema({existingSchema: "drop"});
    console.log("finished migratin schema");
    await app.start();

    const client = createRestAppClient(app);

    return {app, client};
}

export interface AppWithClient {
    app: UserServiceApplication;
    client: Client;
}

