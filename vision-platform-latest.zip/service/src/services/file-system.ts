import {HttpErrors, param, Request, requestBody, Response, RestBindings} from "@loopback/rest";
import {inject} from "@loopback/core";
import {AssetUrlResponse, Item} from "../models";
import fs from "fs";
import multer from "multer";
import {ItemRepository} from "../repositories";
import archiver from "archiver";
import path from "path";

const AWS = require('aws-sdk');

export class FileSystem {

    static createDirectory(dirPath: string) {
        try {
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, {recursive: true});
            }
        } catch (e) {
            console.log("error in creating dir", e);
        }
    }

    static uploadToS3(request: Request, response: Response, itemRepository: ItemRepository): Promise<AssetUrlResponse> {
        const folder = process.cwd() + process.env.STORAGE_FOLDER;
        console.log("folder to save the images = " + folder);
        const storage = multer.diskStorage({
            destination: function (req, file, cb) {
                const filename = (file.fieldname === '__root' || !file.fieldname) ? '' : file.fieldname;
                const dest = folder + filename;
                FileSystem.createDirectory(dest);
                cb(null, dest);
            },
            filename: function (req, file, cb) {
                cb(null, file.originalname);
            }
        })

        return new Promise<AssetUrlResponse>(((resolve, reject) => {
            const upload = multer({storage: storage})
            upload.any()(request, response, async (err: any) => {
                if (err) {
                    console.log("Error saving file", err);
                    reject(err);
                } else {
                    console.log(`Successfully saved file to local storage`);
                    const saveFileType = request.body.saveFileType;
                    let bucketName = process.env.S3_BUCKET_NAME!;
                    const originalName = request.body.imageFileName;
                    let dstFileKey = `assets/components/${originalName}`;
                    let cloudFrontUrl = `https://${process.env.CLOUDFRONT_URL}/assets/components/${originalName}`;
                    if(saveFileType === 'ASSET') {
                        bucketName = process.env.S3_BUCKET_NAME!;
                        dstFileKey = `assets/components/${originalName}`;
                        cloudFrontUrl = `https://${process.env.CLOUDFRONT_URL}/assets/components/${originalName}`;
                    }
                    else if(saveFileType === 'ARTIFACT') {
                        bucketName = process.env.VP_COMPONENTS_BUCKET!;
                        const componentName = request.body.componentName;
                        const componentVersion = request.body.componentVersion;
                        dstFileKey = `artifacts/${componentName}/${componentVersion}/${originalName}`;
                        //cloudFrontUrl = `https://${process.env.COMPONENTS_CLOUDFRONT_URL}/artifacts/${componentName}/${componentVersion}/${originalname}`;
                    }
                    const localFilePath = `${folder}fileKey/${originalName}`;
                    const resultUrl = await FileSystem.uploadFileToS3(localFilePath, bucketName, dstFileKey);
                    console.log("Result S3 URL: " + resultUrl);
                    const assetUrlResponse: AssetUrlResponse = {
                        assetUrl: cloudFrontUrl
                    };
                    resolve(assetUrlResponse);
                }
            });
        }))
    }

    static async removeFileFromS3(id: string) {
        try {
            const s3 = new AWS.S3({
                accessKeyId: process.env.AWS_ACCESS_KEY_ID,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION
            });
            const key = `assets/components/${id}`;
            const bucketName = process.env.S3_BUCKET_NAME!;
            const deleteParams = {
                Bucket: bucketName,
                Key: key
            };
            const result = await s3.deleteObject(deleteParams).promise();
            return result;
        }
        catch (e) {
            console.log("Failed to delete asset file", e.message)
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    static async uploadFileToS3(localFilePath: string, bucketName: string, fileKey: string): Promise<string> {
        const s3 = new AWS.S3({
            accessKeyId: process.env.AWS_ACCESS_KEY_ID,
            secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
        });
        // Read content from the file
        const fileContent = fs.readFileSync(localFilePath);
        // Setting up S3 upload parameters
        const uploadParams = {
            Bucket: bucketName,
            Key: fileKey,// File name you want to save as in S3
            Body: fileContent
        };
        const result = await s3.upload(uploadParams, function (err: any, data: { Location: any; }) {
            if (err) {
                console.log("Error", err);
                throw err;
            }
            if (data) {
                console.log("S3 URL: " + data.Location);
                return data.Location;
            }
        }).promise();

        return result?.Location;
    }

    static upload(request: Request, id: string, response: Response, itemRepository: ItemRepository): Promise<Item> {
        const folder = process.env.STORAGE_FOLDER + id + "/";
        const storage = multer.diskStorage({
            destination: function (req, file, cb) {
                const filename = (file.fieldname === '__root' || !file.fieldname) ? '' : file.fieldname;
                const dest = folder + filename;
                FileSystem.createDirectory(dest);
                cb(null, dest);
            },
            filename: function (req, file, cb) {
                cb(null, file.originalname);
            }
        })
        return new Promise<Item>(((resolve, reject) => {
            const upload = multer({storage: storage})
            upload.any()(request, response, (err: any) => {
                if (err) {
                    console.log("Error saving file", err);
                    reject(err);
                } else {
                    console.log(`Succesfully uploaded ${request.files.length} files for ${id}`);
                    resolve(itemRepository.create(new Item({
                        key: "new" + new Date().getTime(),
                        userId: "user"
                    })));
                }
            });
        }))
    }

    static getFirstFileInFolder(dirPath: string) {
        return new Promise<string>((resolve, reject) => {
            fs.promises.readdir(dirPath).then(files => {
                if (files && files.length > 0) {
                    for (const file of files) {
                        if (file.indexOf('1.png') > -1) {
                            resolve(file);
                            return;
                        }
                    }
                }
                reject(null);
            }).catch(err => {
                console.log("Error reading folder", err);
                reject(err);
            })
        })
    }

    static getFileAsString(filePath: string): Promise<string> {
        return new Promise<string>((resolve, reject) => {
            fs.promises.readFile(filePath, "utf8").then(data => {
                resolve(data);
            }).catch(err => {
                console.log("Error reading file", err);
                reject(err);
            });
        })
    }

    static securePath(relativePath: string) {
        const absolutePath = path.resolve(process.env.STORAGE_FOLDER, relativePath);
        if (!absolutePath.startsWith(process.env.STORAGE_FOLDER)) {
            throw new Error("Error fetching file: Insecure file " + relativePath);
        }
    }

    static zipFolder(folder: string, outputPath: string): Promise<null> {
        return new Promise<null>((resolve, reject) => {
            const output = fs.createWriteStream(outputPath);
            const archive = archiver('zip', {
                zlib: {level: 9} // Sets the compression level.
            });
            output.on('close', function () {
                console.log("[zip]", archive.pointer() + ' total bytes');
                console.log("[zip]", 'archiver has been finalized and the output file descriptor has closed.');
                resolve();
            });
            archive.on('error', function (err) {
                console.log("Error creating zip", err);
                reject(err);
            });
            archive.pipe(output);
            archive.directory(folder + '/color', 'color');
            archive.directory(folder + '/depth', 'depth');
            archive.file(folder + '/metadata.json', {name: 'metadata.json'});
            void archive.finalize();
        });
    }

    static getFilesInFolder(directoryPath: string, filesArr: string[]): string[] {
        const filesInDirectory = fs.readdirSync(directoryPath);
        for (const file of filesInDirectory) {
            const absolute = path.join(directoryPath, file);
            if (fs.statSync(absolute).isDirectory()) {
                this.getFilesInFolder(absolute, filesArr);
            } else {
                filesArr.push(absolute);
            }

        }
        return filesArr;

    }
}
