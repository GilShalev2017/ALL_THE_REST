import {AwsUtilsService} from "./aws-utils.service";

export class TestUtils {
    static timeOut(time?: number): Promise<void> {
        return new Promise(resolve => {
            setTimeout(() => {
                resolve()
            }, time ?? 5000);
        })
    }


    static async extractCodeParameter(randomEmail: string): Promise<{ isCurrentUser: boolean, codeParameter: string }> {
        const latestFile = await AwsUtilsService.getLatestFileInBucket('mevolve-tests-artifacts')
        let isCurrentUser = false;
        let fileDate = false;

        //check if latest file has been added in last two minutes minute in order to correlate with current user
        if (latestFile?.LastModified) {
            fileDate = latestFile.LastModified.valueOf() > (new Date().valueOf() - 60000*2);
        }
        if (!fileDate) {
            return {isCurrentUser: false, codeParameter: ""};
        }
        let codeParameter = "";
        if (latestFile.Body) {
            try {
                const html = latestFile.Body.toString();
                isCurrentUser = html.indexOf(randomEmail.toString()) > -1 ?? false;
                const cpStartIndex = html.indexOf('Your verification code is');
                const cpEndIndex = html.indexOf('.', cpStartIndex);
                const row = html.substring(cpStartIndex, cpEndIndex);
                codeParameter = row.toString().replace(/[^0-9]/g, "");

            } catch (e) {
                console.log(e);
                return {isCurrentUser: false, codeParameter: ""};
            }
        }
        return {isCurrentUser: isCurrentUser, codeParameter: codeParameter.toString().trim()}
    }
}
