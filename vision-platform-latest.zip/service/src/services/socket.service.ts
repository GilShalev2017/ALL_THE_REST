import {bind, BindingScope, inject, Context, Application} from "@loopback/core";
import express from "express";
import http from "http";
import {Server} from "socket.io";

@bind({scope: BindingScope.SINGLETON})
export class SocketService {
    constructor(@inject.context() private ctx: Context) {
        console.log("Init socket service");
        this.init();
    }

    async init() {

        const app = express();
        const server = http.createServer(app);
        const io = new Server(server, {
            path: '/socket',
            cors: {
                origin: '*',
            }
        });

        app.get('/', (req, res) => {
            res.send("Hello world");
        });

        io.on('connection', (socket) => {
            console.log('a user connected');
        });

        server.listen(8080, () => {
            console.log('listening on *:8080');
        });
    }
}
