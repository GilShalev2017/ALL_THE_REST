declare global {
    namespace NodeJS {
        interface ProcessEnv {
            SCOE_APP_NAME: string;
            MONGODB: string;
            RABBITMQ: string;
            STORAGE_FOLDER: string;
            LOCAL?: boolean;
            SERVICE_ID: string;
            AWS_COGNITO_CLIENT_ID: string;
            AWS_COGNITO_USER_POOL: string;
            AWS_COGNITO_CLIENT_SECRET: string;
            AUTHENTICATION_STRATEGY: "LOCAL" | "COGNITO"
        }
    }
}

// If this file has no import/export statements (i.e. is a script)
// convert it into a module by adding an empty export statement.
export {}
