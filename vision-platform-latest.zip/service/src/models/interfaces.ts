import {QMessegeType} from "./enums.model";
import {User} from "../micro-services/users/user.model";
import {Feature} from "../micro-services/iot/feature.model";

export interface QMessage {
    type: QMessegeType;
}

export interface QMessageJobStart extends QMessage {
    jobId: string;
}

export interface GetUsersResponse {
    users: User[];
    count: number;
}

export interface GetFeaturesResponse {
    features: Feature[];
    count: number;
}

export interface AssetUrlResponse {
    assetUrl: string;
}
