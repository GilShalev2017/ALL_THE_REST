import {DefaultCrudRepository} from '@loopback/repository';
import {Confirmation, ConfirmationRelations} from '../../models';
import {DbDataSource} from '../../datasources';
import {inject} from '@loopback/core';

export class ConfirmationRepository extends DefaultCrudRepository<
  Confirmation,
  typeof Confirmation.prototype.id,
  ConfirmationRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Confirmation, dataSource);
  }
}
