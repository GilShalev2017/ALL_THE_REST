import {Model, model, property} from '@loopback/repository';

export enum CloudProvider {
    AWS = 'AWS',
    AZURE = 'AZURE'
}

@model()
export class UserCloudProvider extends Model {

    @property({
        type: 'boolean',
    })
    intelManaged: boolean;

    @property({
        type: 'string',
    })
    connectionString: string;

    @property({
        type: 'string',
    })
    clientId: string;

    @property({
        type: 'string',
    })
    secret: string;

    @property({
        type: 'string',
    })
    tenantId: string;

    @property({
        type: 'string',
    })
    subscriptionId: string;

    @property({
        type: 'string',
    })
    eventsHubConnectionString: string;

    @property({
        type: 'string',
    })
    iotDomainName: string;

    @property({
        type: 'string',
    })
    dpsServiceOperationsHostName: string | undefined;

    @property({
        type: 'string',
    })
    dpsIdScope: string | undefined;

    @property({
        type: 'string',
    })
    dpsKey: string | undefined;

    @property({
        type: 'string',
        jsonSchema: {
            enum: Object.values(CloudProvider),
        },
    })
    provider: CloudProvider;
}
