import {DefaultCrudRepository} from '@loopback/repository';
import {RequestsRate, RequestsRateRelations} from '../../models';
import {DbDataSource} from '../../datasources';
import {inject} from '@loopback/core';

export class RequestsRateRepository extends DefaultCrudRepository<
  RequestsRate,
  typeof RequestsRate.prototype.requestID,
  RequestsRateRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(RequestsRate, dataSource);
  }
}
