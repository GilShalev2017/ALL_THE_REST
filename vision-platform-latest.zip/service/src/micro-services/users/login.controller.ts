import {authenticate} from '@loopback/authentication';
import {Credentials, MyUserService, TokenObject, UserServiceBindings,} from '@loopback/authentication-jwt';
import {inject, service} from '@loopback/core';
import {repository} from '@loopback/repository';
import {
    get,
    getModelSchemaRef,
    HttpErrors,
    param,
    post,
    put,
    Request,
    requestBody,
    Response,
    RestBindings,
    SchemaObject,
} from '@loopback/rest';
import {AuthorizationService} from '../../services/authorization.service';
import {SecurityBindings, securityId, UserProfile} from '@loopback/security';
import {CloudProvider, MevolveUserRelations, NewMevolveUserModel, User} from "../../models";
import {ConfirmationRepository, RequestsRateRepository, UserRepository} from "../../repositories";
import {AzureUtilsService} from "../../services";
import {
    AbstractAuthService,
    EmailRequest,
    getRequestSchema,
    getResponseSchema,
    ILoginResponseBase,
    LoginResponse,
    LoginResponseBase,
    PasswordResetRequest,
    RefreshGrant
} from "./logic/abstract-auth.service";
import {groupARNPrefix} from "../iot/logic/aws-iot.service";

const TokenResponseSchema: SchemaObject = {
    type: 'object',
    properties: {
        accessToken: {type: 'string'},
        refreshToken: {type: 'string'}
    }
}

const LoginResponseSchema: SchemaObject = {
    type: 'object',
    properties: {
        identifier: {type: 'string'},
        token: TokenResponseSchema,
        admin: {type: 'boolean'},
        id: {type: 'string'}
    }
}

const CredentialsSchema: SchemaObject = {
    type: 'object',
    required: ['email', 'password'],
    properties: {
        email: {
            type: 'string',
            format: 'email',
        },
        password: {
            type: 'string',
            minLength: 8,
        },
    },
};
const RefreshGrantSchema: SchemaObject = {
    type: 'object',
    required: ['refreshToken'],
    properties: {
        refreshToken: {
            type: 'string',
        },
        oldAccessToken: {
            type: 'string',
        },
    },
};

// Describes the request body of grant object
const RefreshGrantRequestBody = {
    description: 'Reissuing Acess Token',
    required: true,
    content: {
        'application/json': {schema: RefreshGrantSchema},
    },
};

export const CredentialsRequestBody = {
    description: 'The input of login function',
    required: true,
    content: {
        'application/json': {schema: CredentialsSchema},
    },
};

export class LoginController {
    constructor(
        @inject('services.AuthService') private authService: AbstractAuthService,
        @inject(UserServiceBindings.USER_SERVICE)
        public userService: MyUserService,
        @inject(SecurityBindings.USER, {optional: true})
        public user: UserProfile,
        @repository(UserRepository) protected userRepository: UserRepository,
        @service(AuthorizationService) public authorizationService: AuthorizationService,
        @repository(ConfirmationRepository) public confirmationRepository: ConfirmationRepository,
        @repository(RequestsRateRepository) public requestRateRepository: RequestsRateRepository,
        @inject(RestBindings.Http.RESPONSE) private response: Response,
        @inject(RestBindings.Http.REQUEST) private request: Request,
    ) {
        this.response.setTimeout(600000);
        this.request.setTimeout(600000);
    }


    @authenticate('jwt')
    @put('/users/removeUserBan', {
        responses: {
            '200': {
                description: 'Remove user ban',
                content: {
                    'application/json': {},
                },
            },
        },
    })
    async removeUserBan(
        @inject(SecurityBindings.USER)
            data: { host: string, email: string }
    ): Promise<boolean> {

        const {host, email} = data;

        if (email || host) {
            try {
                await this.requestRateRepository.updateAll({retries: 0}, {or: [{email: email}, {host: host}]});
            } catch (e) {
                console.error(e)

                throw new HttpErrors.InternalServerError("Internal server error occurred");

            }

        }
        return true;
    }

    @post('/users/login', {
        responses: {
            '200': {
                description: 'Token',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                token: TokenResponseSchema,
                                admin: {
                                    type: 'boolean',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async login(
        @requestBody(CredentialsRequestBody) credentials: Credentials,
    ): Promise<LoginResponse> {
        return this.authService.login(credentials);
    }

    @post('/users/refreshToken', {
        responses: {
            '200': {
                description: 'Refresh Token',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                accessToken: {
                                    type: 'string',
                                },

                            },
                        },
                    },
                },
            },
        },
    })
    async refresh(
        @requestBody(RefreshGrantRequestBody) refreshGrant: RefreshGrant,
    ): Promise<TokenObject> {
        return this.authService.refresh(refreshGrant);
    }

    @authenticate('jwt')
    @get('/users/me', {
        responses: {
            '200': {
                description: '',
                content: {
                    'application/json': {
                        schema: {
                            'x-ts-type': User,
                        },
                    },
                },
            },
        },
    })
    async getMe(
        @inject(SecurityBindings.USER)
            currentUserProfile: UserProfile,
    ): Promise<User & MevolveUserRelations> {
        return this.userRepository.findById(currentUserProfile[securityId]);
    }

    @authenticate('jwt')
    @put('/users/me', {
        responses: {
            '200': {
                description: '',
                content: {
                    'application/json': {
                        schema: {
                            'x-ts-type': User,
                        },
                    },
                },
            },
        },
    })
    async editMe(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(User, {
                        title: 'NewUser',
                    }),
                },
            },
        })
            user: User,
        @inject(SecurityBindings.USER)
            currentUserProfile: UserProfile,
    ): Promise<void> {
        if (user?.cloudProvider?.provider === CloudProvider.AZURE) {
            if (!user.cloudProvider.connectionString) {
                await AzureUtilsService.createUserSpace(user);
            } else {
                user.cloudProvider.iotDomainName = user.cloudProvider.connectionString.split(';')[0].split('=')[1];
                console.log("splitted", user.cloudProvider.connectionString, user.cloudProvider.iotDomainName);
            }
        } else if (user?.cloudProvider?.provider === CloudProvider.AWS) {
            user.cloudProvider.iotDomainName = groupARNPrefix + "group-" + new Date().getTime();
        }
        await this.userRepository.updateById(currentUserProfile[securityId], user);
    }


    @post('/users/validateConfirmationCode/{confirmationCode}', {
        responses: {
            '200': {
                description: 'User',
                content: {
                    'application/json': {},
                },
            },
        },
    })


    async validateConfirmationCode(
        @param.path.string('confirmationCode') confirmationCode: string
    ): Promise<{ token: string, identifier: "confirmationCodeValidation" }> {
        console.log(confirmationCode)
        if (!confirmationCode || confirmationCode.toString().length < 6) {
            throw new HttpErrors.Unauthorized('Confirmation code is invalid')

        }


        const confirmationCodeRes = await this.authorizationService.confirmationCodeValidator(confirmationCode);
        const newToken = confirmationCodeRes?.length > 0 && confirmationCodeRes[0]?.token ? confirmationCodeRes[0].token : '-1';
        const userId = confirmationCodeRes?.length > 0 && confirmationCodeRes[0].userId ? confirmationCodeRes[0].userId : undefined;
        if (!userId) {
            return {token: newToken, identifier: "confirmationCodeValidation"};

        }

        return {token: newToken, identifier: "confirmationCodeValidation"};
    }

    @post('/users/passwordUpdate', getResponseSchema(LoginResponseBase))
    async passwordUpdate(
        @requestBody(getRequestSchema(PasswordResetRequest)) data: PasswordResetRequest
    ): Promise<ILoginResponseBase> {
        if (!data || !data.confirmationCode || !data.password) {
            throw new HttpErrors.Unauthorized('Confirmation code is invalid')
        }

        return this.authService.resetPassword(data);
    }

    @post('/users/passwordReset', getResponseSchema(LoginResponseBase))
    async passwordReset(
        @requestBody(getRequestSchema(EmailRequest)) data: EmailRequest
    ): Promise<ILoginResponseBase> {
        return this.authService.forgotPassword(data.email);
    }

    @post('/users/initial', {
        responses: {
            '200': {
                description: 'User',
                content: {
                    'application/json': {
                        schema: {
                            'x-ts-type': User,
                        },
                    },
                },
            },
        },
    })
    async initial(
        @requestBody({
            content: {
                'application/json': {
                    schema: {},
                },
            },
        })
            newUserRequest: NewMevolveUserModel,
    ): Promise<boolean> {

        if (!newUserRequest || !newUserRequest.email) {
            return false;
        } else {
            await this.signUp(newUserRequest);
            return true;
        }
        return true;

    }

    @post('/users/signup', {
        summary: 'Signup a new user or verify a user registration',
        description:    '<h2>Sign up request endpoint</h2><br>' +
            '<b>Sign up Flow</b> - when "verificationToken" is not provided we will signUp the user with' +
            ' the given credentials using the selected Auth strategy (default is Cognito)<br>' +
            '<b>Confirm Sign up Flow</b> - when "verificationToken" is provided we will confirm the user' +
            ' sign up using the provided token',
        responses: {
            '200': {
                description: 'On sign up, identifier = "confirmationCodeRequired", no additional params<br>On verification, identifier = "login" with additional token provided',
                content: {
                    'application/json': {
                        schema: LoginResponseSchema,
                        example: {
                            admin: false,
                            identifier: "login",
                            token: {
                                accessToken: "eyJraWQiOiJrRVEyOG85ZmRxV1ZxUm5Hd2RrWW5xVmJNc29CNFV6TzZPNzhLQ...",
                                expiresIn: "3600",
                                refreshToken: "eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAi...",
                            }
                        },
                    },
                },
            }
        }
    })
    async signUp(
        @requestBody({
            required: true,
            content: {
                'application/json': {
                    schema: getModelSchemaRef(NewMevolveUserModel, {
                        title: 'NewUser',
                    }),
                    example: {
                        "email": "example@intel.com",
                        "firstName": "John",
                        "lastName": "Doe",
                        "password": "ieADRK4gT3iH",
                        "authLevel": "USER",
                    }
                },
            },
        })
            newUserRequest: NewMevolveUserModel,
    ): Promise<LoginResponse> {
        return this.authService.signUp(newUserRequest);
    }

}
