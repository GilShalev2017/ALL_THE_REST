import {DefaultCrudRepository} from '@loopback/repository';
import {inject} from '@loopback/core';
import {RefreshToken} from "./refresh-token.model";
import {DbDataSource} from "../../datasources";

export class RefreshTokenRepository extends DefaultCrudRepository<
  RefreshToken,
  typeof RefreshToken.prototype.id,
    RefreshToken
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(RefreshToken, dataSource);
  }
}
