import {del, get, getModelSchemaRef, HttpErrors, param, patch, post, put, requestBody,} from '@loopback/rest';
import {CloudProvider, Device, User} from '../../models';
import {AzureUtilsService} from "../../services";
import {authenticate} from "@loopback/authentication";
import {inject} from "@loopback/core";
import {SecurityBindings} from "@loopback/security";
import {AwsIotService} from "./logic/aws-iot.service";
import {
    AbstractIotService, Deployment,
    EnrollmentResponse,
    Modules,
    NewModuleRequest,
    NewMultipleModuleRequest,
    StreamUrl, IotEvent, Module, CreateModuleVersionRequest, GetModuleArtifactRequest
} from "./logic/abstract-iot.service";
import {Enroll, EnrollDelete} from "./enroll.model";
import {repository} from "@loopback/repository";
import {UserRepository} from "../users/user.repository";
import {AzureIotService} from "./logic/azure-iot.service";
import {ComponentVersionListItem, GetComponentResponse} from "aws-sdk/clients/greengrassv2";
import {GetObjectOutput} from "@aws-sdk/client-s3";
import {Readable} from "stream";

interface AzureDevice {
    deviceId: string;
    authType?: string;
    autoGenKeys?: boolean;
    primaryKey?: string;
    secondaryKey?: string;
    edgeEnabled?: boolean;
    hubEnabled?: boolean;
    iotDomainName?: string;
}

@authenticate('jwt')
export class DeviceController {
    constructor(
        @repository(UserRepository) protected userRepository: UserRepository
    ) {
    }

    public static getUserIoTService(user: User): AbstractIotService {

        if (user.cloudProvider?.provider === CloudProvider.AWS) {
            return new AwsIotService(user);
        }
        if (user.cloudProvider?.provider === CloudProvider.AZURE) {
            return new AzureIotService(user);
        }

        // If cloudProvider is not configured use AWS as default.
        return new AwsIotService(user);

        // throw new HttpErrors.InternalServerError('no-cloudprovider');
    }

    private static toDeviceModelDomain(azureDevice: AzureDevice, user: User) {
        return {
            ...azureDevice,
            id: azureDevice.deviceId,
            name: azureDevice.deviceId,
            edgeEnabled: true,
            iotDomainName: user ? user.cloudProvider?.iotDomainName ?? 'moshe-iot-1.azure-devices.net' : null
        }
    }

    @post('/devices', {
        responses: {
            '200': {
                description: 'Device model instance',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                deviceId: {
                                    type: 'string',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async create(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Device, {
                        title: 'NewDevice',
                        exclude: ['id'],
                    }),
                },
            },
        })
            device: Omit<Device, 'id'>,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<Device> {
        return DeviceController.getUserIoTService(currentUserProfile).createDevice(device);
    }


    @post('/devices/enroll', {
        responses: {
            '200': {
                description: 'Device enroll model instance',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                deviceId: {
                                    type: 'string',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async enroll(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Enroll, {
                        title: 'NewDeviceEnroll',
                    }),
                },
            },
        })
            enroll: Enroll,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<EnrollmentResponse> {
        if (enroll.caCertificate) {
            return DeviceController.getUserIoTService(currentUserProfile).createDeviceEnrollment(enroll.deviceId, enroll.certificate, enroll.caCertificate);
        }
        return DeviceController.getUserIoTService(currentUserProfile).createDeviceEnrollment(enroll.deviceId, enroll.certificate);
    }

    @post('/devices/enroll/delete', {
        responses: {
            '200': {
                description: 'Device enroll model instance',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                deviceId: {
                                    type: 'string',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async deleteEnroll(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(EnrollDelete, {
                        title: 'DeviceEnrollDelete',
                    }),
                },
            },
        })
            enroll: EnrollDelete,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<void> {
        return DeviceController.getUserIoTService(currentUserProfile).deleteDeviceEnrollment(enroll.deviceId);
    }


    @put('/devices/{id}', {
        responses: {
            '200': {
                description: 'Device model instance',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                deviceId: {
                                    type: 'string',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async update(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Device, {
                        title: 'NewDevice',
                        exclude: ['id'],
                    }),
                },
            },
        })
            device: Omit<Device, 'id'>,
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<Device> {
        return DeviceController.getUserIoTService(currentUserProfile).updateDevice(device);
    }


    //
    // @get('/devices/count', {
    //   responses: {
    //     '200': {
    //       description: 'Device model count',
    //       content: {'application/json': {schema: CountSchema}},
    //     },
    //   },
    // })
    // async count(
    //   @param.where(Device) where?: Where<Device>,
    // ): Promise<Count> {
    //   return this.deviceRepository.count(where);
    // }

    @get('/devices', {
        responses: {
            '200': {
                description: 'Array of Device model instances',
                content: {
                    'application/json': {
                        schema: {
                            type: 'array',
                            devices: getModelSchemaRef(Device, {includeRelations: true}),
                        },
                    },
                },
            },
        },
    })
    async find(
        @inject(SecurityBindings.USER) currentUserProfile: User,
    ): Promise<Device[]> {
        return DeviceController.getUserIoTService(currentUserProfile).getUserDevices();
    }

    @get('/devices/{id}/events')
    async getEvents(
        @param.path.string('id') id: string,
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.query.string('module') module: string,
        @param.query.string('time') time: string,
    ): Promise<Object[] | string[]> {
        return DeviceController.getUserIoTService(currentUserProfile).getEvents(id, module, time);
    }

    // @patch('/devices', {
    //   responses: {
    //     '200': {
    //       description: 'Device PATCH success count',
    //       content: {'application/json': {schema: CountSchema}},
    //     },
    //   },
    // })
    // async updateAll(
    //   @requestBody({
    //     content: {
    //       'application/json': {
    //         schema: getModelSchemaRef(Device, {partial: true}),
    //       },
    //     },
    //   })
    //   device: Device,
    //   @param.where(Device) where?: Where<Device>,
    // ): Promise<Count> {
    //   return this.deviceRepository.updateAll(device, where);
    // }
    //
    @get('/devices/{id}/modules')
    async findById(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string,
    ): Promise<Modules> {
        return DeviceController.getUserIoTService(currentUserProfile).getDeviceModules(id);
    }

    @get('/devices/{id}')
    async getDeviceById(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string,
    ): Promise<Device> {
        return DeviceController.toDeviceModelDomain(await AzureUtilsService.getDevice(currentUserProfile, id), currentUserProfile);
    }

    @get('/devices/module/{name}/{version}')
    async describeModuleByName(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('name') name: string,
        @param.path.string('version') version: string,
    ): Promise<Module> {
        return DeviceController.getUserIoTService(currentUserProfile).describeModule(name, version);
    }

    @get('/devices/module/recipe/{arn}')
    async getModuleByName(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('arn') arn: string,
    ): Promise<GetComponentResponse> {
        return DeviceController.getUserIoTService(currentUserProfile).getModule(arn);
    }

    @get('/devices/module/versions/{arn}')
    async getModuleVersionByArn(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('arn') arn: string,
    ): Promise<ComponentVersionListItem[] | undefined> {
        return DeviceController.getUserIoTService(currentUserProfile).getModuleVersions(arn);
    }

    // @get('/devices/module/artifact/{uri}')
    // async getArtifactByUri2(
    //     @inject(SecurityBindings.USER) currentUserProfile: User,
    //     @param.path.string('uri') uri: string,
    // ): Promise<Readable | ReadableStream | Blob | undefined> {
    //     return DeviceController.getUserIoTService(currentUserProfile).getModuleArtifact(uri);
    // }

    @post('/devices/module/artifact/get', {
        summary: 'Get module artifact ',
        description: 'Get artifact',
        responses: {
            '200': {
            },
        },
    })
    async getArtifactByUri(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @requestBody(
            {
                description: 'Create an artifact for module version',
                required: true,
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                uri: {type: 'string'},
                            }
                        }
                    },
                    example: {}
                }
            }) getArtifactRequest: GetModuleArtifactRequest
    ): Promise<Readable | ReadableStream | Blob | undefined> {
        return DeviceController.getUserIoTService(currentUserProfile).getModuleArtifact(getArtifactRequest);
    }


    @post('/devices/module/artifact/', {
        summary: 'Save module version',
        description: 'Uploads an artifact and create a new module version',
        responses: {
            '200': {
            },
        },
    })
    async createModuleVersion(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @requestBody(
            {
                description: 'Create an artifact for module version',
                required: true,
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                componentName: {type: 'string'},
                                componentVersion: {type: 'string'},
                                bucket: {type: 'string'},
                                key: {type: 'string'},
                                recipe: {type: 'string'},
                                code: {type: 'string'}
                            }
                        }
                    },
                    example: {}
                }
            }) createRequest: CreateModuleVersionRequest
    ): Promise<void> {
        return DeviceController.getUserIoTService(currentUserProfile).createModuleVersion(createRequest)
    }


    @post('/devices/{id}/deploy', {
        summary: 'Deploy device modules',
        description: 'Deploy modules belong to specific device ',
        responses: {
            '200': {
                content: {
                    'application/json': {
                        schema: {properties: {deploymentId: {type: 'string'}}},
                    },
                },
            },
        },
    })
    async updateById(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string,
        @requestBody(
            {
                description: 'Start deployment for a device',
                required: true,
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                moduleName: {type: 'string'},
                                moduleVersion: {type: 'string'},
                                moduleUri: {type: 'string'},
                                connectionString: {type: 'string'}
                            }
                        }
                    },
                    example: {}
                }
            }) body: NewModuleRequest
    ): Promise<Deployment> {
        return DeviceController.getUserIoTService(currentUserProfile).deployModules(id, body)
    }

    @patch('/devices/multiple/{id}')
    async updateMultipleById(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string,
        @requestBody() body: NewMultipleModuleRequest
    ): Promise<void> {
        await DeviceController.getUserIoTService(currentUserProfile).deployMultipleModules(id, body);
    }

    @del('/devices/{id}/deleteModule/{moduleName}', {
        summary: 'Delete specific module from device',
        description: 'Delete specific module from device',
        responses: {
            '200': {
                content: {
                    'application/json': {
                        schema: {properties: {deploymentId: {type: 'string'}}},
                    },
                },
            },
        },
    })
    async deleteModule(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string,
        @param.path.string('moduleName') moduleName: string,
    ): Promise<Deployment> {
        return DeviceController.getUserIoTService(currentUserProfile).deleteModules(id, moduleName.toString().trim());
    }

    //
    // @put('/devices/{id}', {
    //   responses: {
    //     '204': {
    //       description: 'Device PUT success',
    //     },
    //   },
    // })
    // async replaceById(
    //   @param.path.string('id') id: string,
    //   @requestBody() device: Device,
    // ): Promise<void> {
    //   await this.deviceRepository.replaceById(id, device);
    // }
    //
    @del('/devices/{id}', {
        responses: {
            '204': {
                description: 'Device DELETE success',
            },
        },
    })
    async deleteById(@inject(SecurityBindings.USER) currentUserProfile: User, @param.path.string('id') id: string): Promise<void> {
        return DeviceController.getUserIoTService(currentUserProfile).deleteDeviceEnrollment(id);
    }


    @get('/devices/deviceDeployments/{deviceId}', {
        description: 'List deployments in device',
        responses: {
            '200': {
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                deploymentId: {type: 'string'},
                                deploymentStatus: {type: 'string'}
                            }
                        },
                    },
                },
            },
        },
    })
    async listDeviceDeployments(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('deviceId') deviceId: string,
    ): Promise<Deployment> {
        try {
            return await new AwsIotService(currentUserProfile).getLatestDeployment(deviceId, {})
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);

        }
    }

    @get('/devices/deploymentStatus/{deploymentId}', {
        responses: {
            '200': {
                description: 'Deployment status',
                content: {
                    'application/json': {
                        schema: {
                            type: 'string'
                        },
                    },
                },
            },
        },
    })
    async getDeploymentStatus(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('deploymentId') deploymentId: string,
    ): Promise<{ deploymentStatus: string }> {
        return new AwsIotService(currentUserProfile).getDeploymentsStatus(deploymentId)
    }

    @get('/devices/mobileTest/{id}', {
        responses: {
            '204': {
                description: 'Device provision starting',
            },
        },
    })
    async mobileTest(@inject(SecurityBindings.USER) currentUserProfile: User, @param.path.string('id') id: string): Promise<string> {
        return DeviceController.getUserIoTService(currentUserProfile).mobileTest(id);
    }

    @get('/devices/{id}/stream-url')
    async getDeviceStreamUrl(
        @inject(SecurityBindings.USER) currentUserProfile: User,
        @param.path.string('id') id: string,
    ): Promise<StreamUrl> {
        return new AwsIotService(currentUserProfile).getDeviceStreamUrl(id);
    }


}
