import {
    AbstractIotService,
    CreateModuleVersionRequest,
    Deployment,
    EnrollmentResponse, GetModuleArtifactRequest,
    Module,
    Modules,
    NewModuleRequest,
    NewMultipleModuleRequest
} from "./abstract-iot.service";
import {User} from "../../users/user.model";
import {Device} from "../device.model";
import {AzureUtilsService} from "../../../services";
import {Mockdevice} from "../mockdevice.model";
import {Group} from "../group.model";
import {GetComponentResponse} from 'aws-sdk/clients/greengrassv2';
import {GetObjectOutput} from "@aws-sdk/client-s3";
import {Readable} from "stream";
import {GreengrassV2} from "aws-sdk";
import {Feature} from "../feature.model";

interface AzureDevice {
    deviceId: string;
    authType?: string;
    autoGenKeys?: boolean;
    primaryKey?: string;
    secondaryKey?: string;
    edgeEnabled?: boolean;
    hubEnabled?: boolean;
    iotDomainName?: string;
}

export class AzureIotService extends AbstractIotService {

    deleteComponent(componentArn: string): void {
    }

    createComponent(feature: Omit<Feature, "id">): Promise<Feature> {
        return Promise.resolve(new Feature());
    }

    getComponents(): Promise<Feature[]> {
        return Promise.resolve([]);
    }

    constructor(user: User, update = false) {
        super();
        this.user = user;
    }

    public toDeviceModel(azureDevice: AzureDevice) {
        return {
            ...azureDevice,
            id: azureDevice.deviceId,
            name: azureDevice.deviceId,
            edgeEnabled: true,
            iotDomainName: this.user? this.user.cloudProvider?.iotDomainName ?? 'moshe-iot-1.azure-devices.net' : null
        }
    }

    async getUserDevices(): Promise<Device[]> {
        const devices = await AzureUtilsService.listDevices(this.user);
        return devices.map(device => this.toDeviceModel(device));
    }

    getDeviceModules(deviceId: string): Promise<Modules> {
        return AzureUtilsService.getModules(this.user, deviceId)
    }

    async deployModules(deviceId: string, moduleRequest: NewModuleRequest): Promise<Deployment> {
        await AzureUtilsService.deployModules(this.user, deviceId, moduleRequest.moduleName, moduleRequest.moduleUri, moduleRequest.connectionString);
        return {};
    }

    deployMultipleModules(deviceId: string, moduleRequest: NewMultipleModuleRequest): Promise<Deployment> {
        return Promise.resolve({});
    }

    deleteModules(deviceId: string, moduleName: string): Promise<Deployment> {
        return AzureUtilsService.deleteModule(this.user, deviceId, moduleName);
    }

    async createDevice(device: Omit<Device, "id">): Promise<Device> {
        return this.toDeviceModel(await AzureUtilsService.createDevice(this.user, device));
    }

    async createDeviceEnrollment(deviceId: string, certificate: string): Promise<EnrollmentResponse> {
        console.log(this.user);
        return AzureUtilsService.createDeviceEnrollment(this.user, deviceId, certificate);
    }

    async deleteDeviceEnrollment(deviceId: string): Promise<void> {
        console.log(this.user);
        return AzureUtilsService.deleteDeviceEnrollment(this.user, deviceId);
    }

    async mobileTest(deviceId: string): Promise<string> {
        console.log(this.user);
        return 'Success';
    }

    async updateDevice(device: Omit<Device, "id">): Promise<Device> {
        return this.toDeviceModel(await AzureUtilsService.createDevice(this.user, device, true))
    }

    getEvents(deviceId: string, module: string, time: string): Promise<string[]> {
        return AzureUtilsService.getEvents(deviceId);
    }

    sendToDevice(deviceId: string, module: string, message: string): Promise<void> {
        return AzureUtilsService.sendToModule(AzureUtilsService.getConnectionString(this.user), deviceId, module, message);
    }


    async getUserGroups(currentUserProfile: User): Promise<Group[]> {
        return Promise.resolve([]);
    }
    getMockDevices(): Promise<Mockdevice[]> {
        return Promise.resolve([]);
    }

    isDeviceExist(deviceId: string): Promise<boolean> {
        return Promise.resolve(false);
    }

    createVirtualMachine(deviceName: string) : Promise<void> {
        return Promise.resolve();
    }

    enrollDevice(mockdevice: Mockdevice) : Promise<void>{
        return Promise.resolve();
    }

    rebootMockDevice(deviceName: string) {

    }

    createUserGroup(currentUserProfile: User, group: Group): Promise<Group> {
        return Promise.resolve(new Group());
    }

    deleteUserGroup(name: string): Promise<void> {
        return Promise.resolve(undefined);
    }

    getGroupByName(name: string): Promise<Group> {
        return Promise.resolve(new Group());
    }

    getGroupDevicesByName(name: string): Promise<string[]> {
        return Promise.resolve([]);
    }


    deleteMockDevice(deviceId: string) {

    }

    describeModule(componentName: string, componentVersion: string): Promise<Module> {
        return Promise.resolve({});
    }

    getModule(arn: string): Promise<GetComponentResponse> {
        return Promise.resolve({recipe: '', recipeOutputFormat: ''});
    }

    getModuleArtifact(getArtifactRequest: GetModuleArtifactRequest): Promise<Readable | ReadableStream | Blob | undefined> {
        return Promise.resolve(undefined);
    }

    createModuleVersion(createRequest: CreateModuleVersionRequest): Promise<void> {
        return Promise.resolve(undefined);
    }

    getModuleVersions(arn: string): Promise<GreengrassV2.ComponentVersionListItem[] | undefined> {
        return Promise.resolve(undefined);
    }

    countUserGroups(currentUserProfile: User): Promise<number> {
        return Promise.resolve(0);
    }
}
