export class AwsEventsService {

    static async createDynamoDBRule(userId: string, module: string) {
        console.log("generating rule");
    }
}
