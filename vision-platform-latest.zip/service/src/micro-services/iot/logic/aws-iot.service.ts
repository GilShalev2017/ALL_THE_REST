import {
    AbstractIotService, CreateModuleVersionRequest, Deployment,
    EnrollmentResponse, GetModuleArtifactRequest,
    Module,
    Modules,
    NewModuleRequest, NewMultipleModuleRequest,
    StreamUrl
} from "./abstract-iot.service";
import {User} from "../../users/user.model";
import {Device} from "../device.model";
import {Mockdevice} from "../mockdevice.model";
import {AwsUtilsService} from "../../../services";
import AWS, {AWSError, GreengrassV2, Iot} from "aws-sdk";
import {
    CloudComponentStatus,
    ComponentDeploymentSpecifications, ComponentVersionListItem, ComponentNameString, ComponentVersionARN, ComponentVersionString,
    CoreDevice, CreateComponentVersionResponse,
    GetComponentRequest,
    GetComponentResponse, ListTagsForResourceRequest, TagValue, Timestamp
} from "aws-sdk/clients/greengrassv2";
import {HttpErrors, RestBindings, tags} from "@loopback/rest";
import {
    AttachPolicyRequest, Attributes,
    RegisterThingRequest,
} from "aws-sdk/clients/iot";

export const groupARNPrefix = 'arn:aws:iot:us-east-1:435076512082:thinggroup/';
export const defaultGroupARN = 'arn:aws:iot:us-east-1:435076512082:thinggroup/GreengrassQuickStartGroup';
import {exec} from 'child_process';
import * as fs from 'fs';
import * as util from 'util'
import {
    ListThingsInThingGroupCommand,
    DescribeThingGroupCommand,
    CreateThingGroupCommand,
    DeleteThingGroupCommand,
    IoTClient,
    ListThingGroupsCommand
} from "@aws-sdk/client-iot";
import {Group} from '../group.model';
import {addProxyToClient} from 'aws-sdk-v3-proxy';
import {AwsEventsService} from "./aws-events.service";
import {RunShellCommand} from "../../../utils/run-shell-command";
import proxy from "proxy-agent";
import {DeviceController} from "../device.controller";
import Http = RestBindings.Http;
import {
    Boolean,
    CreateTagsRequest,
    DescribeInstanceStatusRequest, DescribeInstanceStatusResult,
    ResourceIdList,
    Tag,
    TagList
} from "aws-sdk/clients/ec2";

import {ok} from "assert";
import {Feature} from "../feature.model";
import {GreengrassV2Client, DescribeComponentCommand, GetComponentCommand,
    CreateComponentVersionCommand, ListComponentVersionsCommand, ListComponentsCommand, ListComponentsResponse} from "@aws-sdk/client-greengrassv2";
import {S3Client, GetObjectCommand, PutObjectCommand} from "@aws-sdk/client-s3";
import {Readable} from "stream";
import {Count} from "@loopback/repository";



export interface DeviceThing extends CoreDevice {
    type?: string;
    attributes?: Attributes;
}

export class AwsIotService extends AbstractIotService {
    greengrassv2: GreengrassV2;
    iot: Iot;
    iotClient: IoTClient;
    ggClient: GreengrassV2Client;
    s3Client: S3Client;

    constructor(user: User) {
        super();
        this.user = user;
        AwsUtilsService.config();
        this.greengrassv2 = new AWS.GreengrassV2();
        this.iot = new AWS.Iot();
        this.iotClient = process.env.USE_PROXY ? addProxyToClient(new IoTClient({}),
            {httpsOnly: true}) : new IoTClient({});
        this.ggClient = process.env.USE_PROXY ? addProxyToClient(new GreengrassV2Client({}),
            {httpsOnly: true}) : new GreengrassV2Client({});
        this.s3Client = process.env.USE_PROXY ? addProxyToClient(new S3Client({}),
            {httpsOnly: true}) : new S3Client({});

    }

    async getUserGroups(user: User): Promise<Group[]> {
        console.log('Getting user groups...');
        try {
            const command = new ListThingGroupsCommand({
                parentGroup: user.id
            });
            const response = await this.iotClient.send(command);
            console.log(response.thingGroups)
            return response.thingGroups as Group[];
        } catch (e) {
            if (e?.name === 'ResourceNotFoundException') {
                try {
                    await this.createUserGroup(user, new Group(), true);
                    return [];
                } catch (err) {
                    throw new HttpErrors.InternalServerError(err?.code);
                }
            }
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async createUserGroup(user: User, group: Group, parent = false): Promise<Group> {
        const groupName = parent ? user.id : group.groupName;
        console.log('Creating group ' + groupName);
        try {
            const command = new CreateThingGroupCommand({
                thingGroupName: groupName,
                parentGroupName: parent ? undefined : user.id
            });
            const response = await this.iotClient.send(command);
            return new Group({
                id: response.thingGroupId,
                groupArn: response.thingGroupArn,
                groupName: response.thingGroupName
            });
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async countUserGroups(user: User): Promise<number> {
        const groups = await this.getUserGroups(user)
        return Promise.resolve(groups.length);
    }

    async deleteUserGroup(name: string): Promise<void> {
        console.log("Deleting group " + name)
        try {
            const command = new DeleteThingGroupCommand({
                thingGroupName: name
            });
            const response = await this.iotClient.send(command);
            console.log(response);
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    static toDeviceModel(device: DeviceThing): Device {
        return <Device>{
            ...device,
            deviceId: device.coreDeviceThingName,
            name: device.coreDeviceThingName,
            id: device.coreDeviceThingName,
            type: device.type,
            attributes: device.attributes,
            connectionState: 'Connected'
        };
    }

    static toModule(device: CoreDevice): Device {
        return <Device>{
            ...device,
            deviceId: device.coreDeviceThingName,
            name: device.coreDeviceThingName,
            id: device.coreDeviceThingName,
        };
    }

    async getUserDevices(): Promise<Device[]> {
        try {
            const things = (await this.iot.listThings({}).promise()).things;

            const coreDevices = (await this.greengrassv2.listCoreDevices({
                //thingGroupArn: defaultGroupARN
            }).promise()).coreDevices;
            const thingsMap = new Map();
            if (things) {
                for (const t of things) {
                    if (t.thingName !== undefined) {
                        thingsMap.set(t.thingName, {type: t.thingTypeName, attributes: t.attributes});
                    }
                }
            }

            const merged = coreDevices?.map((e) => {
                return e.coreDeviceThingName ? {...e, ...thingsMap.get(e.coreDeviceThingName)} : e;
            });

            return merged?.map(AwsIotService.toDeviceModel) ?? [];
        } catch (e) {
            console.log("error getting devices", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async describeModule(componentName: string, componentVersion: string): Promise<Module> {
        // [TODO] get ARN for listed installed module, you may build using the region and account
        const arn = `arn:aws:greengrass:us-east-1:435076512082:components:${componentName}:versions:${componentVersion}`;
        const command = new DescribeComponentCommand({
            arn
        });
        try {
            return await this.ggClient.send(command) as Module;
        } catch(e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getModuleArtifact(getArtifactRequest: GetModuleArtifactRequest): Promise<Readable | ReadableStream | Blob | undefined> {
        const split = getArtifactRequest.uri.split('/');
        const bucket = split[2];
        const key = getArtifactRequest.uri.split(bucket + '/')[1];
        console.log(bucket, key);
        const command = new GetObjectCommand({
            Bucket: bucket,
            Key: key
        })
        try {
            return (await this.s3Client.send(command)).Body;
        } catch(e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async createComponentVersion(recipe: string) {
        const utf8encoder = new TextEncoder();
        const input = {
            inlineRecipe: utf8encoder.encode(recipe)
        };
        const command = new CreateComponentVersionCommand(input);
        try {
            const response = await this.ggClient.send(command);
            console.log(response);
        } catch(e) {
            console.log(e)
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async createModuleVersion(createRequest: CreateModuleVersionRequest): Promise<void> {
        const putObjectCmdInput = {
            Bucket: createRequest.bucket,
            Key: createRequest.key,
            Body: createRequest.code
        }
        console.log(createRequest);
        console.log(putObjectCmdInput);
        const command = new PutObjectCommand(putObjectCmdInput);
        try {
            const res = await this.s3Client.send(command);
            console.log(res);
            await this.createComponentVersion(createRequest.recipe);
        } catch(e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getModule(arn: string): Promise<GetComponentResponse> {
        const command = new GetComponentCommand({
            arn
        });
        try {
            const res = await this.ggClient.send(command) as GetComponentResponse;
            return res;
        } catch(e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getModuleVersions(arn: string): Promise<ComponentVersionListItem[] | undefined> {
        console.log(arn);
        const command = new ListComponentVersionsCommand({
            arn
        });
        try {
            const res = await this.ggClient.send(command);
            return res.componentVersions;
        } catch(e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getDeviceModules(deviceId: string): Promise<Modules> {
        try {
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();
            console.log(modules);
            return modules.installedComponents?.reduce((map: Modules, item) => {
                if (item.componentName) {
                    map[item.componentName] = {
                        ...item,
                        status: item.lifecycleState
                    };
                }
                return map;
            }, {}) ?? {};
        } catch (e) {
            console.log("error getting device modules", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async deployModules(deviceId: string, moduleRequest: NewModuleRequest): Promise<{ deploymentId: string }> {
        try {
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();
            const components: ComponentDeploymentSpecifications = {};
            if (modules.installedComponents) {
                for (const installedComponent of modules.installedComponents) {
                    if (installedComponent.componentName) {
                        components[installedComponent.componentName] = {
                            componentVersion: installedComponent.componentVersion,
                            configurationUpdate: {
                                merge: JSON.stringify({
                                    deviceId: deviceId
                                })
                            }
                        }
                    }
                }
            }
            components[moduleRequest.moduleName] = {
                componentVersion: moduleRequest.componentVersion,
                configurationUpdate: {
                    merge: JSON.stringify({
                        deviceId: deviceId
                    })
                }
            }
            const deploymentResponse = await this.greengrassv2.createDeployment({
                targetArn: 'arn:aws:iot:us-east-1:435076512082:thing/' + deviceId,
                components: components
            }).promise();
            console.log(deploymentResponse);
            return {deploymentId: deploymentResponse.deploymentId ?? ""}
        } catch (e) {
            console.log("error deploying module", e);
            throw new HttpErrors.BadRequest(e?.code);
        }
    }

    async deployMultipleModules(deviceId: string, multipleModuleRequest: NewMultipleModuleRequest): Promise<{ deploymentId: string }> {
        try {
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();
            const components: ComponentDeploymentSpecifications = {};
            if (modules.installedComponents) {
                for (const installedComponent of modules.installedComponents) {
                    if (installedComponent.componentName) {
                        components[installedComponent.componentName] = {
                            componentVersion: installedComponent.componentVersion,
                            configurationUpdate: {
                                merge: JSON.stringify({
                                    deviceId: deviceId
                                })
                            }
                        }
                    }
                }
            }
            multipleModuleRequest.selectedModules.forEach(feature => {
                if (feature.name) {
                    components[feature.name] = {
                        componentVersion: feature.componentVersion,
                        configurationUpdate: {
                            merge: JSON.stringify({
                                deviceId: deviceId
                            })
                        }
                    }
                }
            })
            const deploymentResponse = await this.greengrassv2.createDeployment({
                targetArn: 'arn:aws:iot:us-east-1:435076512082:thing/' + deviceId, //For Mevolve
                //targetArn: 'arn:aws:iot:us-east-2:588972610491:thing/' + deviceId, //For ATI
                components: components
            }).promise();
            console.log(deploymentResponse);
            return {deploymentId: deploymentResponse.deploymentId ?? ""}
        } catch (e) {
            console.log("error deploying module", e);
            throw new HttpErrors.BadRequest(e?.code);
        }
    }

    async deleteModules(deviceId: string, moduleName: string): Promise<Deployment> {
        try {
            const modules = await this.greengrassv2.listInstalledComponents({
                coreDeviceThingName: deviceId
            }).promise();
            console.log(modules);
            const components: ComponentDeploymentSpecifications = {};
            if (modules.installedComponents) {
                for (const installedComponent of modules.installedComponents) {
                    if (installedComponent.componentName && installedComponent.componentName !== moduleName) {
                        components[installedComponent.componentName] = {
                            componentVersion: installedComponent.componentVersion
                        }
                    }
                }
            }
            const deploymentResponse = await this.greengrassv2.createDeployment({
                targetArn: 'arn:aws:iot:us-east-1:435076512082:thing/' + deviceId,
                components: components
            }).promise();
            console.log(deploymentResponse);
            return {deploymentId: deploymentResponse.deploymentId ?? ""}
        } catch (e) {
            console.log("error deleting module", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    createDevice(device: Omit<Device, "id">): Promise<Device> {
        return Promise.reject();
    }

    async createDeviceEnrollment(deviceId: string, certificate: string, caCertificate: string): Promise<EnrollmentResponse> {
        const registerCertificateRequest = {
            certificatePem: certificate,
            status: 'ACTIVE',
        };

        try {
            // Instead of registering certificate we will verify the certificate is signed by Intel CA.
            // const certRes = await this.iot.registerCertificateWithoutCA(registerCertificateRequest).promise();
            const createCertParams = {
                setAsActive: true
            };

            const certRes = await this.iot.createKeysAndCertificate(createCertParams).promise();

            console.log('Certificate registered successfully', certRes);

            const attachPolicyRequest: AttachPolicyRequest = {
                policyName: 'GreengrassTESCertificatePolicyVisionPlatformProvisionRoleAlias',
                target: certRes.certificateArn ?? ''
            };
            let res = await this.iot.attachPolicy(attachPolicyRequest).promise();
            console.log('Attach Policy Success', res);
            attachPolicyRequest.policyName = 'GreengrassV2IoTThingPolicy';
            res = await this.iot.attachPolicy(attachPolicyRequest).promise();
            attachPolicyRequest.policyName = 'GreengrassTESCertificatePolicyGreengrassCoreTokenExchangeRoleAlias';
            res = await this.iot.attachPolicy(attachPolicyRequest).promise();
            attachPolicyRequest.policyName = 'GreengrassTESCertificatePolicyGreengrassV2TokenExchangeRoleAlias';
            res = await this.iot.attachPolicy(attachPolicyRequest).promise();

            console.log('Attach Policy Success', res);

            const request: RegisterThingRequest = {
                templateBody: JSON.stringify({
                    "Parameters": {
                        "ThingName": {
                            "Type": "String"
                        },
                        "SerialNumber": {
                            "Type": "String"
                        },
                        "Location": {
                            "Type": "String",
                            "Default": "WA"
                        },
                        "CertificateId": {
                            "Type": "String"
                        }
                    },
                    "Resources": {
                        "thing": {
                            "Type": "AWS::IoT::Thing",
                            "Properties": {
                                "ThingName": {"Ref": "ThingName"},
                                "ThingGroups": ["group-test-1"]
                            },
                            "OverrideSettings": {
                                "AttributePayload": "MERGE",
                                "ThingTypeName": "REPLACE",
                                "ThingGroups": "REPLACE"
                            }
                        },
                        "certificate": {
                            "Type": "AWS::IoT::Certificate",
                            "Properties": {
                                "CertificateId": {"Ref": "CertificateId"}
                            }
                        }
                    }
                }),
                parameters: {
                    'ThingName': deviceId,
                    'CertificateId': certRes.certificateId ?? '',
                }
            }

            res = await this.iot.registerThing(request).promise();
            console.log('Thing registered successfully', res);

            const endpointRequestParams = {
                endpointType: 'iot:CredentialProvider'
            };

            const credEndpoint = (await this.iot.describeEndpoint(endpointRequestParams).promise()).endpointAddress ?? '';
            endpointRequestParams.endpointType = 'iot:Data-ATS'
            const dataEndpoint = (await this.iot.describeEndpoint(endpointRequestParams).promise()).endpointAddress ?? '';

            console.log('Credentials Endpoint: ' + credEndpoint);
            console.log('Data Endpoint: ' + dataEndpoint);
            return {
                certRes,
                dataEndpoint,
                credEndpoint
            };

        } catch (e) {
            console.log('Error creating device enrollment', e);
            return Promise.reject();
        }
    }

    async deleteDeviceEnrollment(deviceId: string): Promise<void> {
        console.log(`==> AWS deleting ${deviceId} enrollment`);
        try {
            const principals = (await this.iot.listThingPrincipals({thingName: deviceId}).promise()).principals;
            if (principals) {
                for (const p of principals) {
                    if (p.includes('cert')) {
                        const certId = p.split('/')[1];
                        await this.iot.updateCertificate({certificateId: certId, newStatus: 'INACTIVE'}).promise();
                        const policies = (await this.iot.listAttachedPolicies({target: p}).promise()).policies;
                        if (policies) {
                            for (const pol of policies) {
                                if (pol.policyName) {
                                    await this.iot.detachPolicy({policyName: pol.policyName, target: p}).promise();
                                }
                            }
                        }
                        await this.iot.detachThingPrincipal({principal: p, thingName: deviceId}).promise()
                        await this.iot.deleteCertificate({certificateId: certId}).promise();
                    }
                }
            }

            await this.greengrassv2.deleteCoreDevice({coreDeviceThingName: deviceId}).promise();
            await this.iot.deleteThing({thingName: deviceId}).promise();

        } catch (e) {
            console.log(`Error: Failed to delete ${deviceId}`, e);
            return Promise.reject(e);
        }
    }

    updateDevice(device: Omit<Device, "id">): Promise<Device> {
        return Promise.reject();
    }

    async getEvents(deviceId: string, module: string, time: string): Promise<Object[]> {
        // console.log('getEvents');
        // console.log(time);
        try {
            const dynamodb = new AWS.DynamoDB();
            const query = {
                TableName: "iot_events_db",
                ScanIndexForward: false,
                ExpressionAttributeValues: {
                    ":id": {
                        S: deviceId
                    },
                    ":name": {
                        S: module
                    },
                    ":time": {
                        N: time
                    }
                },
                KeyConditionExpression: "device_id = :id and sample_time >= :time",
                FilterExpression: "module_name = :name"
            }
            // console.log(query);
            const response = await dynamodb.query(query).promise();
            // const response = await dynamodb.scan({
            //     TableName: "wx_data",
            // }).promise();
            // console.log(response);
            // return response.Items ? (response.Items.map(item => AWS.DynamoDB.Converter.unmarshall(item)) as IotEvent[]) : [];
            return response.Items ? response.Items.map(item => AWS.DynamoDB.Converter.unmarshall(item)) : [];
        } catch (e) {
            console.log("error getting events", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    static async sendToDeviceStatic(deviceId: string, module: string, message: string): Promise<void> {
        try {
            const iotdata = new AWS.IotData({endpoint: 'a1z1niunapoaag-ats.iot.us-east-1.amazonaws.com'});
            const response = await iotdata.publish({
                qos: 0,
                topic: "topic_1",
                payload: JSON.stringify({
                    "message": message
                })
            }).promise()
            console.log(response);
        } catch (e) {
            console.log("error sending to device", e);
        }
    }

    async sendToDevice(deviceId: string, module: string, message: string): Promise<void> {
        await AwsIotService.sendToDeviceStatic('', '', message);
    }

    async mobileTest(deviceId: string): Promise<string> {
        console.log(`==> Provisioning device '${deviceId}' from mobile`)
        const execPromise = util.promisify(exec);
        try {
            // console.log(this.user);
            const pemPath = process.cwd() + "/config/vision.pem"
            // const key = fs.readFileSync(pemPath).toString()
            const host = 'ec2-3-239-174-52.compute-1.amazonaws.com'
            // Start provisioning process on test device
            const downloadCommand = `chmod 0400 ${pemPath} && ssh -i ` + pemPath + ` -oStrictHostKeyChecking=no ubuntu@${host} "cd /home/ubuntu/ && curl http://dn62sfq0w0t3e.cloudfront.net/provision-${deviceId}.tar.gz -o provision-${deviceId}.tar.gz && tar -xvf provision-${deviceId}.tar.gz"`;
            await execPromise(downloadCommand, {maxBuffer: 1024 * 10000});

            const provisionCommand = "ssh -i " + pemPath + ` -oStrictHostKeyChecking=no ubuntu@${host} "cd /home/ubuntu/provision-${deviceId} && sudo -E ./start.sh roy.michael@intel.com A123456789 ${deviceId}"`;
            const {stdout, stderr} = await execPromise(provisionCommand, {maxBuffer: 1024 * 10000});
            if (stderr) {
                console.log(stderr)
                // return stderr;
            }
            console.log(stdout);
            return 'Success';
        } catch (e) {
            return e;
        }
    }

    async getDeviceStreamUrl(deviceId: string): Promise<StreamUrl> {
        try {
            const kinesisVideo = new AWS.KinesisVideo({
                //region: 'us-east-2' //ATI
                region: 'us-east-1'
            });
            const kinesisVideoArchivedContent = new AWS.KinesisVideoArchivedMedia({
                //region: 'us-east-2' //ATI
                region: 'us-east-1'
            });

            const endpoint = await kinesisVideo.getDataEndpoint({
                StreamName: "test-stream",
                APIName: "GET_HLS_STREAMING_SESSION_URL"
            }).promise();

            kinesisVideoArchivedContent.endpoint = new AWS.Endpoint(endpoint.DataEndpoint!);

            const hlsUrl = await kinesisVideoArchivedContent.getHLSStreamingSessionURL({
                StreamName: "test-stream",
            }).promise();

            return {
                url: hlsUrl.HLSStreamingSessionURL!
            };
        } catch (e) {
            return {
                url: 'https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8'
            }
        }
    }

    async getGroupByName(name: string): Promise<Group> {
        console.log('Getting group metadata ', name);
        try {
            const command = new DescribeThingGroupCommand({
                thingGroupName: name
            });
            const response = await this.iotClient.send(command);
            console.log(response)
            return (response as unknown) as Group;
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getGroupDevicesByName(name: string): Promise<string[]> {
        console.log('Getting group devices...', name);
        try {
            const command = new ListThingsInThingGroupCommand({
                thingGroupName: name
            });
            const response = await this.iotClient.send(command);
            console.log(response)
            return response.things ?? [];
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getDeploymentsStatus(deploymentId: string): Promise<{ deploymentStatus: string }> {
        try {

            const deploymentRes = await this.greengrassv2.getDeployment({deploymentId: deploymentId}).promise()
            return {deploymentStatus: deploymentRes?.deploymentStatus ?? ""}
        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getLatestDeployment(deviceId?: string, params?: {
        historyFilter?: string,
        maxResults?: string,
        nextToken?: string,
        targetArn?: string
    }): Promise<Deployment> {
        try {
            const device = await this.iot.describeThing({thingName: deviceId ?? ''}).promise();
            const listDeploymentsRes = await this.greengrassv2.listDeployments({
                historyFilter: "LATEST_ONLY",
                targetArn: device.thingArn
            }).promise()
            const {deployments} = listDeploymentsRes;
            if (deployments && deployments.length >=1 && deployments[0].deploymentStatus !== 'COMPLETED' && deviceId) {
                return {
                    deploymentId: deployments[0].deploymentId,
                    deploymentStatus: deployments[0].deploymentStatus
                }
            }
            return {}

        } catch (e) {
            console.log(e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getMockDevices(): Promise<Mockdevice[]> {
        const ec2 = new AWS.EC2({apiVersion: '2016-11-15'});

        if (process.env.IS_LOCALHOST_ENV?.toString() === "true" || process.env.USE_PROXY) {
            console.log("Using proxy for AWS");
            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            AWS.config.update({httpOptions});
        }

        const mockDevices: Mockdevice[] = [];

        return new Promise<Mockdevice[]>(function (resolve, reject) {
            ec2.describeInstances({}, function (err, data) {
                if (err) {
                    console.error(err.toString());
                    return reject(err)
                } else {
                    data.Reservations?.forEach(element => {
                        element.Instances?.forEach(instance => {
                            if (instance.Tags?.find(tag => tag.Key === 'IsInstanceMockDevice')) {
                                const foundEc2Name = instance.Tags.find(x => x.Key === 'Name');
                                if (foundEc2Name) {
                                    const enrollmentTag = instance.Tags.find(x => x.Key === 'EnrollmentState');
                                    const newMockDevice = new Mockdevice({
                                        id: instance.InstanceId,
                                        deviceName: foundEc2Name?.Value,
                                        publicDns: instance.PublicDnsName,
                                        instanceId: instance.InstanceId,
                                        state: instance.State?.Name?.toUpperCase(),
                                        stateReason: instance.StateReason?.Message?.replace('Client.UserInitiatedShutdown:', ''),
                                        enrollmentState: enrollmentTag?.Value
                                    });
                                    mockDevices.push(newMockDevice);
                                }
                            }
                        })
                    })
                    resolve(mockDevices);
                }
            })
        });
    }

    async isDeviceExist(deviceName: string): Promise<boolean> {
        const params = {
            coreDeviceThingName: deviceName
        };
        try {
            await this.greengrassv2.getCoreDevice(params).promise();
            return true;
        } catch (e) {
            if (e.code === 'ResourceNotFoundException') {
                return false;
            }
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async createVirtualMachine(deviceName: string): Promise<void> {
        const ec2 = new AWS.EC2({apiVersion: '2016-11-15'});
        if (process.env.IS_LOCALHOST_ENV?.toString() === "true" || process.env.USE_PROXY) {
            console.log("Using proxy for AWS");
            const httpOptions = {agent: proxy('http://proxy-us.intel.com:911')}
            AWS.config.update({httpOptions});
        }
        const instanceParams = {
            //ImageId: 'ami-00399ec92321828f5',//'ami im us-east-2 !!!
            ImageId: 'ami-09e67e426f25ce0d7', //ami in us-east-1 !!!
            InstanceType: 't3.medium',
            KeyName: 'gil-greengrass',
            MinCount: 1,
            MaxCount: 1,
            SecurityGroupIds: ["sg-039ef6c475ac4d566", "sg-01d57021407e02397"],//- of the eks cluster TODO hard coded???
            SubnetId: "subnet-00dff95bd6f79e1a1",//choose one of the public subnets - of the eks cluster TODO hard coded???
        };
        await ec2.runInstances(instanceParams).promise()
            .then(async response => {
                const instanceId = response.Instances?.[0].InstanceId;
                if (instanceId) {
                    console.log("Created instance", instanceId);
                    const tagParams: CreateTagsRequest = {
                        Resources: [instanceId],
                        Tags: [
                            {
                                Key: 'Name',
                                Value: deviceName
                            },
                            {
                                Key: 'IsInstanceMockDevice',
                                Value: 'Yes'
                            },
                            {
                                Key: 'EnrollmentState',
                                Value: 'NotEnrolled'
                            }
                        ]
                    };
                    await ec2.createTags(tagParams).promise()
                        .then()
                        .catch(error => {
                            console.log(error.message);
                            throw new HttpErrors.InternalServerError(error?.code);
                        })
                }
            })
            .catch(error => {
                console.log(error.message);
                throw new HttpErrors.InternalServerError(error?.code);
            })
    }

    async deployCloudFormation(stackName: string, cloudformationFile: string, parameters: string[], cwd: string = '') {
        return RunShellCommand.spawnAsPromise("aws", [
            "cloudformation",
            "deploy",
            "--template-file",
            cloudformationFile,
            "--parameter-overrides",
            parameters.join(' '),
            "--stack-name",
            stackName
        ], process.cwd() + cwd);
    }

    async enrollDevice(mockdevice: Mockdevice): Promise<void> {
        console.log("publicDNS=" + mockdevice.publicDns);
        console.log(`==> Provisioning device '${mockdevice.deviceName}'`)
        const execAsyncFunc = util.promisify(exec);
        const tempDeviceName = 'snir-test-device';//'virtual';

        try {
            await this.addEc2EnrollmentTag(mockdevice.instanceId, 'Enrolling');
            const pemPath = process.cwd() + "/config/gil-greengrass.pem" //mevolve
            //const pemPath = process.cwd() + "/config/gils.pem" //ati
            console.log("started provisioning");
            //For Production the following line:
            const downloadCommand = `chmod 0400 ${pemPath} && ssh -i ` + pemPath + ` -oStrictHostKeyChecking=no ubuntu@${mockdevice.publicDns} "cd /home/ubuntu/ && curl http://d2i9lp71nvpny1.cloudfront.net/provision-${tempDeviceName}.tar.gz -o provision-${tempDeviceName}.tar.gz && tar -xvf provision-${tempDeviceName}.tar.gz"`;
            //For Debug time, om Windows -  the following line:
            //const downloadCommand = `ssh -i ` + pemPath + ` -oStrictHostKeyChecking=no ubuntu@${mockdevice.publicDns} "cd /home/ubuntu/ && curl http://d2i9lp71nvpny1.cloudfront.net/provision-${tempDeviceName}.tar.gz -o provision-${tempDeviceName}.tar.gz && tar -xvf provision-${tempDeviceName}.tar.gz"`;
            //const downloadCommand = `ssh -i ` + pemPath + ` -oStrictHostKeyChecking=no ubuntu@${mockdevice.publicDns} "cd /home/ubuntu/ && curl http://d2i9lp71nvpny1.cloudfront.net/provision-${tempDeviceName}.tar.gz -o provision-${tempDeviceName}.tar.gz && tar -xvf provision-${tempDeviceName}.tar.gz"`;
            await execAsyncFunc(downloadCommand, {maxBuffer: 1024 * 10000});
            console.log("finished downloading");
            const provisionCommand = "ssh -i " + pemPath + ` -oStrictHostKeyChecking=no ubuntu@${mockdevice.publicDns} "cd /home/ubuntu/provision-${tempDeviceName} && sudo -E ./start.sh gilshalev2014@gmail.com 12345678 ${mockdevice.deviceName}"`;
            const {stdout, stderr} = await execAsyncFunc(provisionCommand, {maxBuffer: 1024 * 10000});
            console.log("finished provisioning");
            if (stderr) {
                console.log(stderr)
                //throw new HttpErrors.InternalServerError(stderr);
            }
            console.log(stdout);
            await this.addEc2EnrollmentTag(mockdevice.instanceId, 'Enrolled');
        } catch (e) {
            console.log(e)
            await this.addEc2EnrollmentTag(mockdevice.instanceId, 'NotEnrolled');
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async rebootMockDevice(deviceId: string) {
        const ec2 = new AWS.EC2({apiVersion: '2016-11-15'});

        if (process.env.IS_LOCALHOST_ENV?.toString() === "true" || process.env.USE_PROXY) {
            console.log("Using proxy for AWS");
            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            AWS.config.update({httpOptions});
        }
        const params = {
            InstanceIds: [deviceId],
            DryRun: true
        };

        // Call EC2 to reboot instances
        ec2.rebootInstances(params, function (err, data) {
            if (err && err.code === 'DryRunOperation') {
                params.DryRun = false;
                ec2.rebootInstances(params, function (error, data2) {
                    if (error) {
                        console.log("Error", error);
                        throw new HttpErrors.InternalServerError(error.code);
                    } else if (data2) {
                        console.log("Success", data2);
                    }
                });
            } else {
                console.log("You don't have permission to reboot instances.");
                throw new HttpErrors.Unauthorized(err?.code);
            }
        });
    }

    async deleteMockDevice(id: string) {
        //pay attention that the id is composed of the following format: instanceId:${entity.id}-deviceName:${entity.deviceName}
        const instanceId = id.split('instanceId:')[1].split('-deviceName:')[0];
        const deviceName = id.split('-deviceName:')[1];
        console.log(`found instanceId=${instanceId}, deviceName=${deviceName}`);

        try {
            const exist = await this.isDeviceExist(deviceName);
            if (exist) {
                await this.deleteDeviceEnrollment(deviceName);
                await this.addEc2EnrollmentTag(instanceId, 'NotEnrolled');
            }
            const result = await this.stopEc2(instanceId);
            console.log(result);
            const result2 = await this.terminateEc2(instanceId);
            console.log(result2);
        } catch (e) {
            console.log("error getting devices", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async stopEc2(instanceId: string) {
        if (process.env.IS_LOCALHOST_ENV?.toString() === "true" || process.env.USE_PROXY) {
            console.log("Using proxy for AWS");
            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            AWS.config.update({httpOptions});
        }
        // create an ec2 object
        const ec2 = new AWS.EC2({apiVersion: '2016-11-15'});
        // setup instance params
        const params = {
            InstanceIds: [instanceId]
        };
        try {
            await ec2.stopInstances(params).promise();
        } catch (e) {
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async terminateEc2(instanceId: string) {
        if (process.env.IS_LOCALHOST_ENV?.toString() === "true" || process.env.USE_PROXY) {
            console.log("Using proxy for AWS");
            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            AWS.config.update({httpOptions});
        }
        // create an ec2 object
        const ec2 = new AWS.EC2({apiVersion: '2016-11-15'});
        // setup instance params
        const params = {
            InstanceIds: [instanceId]
        };
        try {
            await ec2.terminateInstances(params).promise()
        } catch (e) {
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async addEc2EnrollmentTag(instanceId: string, enrollmentValue: string) {
        if (process.env.IS_LOCALHOST_ENV?.toString() === "true" || process.env.USE_PROXY) {
            console.log("Using proxy for AWS");
            const httpOptions = {agent: proxy("http://proxy-us.intel.com:911")}
            AWS.config.update({httpOptions});
        }
        // create an ec2 object
        const ec2 = new AWS.EC2({apiVersion: '2016-11-15'});

        const tagList: Tag[] = [];

        tagList.push({
            Key: 'EnrollmentState',
            Value: enrollmentValue
        });

        const params: CreateTagsRequest = {
            DryRun: false,
            Resources: [instanceId],
            Tags: tagList
        };

        try {
            await ec2.createTags(params).promise();
            return true;
        } catch (e) {
            if (e.code === 'ResourceNotFoundException') {
                return false;
            }
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async getComponents(): Promise<Feature[]> {
        try {
            const listComponentsResponse: ListComponentsResponse = await this.greengrassv2.listComponents().promise();
            const features: Feature[] = [];
            if (listComponentsResponse?.components) {
                for (const item of listComponentsResponse.components) {
                    if (!item.arn)
                        continue;
                    const feature = new Feature({
                        id: item.componentName ? item.componentName : "",
                        name: item?.componentName,
                        latestVersion: item?.latestVersion?.componentVersion,
                        description: item?.latestVersion?.description,
                    });
                    if (item?.latestVersion?.arn) {
                        const params: ListTagsForResourceRequest = {resourceArn: item.latestVersion.arn};
                        try {
                            const tagsResponse = await this.greengrassv2.listTagsForResource(params).promise();
                            if (tagsResponse.tags?.image_url) {
                                feature.picture = tagsResponse.tags.image_url;
                            }
                        } catch
                            (err) {
                            console.log("error getting component", err);
                        }
                    }
                    features.push(feature);
                }
            }
            return features;
        } catch (e) {
            console.log("error listing Components", e);
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }

    async createComponent(feature: Feature): Promise<Feature> {
        try {
            if (feature.recipe) {
                const componentResponse = await this.greengrassv2.createComponentVersion({
                    inlineRecipe: feature.recipe,//JSON.stringify(componentRecipe),
                    //tags: {[key: 'componentImageUri', TagValue: feature.picture]}
                }).promise();
                feature.componentVersionARN = componentResponse.arn;
                feature.creationTimestamp = componentResponse.creationTimestamp.toString();
                feature.cloudComponentState = componentResponse.status.componentState;
                feature.cloudComponentStateMessage = componentResponse.status.message;
                return feature;
            }
            console.log("Missing Recipe");
            return new Feature();
        } catch (e) {
            console.log("Failed to create component", e.message)
            //In case of a validation error throw something informative!
            //In case of component that is already existsing  throw something informative!
            throw e;//new HttpErrors.InternalServerError(e?.code);
        }
    }

    async deleteComponent(componentArn: string) {
        try {
            await this.greengrassv2.deleteComponent({arn: componentArn}).promise();
        } catch (e) {
            console.log("Failed to delete component", e.message)
            throw new HttpErrors.InternalServerError(e?.code);
        }
    }
}

//const getComponentResponse: GetComponentResponse = await this.greengrassv2.getComponent(params).promise();
// if (item.componentName === 'sql-server') {
//     const i = 'koko';
// }
// if (item.latestVersion.arn === 'arn:aws:greengrass:us-east-1:435076512082:components:sql-server:versions:1.0.0') {
//     const b = 'moko';
// }
// a client can be shared by different commands.
//const client = new GreengrassV2Client({region: "us-east-1"});
//const cmd = new ListComponentsCommand({maxResults: 5});
//const allComponents = await client.send(cmd);

//
// async deployModules(deviceId: string, moduleRequest: NewModuleRequest): Promise<{ deploymentId: string }> {
//     try {
//         let moduleName = moduleRequest.moduleName === 'realsense-ai' ? 'com.intel.realsense' : moduleRequest.moduleName;// + '-' + new Date().getTime();
//         if (moduleRequest.moduleName === 'com.intel.environment') {
//     moduleName = moduleRequest.moduleName;
// }
// const modules = await this.greengrassv2.listInstalledComponents({
//     coreDeviceThingName: deviceId
// }).promise();
//
// const mqttEndpoint = 'a1z1niunapoaag-ats.iot.us-east-1.amazonaws.com';
// const caFile = 'config/root-CA.crt';
// const certFile = 'config/12d1cce52b-certificate.pem.crt';
// const keyFile = 'config/12d1cce52b-private.pem.key';
// const version = Math.floor(Math.random() * 10000);
// const json = moduleRequest.moduleName === 'realsense-ai' ? {
//     "RecipeFormatVersion": "2020-01-25",
//     "ComponentName": "com.intel.realsense",
//     "ComponentVersion": "0.1." + version,
//     "ComponentType": "aws.greengrass.generic",
//     "ComponentDescription": "Docker container with Vision Platform Demo binaries.",
//     "ComponentPublisher": "Intel Corporation",
//     "ComponentConfiguration": {
//         "DefaultConfiguration": {
//             "accessControl": {
//                 "aws.greengrass.ipc.mqttproxy": {
//                     "com.intel.realsense:pubsub:1": {
//                         "policyDescription": "Allows access to publish/subscribe to all topics.",
//                         "operations": [
//                             "aws.greengrass#PublishToIoTCore",
//                             "aws.greengrass#SubscribeToIoTCore"
//                         ],
//                         "resources": [
//                             "*"
//                         ]
//                     }
//                 }
//             },
//             "aws_env": "-e AWS_IOT_THING_NAME=$AWS_IOT_THING_NAME -e AWS_REGION=$AWS_REGION -e SVCUID=$SVCUID -e AWS_GG_NUCLEUS_DOMAIN_SOCKET_FILEPATH_FOR_COMPONENT=$AWS_GG_NUCLEUS_DOMAIN_SOCKET_FILEPATH_FOR_COMPONENT -e AWS_CONTAINER_AUTHORIZATION_TOKEN=$AWS_CONTAINER_AUTHORIZATION_TOKEN -e AWS_CONTAINER_CREDENTIALS_FULL_URI=$AWS_CONTAINER_CREDENTIALS_FULL_URI",
//             "docker_flags": " --device-cgroup-rule \"c 81:* rmw\" --device-cgroup-rule \"c 189:* rmw\" ",
//             "docker_mounts": "-v /dev:/dev -v /greengrass/v2:/greengrass/v2",
//             "docker_volumes": "--mount source=vol_models,target=/app/all_models",
//             "docker_cmd": "./run.sh"
//         }
//     },
//     "ComponentDependencies": {
//         "aws.greengrass.DockerApplicationManager": {
//             "VersionRequirement": "~2.0.0"
//         }
//     },
//     "Manifests": [
//         {
//             "Platform": {
//                 "os": "all"
//             },
//             "Lifecycle": {
//                 "Run": {
//                     "Script": "docker run --rm {configuration:/docker_mounts} {configuration:/docker_volumes} {configuration:/docker_flags} {configuration:/aws_env} public.ecr.aws/h2d5i2r7/librealsense:realsense-app"
//                 }
//             },
//             "Artifacts": [
//                 {
//                     "Uri": "docker:public.ecr.aws/h2d5i2r7/librealsense:realsense-app",
//                     "Unarchive": "NONE",
//                     "Permission": {
//                         "Read": "OWNER",
//                         "Execute": "NONE"
//                     }
//                 }
//             ]
//         }
//     ],
//     "Lifecycle": {}
// } : {
//     "RecipeFormatVersion": "2020-01-25",
//     "ComponentName": moduleName,
//     "ComponentVersion": "0.1." + version,
//     "ComponentDescription": moduleName,
//     "ComponentPublisher": "Amazon",
//     "ComponentConfiguration": {
//         "DefaultConfiguration": {
//             "env": `-e CERT_FILE=${certFile} -e KEY_FILE=${keyFile} -e CA_FILE=${caFile} -e MQTT_ENDPOINT=${mqttEndpoint} -e MQTT_ACCOUNT_NAMESPACE=${this.user.id} -e MQTT_MODULE_ID=${moduleName}`,
//         }
//     },
//     "ComponentDependencies": {
//         "aws.greengrass.DockerApplicationManager": {
//             "VersionRequirement": "~2.0.0"
//         }
//     },
//     "Manifests": [
//         {
//             "Platform": {
//                 "os": "all"
//             },
//             "Lifecycle": {
//                 "Run": `docker run --name ${moduleName} {configuration:/env} mosheshaham/pub:greengrass_5`
//             },
//             "Artifacts": [
//                 {
//                     "URI": "docker:mosheshaham/pub:greengrass_5"
//                 }
//             ]
//         }
//     ]
// }
//
// const components: ComponentDeploymentSpecifications = {};
// // For demo purposes only
// if (moduleName === "com.intel.environment") {
//     components[moduleName] = {
//         componentVersion: '3.0.0',
//     }
// } else {
//     components[moduleName] = {
//         componentVersion: moduleRequest.componentVersion
//     }
// }
// if (modules.installedComponents) {
//     for (const installedComponent of modules.installedComponents) {
//         if (installedComponent.componentName) {
//             components[installedComponent.componentName] = {
//                 componentVersion: installedComponent.componentVersion
//             }
//         }
//     }
// }
// const deploymentResponse = await this.greengrassv2.createDeployment({
//     targetArn: 'arn:aws:iot:us-east-1:435076512082:thing/' + deviceId,
//     components: components
// }).promise();
// console.log(deploymentResponse);
// return {deploymentId: deploymentResponse.deploymentId ?? ""}
// } catch (e) {
//     console.log("error deploying module", e);
//     throw new HttpErrors.BadRequest(e?.code);
// }
// }

// getComponentRecipe(feature: Omit<Feature, 'id'>): any {
//     const componentRecipe = {
//         "RecipeFormatVersion": "2020-01-25",
//         "ComponentName": feature.name,//"com.intel.realsense",
//         "ComponentVersion": feature.componentVersion,//"1.0.0"
//         "ComponentType": "aws.greengrass.generic",
//         "ComponentDescription": feature.description,
//         "ComponentPublisher": "Intel Corporation",
//         "ComponentConfiguration": {
//             "DefaultConfiguration": {
//                 // "Message": "world"
//                 // "accessControl": {
//                 //     "aws.greengrass.ipc.mqttproxy": {
//                 //         "com.intel.realsense:pubsub:1": {
//                 //             "policyDescription": "Allows access to publish/subscribe to all topics.",
//                 //             "operations": [
//                 //                 "aws.greengrass#PublishToIoTCore",
//                 //                 "aws.greengrass#SubscribeToIoTCore"
//                 //             ],
//                 //             "resources": [
//                 //                 "*"
//                 //             ]
//                 //         }
//                 //     }
//                 // },
//                 // "aws_env": "-e AWS_IOT_THING_NAME=$AWS_IOT_THING_NAME -e AWS_REGION=$AWS_REGION -e SVCUID=$SVCUID -e AWS_GG_NUCLEUS_DOMAIN_SOCKET_FILEPATH_FOR_COMPONENT=$AWS_GG_NUCLEUS_DOMAIN_SOCKET_FILEPATH_FOR_COMPONENT -e AWS_CONTAINER_AUTHORIZATION_TOKEN=$AWS_CONTAINER_AUTHORIZATION_TOKEN -e AWS_CONTAINER_CREDENTIALS_FULL_URI=$AWS_CONTAINER_CREDENTIALS_FULL_URI",
//                 // "docker_flags": " --device-cgroup-rule \"c 81:* rmw\" --device-cgroup-rule \"c 189:* rmw\" ",
//                 // "docker_mounts": "-v /dev:/dev -v /greengrass/v2:/greengrass/v2",
//                 // "docker_volumes": "--mount source=vol_models,target=/app/all_models",
//                 // "docker_cmd": "./run.sh"
//             }
//         },
//         // "ComponentDependencies": {
//         //     "aws.greengrass.DockerApplicationManager": {
//         //         "VersionRequirement": "~2.0.0"
//         //     }
//         // },
//         "Manifests": [
//             {
//                 "Platform": {
//                     "os": "all"
//                 },
//                 "Lifecycle": {
//                     "Run": {
//                         "Script": feature.runScript//"docker run --rm {configuration:/docker_mounts} {configuration:/docker_volumes} {configuration:/docker_flags} {configuration:/aws_env} public.ecr.aws/h2d5i2r7/librealsense:realsense-app"
//                     }
//                 },
//                 "Artifacts": [
//                     {
//                         "Uri": feature.artifactUri,//"docker:public.ecr.aws/h2d5i2r7/librealsense:realsense-app",
//                         // "Unarchive": "NONE",
//                         // "Permission": {
//                         //     "Read": "OWNER",
//                         //     "Execute": "NONE"
//                         // }
//                     }
//                 ]
//             }
//         ],
//     }
//     return componentRecipe;
// }

// async deployMultipleModules(deviceId: string, multipleModuleRequest: NewMultipleModuleRequest): Promise<void> {
//     try {
//         const newModuleDate = new Date().getTime();
//         const version = Math.floor(Math.random() * 10000);
//         const components: ComponentDeploymentSpecifications = {};
// for (const feature of multipleModuleRequest.selectedModules) {
//     const newModuleName = feature.name;//+ '-' + newModuleDate; //ve
//     const json = {
//         "RecipeFormatVersion": "2020-01-25",
//         "ComponentName": newModuleName,
//         "ComponentVersion": "0.1." + version,
//         "ComponentDescription": newModuleName,
//         "ComponentPublisher": "Amazon",
//         "Manifests": [
//             {
//                 "Name": "Linux",
//                 "Platform": {
//                     "os": "linux"
//                 },
//                 "Lifecycle": {
//                     "Install": {
//                         "Script": "docker load -i {artifacts:path}/bare-min.tar"
//                     },
//                     "Run": {
//                         "Script": `docker run --rm --name ${newModuleName} bare-min`
//                     }
//                 },
//                 "Artifacts": [
//                     {
//                         "Uri": "s3://scoe-greengrass-artifacts-2/bare-min.tar"
//                     }
//                 ]
//             }
//         ]
//     }
//     const componentResponse = await this.greengrassv2.createComponentVersion({
//         inlineRecipe: JSON.stringify(json)
//     }).promise();
//     console.log(componentResponse);
//
//     if (newModuleName) {
//         components[newModuleName] = {
//             componentVersion: '0.1.' + version
//         }
//     }
// }
// const modules = await this.greengrassv2.listInstalledComponents({
//     coreDeviceThingName: deviceId
// }).promise();
// if (modules.installedComponents) {
//     for (const installedComponent of modules.installedComponents) {
//         if (installedComponent.componentName) {
//             components[installedComponent.componentName] = {
//                 componentVersion: installedComponent.componentVersion
//             }
//         }
//     }
// }
// const deploymentResponse = await this.greengrassv2.createDeployment({
//     targetArn: 'arn:aws:iot:us-east-1:435076512082:thing/' + deviceId, //need to ch
//     components: components
// }).promise();
// console.log(deploymentResponse);
// } catch (e) {
//     console.log("error deploying module", e);
//     throw new HttpErrors.BadRequest(e?.code);
// }
// }
//
// test() {
//     const dynamodb = new AWS.DynamoDB();
//     const params = {
//         TableName: 'iot_events_db',
//         Item: {
//             'device_id': {S: '9999999device'},
//             'sample_time': {N: '112233'},
//             'module_name': {S: 'MymoduleName!!!'},
//             'payload': {S: 'Payload!!!'}
//         }
//     };
//
//     // Call DynamoDB to add the item to the table
//     dynamodb.putItem(params, function (err, data) {
//         if (err) {
//             console.log("Error", err);
//         } else {
//             console.log("Success", data);
//         }
//     });
// }
