import {
    Count,
    CountSchema,
    Filter,
    FilterExcludingWhere, ModelDefinition,
    repository,
    Where,
} from '@loopback/repository';
import {
    post,
    param,
    get,
    getModelSchemaRef,
    patch,
    put,
    del,
    requestBody, HttpErrors,
} from '@loopback/rest';
import {Mockdevice, User} from '../../models';
import {MockdeviceRepository, UserRepository} from '../../repositories';
import AWS from "aws-sdk";
import {RunShellCommand} from "../../utils/run-shell-command";
import {exec} from "child_process";
import util from "util";
import {inject} from "@loopback/core";
import {SecurityBindings} from "@loopback/security";
import proxy from "proxy-agent";
import {DeviceController} from "./device.controller";
import {authenticate} from "@loopback/authentication";

// Load the AWS SDK for Node.js
// Set the region
//TODO remove the hardcoded region

// Create EC2 service object
@authenticate('jwt')
export class MockdeviceController {
    constructor(
        @repository(MockdeviceRepository)
        public mockdeviceRepository: MockdeviceRepository,
        @repository(UserRepository) protected userRepository: UserRepository,
    ) {
    }

    @post('/mockdevices', {
        responses: {
            '200': {
                description: 'Mockdevice model instance',
                content: {'application/json': {schema: getModelSchemaRef(Mockdevice)}},
            },
        },
    })
    async create(@inject(SecurityBindings.USER) currentUserProfile: User,
                 @requestBody({
                     content: {
                         'application/json': {
                             schema: getModelSchemaRef(Mockdevice, {
                                 title: 'NewMockdevice',
                                 exclude: ['id'],
                             }),
                         },
                     },
                 })
                     mockdevice: Omit<Mockdevice, 'id'>,
    ): Promise<Mockdevice> {
        await DeviceController.getUserIoTService(currentUserProfile).createVirtualMachine(mockdevice.deviceName);
        return this.mockdeviceRepository.create(mockdevice);
    }

    @post('/mockdevices/enroll', {
        responses: {
            '200': {
                description: 'Device enroll model instance',
                content: {
                    'application/json': {
                        schema: {
                            type: 'object',
                            properties: {
                                deviceId: {
                                    type: 'string',
                                },
                            },
                        },
                    },
                },
            },
        },
    })
    async enroll(@inject(SecurityBindings.USER) currentUserProfile: User,
                 @requestBody({
                     content: {
                         'application/json': {
                             schema: getModelSchemaRef(Mockdevice, {
                                 title: 'NewMockDeviceEnroll',
                             }),
                         },
                     },
                 })
                     mockdevice: Mockdevice,
    ): Promise<Mockdevice> {
        await DeviceController.getUserIoTService(currentUserProfile).enrollDevice(mockdevice);
        return mockdevice;
    }

    @get('/mockdevices/count', {
        responses: {
            '200': {
                description: 'Mockdevice model count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async count(
        @param.where(Mockdevice) where?: Where<Mockdevice>,
    ): Promise<Count> {
        return this.mockdeviceRepository.count(where);
    }

    @get('/mockdevices', {
        responses: {
            '200': {
                description: 'Array of Mockdevice model instances',
                content: {
                    'application/json': {
                        schema: {
                            type: 'array',
                            mockdevices: getModelSchemaRef(Mockdevice, {includeRelations: true}),
                        },
                    },
                },
            },
        },
    })
    async find(@inject(SecurityBindings.USER) currentUserProfile: User,
               @param.filter(Mockdevice) filter?: Filter<Mockdevice>,
    ): Promise<Mockdevice[]> {
        return DeviceController.getUserIoTService(currentUserProfile).getMockDevices();
    }

    @patch('/mockdevices', {
        responses: {
            '200': {
                description: 'Mockdevice PATCH success count',
                content: {'application/json': {schema: CountSchema}},
            },
        },
    })
    async updateAll(
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Mockdevice, {partial: true}),
                },
            },
        })
            mockdevice: Mockdevice,
        @param.where(Mockdevice) where?: Where<Mockdevice>,
    ): Promise<Count> {
        return this.mockdeviceRepository.updateAll(mockdevice, where);
    }

    @get('/mockdevices/{id}', {
        responses: {
            '200': {
                description: 'Mockdevice model instance',
                content: {
                    'application/json': {
                        schema: getModelSchemaRef(Mockdevice, {includeRelations: true}),
                    },
                },
            },
        },
    })
    async findById(
        @param.path.string('id') id: string,
        @param.filter(Mockdevice, {exclude: 'where'}) filter?: FilterExcludingWhere<Mockdevice>
    ): Promise<Mockdevice> {
        return this.mockdeviceRepository.findById(id, filter);
    }

    @get('/mockdevices/reboot/{id}', {
        responses: {
            '200': {
                description: 'Mockdevice REBOOT success',
            },
        },
    })
    async rebootById(@inject(SecurityBindings.USER) currentUserProfile: User, @param.path.string('id') id: string): Promise<void> {
        return DeviceController.getUserIoTService(currentUserProfile).rebootMockDevice(id);
    }

    @patch('/mockdevices/{id}', {
        responses: {
            '204': {
                description: 'Mockdevice PATCH success',
            },
        },
    })
    async updateById(
        @param.path.string('id') id: string,
        @requestBody({
            content: {
                'application/json': {
                    schema: getModelSchemaRef(Mockdevice, {partial: true}),
                },
            },
        })
            mockdevice: Mockdevice,
    ): Promise<void> {
        await this.mockdeviceRepository.updateById(id, mockdevice);
    }

    @put('/mockdevices/{id}', {
        responses: {
            '204': {
                description: 'Mockdevice PUT success',
            },
        },
    })
    async replaceById(
        @param.path.string('id') id: string,
        @requestBody() mockdevice: Mockdevice,
    ): Promise<void> {
        await this.mockdeviceRepository.replaceById(id, mockdevice);
    }

    @del('/mockdevices/{id}', {
        responses: {
            '204': {
                description: 'Mockdevice DELETE success',
            },
        },
    })
    async deleteById(@inject(SecurityBindings.USER) currentUserProfile: User, @param.path.string('id') id: string): Promise<void> {
        return DeviceController.getUserIoTService(currentUserProfile).deleteMockDevice(id)
    }
}
