import {
  Count,
  CountSchema,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
} from '@loopback/rest';
import {Group, User} from '../../models';
import {GroupRepository, UserRepository} from '../../repositories';
import {inject} from "@loopback/core";
import {SecurityBindings} from "@loopback/security";
import {DeviceController} from "./device.controller";
import {authenticate} from "@loopback/authentication";

@authenticate('jwt')
export class GroupController {
  constructor(
      @repository(UserRepository) protected userRepository: UserRepository,
      @repository(GroupRepository) public groupRepository : GroupRepository,
  ) {}

  @post('/groups', {
    responses: {
      '200': {
        description: 'Group model instance',
        content: {'application/json': {schema: getModelSchemaRef(Group)}},
      },
    },
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Group, {
            title: 'NewGroup',
            exclude: ['id', "groupArn"],
          }),
        },
      },
    })
    group: Omit<Group, 'id'>,
    @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<Group> {
    return DeviceController.getUserIoTService(currentUserProfile).createUserGroup(currentUserProfile, group);
  }

  @get('/groups/count', {
    responses: {
      '200': {
        description: 'Group model count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async count(
    @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<number> {
    return DeviceController.getUserIoTService(currentUserProfile).countUserGroups(currentUserProfile);
  }

  @get('/groups', {
    responses: {
      '200': {
        description: 'Array of Group model instances',
        content: {
          'application/json': {
            schema: {
              type: 'array',
              groups: getModelSchemaRef(Group, {includeRelations: true}),
            },
          },
        },
      },
    },
  })
  async find(
      @inject(SecurityBindings.USER) currentUserProfile: User,
  ): Promise<Group[]> {
    return DeviceController.getUserIoTService(currentUserProfile).getUserGroups(currentUserProfile);
  }

  @patch('/groups', {
    responses: {
      '200': {
        description: 'Group PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Group, {partial: true}),
        },
      },
    })
    group: Group,
    @param.where(Group) where?: Where<Group>,
  ): Promise<Count> {
    return this.groupRepository.updateAll(group, where);
  }

  @get('/groups/{name}', {
    responses: {
      '200': {
        description: 'Group model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Group, {includeRelations: true}),
          },
        },
      },
    },
  })
  async findById(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('name') name: string,
  ): Promise<Group> {
    return DeviceController.getUserIoTService(currentUserProfile).getGroupByName(name);
  }

  @get('/groups/{name}/devices', {
    responses: {
      '200': {
        description: 'Group model instance',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Group, {includeRelations: true}),
          },
        },
      },
    },
  })
  async getDevicesByName(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('name') name: string,
  ): Promise<string[]> {
    return DeviceController.getUserIoTService(currentUserProfile).getGroupDevicesByName(name);
  }


  @patch('/groups/{id}', {
    responses: {
      '204': {
        description: 'Group PATCH success',
      },
    },
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Group, {partial: true}),
        },
      },
    })
    group: Group,
  ): Promise<void> {
    await this.groupRepository.updateById(id, group);
  }

  @put('/groups/{id}', {
    responses: {
      '204': {
        description: 'Group PUT success',
      },
    },
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() group: Group,
  ): Promise<void> {
    await this.groupRepository.replaceById(id, group);
  }

  @del('/groups/{name}', {
    responses: {
      '204': {
        description: 'Group DELETE success',
      },
    },
  })
  async deleteByName(
      @inject(SecurityBindings.USER) currentUserProfile: User,
      @param.path.string('name') name: string
  ): Promise<void> {
    await DeviceController.getUserIoTService(currentUserProfile).deleteUserGroup(name);
  }
}
