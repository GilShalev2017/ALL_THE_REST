import {model, property} from '@loopback/repository';

@model()
export class Enroll {
    @property({
        type: 'string',
    })
    deviceId: string;

    @property({
        type: 'string',
    })
    certificate: string;

    @property({
        type: 'string',
    })
    caCertificate?: string;
}

@model()
export class EnrollDelete {
    @property({
        type: 'string',
    })
    deviceId: string;
}

