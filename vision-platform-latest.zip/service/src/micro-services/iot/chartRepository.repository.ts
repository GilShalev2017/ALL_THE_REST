import {DefaultCrudRepository} from '@loopback/repository';
import {Chart, ChartsWithRelations} from '../../models';
import {DbDataSource} from '../../datasources';
import {inject} from '@loopback/core';

export class ChartRepositoryRepository extends DefaultCrudRepository<
    Chart,
    typeof Chart.prototype.id,
    ChartsWithRelations
    > {
  constructor(
      @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Chart, dataSource);
  }
}
