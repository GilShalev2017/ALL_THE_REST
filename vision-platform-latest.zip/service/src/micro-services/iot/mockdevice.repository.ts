import {DefaultCrudRepository} from '@loopback/repository';
import {Mockdevice, MockdeviceRelations} from '../../models';
import {DbDataSource} from '../../datasources';
import {inject} from '@loopback/core';

export class MockdeviceRepository extends DefaultCrudRepository<
  Mockdevice,
  typeof Mockdevice.prototype.id,
  MockdeviceRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Mockdevice, dataSource);
  }
}
