import {Entity, model, property} from '@loopback/repository';

// export enum SharingType {
//   PRIVATE = 'PRIVATE',
//   PUBLIC = 'PUBLIC',
// }

@model()
export class Feature extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    defaultFn: 'uuidv4',
  })
  id: string;

  @property({
    type: 'string',
    required: true,
  })
  name?: string;

  @property({
    type: 'string',
  })
  description?: string;

  @property({
    type: 'string',
  })
  picture?: string;

  @property({
    type: 'string',
  })
  componentVersion?: string;

  // @property({
  //   type: 'string',
  // })
  // runScript?: string;
  //
  // @property({
  //   type: 'string',
  // })
  // artifactUri?: string;

  @property({
    type: 'string',
  })
  recipe?: string;

  @property({
    type: 'string',
  })
  componentVersionARN?: string;

  @property({
    type: 'string',
  })
  creationTimestamp?: string;

  @property({
    type: 'string',
  })
  cloudComponentState?: string;

  @property({
    type: 'string',
  })
  cloudComponentStateMessage?: string;

  @property({
    type: 'string',
  })
  latestVersion?: string;

  constructor(data?: Partial<Feature>) {
    super(data);
  }
}

export interface FeatureRelations {
  // describe navigational properties here
}

export type FeatureWithRelations = Feature & FeatureRelations;


// @property({
//   type: 'string',
// })
// owner: string;
//
// @property({
//   type: 'string',
//   jsonSchema: {
//     enum: Object.values(SharingType),
//   },
// })
// sharingType?: string;
//
// @property({
//   type: 'string',
// })
// installedComponentVersion?: string;
//

