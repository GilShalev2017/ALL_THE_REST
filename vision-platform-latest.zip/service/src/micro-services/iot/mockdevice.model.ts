import {Entity, model, property} from '@loopback/repository';

@model()
export class Mockdevice extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    defaultFn: 'uuidv4',
  })
  id: string;

  @property({
    type: 'string',
  })
  deviceName: string;

  @property({
    type: 'string',
  })
  instanceId: string;

  @property({
    type: 'string',
  })
  publicDns: string;

  @property({
    type: 'string',
  })
  state: string;

  @property({
    type: 'string',
  })
  stateReason: string;

  @property({
    type: 'string',
  })
  enrollmentState?: string;

  constructor(data?: Partial<Mockdevice>) {
    super(data);
  }
}

export interface MockdeviceRelations {
  // describe navigational properties here
}

export type MockdeviceWithRelations = Mockdevice & MockdeviceRelations;
