import {model, property} from '@loopback/repository';

@model()
export class Device {
  @property({
    type: 'string',
    id: true,
    generated: false,
  })
  id: string;

  @property({
    type: 'string',
  })
  deviceId: string;

  @property({
    type: 'string',
  })
  type?: string;

  @property({
    type: 'object',
  })
  attributes?: string;

  @property({
    type: 'string',
  })
  authType?: string;

  @property({
    type: 'boolean',
  })
  autoGenKeys?: boolean;

  @property({
    type: 'string',
  })
  primaryKey?: string;

  @property({
    type: 'string',
  })
  secondaryKey?: string;

  @property({
    type: 'boolean',
  })
  edgeEnabled?: boolean;

  @property({
    type: 'boolean',
  })
  hubEnabled?: boolean;
}

