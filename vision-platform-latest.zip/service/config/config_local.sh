#!/bin/bash

#export ENV=.env.$(git rev-parse --abbrev-ref HEAD)
export ENV=$1
set -a
source config/.env
source config/.env.$ENV
npm run start:proxy

