﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace VTGDbInserter
{
    public class GeneralSensorEvent
    {
        public string device_id { get; set;}
        public string module_name { get; set; }
        public object payload { get; set; }
    }

    //{"temp": 77, "radiation": 18, "humidity": 39, "wind": 13, "moduleName": "GilsSenseIt"}
}
