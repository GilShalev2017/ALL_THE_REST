﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Common;
using Common.Model;
using Microsoft.AspNetCore.Http;

namespace Fd19ControllerApi.Controllers
{
    [Route("api/[controller]")]
    public class FlinkJarsController : ControllerBase
    {
        ILogger Logger { get; set; }

        public FlinkJarsController(IConfiguration configuration, ILogger<DeploymentController> logger)
        {
            this.Logger = logger;
        }

        /// <summary>
        /// Lists flink jars
        /// </summary>
        [HttpGet]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ODProgram[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public IActionResult Get()
        {
            return UtilityFunctions.GetFlinkJarList();
        }
    }
}