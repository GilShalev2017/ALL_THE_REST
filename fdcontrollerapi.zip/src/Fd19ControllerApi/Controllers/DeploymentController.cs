﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Common;
using Common.Model;
using Microsoft.AspNetCore.Http;

namespace Fd19ControllerApi.Controllers
{
    [Route("api/[controller]")]
    public class DeploymentController : ControllerBase
    {
        ILogger Logger { get; set; }

        public DeploymentController(IConfiguration configuration, ILogger<DeploymentController> logger)
        {
            this.Logger = logger;
        }

        /// <summary>
        /// Lists active deployments
        /// </summary>
        [HttpGet]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Deployment[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [ProducesResponseType(StatusCodes.Status410Gone)]
        [ProducesResponseType(StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status413PayloadTooLarge)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [ProducesResponseType(StatusCodes.Status415UnsupportedMediaType)]
        [Produces("application/json")]
        public IActionResult Get()
        {
            return UtilityFunctions.GetActiveDeployments();
        }

        /// <summary>
        /// Fetches s3 config bucket files
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ODTask), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public IActionResult GetS3StaticBucket(string id)
        {
            return UtilityFunctions.GetS3ConfigBucket(id);
        }
    } 
}
