﻿using Common;
using Common.Model;
using Fd19ControllerApi.Common.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Fd19ControllerApi.Controllers
{
    [Route("api/[controller]")]
    public class TaskController : ControllerBase
    {
        /// <summary>
        /// Fetches a task by id
        /// </summary>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ODTask), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public ODTask GetTaskFunctionHandler(string id)
        {
            return UtilityFunctions.GetTask(id);
        }

        /// <summary>
        /// Lists tasks
        /// </summary>
        [HttpGet]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ODTask[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public IActionResult Get()
        {
            return UtilityFunctions.GetODTaskListRes();
        }

        /// <summary>
        /// Lists completed tasks
        /// </summary>
        [HttpPost("completed")]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ODTask[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public IActionResult GetCompletedTasks([FromBody] CompletedTaskPayload payload)
        {
            return UtilityFunctions.GetCompletedTaskListRes(payload); 
        }

        /// <summary>
        /// Creates a new task
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Post([FromBody]ODTask value)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            return UtilityFunctions.AddODTask(value);
        }

        /// <summary>
        /// Updates a task
        /// </summary>
        [HttpPut]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Put([FromBody]ODTask value)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            return UtilityFunctions.UpdateODTask(value);
        }

        /// <summary>
        /// Deletes a task
        /// </summary>
        /// <param name="id"></param>
        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Delete(string id)
        {
            return UtilityFunctions.DeleteODTask(id);
        }
    }
}
