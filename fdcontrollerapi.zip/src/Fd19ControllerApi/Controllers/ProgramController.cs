﻿using System;
using Common;
using Common.Model;
using Fd19ControllerApi.Common.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Fd19ControllerApi.Controllers
{
    [Route("api/[controller]")]
    public class ProgramController : ControllerBase
    {
        /// <summary>
        /// Lists programs
        /// </summary>
        [HttpGet]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ODProgram[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public IActionResult Get()
        {
            return UtilityFunctions.GetODProgramList();
        }

        /// <summary>
        /// Creates a program
        /// </summary>
        [HttpPost]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Post([FromBody] ODProgram value)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            return UtilityFunctions.AddODProgram(value);
        }

        /// <summary>
        /// Updates program
        /// </summary>
        [HttpPut]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Put([FromBody] ODProgram value)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            return UtilityFunctions.UpdateODProgram(value);
        }

        /// <summary>
        /// Uploads program
        /// </summary>
        [HttpPut("uploader")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Upload([FromBody] PresignedPayload presignedPayload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            //return UtilityFunctions.GetProgramPreSignedURL(presignedPayload);

            var jObject = UtilityFunctions.GetProgramPreSignedURL(presignedPayload);

            return jObject;
        }

        /// <summary>
        /// Deletes a program
        /// </summary>
        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Delete(string id)
        {
            return UtilityFunctions.DeleteODProgram(id);
        }

        /// <summary>
        /// Delete the program fromn S3
        /// </summary>
        [HttpPost("delete-from-s3")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult DeleteFromS3([FromBody] ODProgram program)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            
            UtilityFunctions.DeleteProgramFromS3Bucket(program.Id).Wait();

            return new OkObjectResult(true);
        }

        /// <summary>
        /// Returns the script content
        /// </summary>
        [HttpPost("content")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult PostScriptContentFunctionHandler([FromBody] ScriptPayload payload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }

            Console.WriteLine("fileKey = " + payload.fileKey);

            var jObject = UtilityFunctions.GetScriptContent(payload.fileKey);

            Console.WriteLine(jObject.ToString());

            return jObject;
        }

        /// <summary>
        /// Updates the script content
        /// </summary>
        [HttpPut("content")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult SetScriptContentFunctionHandler([FromBody] ScriptPayload payload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }

            Console.WriteLine("fileKey = " + payload.fileKey);

            Console.WriteLine("scriptContent = " + payload.scriptContent);

            var res = UtilityFunctions.SetScriptContent(payload);
          
            Console.WriteLine(res);

            return res;
        }
    }
}
