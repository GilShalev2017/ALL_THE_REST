﻿using Common;
using Common.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Fd19ControllerApi.Controllers
{
    [Route("api/[controller]")]
    public class FlowsController : ControllerBase
    {
        /// <summary>
        /// Lists flink flows
        /// </summary>
        [HttpGet]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ODFlow[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public IActionResult Get()
        {
            return UtilityFunctions.GetODFlowList();
        }

        /// <summary>
        /// Lists flink flows
        /// </summary>
        [HttpGet("{userGroup}")]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ODFlow[]), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        [Produces("application/json")]
        public IActionResult GetFilteredODFlowList(string userGroup)
        {
            return UtilityFunctions.GetFilteredODFlowList(userGroup);
        }

        /// <summary>
        /// Creates a flink flow
        /// </summary>
        [HttpPost]
        // [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Post([FromBody]ODFlow input)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            return UtilityFunctions.AddODFlow(input);
        }

        /// <summary>
        /// Updates a flink flow
        /// </summary>
        [HttpPut]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Put([FromBody] ODFlow value)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            return UtilityFunctions.UpdateODFlow(value);
        }

        /// <summary>
        /// Deletes a flink flow
        /// </summary>
        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult Delete(string id)
        {
            return UtilityFunctions.DeleteODFlow(id);
        }
    }
}
