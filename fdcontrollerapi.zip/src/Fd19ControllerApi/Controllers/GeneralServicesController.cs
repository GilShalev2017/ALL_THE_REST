﻿using System;
using Common;
using Fd19ControllerApi.Common.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace Fd19ControllerApi.Controllers
{
    [Route("api/[controller]")]
    public class GeneralServicesController : ControllerBase
    {
        /// <summary>
        /// Returns the bucket files as a tree of "folders" and "simple files"
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(FileNode[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult PostGetBucketFileTreeFunctionHandler([FromBody] GeneralServicePayload payload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            
            Console.WriteLine("Inside PostGetBucketFileTreeFunctionHandler");

            return UtilityFunctions.GetBucketFileTree(payload);
        }

        /// <summary>
        /// Returns the bucket files as a tree of "folders" and "simple files"
        /// </summary>
        //[HttpPost("all")]
        //[ProducesResponseType(typeof(FileNode[]), StatusCodes.Status200OK)]
        //[ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        //// AWS lambda invocation error codes
        //[ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[ProducesResponseType(StatusCodes.Status404NotFound)]
        //[ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        //public IActionResult PostGetAllBucketFileTreeFunctionHandler([FromBody] GeneralServicePayload payload)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
        //    }

        //    Console.WriteLine("Inside PostGetAllBucketFileTreeFunctionHandler");

        //    return UtilityFunctions.NewGetBucketFileTree(payload);
        //}

        [HttpPost("presignedUrl")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult GetS3FilePreSignedURL([FromBody] GeneralServicePayload payload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }

            var jObject = UtilityFunctions.GetS3FilePreSignedURL(payload);

            return jObject;
        }
    }
}
