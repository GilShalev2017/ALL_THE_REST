﻿using System;
using System.Threading.Tasks;
using Common;
using Fd19ControllerApi.Common.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace Fd19ControllerApi.Controllers
{
    [Route("api/[controller]")]
    public class ConfigController : ControllerBase
    {
        /// <summary>
        /// Updates config content
        /// </summary>
        [HttpPut("content")]
        [ProducesResponseType(typeof(Task<string>[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult SetConfigContentFunctionHandler([FromBody] ConfigurationPayload payload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }

            Console.WriteLine("keyName = " + payload.KeyName);

            Console.WriteLine("ContentBody = " + payload.ContentBody);
            
            var res = UtilityFunctions.SetConfigContent(payload);

            Console.WriteLine(res);

            return res;
        }

        /// <summary>
        /// Returns the config Tree
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(FileNode[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult PostConfigurationsFunctionHandler([FromBody] ConfigurationPayload payload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }
            //TODO bucket name will be read from deployment.json that will be retreived from DAAS Deployment API
            //Needs to find out how to sign the request
            //var bucketName = "intel-sports-us-east-1-teecontrol-" + payload.DeploymentId;
            //Environment.SetEnvironmentVariable(Constants.AWS_REGION, payload.DeploymentRegion);

            Console.WriteLine("Inside PostConfigurationsFunctionHandler");
            Console.WriteLine("DeploymentId = " + payload.DeploymentId);

            return UtilityFunctions.GetBucketFileList(payload);
        }

        /// <summary>
        /// Returns the config content
        /// </summary>
        [HttpPost("content")]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status400BadRequest)]
        // AWS lambda invocation error codes
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status429TooManyRequests)]
        public IActionResult PostConfigContentFunctionHandler([FromBody] ConfigurationPayload payload)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(UtilityFunctions.GetErrorListFromModelState(ModelState));
            }

            Console.WriteLine("keyName = " + payload.KeyName);

            var jObject = UtilityFunctions.GetConfigContent(payload);

            Console.WriteLine(jObject.ToString());

            return jObject;
        }
    }
}
