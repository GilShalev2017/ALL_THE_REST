﻿using System;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;

namespace Fd19ControllerApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public static IConfiguration Configuration { get; private set; }

        // This method gets called by the runtime. Use this method to add services to the container
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            });

            // Add S3 to the ASP.NET Core dependency injection framework.
            // services.AddAWSService<Amazon.S3.IAmazonS3>();

            services.AddSwaggerGen(c => {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "AWS Serverless Fd19Controller Api for Operational Docker", Version = "v1" });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCorsMiddleware();

            string swaggerEnv = "/Prod";
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                swaggerEnv = "";
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            /*app.UseCors(
                options => options.WithOrigins("http://task-automation-tool-system.s3-website-eu-west-1.amazonaws.com",
                                                                "http://localhost:4200").AllowAnyMethod()
            );*/

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint(swaggerEnv + "/swagger/v1/swagger.json", "AWS Serverless Fd19Controller Api for Operational Docker");
                c.RoutePrefix = "swagger";
            });
        }
    }
}


///services.AddCors(options => options.AddPolicy("ApiCorsPolicy", builder =>
//{
//    builder.WithOrigins("http://task-automation-tool-system.s3-website-eu-west-1.amazonaws.com").AllowAnyMethod().AllowAnyHeader();
//}));

//TODO choose the relevant one
//https://stackoverflow.com/questions/58072703/jsonresultobject-causes-the-collection-type-newtonsoft-json-linq-jtoken-is
//services.AddMvc().AddNewtonsoftJson();
//services.AddControllersWithViews().AddNewtonsoftJson();

//services.AddMvc().AddNewtonsoftJson();

//services.AddControllers().AddJsonOptions(jsonOptions =>
//{
//    jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null;
//})
//.SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

//.AddNewtonsoftJson()
//.AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null);
//services.AddControllersWithViews().AddNewtonsoftJson();

//services.AddControllers().AddJsonOptions(jsonOptions =>
//{
//    jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null;
//})
//.SetCompatibilityVersion(CompatibilityVersion.Version_3_0);