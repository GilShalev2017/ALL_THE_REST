﻿using System.ComponentModel.DataAnnotations;

namespace Common.Model
{
    public class PresignedPayload
    {
        [Required]
        public string ProgramName {get; set; }
        //Package may be empty!
        public string Package { get; set; }
        [Required]
        public string CategoryGroup { get; set; }
        public string HttpVerb { get; set; }
    }
}
