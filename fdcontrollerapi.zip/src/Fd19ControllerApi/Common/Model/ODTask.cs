using System.ComponentModel.DataAnnotations;

namespace Common.Model
{
    public class ODTask
  {
        public string Id { get; set; }
        public string ODProgramId { get; set; }
        public string ODProgramName { get; set; }
        public string CategoryGroup { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        public string ProgramToExecute { get; set; }
        public string ProgramParameters { get; set; }
        public string TaskParameters { get; set; }
        public bool ReportStandardOutput { get; set; }
        public string WorkingDirectory { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedAt { get; set; }
    }
}
