﻿using System.Collections.Generic;

namespace Fd19ControllerApi.Common.Model
{
    public class Folder
    {
        public string Name { get; set; }
        public List<Folder> Folders { get; set; } = new List<Folder>();
        public List<File> Files { get; set; } = new List<File>();
    }

    public class File
    {
        public string Name { get; set; }
    }
}
