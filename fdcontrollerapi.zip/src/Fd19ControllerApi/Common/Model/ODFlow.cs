﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Common.Model
{
    public class ODFlow
    {
        public string Id { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        public List<ODTask> Tasks { get; set; }
        public List<ODTask> CleanupTasks { get; set; }
        public string RunInParallel { get; set; }
        public string UserGroup { get; set; }
        public string IsFlinkFlow { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedAt { get; set; }
    }
}
