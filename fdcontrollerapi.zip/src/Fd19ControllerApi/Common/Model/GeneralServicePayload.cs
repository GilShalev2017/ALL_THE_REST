﻿namespace Fd19ControllerApi.Common.Model
{
    public class GeneralServicePayload
    {
        public string BucketName { get; set; }
        public string BucketBaseKey { get; set; }
        public string BucketRegion { get; set; }
        public string FileKey { get; set; }
        public string HttpVerb { get; set; }
    }
}
