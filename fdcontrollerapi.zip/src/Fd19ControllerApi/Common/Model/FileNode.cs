﻿using System.Collections.Generic;

namespace Fd19ControllerApi.Common.Model
{
    public class FileNode
    {
        public string name { get; set; }
        public string parentName { get; set; }
        public string folderPath { get; set; }
        public string parentFolderPath { get; set; }        
        public string fileType { get; set; }
        public List<FileNode> children { get; set; }
    }
}
