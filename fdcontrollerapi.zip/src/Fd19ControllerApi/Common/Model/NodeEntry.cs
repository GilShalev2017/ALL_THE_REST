﻿using System.Collections.Generic;

namespace Fd19ControllerApi.Common.Model
{
    public class NodeEntry
    {
        public NodeEntry()
        {
            this.children = new NodeEntryCollection();
        }

        public string name { get; set; }
        public NodeEntryCollection children { get; set; }

    }

    public class NodeEntryCollection : Dictionary<string, NodeEntry>
    {
        public void AddEntry(string sEntry, int wBegIndex)
        {
            if (wBegIndex < sEntry.Length)
            {
                string sKey;
                int wEndIndex;

                wEndIndex = sEntry.IndexOf("/", wBegIndex);
                if (wEndIndex == -1)
                {
                    wEndIndex = sEntry.Length;
                }
                sKey = sEntry.Substring(wBegIndex, wEndIndex - wBegIndex);
                if (!string.IsNullOrEmpty(sKey))
                {
                    NodeEntry oItem;

                    if (this.ContainsKey(sKey))
                    {
                        oItem = this[sKey];
                    }
                    else
                    {
                        oItem = new NodeEntry();
                        oItem.name = sKey;
                        this.Add(sKey, oItem);
                    }
                    // Now add the rest to the new item's children
                    oItem.children.AddEntry(sEntry, wEndIndex + 1);
                }
            }
        }
    }
}
