﻿namespace Fd19ControllerApi.Common.Model
{
    public enum StatusOptions
    {
        TaskStarting,
        TaskStarted,
        TaskCompleted,
        TaskCompletedWithError,
        ProcessExited,
        TaskStopped,
        TaskStoppedError,
    }
}
