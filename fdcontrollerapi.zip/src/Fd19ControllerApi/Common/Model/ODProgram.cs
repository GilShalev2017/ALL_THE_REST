namespace Common.Model
{
    public enum CategoryGroup
    {
        DeploymentConfiguration,
        Validation,
        Publishers,
        Playback,
        Flink,
        Debug,
        None
    }

    public enum ProgramType
    {
        dotnet,
        java,
        python,
        python3,
        bashScript,
        golang,
        windowsBatchScript,
        none
    }

    public class ODProgram
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Package { get; set; }
        public bool IsPackageCompressed { get; set; }
        public string ExecutedProgram { get; set; }
        public string ExecutedProgramParams { get; set; }
        public CategoryGroup CategoryGroup { get; set; }
        public ProgramType ProgramType { get; set; }
        public string ConfigurationFile { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedAt { get; set; }
    }
}
