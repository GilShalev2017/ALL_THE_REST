﻿namespace Fd19ControllerApi.Common.Model
{
    public class ScriptPayload
    {
        public string fileKey { get; set; }
        public string scriptContent { get; set; }
    }
}
