﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Common.Model
{
    public class Deployment
    {
        [Required]
        public string deployment_id { get; set; }

        [Required]
        public string deployment_name { get; set; }

        [DefaultValue("active")]
        public string deployment_status { get; set; }

        public string deployment_region { get; set; }
        public string default_game_id { get; set; }
        public string game_id { get; set; }
    }

    public class DeploymentDetails
    {
        public string deployment_id { get; set; }
        public string deployment_name { get; set; }
        public string region { get; set; }
        public string default_game_id { get; set; }
        public string game_id { get; set; }
    }
}
