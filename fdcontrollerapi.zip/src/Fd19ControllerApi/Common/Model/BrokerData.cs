﻿namespace Fd19ControllerApi.Common.Model
{
    public class BrokerData
    {
        public string mq_username { get; set; }
        public string mq_password { get; set; }
        public string mq_wss_url { get; set; }
        public string mq_stomp_url { get; set; }
        public string mq_openwire_url { get; set; }
    }
}
