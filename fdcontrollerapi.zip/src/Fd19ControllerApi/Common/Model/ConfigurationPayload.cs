﻿namespace Fd19ControllerApi.Common.Model
{
    public class ConfigurationPayload
    {
        public string ConfigType { get; set; }
        public string DeploymentId { get; set; }
        //public string DeploymentRegion { get; set; }
        public string KeyName { get; set; }
        public string ContentBody { get; set; }
    }
}
