﻿namespace Fd19ControllerApi.Common.Model
{
    public class CompletedTaskPayload
    {
        public string DeploymentId { get; set; }
    }
}
