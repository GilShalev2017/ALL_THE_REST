namespace Common
{
    public class Constants
    {
        //Lambda - Environment Variables
        public const string DYNAMO_DB_PROGRAMS = "DYNAMO_DB_PROGRAMS";
        public const string DYNAMO_DB_FLOWS = "DYNAMO_DB_FLOWS";
        public const string DYNAMO_DB_TASKS = "DYNAMO_DB_TASKS";
        public const string DYNAMO_DB_COMPLETED_TASKS = "DYNAMO_DB_COMPLETED_TASKS";
        public const string S3_BUCKET = "BUCKET";
        public const string S3_PROGRAMS_BUCKET = "PROGRAMS_BUCKET";
        public const string S3_PROGRAMS_BUCKET_REGION = "REGION";
        public const string AWS_REGION = "AWS_REGION";

        //COMMON
        public const string COLUMN_CREATED_BY = "CreatedBy";
        public const string COLUMN_CREATED_AT = "CreatedAt";
        public const string COLUMN_UPDATED_BY = "UpdatedBy";
        public const string COLUMN_UPDATED_AT = "UpdatedAt";

        //TASKS
        public const string COLUMN_TASK_ID = "Id";
        public const string COLUMN_TASK_CATEGORY_GROUP = "CategoryGroup";
        public const string COLUMN_TASK_PROGRAM_ID = "ODProgramId";
        public const string COLUMN_TASK_PROGRAM_NAME = "ODProgramName";
        public const string COLUMN_TASK_NAME = "Name";
        public const string COLUMN_TASK_DESCRIPTION = "Description";
        public const string COLUMN_TASK_PROGRAM_TO_EXECUTE = "ProgramToExecute";
        public const string COLUMN_TASK_PROGRAM_PARAMETERS = "ProgramParameters";
        public const string COLUMN_TASK_PARAMS = "TaskParameters";
        public const string COLUMN_REPORT_STDOUT = "ReportStandardOutput";
        public const string COLUMN_WORKING_DIRECTORY = "WorkingDirectory";

        //COMPLETED TASKS
        public const string COLUMN_COMPLETED_TASK_ID = "Id";
        public const string COLUMN_COMPLETED_TASK_CATEGORY_GROUP = "CategoryGroup";
        public const string COLUMN_COMPLETED_TASK_NAME = "Name";
        public const string COLUMN_COMPLETED_TASK_DESCRIPTION = "Description";
        public const string COLUMN_COMPLETED_TASK_PARAMS = "TaskParameters";
        public const string COLUMN_COMPLETED_TASK_START_DATE_TIME = "StartDateTime";
        public const string COLUMN_COMPLETED_TASK_END_DATE_TIME = "EndDateTime";
        public const string COLUMN_COMPLETED_TASK_STATUS = "Status";
        public const string COLUMN_COMPLETED_TASK_ERROR = "Error";
        public const string COLUMN_COMPLETED_TASK_EXECUTER_NAME = "ExecuterName";
        public const string COLUMN_COMPLETED_TASK_DEPLOYMENT_ID = "DeploymentId";
        public const string COLUMN_COMPLETED_TASK_FD_CONTROLLER_ID = "FdControllerId";


        //PROGRAMS
        public const string COLUMN_PROGRAM_ID = "Id";
        public const string COLUMN_PROGRAM_NAME = "Name";
        public const string COLUMN_PROGRAM_DESCRIPTION = "Description";
        public const string COLUMN_PROGRAM_PACKAGE = "Package";
        public const string COLUMN_PROGRAM_CATEGORY_GROUP = "CategoryGroup";
        public const string COLUMN_PROGRAM_TYPE = "Type";
        public const string COLUMN_PROGRAM_CONFIG_FILE = "ConfigFile";
        public const string COLUMN_PROGRAM_PREREQUISITES = "Prerequisites";
        public const string COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED = "IsPackageCompressed";
        public const string COLUMN_PROGRAM_EXECUTED_PROGRAM = "ExecutedProgram";
        public const string COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS = "ExecutedProgramParams";
        //FLOWS
        public const string COLUMN_FLOW_ID = "Id";
        public const string COLUMN_FLOW_NAME = "Name";
        public const string COLUMN_FLOW_DESCRIPTION = "Description";
        public const string COLUMN_FLOW_TASKS = "Tasks";
        public const string COLUMN_FLOW_CLEANUP_TASKS = "CleanupTasks";
        public const string COLUMN_RUN_IN_PARALLEL = "RunInParallel";
        public const string COLUMN_IS_FLINK_FLOW = "IsFlinkFlow";

        public const int DEFAULT_EXPIRATION_TIME_IN_MINUTES = 1440;//24 * 60;
    }
}
