using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.S3;
using Amazon.S3.Model;
using Common.Model;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Net.Http;
using Aws4RequestSigner;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json.Linq;
using System.IO;
using Fd19ControllerApi.Common.Model;
using Amazon.DynamoDBv2.DocumentModel;

namespace Common
{
    public class UtilityFunctions
    {
        public static List<string> GetErrorListFromModelState
                                              (ModelStateDictionary modelState)
        {
            var query = from state in modelState.Values
                        from error in state.Errors
                        select error.ErrorMessage;

            var errorList = query.ToList();
            return errorList;
        }
        #region General Services
        public static ActionResult GetBucketFileTree(GeneralServicePayload payload)
        {
            try
            {
                var getBucketFiles = InnerGetBucketFileList(payload);

                if (getBucketFiles.Result == null)
                {
                    Console.WriteLine("Exception when getting files");
                    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                }

                var segments = payload.BucketBaseKey.Split("/");
                var rootFolder = segments[segments.Length - 1];
                var perfixToRemove = "";
                for (int i = 0; i < segments.Length - 1; i++)
                {
                    perfixToRemove = perfixToRemove + segments[i] + "/";
                }
                List<string> files = getBucketFiles.Result;

                for (int i = 0; i < files.Count; i++)
                {
                    files[i] = files[i].Replace(perfixToRemove, "");
                }

                //If there are folders within folders we need to add them!

                //For Images
                files.Insert(0, rootFolder + "/");

                //https://stackoverflow.com/questions/63069296/build-folder-files-tree-from-string-path-with-c-sharp

                List<FileNode> fileNodes = GetFileNodesFromStrings(files);


                return new OkObjectResult(fileNodes);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        //public static ActionResult NewGetBucketFileTree(GeneralServicePayload payload)
        //{
        //    try
        //    {
        //        var getBucketFiles = InnerGetBucketFileList(payload);

        //        if (getBucketFiles.Result == null)
        //        {
        //            Console.WriteLine("Exception when getting files");
        //            return new StatusCodeResult(StatusCodes.Status500InternalServerError);
        //        }

        //        var segments = payload.BucketBaseKey.Split("/");
        //        var rootFolder = segments[segments.Length - 1];
        //        var perfixToRemove = "";
        //        for (int i = 0; i < segments.Length - 1; i++)
        //        {
        //            perfixToRemove = perfixToRemove + segments[i] + "/";
        //        }
        //        List<string> files = getBucketFiles.Result;

        //        for (int i = 0; i < files.Count; i++)
        //        {
        //            var fileSegments = files[i].Split("/");

        //            var folder = fileSegments[0] + "/";

        //            for (int j = 1; j < fileSegments.Length; j++)
        //            {
        //                if(!files.Contains(folder))
        //                {
        //                    files.Add(folder);
        //                }
        //                folder = folder + fileSegments[j] + "/";
        //            }
        //        }

        //        //https://stackoverflow.com/questions/63069296/build-folder-files-tree-from-string-path-with-c-sharp

        //        List<FileNode> fileNodes = GetFileNodesFromStrings(files);


        //        return new OkObjectResult(fileNodes);
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("Exception: " + e.ToString());
        //        return new StatusCodeResult(StatusCodes.Status500InternalServerError);
        //    }
        //}

        static List<FileNode> GetFileNodesFromStrings(List<string> strings)
        {
            var fileNodes = new List<FileNode>();

            strings.Sort(StringComparer.InvariantCultureIgnoreCase);

            var folderByPath = new Dictionary<string, FileNode>();

            foreach (var str in strings)
            {
                if (str.EndsWith("/")) // we have a folder
                {
                    MyEnsureFolder(fileNodes, folderByPath, str);
                }
                else // we have a file
                {
                    var lastSlashPosition = str.LastIndexOf("/");
                    var parentFolderPath = str.Substring(0, lastSlashPosition + 1);
                    var parentFolder = MyEnsureFolder(fileNodes, folderByPath, parentFolderPath);
                    var fileName = str.Substring(lastSlashPosition + 1);
                    var file = new FileNode
                    {
                        name = fileName,
                        fileType = "file",
                        parentName = parentFolder.name,
                        parentFolderPath = parentFolderPath
                    };
                    parentFolder.children.Add(file);
                }
            }

            return fileNodes;
        }

        private static FileNode MyEnsureFolder(List<FileNode> rootFolders, Dictionary<string, FileNode> folderByPath, string folderPath)
        {
            if (!folderByPath.TryGetValue(folderPath, out var folder))
            {
                var folderPathWithoutEndSlash = folderPath.TrimEnd('/');
                var lastSlashPosition = folderPathWithoutEndSlash.LastIndexOf("/");
                List<FileNode> fileNodes;
                string fileName;
                if (lastSlashPosition < 0) // it's a first level folder
                {
                    fileName = folderPathWithoutEndSlash;
                    fileNodes = rootFolders;
                }
                else
                {
                    var parentFolderPath = folderPath.Substring(0, lastSlashPosition + 1);
                    if (folderByPath[parentFolderPath].children == null)
                    {
                        folderByPath[parentFolderPath].children = new List<FileNode>();
                    }

                    fileNodes = folderByPath[parentFolderPath].children;

                    fileName = folderPathWithoutEndSlash.Substring(lastSlashPosition + 1);
                }
                folder = new FileNode
                {
                    name = fileName,
                    fileType = "folder",
                    children = new List<FileNode>(),
                    folderPath = folderPath
                };
                fileNodes.Add(folder);
                folderByPath.Add(folderPath, folder);
            }
            return folder;
        }

        private async static Task<List<string>> InnerGetBucketFileList(GeneralServicePayload payload)
        {
            IAmazonS3 s3Client = ClientFactory.GetS3Client(payload.BucketRegion);

            List<string> files = new List<string>();

            try
            {
                ListObjectsV2Request request = new ListObjectsV2Request
                {
                    BucketName = payload.BucketName,
                    Prefix = payload.BucketBaseKey,
                    MaxKeys = 1000
                };

                ListObjectsV2Response response;

                do
                {
                    response = await s3Client.ListObjectsV2Async(request);

                    // Process the response.
                    foreach (S3Object entry in response.S3Objects)
                    {
                        files.Add(entry.Key);
                    }

                    request.ContinuationToken = response.NextContinuationToken;

                } while (response.IsTruncated);
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                Console.WriteLine("S3 error occurred. Exception: " + amazonS3Exception.ToString());
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
                return null;
            }

            return files;
        }

        public static ActionResult GetS3FilePreSignedURL(GeneralServicePayload payload)
        {
            try
            {
                IAmazonS3 s3Client = ClientFactory.GetS3Client(payload.BucketRegion);

                Console.WriteLine("RECEIVED BucketBaseKey = " + payload.BucketBaseKey);
                Console.WriteLine("RECEIVED BucketName = " + payload.BucketName);
                Console.WriteLine("RECEIVED BucketRegion = " + payload.BucketRegion);
                Console.WriteLine("RECEIVED FileKey = " + payload.FileKey);
                Console.WriteLine("RECEIVED HttpVerb = " + payload.HttpVerb);

                var httpVerb = HttpVerb.GET;
                if (payload.HttpVerb.ToUpper() == "PUT")
                {
                    httpVerb = HttpVerb.PUT;
                }

                var request = new GetPreSignedUrlRequest
                {
                    BucketName = payload.BucketName,
                    Key = payload.FileKey,
                    Verb = httpVerb,
                    Expires = DateTime.Now.AddMinutes(Constants.DEFAULT_EXPIRATION_TIME_IN_MINUTES)
                };

                var urlString = s3Client.GetPreSignedURL(request);

                JObject jObject = new JObject
                {
                    ["URL_STRING"] = urlString
                };

                return new OkObjectResult(jObject);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when getting preSignedUrl for bucket {ClientFactory.S3ProgramsBucket}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        #endregion

        #region Programs

        public static ODProgram GetODProgram(string id)
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
            {
                { Constants.COLUMN_PROGRAM_ID, new AttributeValue(id) }
            };

            GetItemResponse response = client.GetItemAsync(ClientFactory.DynamoDbTable, dic).Result;

            ODProgram odp = new ODProgram
            {
                Id = response.Item[Constants.COLUMN_PROGRAM_ID].S,
                Name = response.Item[Constants.COLUMN_PROGRAM_NAME].S,
                Description = response.Item[Constants.COLUMN_PROGRAM_DESCRIPTION].S,
                Package = response.Item[Constants.COLUMN_PROGRAM_PACKAGE].S,
                ExecutedProgram = response.Item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM].S,
                ExecutedProgramParams = response.Item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS].S,
            };
            
            if (Enum.TryParse(response.Item[Constants.COLUMN_PROGRAM_CATEGORY_GROUP].S, out CategoryGroup parsedCategoryGroup))
            {
                odp.CategoryGroup = parsedCategoryGroup;
            }

            if (response.Item.ContainsKey(Constants.COLUMN_CREATED_BY))
            {
                var createdBy = response.Item[Constants.COLUMN_CREATED_BY].S;
                odp.CreatedBy = createdBy;
            }

            if (response.Item.ContainsKey(Constants.COLUMN_CREATED_AT))
            {
                var createdAt = response.Item[Constants.COLUMN_CREATED_AT].S;
                odp.CreatedAt = createdAt;
            }

            if (response.Item.ContainsKey(Constants.COLUMN_UPDATED_BY))
            {
                var updatedBy = response.Item[Constants.COLUMN_UPDATED_BY].S;
                odp.UpdatedBy = updatedBy;
            }

            if (response.Item.ContainsKey(Constants.COLUMN_UPDATED_AT))
            {
                var updatedAt = response.Item[Constants.COLUMN_UPDATED_AT].S;
                odp.UpdatedAt = updatedAt;
            }

            return odp;
        }

        public static ActionResult AddODProgram(ODProgram oDProgram)
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            var id = Guid.NewGuid().ToString();

            var addTime = DateTime.Now.ToString();

            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
            {
                { Constants.COLUMN_PROGRAM_ID, new AttributeValue(id) },
                { Constants.COLUMN_PROGRAM_NAME, new AttributeValue(oDProgram.Name) },
                { Constants.COLUMN_PROGRAM_DESCRIPTION, new AttributeValue(oDProgram.Description) },
                { Constants.COLUMN_PROGRAM_PACKAGE, new AttributeValue(oDProgram.Package) },
                { Constants.COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED, new AttributeValue(oDProgram.IsPackageCompressed.ToString()) },
                { Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM, new AttributeValue(oDProgram.ExecutedProgram) },
                { Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS, new AttributeValue(oDProgram.ExecutedProgramParams) },
                { Constants.COLUMN_PROGRAM_CATEGORY_GROUP, new AttributeValue(oDProgram.CategoryGroup.ToString()) },
                { Constants.COLUMN_PROGRAM_TYPE, new AttributeValue(oDProgram.ProgramType.ToString()) },
                { Constants.COLUMN_CREATED_BY, new AttributeValue(oDProgram.CreatedBy.ToString()) },
                { Constants.COLUMN_CREATED_AT, new AttributeValue(addTime) },
                { Constants.COLUMN_UPDATED_BY, new AttributeValue(oDProgram.CreatedBy.ToString()) },
                { Constants.COLUMN_UPDATED_AT, new AttributeValue(addTime) },
            };

            if (!string.IsNullOrEmpty(oDProgram.ConfigurationFile))
            {
                dic.Add(Constants.COLUMN_PROGRAM_CONFIG_FILE, new AttributeValue(oDProgram.ConfigurationFile.ToString()));
            }

            //if (oDProgram.Prerequisites != null)
            //{
            //    string combindedString = string.Join(",", oDProgram.Prerequisites.ToArray());

            //    dic.Add(Constants.COLUMN_PROGRAM_PREREQUISITES, new AttributeValue(combindedString));
            //}

            PutItemResponse response = client.PutItemAsync(ClientFactory.DynamoDbTable, dic).Result;

            if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                return new OkObjectResult(true);
            else
                return new StatusCodeResult((int)response.HttpStatusCode);
        }

        public static ActionResult GetODProgramList()
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = ClientFactory.DynamoDbTable
            };

            result = client.ScanAsync(req).Result;

            if (!(result.HttpStatusCode == System.Net.HttpStatusCode.OK))
            {
                Console.WriteLine($"Invalid response when invoking ScanAsync on DynamoDb {ClientFactory.DynamoDbTable}:", result);
                return new StatusCodeResult((int)result.HttpStatusCode);
            }

            List<ODProgram> list = new List<ODProgram>();

            foreach (var item in result.Items)
            {
                ODProgram odp = new ODProgram
                {
                    Id = item[Constants.COLUMN_PROGRAM_ID].S,
                    Name = item[Constants.COLUMN_PROGRAM_NAME].S,
                    Description = item[Constants.COLUMN_PROGRAM_DESCRIPTION].S,
                    Package = item[Constants.COLUMN_PROGRAM_PACKAGE].S,
                    ExecutedProgram = item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM].S,
                    ExecutedProgramParams = item[Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS].S,
                };

                if (item.ContainsKey(Constants.COLUMN_CREATED_BY))
                {
                    var createdBy = item[Constants.COLUMN_CREATED_BY].S;
                    odp.CreatedBy = createdBy;
                }

                if (item.ContainsKey(Constants.COLUMN_CREATED_AT))
                {
                    var createdAt = item[Constants.COLUMN_CREATED_AT].S;
                    odp.CreatedAt = createdAt;
                }

                if (item.ContainsKey(Constants.COLUMN_UPDATED_BY))
                {
                    var updatedBy = item[Constants.COLUMN_UPDATED_BY].S;
                    odp.UpdatedBy = updatedBy;
                }

                if (item.ContainsKey(Constants.COLUMN_UPDATED_AT))
                {
                    var updatedAt = item[Constants.COLUMN_UPDATED_AT].S;
                    odp.UpdatedAt = updatedAt;
                }

                if (item.ContainsKey(Constants.COLUMN_PROGRAM_CONFIG_FILE))
                {
                    var configurationFile = item[Constants.COLUMN_PROGRAM_CONFIG_FILE].S;
                    odp.ConfigurationFile = configurationFile;
                }

                //if (item.ContainsKey(Constants.COLUMN_PROGRAM_PREREQUISITES))
                //{
                //    var prereqisites = item[Constants.COLUMN_PROGRAM_PREREQUISITES].S;
                //    var splits = prereqisites.Split(",");

                //    if (splits != null)
                //    {
                //        odp.Prerequisites = new List<Prerequisite>();

                //        foreach (string split in splits)
                //        {
                //            if (Enum.TryParse(split, out Prerequisite parsedPrerequisite))
                //            {
                //                odp.Prerequisites.Add(parsedPrerequisite);
                //            }
                //        }
                //    }
                //}

                if (bool.TryParse(item[Constants.COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED].S, out bool parsedIsCompressed))
                {
                    odp.IsPackageCompressed = parsedIsCompressed;
                }

                if (Enum.TryParse(item[Constants.COLUMN_PROGRAM_CATEGORY_GROUP].S, out CategoryGroup parsedCategoryGroup))
                {
                    odp.CategoryGroup = parsedCategoryGroup;
                }

                if (Enum.TryParse(item[Constants.COLUMN_PROGRAM_TYPE].S, out ProgramType programType))
                {
                    odp.ProgramType = programType;
                }

                list.Add(odp);
            }

            if (list == null)
                return null;

            return new OkObjectResult(list.ToArray());

            //Dictionary< CategoryGroup, List <OperationalDockerProgram>> dic = new Dictionary<CategoryGroup, List<OperationalDockerProgram>>();

            //foreach (OperationalDockerProgram odp in list)
            //{
            //    if(!dic.ContainsKey(odp.CategoryGroup))
            //    {
            //        dic.Add(odp.CategoryGroup, new List<OperationalDockerProgram> { odp });
            //    }
            //    else
            //    {
            //        dic[odp.CategoryGroup].Add(odp);
            //    }

            //}

            //return dic;
        }

        public static ActionResult GetProgramPreSignedURL(PresignedPayload presignedPayload)
        {
            try
            {
                IAmazonS3 s3Client = ClientFactory.GetS3Client(ClientFactory.S3ProgramsBucketRegion);

                string programKey = "";

                if (!string.IsNullOrEmpty(presignedPayload.Package))
                {
                    programKey = presignedPayload.CategoryGroup + @"/" + presignedPayload.ProgramName + @"/" + presignedPayload.Package;
                }
                else
                {
                    programKey = presignedPayload.CategoryGroup + @"/" + presignedPayload.ProgramName;
                }

                Console.WriteLine("RECEIVED ProgramName = " + presignedPayload.ProgramName);
                Console.WriteLine("RECEIVED Package = " + presignedPayload.Package);
                Console.WriteLine("RECEIVED CategoryGroup = " + presignedPayload.CategoryGroup);
                Console.WriteLine("RECEIVED HttpVerb = " + presignedPayload.HttpVerb);
                Console.WriteLine("FOUND PROGRAMS BUCKET = " + ClientFactory.S3ProgramsBucket);
                Console.WriteLine("FOUND PROGRAMS BUCKET REGION = " + ClientFactory.S3ProgramsBucketRegion);
                Console.WriteLine("PROGRAM KEY = " + programKey);

                var request = new GetPreSignedUrlRequest
                {
                    BucketName = ClientFactory.S3ProgramsBucket,
                    Key = programKey,
                    Verb = HttpVerb.PUT,
                    Expires = DateTime.Now.AddMinutes(Constants.DEFAULT_EXPIRATION_TIME_IN_MINUTES)
                };

                if (!string.IsNullOrEmpty(presignedPayload.HttpVerb))
                {
                    if (presignedPayload.HttpVerb.ToUpper() == "GET")
                    {
                        request.Verb = HttpVerb.GET;
                    }
                }

                var urlString = s3Client.GetPreSignedURL(request);

                JObject jObject = new JObject
                {
                    ["URL_STRING"] = urlString
                };
                // var urlStringObject = JObject.Parse(urlString);

                return new OkObjectResult(jObject);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when getting preSignedUrl for bucket {ClientFactory.S3ProgramsBucket}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
        public static async Task DeleteProgramFromS3Bucket(string programId)
        {
            try
            {
                Console.WriteLine(string.Format("Inside DeleteProgramFromS3Bucket progId={0}", programId));

                //Condiser remove program from S3 too !!!
                IAmazonS3 s3Client = ClientFactory.GetS3Client(ClientFactory.S3ProgramsBucketRegion);

                ODProgram odp = GetODProgram(programId);

                var objKey = odp.CategoryGroup + "/" + odp.Name + "/" + odp.Package;

                var folderKey = odp.CategoryGroup + "/" + odp.Name+ "/";

                Console.WriteLine(string.Format("objKey={0}",objKey));

                Console.WriteLine(string.Format("folderKey{0}", folderKey));

                try
                {
                    //Delete the program itself (the package)
                    var deleteObjectRequest = new DeleteObjectRequest
                    {
                        BucketName = ClientFactory.S3ProgramsBucket,
                        Key = objKey
                    };

                    await s3Client.DeleteObjectAsync(deleteObjectRequest);

                    //Delete the parent folder that contains the program
                    var deleteFolderRequest = new DeleteObjectRequest
                    {
                        BucketName = ClientFactory.S3ProgramsBucket,
                        Key = folderKey
                    };

                    await s3Client.DeleteObjectAsync(ClientFactory.S3ProgramsBucket, folderKey);
            
                }
                catch (AmazonS3Exception e)
                {
                    Console.WriteLine("Error encountered on server. Message:'{0}' when deleting an object", e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Unknown encountered on server. Message:'{0}' when deleting an object", e.Message);
                }
            }
           catch (Exception e)
            {
                Console.WriteLine("Unknown encountered on server. Message:'{0}' when deleting an object", e.Message);
            }
        }

        public static ActionResult DeleteODProgram(string programId)
        {
            try
            {
                DeleteProgramFromS3Bucket(programId).Wait();
         
                IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

                Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
                {
                  { Constants.COLUMN_PROGRAM_ID, new AttributeValue(programId) }
                };

                DeleteItemResponse response = client.DeleteItemAsync(new DeleteItemRequest(ClientFactory.DynamoDbTable, key)).Result;

                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return new OkObjectResult(true);
                else
                    return new StatusCodeResult((int)response.HttpStatusCode);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        public static ActionResult UpdateODProgram(ODProgram program)
        {
            try
            {
                IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

                var updateTime = DateTime.Now.ToString();

                Dictionary<string, AttributeValueUpdate> attributeUpdates = new Dictionary<string, AttributeValueUpdate>
                {
                    { Constants.COLUMN_PROGRAM_NAME,         new AttributeValueUpdate(new AttributeValue(program.Name), AttributeAction.PUT) },
                    { Constants.COLUMN_PROGRAM_DESCRIPTION,  new AttributeValueUpdate(new AttributeValue(program.Description), AttributeAction.PUT) },
                    { Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM, new AttributeValueUpdate(new AttributeValue(program.ExecutedProgram), AttributeAction.PUT) },
                    { Constants.COLUMN_PROGRAM_EXECUTED_PROGRAM_PARAMS, new AttributeValueUpdate(new AttributeValue(program.ExecutedProgramParams), AttributeAction.PUT) },
                    { Constants.COLUMN_PROGRAM_TYPE, new AttributeValueUpdate(new AttributeValue(program.ProgramType.ToString()), AttributeAction.PUT) },
                    { Constants.COLUMN_UPDATED_BY, new AttributeValueUpdate(new AttributeValue(program.UpdatedBy), AttributeAction.PUT) },
                    { Constants.COLUMN_PROGRAM_PACKAGE, new AttributeValueUpdate(new AttributeValue(program.Package), AttributeAction.PUT) },
                    { Constants.COLUMN_PROGRAM_IS_PACAKGE_COMPRESSED, new AttributeValueUpdate(new AttributeValue(program.IsPackageCompressed.ToString()), AttributeAction.PUT) },
                    { Constants.COLUMN_UPDATED_AT, new AttributeValueUpdate(new AttributeValue(updateTime), AttributeAction.PUT) }
                };

                Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
                {
                  { Constants.COLUMN_PROGRAM_ID, new AttributeValue(program.Id) }
                };

                UpdateItemResponse response = client.UpdateItemAsync(ClientFactory.DynamoDbTable, key, attributeUpdates).Result;

                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return new OkObjectResult(true);
                else
                    return new StatusCodeResult((int)response.HttpStatusCode);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        public static ActionResult GetScriptContent(string fileKey)
        {
            var getScriptFileContent = GetScriptFileContent(fileKey);

            if (getScriptFileContent.Result == null)
            {
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }

            var content = getScriptFileContent.Result;

            return new OkObjectResult(content);
        }

        private static async Task<List<string>> GetScriptFileContent(string fileKey)
        {
            IAmazonS3 s3Client = ClientFactory.GetS3Client(ClientFactory.S3ProgramsBucketRegion);

            GetObjectRequest request = new GetObjectRequest
            {
                BucketName = ClientFactory.S3ProgramsBucket,
                Key = fileKey
            };

            List<string> lines = new List<string>();

            try
            {
                using (GetObjectResponse response = await s3Client.GetObjectAsync(request))
                using (Stream responseStream = response.ResponseStream)
                using (StreamReader reader = new StreamReader(responseStream))
                {
                    string title = response.Metadata["x-amz-meta-title"]; // Assume you have "title" as medata added to the object.

                    Console.WriteLine("title=" + title);

                    string contentType = response.Headers["Content-Type"];

                    Console.WriteLine("contentType=" + contentType);

                    while (reader.Peek() >= 0)
                    {
                        var line = reader.ReadLine();
                        lines.Add(line);
                        Console.WriteLine(line);
                    }

                    //responseBody = reader.ReadToEnd(); // Now you process the response body.
                }
            }
            catch (AmazonS3Exception e)
            {
                // If bucket or object does not exist
                Console.WriteLine("Error encountered ***. Message:'{0}' when reading object", e.Message);
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine("Unknown encountered on server. Message:'{0}' when reading object", e.Message);
                return null;
            }

            return lines;
            //JObject jObject = new JObject
            //{
            //    ["SCRIPT_CONTENT"] = lines
            //};

            //return jObject;
        }

        public static ActionResult SetScriptContent(ScriptPayload payload)
        {
            var setScriptContentAsync = SetScriptContentAsync(payload);

            if (setScriptContentAsync.Result == null)
            {
                Console.WriteLine("Exception when setting script content");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }

            var result = setScriptContentAsync.Result;

            return new OkObjectResult(result);
        }

        static async Task<string> SetScriptContentAsync(ScriptPayload payload)
        {
            IAmazonS3 s3Client = ClientFactory.GetS3Client(ClientFactory.S3ProgramsBucketRegion);

            var putRequest = new PutObjectRequest
            {
                BucketName = ClientFactory.S3ProgramsBucket,
                Key = payload.fileKey,
                ContentBody = payload.scriptContent
            };

            try
            {
                PutObjectResponse response = await s3Client.PutObjectAsync(putRequest);

                return response.HttpStatusCode.ToString();
            }
            catch (AmazonS3Exception e)
            {
                Console.WriteLine("payload.fileKey" + payload.fileKey + "payload.ScriptContent" + payload.scriptContent + "bucketName" + ClientFactory.S3ProgramsBucket);
                Console.WriteLine(string.Format("Error encountered ***. Message:'{0}' when writing an object", e.Message));
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine("payload.fileKey" + payload.fileKey + "payload.ScriptContent" + payload.scriptContent + "bucketName" + ClientFactory.S3ProgramsBucket);
                Console.WriteLine(string.Format("Unknown encountered on server. Message:'{0}' when writing an object Details: {1}", e.Message, "putRequest1.Key=" + putRequest.Key + "payload.fileKey" + payload.fileKey + "payload.ScriptContent" + payload.scriptContent + "bucketName" + ClientFactory.S3ProgramsBucket));
                return null;
            }
        }

        #endregion Programs

        #region Tasks

        public static ActionResult AddODTask(ODTask task)
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            var Id = Guid.NewGuid().ToString();

            var addTime = DateTime.Now.ToString();

            //Values can not be empty!
            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
            {
                { Constants.COLUMN_TASK_ID, new AttributeValue(Id) },
                { Constants.COLUMN_TASK_CATEGORY_GROUP, new AttributeValue(task.CategoryGroup) },
                { Constants.COLUMN_TASK_PROGRAM_ID, new AttributeValue(task.ODProgramId) },
                { Constants.COLUMN_TASK_PROGRAM_NAME, new AttributeValue(task.ODProgramName) },
                { Constants.COLUMN_TASK_NAME, new AttributeValue(task.Name) },
                { Constants.COLUMN_REPORT_STDOUT, new AttributeValue(task.ReportStandardOutput.ToString()) },
                { Constants.COLUMN_CREATED_BY, new AttributeValue(task.CreatedBy.ToString()) },
                { Constants.COLUMN_CREATED_AT, new AttributeValue(addTime) },
                { Constants.COLUMN_UPDATED_BY, new AttributeValue(task.CreatedBy.ToString()) },
                { Constants.COLUMN_UPDATED_AT, new AttributeValue(addTime) },
            };

            // { Constants.COLUMN_EXECUTED_PROGRAM, new AttributeValue(task.ExecutedProgram) }, // will be filled from the program

            if (!string.IsNullOrEmpty(task.Description))
            {
                dic.Add(Constants.COLUMN_TASK_DESCRIPTION, new AttributeValue(task.Description));
            }

            if (!string.IsNullOrEmpty(task.TaskParameters))
            {
                dic.Add(Constants.COLUMN_TASK_PARAMS, new AttributeValue(task.TaskParameters));
            }

            if (!string.IsNullOrEmpty(task.WorkingDirectory))
            {
                dic.Add(Constants.COLUMN_WORKING_DIRECTORY, new AttributeValue(task.WorkingDirectory));
            }

            PutItemResponse response = client.PutItemAsync(ClientFactory.DynamoDbTable3, dic).Result;

            if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                return new OkObjectResult(true);
            else
                return new StatusCodeResult((int)response.HttpStatusCode);
        }

        public static ODTask GetTask(string id)
        {
            return null;
        }

        public static List<ODTask> GetODTaskList()
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = ClientFactory.DynamoDbTable3
            };

            result = client.ScanAsync(req).Result;

            /*if (!((int)result.HttpStatusCode == 200))
            {
                Console.WriteLine($"Invalid response when invoking ScanAsync on DynamoDb {ClientFactory.DynamoDbTable3}:", result);
                return new StatusCodeResult((int)result.HttpStatusCode);
            }*/

            List<ODTask> list = new List<ODTask>();

            foreach (var item in result.Items)
            {
                ODTask task = new ODTask
                {
                    Id = item[Constants.COLUMN_TASK_ID].S,
                    ODProgramId = item[Constants.COLUMN_TASK_PROGRAM_ID].S,
                    ODProgramName = item[Constants.COLUMN_TASK_PROGRAM_NAME].S,
                    Name = item[Constants.COLUMN_TASK_NAME].S,
                };

                if (item.ContainsKey(Constants.COLUMN_PROGRAM_CATEGORY_GROUP))
                {
                    task.CategoryGroup = item[Constants.COLUMN_PROGRAM_CATEGORY_GROUP].S;
                }

                if (item.ContainsKey(Constants.COLUMN_TASK_DESCRIPTION))
                {
                    task.Description = item[Constants.COLUMN_TASK_DESCRIPTION].S;
                }

                if (item.ContainsKey(Constants.COLUMN_TASK_PARAMS))
                {
                    task.TaskParameters = item[Constants.COLUMN_TASK_PARAMS].S;
                }

                if (item.ContainsKey(Constants.COLUMN_WORKING_DIRECTORY))
                {
                    task.WorkingDirectory = item[Constants.COLUMN_WORKING_DIRECTORY].S;
                }

                task.ReportStandardOutput = item[Constants.COLUMN_REPORT_STDOUT].S.ToLower() == "true" ? true : false;

                if (item.ContainsKey(Constants.COLUMN_CREATED_BY))
                {
                    var createdBy = item[Constants.COLUMN_CREATED_BY].S;
                    task.CreatedBy = createdBy;
                }

                if (item.ContainsKey(Constants.COLUMN_CREATED_AT))
                {
                    var createdAt = item[Constants.COLUMN_CREATED_AT].S;
                    task.CreatedAt = createdAt;
                }

                if (item.ContainsKey(Constants.COLUMN_UPDATED_BY))
                {
                    var updatedBy = item[Constants.COLUMN_UPDATED_BY].S;
                    task.UpdatedBy = updatedBy;
                }

                if (item.ContainsKey(Constants.COLUMN_UPDATED_AT))
                {
                    var updatedAt = item[Constants.COLUMN_UPDATED_AT].S;
                    task.UpdatedAt = updatedAt;
                }

                list.Add(task);
            }
            return list;
        }

        public static ActionResult GetODTaskListRes()
        {
            List<ODTask> taskList = GetODTaskList();
            return new OkObjectResult(taskList.ToArray());
        }

        public static ActionResult DeleteODTask(string taskId)
        {
            try
            {
                IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

                //Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
                //{
                //  { Constants.COLUMN_TASK_NAME, new AttributeValue(taskName) }
                //};

                Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
                  {
                    { Constants.COLUMN_TASK_ID, new AttributeValue(taskId) }
                  };

                DeleteItemResponse response = client.DeleteItemAsync(new DeleteItemRequest(ClientFactory.DynamoDbTable3, key)).Result;

                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return new OkObjectResult(true);
                else
                    return new StatusCodeResult((int)response.HttpStatusCode);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable3}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        public static ActionResult UpdateODTask(ODTask task)
        {
            try
            {
                IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

                var updateTime = DateTime.Now.ToString();

                Dictionary<string, AttributeValueUpdate> attributeUpdates = new Dictionary<string, AttributeValueUpdate>
                {
                    { Constants.COLUMN_TASK_NAME,         new AttributeValueUpdate(new AttributeValue(task.Name), AttributeAction.PUT) },
                    { Constants.COLUMN_TASK_DESCRIPTION,  new AttributeValueUpdate(new AttributeValue(task.Description), AttributeAction.PUT) },
                    { Constants.COLUMN_REPORT_STDOUT,     new AttributeValueUpdate(new AttributeValue(task.ReportStandardOutput.ToString()), AttributeAction.PUT) },
                    { Constants.COLUMN_UPDATED_BY, new AttributeValueUpdate(new AttributeValue(task.UpdatedBy), AttributeAction.PUT) },
                    { Constants.COLUMN_UPDATED_AT, new AttributeValueUpdate(new AttributeValue(updateTime), AttributeAction.PUT) }
                };

                Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
                {
                  { Constants.COLUMN_TASK_ID, new AttributeValue(task.Id) }
                };

                if (!string.IsNullOrEmpty(task.TaskParameters))
                {
                    attributeUpdates.Add(Constants.COLUMN_TASK_PARAMS, new AttributeValueUpdate(new AttributeValue(task.TaskParameters), AttributeAction.PUT));
                }
                else
                {
                    attributeUpdates[Constants.COLUMN_TASK_PARAMS] = new AttributeValueUpdate()
                    {
                        Action = AttributeAction.DELETE
                    };
                }

                if (!string.IsNullOrEmpty(task.WorkingDirectory))
                {
                    attributeUpdates.Add(Constants.COLUMN_WORKING_DIRECTORY, new AttributeValueUpdate(new AttributeValue(task.WorkingDirectory), AttributeAction.PUT));
                }

                UpdateItemResponse response = client.UpdateItemAsync(ClientFactory.DynamoDbTable3, key, attributeUpdates).Result;

                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return new OkObjectResult(true);
                else
                    return new StatusCodeResult((int)response.HttpStatusCode);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable3}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        public static Dictionary<string, List<ODTask>> GetTasksByCategory()//another overloading could get the category and returns a list not a dic!
        {
            var list = GetODTaskList();

            Dictionary<string, List<ODTask>> dic = new Dictionary<string, List<ODTask>>();

            foreach (ODTask odTask in list)
            {
                if (!dic.ContainsKey(odTask.CategoryGroup))
                {
                    dic.Add(odTask.CategoryGroup, new List<ODTask> { odTask });
                }
                else
                {
                    dic[odTask.CategoryGroup].Add(odTask);
                }

            }

            return dic;
        }

        #endregion Tasks

        #region CompletedTasks

        public static ActionResult GetCompletedTaskListRes(CompletedTaskPayload payload)
        {
            List<CompletedTask> completedTaskList = GetCompletedTasks(payload);
            return new OkObjectResult(completedTaskList.ToArray());
        }
        public static List<CompletedTask> GetCompletedTasks(CompletedTaskPayload payload)
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            ScanResponse result;

            var req = new ScanRequest
            {
                TableName = ClientFactory.DynamoDbTableCompletedTasks
            };

            result = client.ScanAsync(req).Result;

            List<CompletedTask> list = new List<CompletedTask>();

            foreach (var item in result.Items)
            {
                if (item[Constants.COLUMN_COMPLETED_TASK_DEPLOYMENT_ID].S != payload.DeploymentId)
                    continue;

                CompletedTask task = new CompletedTask
                {
                    Id = item[Constants.COLUMN_COMPLETED_TASK_ID].S,
                    Name = item[Constants.COLUMN_COMPLETED_TASK_NAME].S,
                    CategoryGroup = item[Constants.COLUMN_COMPLETED_TASK_CATEGORY_GROUP].S,
                    Description = item[Constants.COLUMN_COMPLETED_TASK_DESCRIPTION].S,
                    // TaskParameters = item[Constants.COLUMN_COMPLETED_TASK_PARAMS].S,
                    StartDateTime = item[Constants.COLUMN_COMPLETED_TASK_START_DATE_TIME].S,
                    EndDateTime = item[Constants.COLUMN_COMPLETED_TASK_END_DATE_TIME].S,
                    Status = item[Constants.COLUMN_COMPLETED_TASK_STATUS].S,
                    //Error = item[Constants.COLUMN_COMPLETED_TASK_ERROR].S,
                    ExecuterName = item[Constants.COLUMN_COMPLETED_TASK_EXECUTER_NAME].S,
                    DeploymentId = item[Constants.COLUMN_COMPLETED_TASK_DEPLOYMENT_ID].S,
                    FdControllerId = item[Constants.COLUMN_COMPLETED_TASK_FD_CONTROLLER_ID].S,
                };

                if (item.ContainsKey(Constants.COLUMN_COMPLETED_TASK_PARAMS))
                {
                    task.TaskParameters = item[Constants.COLUMN_COMPLETED_TASK_PARAMS].S;
                }

                if (item.ContainsKey(Constants.COLUMN_COMPLETED_TASK_ERROR))
                {
                    task.Error = item[Constants.COLUMN_COMPLETED_TASK_ERROR].S;
                }

                list.Add(task);
            }
            return list;
        }
        public static ActionResult AddCompletedTask(CompletedTask task)
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            var Id = Guid.NewGuid().ToString();

            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
            {
                { Constants.COLUMN_COMPLETED_TASK_ID, new AttributeValue(Id) },
                { Constants.COLUMN_COMPLETED_TASK_NAME, new AttributeValue(task.Name) },
                { Constants.COLUMN_COMPLETED_TASK_CATEGORY_GROUP, new AttributeValue(task.CategoryGroup) },
                { Constants.COLUMN_COMPLETED_TASK_DESCRIPTION, new AttributeValue(task.Description) },
                { Constants.COLUMN_COMPLETED_TASK_PARAMS, new AttributeValue(task.TaskParameters) },
                { Constants.COLUMN_COMPLETED_TASK_START_DATE_TIME, new AttributeValue(task.StartDateTime) },
                { Constants.COLUMN_COMPLETED_TASK_END_DATE_TIME, new AttributeValue(task.EndDateTime) },
                { Constants.COLUMN_COMPLETED_TASK_STATUS, new AttributeValue(task.Status) },
                { Constants.COLUMN_COMPLETED_TASK_ERROR, new AttributeValue(task.Error) },
                { Constants.COLUMN_COMPLETED_TASK_EXECUTER_NAME, new AttributeValue(task.ExecuterName) },
                { Constants.COLUMN_COMPLETED_TASK_DEPLOYMENT_ID, new AttributeValue(task.DeploymentId) },
                { Constants.COLUMN_COMPLETED_TASK_FD_CONTROLLER_ID, new AttributeValue(task.FdControllerId) },
            };

            PutItemResponse response = client.PutItemAsync(ClientFactory.DynamoDbTable3, dic).Result;

            if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                return new OkObjectResult(true);
            else
                return new StatusCodeResult((int)response.HttpStatusCode);
        }

        #endregion CompletedTasks

        #region Flows
        public static ActionResult AddODFlow(ODFlow flow)
        {
            IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

            var Id = Guid.NewGuid().ToString();

            var addTime = DateTime.Now.ToString();

            string tasksAsJson = JsonConvert.SerializeObject(flow.Tasks.ToArray());

            string cleanupTasksAsJson = JsonConvert.SerializeObject(flow.CleanupTasks.ToArray());

            //Values can not be empty!
            Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
            {
                { Constants.COLUMN_FLOW_ID, new AttributeValue(Id) },
                { Constants.COLUMN_FLOW_NAME, new AttributeValue(flow.Name) },
                { Constants.COLUMN_FLOW_DESCRIPTION, new AttributeValue(flow.Description) },
                { Constants.COLUMN_FLOW_TASKS, new AttributeValue(tasksAsJson) },
                { Constants.COLUMN_FLOW_CLEANUP_TASKS, new AttributeValue(cleanupTasksAsJson) },
                { Constants.COLUMN_RUN_IN_PARALLEL, new AttributeValue(flow.RunInParallel.ToString())},
                { Constants.COLUMN_IS_FLINK_FLOW, new AttributeValue(flow.IsFlinkFlow.ToString())},
                { Constants.COLUMN_CREATED_BY, new AttributeValue(flow.CreatedBy.ToString()) },
                { Constants.COLUMN_CREATED_AT, new AttributeValue(addTime) },
                { Constants.COLUMN_UPDATED_BY, new AttributeValue(flow.CreatedBy.ToString()) },
                { Constants.COLUMN_UPDATED_AT, new AttributeValue(addTime) },
            };

            PutItemResponse response = client.PutItemAsync(ClientFactory.DynamoDbTable2, dic).Result;

            if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                return new OkObjectResult(true);
            else
                return new StatusCodeResult((int)response.HttpStatusCode);
        }

        public static ODTask GetFlow(string id)
        {
            return null;
        }

        private static ODFlow[] ODFlowList()
        {
            try
            {
                IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

                ScanResponse result;

                var req = new ScanRequest
                {
                    TableName = ClientFactory.DynamoDbTable2
                };

                result = client.ScanAsync(req).Result;

                if (!(result.HttpStatusCode == System.Net.HttpStatusCode.OK))
                {
                    Console.WriteLine($"Invalid response when invoking ScanAsync on DynamoDb {ClientFactory.DynamoDbTable2}:");
                    Console.WriteLine(result);
                    return null;
                }

                List<ODFlow> list = new List<ODFlow>();

                foreach (var item in result.Items)
                {
                    ODFlow flow = new ODFlow
                    {
                        Id = item[Constants.COLUMN_FLOW_ID].S,
                        Name = item[Constants.COLUMN_FLOW_NAME].S,
                        RunInParallel = item[Constants.COLUMN_RUN_IN_PARALLEL].S,
                        IsFlinkFlow = item[Constants.COLUMN_IS_FLINK_FLOW].S
                    };

                    if (item.ContainsKey(Constants.COLUMN_FLOW_DESCRIPTION))
                    {
                        flow.Description = item[Constants.COLUMN_FLOW_DESCRIPTION].S;
                    }

                    var jsonTasks = item[Constants.COLUMN_FLOW_TASKS].S;
                    var tasks = JsonConvert.DeserializeObject<List<ODTask>>(jsonTasks);
                    flow.Tasks = tasks;

                    if (item.ContainsKey(Constants.COLUMN_FLOW_CLEANUP_TASKS))
                    {
                        var jsonCleanupTasks = item[Constants.COLUMN_FLOW_CLEANUP_TASKS].S;
                        var cleanupTasks = JsonConvert.DeserializeObject<List<ODTask>>(jsonCleanupTasks);
                        flow.CleanupTasks = cleanupTasks;
                    }

                    if (item.ContainsKey(Constants.COLUMN_CREATED_BY))
                    {
                        var createdBy = item[Constants.COLUMN_CREATED_BY].S;
                        flow.CreatedBy = createdBy;
                    }

                    if (item.ContainsKey(Constants.COLUMN_CREATED_AT))
                    {
                        var createdAt = item[Constants.COLUMN_CREATED_AT].S;
                        flow.CreatedAt = createdAt;
                    }

                    if (item.ContainsKey(Constants.COLUMN_UPDATED_BY))
                    {
                        var updatedBy = item[Constants.COLUMN_UPDATED_BY].S;
                        flow.UpdatedBy = updatedBy;
                    }

                    if (item.ContainsKey(Constants.COLUMN_UPDATED_AT))
                    {
                        var updatedAt = item[Constants.COLUMN_UPDATED_AT].S;
                        flow.UpdatedAt = updatedAt;
                    }

                    list.Add(flow);
                }

                return list.ToArray();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable2}", e);
                Console.WriteLine(e);
                return null;
            }
        }

        public static ActionResult GetFilteredODFlowList(string userGroup)
        {
            var odFlowListVal = ODFlowList();

            if (odFlowListVal == null)
            {
                Console.WriteLine($"Errors encountered {ClientFactory.DynamoDbTable2}");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }

            List<ODFlow> originalList = odFlowListVal.ToList();

            List<ODFlow> filteredList = originalList.FindAll(p => p.UserGroup == userGroup);

            return new OkObjectResult(filteredList);
        }

        public static ActionResult GetODFlowList()
        {
            try
            {
                var odFlowListVal = ODFlowList();

                if (odFlowListVal == null)
                {
                    Console.WriteLine($"Errors encountered {ClientFactory.DynamoDbTable2}");
                    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                }

                List<ODFlow> list = odFlowListVal.ToList();

                return new OkObjectResult(list.ToArray());
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable2}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        public static ActionResult DeleteODFlow(string id)
        {
            try
            {
                IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

                Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
                {
                    { Constants.COLUMN_TASK_ID, new AttributeValue(id) }
                };

                DeleteItemResponse response = client.DeleteItemAsync(new DeleteItemRequest(ClientFactory.DynamoDbTable2, key)).Result;

                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return new OkObjectResult(true);
                else
                    return new StatusCodeResult((int)response.HttpStatusCode);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable2}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        public static ActionResult UpdateODFlow(ODFlow flow)
        {
            try
            {
                Console.WriteLine(string.Format("Got flow id {0}, Name {1}", flow.Id, flow.Name));

                IAmazonDynamoDB client = ClientFactory.GetAmazonDynamoDBClient();

                var updateTime = DateTime.Now.ToString();

                Dictionary<string, AttributeValueUpdate> attributeUpdates = new Dictionary<string, AttributeValueUpdate>
                {
                    { Constants.COLUMN_FLOW_NAME,         new AttributeValueUpdate(new AttributeValue(flow.Name), AttributeAction.PUT) },
                    { Constants.COLUMN_FLOW_DESCRIPTION,  new AttributeValueUpdate(new AttributeValue(flow.Description), AttributeAction.PUT) },
                    { Constants.COLUMN_RUN_IN_PARALLEL,    new AttributeValueUpdate(new AttributeValue(flow.RunInParallel.ToString()), AttributeAction.PUT)},
                    { Constants.COLUMN_IS_FLINK_FLOW, new AttributeValueUpdate(new AttributeValue(flow.IsFlinkFlow.ToString()), AttributeAction.PUT)},
                    { Constants.COLUMN_UPDATED_BY, new AttributeValueUpdate(new AttributeValue(flow.UpdatedBy), AttributeAction.PUT) },
                    { Constants.COLUMN_UPDATED_AT, new AttributeValueUpdate(new AttributeValue(updateTime), AttributeAction.PUT) }
                };

                if (flow.Tasks != null)
                {
                    string tasksAsJson = JsonConvert.SerializeObject(flow.Tasks.ToArray());

                    attributeUpdates.Add(Constants.COLUMN_FLOW_TASKS, new AttributeValueUpdate(new AttributeValue(tasksAsJson), AttributeAction.PUT));
                }
                else
                {
                    attributeUpdates[Constants.COLUMN_FLOW_TASKS] = new AttributeValueUpdate()
                    {
                        Action = AttributeAction.DELETE
                    };
                }

                if (flow.CleanupTasks != null)
                {
                    string cleanupTasksAsJson = JsonConvert.SerializeObject(flow.CleanupTasks.ToArray());

                    attributeUpdates.Add(Constants.COLUMN_FLOW_CLEANUP_TASKS, new AttributeValueUpdate(new AttributeValue(cleanupTasksAsJson), AttributeAction.PUT));
                }
                else
                {
                    attributeUpdates[Constants.COLUMN_FLOW_CLEANUP_TASKS] = new AttributeValueUpdate()
                    {
                        Action = AttributeAction.DELETE
                    };
                }

                Dictionary<string, AttributeValue> key = new Dictionary<string, AttributeValue>
                {
                  { Constants.COLUMN_FLOW_ID, new AttributeValue(flow.Id) }
                };

                UpdateItemResponse response = client.UpdateItemAsync(ClientFactory.DynamoDbTable2, key, attributeUpdates).Result;

                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return new OkObjectResult(true);
                else
                    return new StatusCodeResult((int)response.HttpStatusCode);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Exception when scanning DB {ClientFactory.DynamoDbTable2}", e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        #endregion Flows

        #region Deployments

        public static ActionResult GetS3ConfigBucket(string id)
        {
            try
            {
                string accessKey = System.Environment.GetEnvironmentVariable("AWS_ACCESS_KEY_ID");
                Console.WriteLine(accessKey);

                string secretKey = System.Environment.GetEnvironmentVariable("AWS_SECRET_ACCESS_KEY");
                Console.WriteLine(secretKey);

                string token = System.Environment.GetEnvironmentVariable("AWS_SESSION_TOKEN");
                Console.WriteLine(token);

                var client = new HttpClient();

                var signer = new AWS4RequestSigner(accessKey, secretKey);

                var content = new StringContent("", Encoding.UTF8, "application/json");

                string deploymentApiEndpoint = System.Environment.GetEnvironmentVariable("DEPLOYMENT_API_ENDPOINT");
                Console.WriteLine(deploymentApiEndpoint);

                if (string.IsNullOrEmpty(deploymentApiEndpoint))
                {
                    deploymentApiEndpoint = "https://dev.deployment.fd19.sports.intel.com/fd19/deployments"; //for INT env use-> "https://deployment-int.tee.sports.intel.com/fd19/deployments"
                }

                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,

                    RequestUri = new Uri(deploymentApiEndpoint + "/" + id),

                    Content = content
                };

                //The token is mandatory
                request.Headers.Add("X-Amz-Security-Token", token);

                request = signer.Sign(request, "execute-api", "us-east-1").Result;

                HttpResponseMessage response = client.SendAsync(request).Result;

                if (!(response.StatusCode == HttpStatusCode.OK))
                {
                    Console.WriteLine("Invalid response when invoking remote lambda:");
                    Console.WriteLine(response);
                    return new StatusCodeResult((int)response.StatusCode);
                }

                var activeDeploymentJsonString = response.Content.ReadAsStringAsync().Result;

                JObject activeDeployment = JObject.Parse(activeDeploymentJsonString);

                var s3StaticBucket = activeDeployment["periodic_metadata"]["s3_bucket_static"].ToString();

                return new OkObjectResult(s3StaticBucket);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception when invoking lambda:");
                Console.WriteLine(e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        private static DeploymentDetails GetDeploymentDetails(string deploymentId, string deploymentApiEndpoint)
        {
            try
            {
                Console.WriteLine(string.Format("GetDeploymentDetails received deploymentApiEndpoint is {0}", deploymentApiEndpoint));

                Console.WriteLine("deploymentId=" + deploymentId);

                string accessKey = System.Environment.GetEnvironmentVariable("AWS_ACCESS_KEY_ID");
                Console.WriteLine(accessKey);

                string secretKey = System.Environment.GetEnvironmentVariable("AWS_SECRET_ACCESS_KEY");
                Console.WriteLine(secretKey);

                string token = System.Environment.GetEnvironmentVariable("AWS_SESSION_TOKEN");
                Console.WriteLine(token);

                var client = new HttpClient();

                var signer = new AWS4RequestSigner(accessKey, secretKey);

                var content = new StringContent("", Encoding.UTF8, "application/json");

                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,

                    RequestUri = new Uri(deploymentApiEndpoint + "/" + deploymentId),
                    //https://dev.deployment.fd19.sports.intel.com/fd19/deployments/
                    //https://deployment-int.tee.sports.intel.com/fd19/deployments
                    Content = content
                };

                //The token is mandatory
                request.Headers.Add("X-Amz-Security-Token", token);

                request = signer.Sign(request, "execute-api", "us-east-1").Result;

                HttpResponseMessage response = client.SendAsync(request).Result;

                if (!(response.StatusCode == HttpStatusCode.OK))
                {
                    Console.WriteLine(response);
                    return null;
                }

                var deploymentDetailsJsonString = response.Content.ReadAsStringAsync().Result;

                DeploymentDetails deploymentDetails = JsonConvert.DeserializeObject<DeploymentDetails>(deploymentDetailsJsonString);

                return deploymentDetails;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public static ActionResult GetActiveDeployments()
        {
            try
            {
                string accessKey = System.Environment.GetEnvironmentVariable("AWS_ACCESS_KEY_ID");
                Console.WriteLine(accessKey);

                string secretKey = System.Environment.GetEnvironmentVariable("AWS_SECRET_ACCESS_KEY");
                Console.WriteLine(secretKey);

                string token = System.Environment.GetEnvironmentVariable("AWS_SESSION_TOKEN");
                Console.WriteLine(token);

                var client = new HttpClient();

                var signer = new AWS4RequestSigner(accessKey, secretKey);

                var content = new StringContent("", Encoding.UTF8, "application/json");

                string deploymentApiEndpoint = System.Environment.GetEnvironmentVariable("DEPLOYMENT_API_ENDPOINT");
                Console.WriteLine(deploymentApiEndpoint);

                if (string.IsNullOrEmpty(deploymentApiEndpoint))
                {
                    deploymentApiEndpoint = "https://dev.deployment.fd19.sports.intel.com/fd19/deployments"; //for INT env use-> "https://deployment-int.tee.sports.intel.com/fd19/deployments"
                }

                Console.WriteLine(string.Format("deploymentApiEndpoint is {0}", deploymentApiEndpoint));

                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,

                    RequestUri = new Uri(deploymentApiEndpoint),

                    Content = content
                };

                //The token is mandatory
                request.Headers.Add("X-Amz-Security-Token", token);

                request = signer.Sign(request, "execute-api", "us-east-1").Result;

                HttpResponseMessage response = client.SendAsync(request).Result;

                if (!(response.StatusCode == HttpStatusCode.OK))
                {
                    Console.WriteLine("Invalid response when invoking remote lambda:");
                    Console.WriteLine(response);
                    return new StatusCodeResult((int)response.StatusCode);
                }

                var activeDeploymentsJsonString = response.Content.ReadAsStringAsync().Result;

                List<Deployment> activeDeployments = new List<Deployment>();

                var allDeployments = JsonConvert.DeserializeObject<List<Deployment>>(activeDeploymentsJsonString);

                foreach (Deployment deployment in allDeployments)
                {
                    if (deployment.deployment_status == "active")
                    {
                        DeploymentDetails deploymentDetails = GetDeploymentDetails(deployment.deployment_id, deploymentApiEndpoint);

                        Console.WriteLine(string.Format("deploymentDetails: deployment_id={0}, deployment_name={1}, deployment_status={2}, deployment_region={3}, default_game_id={4} ,game_id={5}",
                                            deployment.deployment_id, deployment.deployment_name, deployment.deployment_status, deploymentDetails.region, deploymentDetails.default_game_id, deploymentDetails.game_id));

                        try
                        {
                            activeDeployments.Add(new Deployment()
                            {
                                deployment_id = deployment.deployment_id,
                                deployment_name = deployment.deployment_name,
                                deployment_status = deployment.deployment_status,
                                deployment_region = deploymentDetails.region,
                                default_game_id = deploymentDetails.default_game_id,
                                game_id = deploymentDetails.game_id
                            });
                        }
                        catch (Exception xcp)
                        {
                            Console.WriteLine("xcp.Message" + xcp.Message + "xcp.StackTrace" + xcp.StackTrace);
                        }
                    }
                }
                return new OkObjectResult(activeDeployments.ToArray());
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception when invoking lambda:");
                Console.WriteLine(e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        public static ActionResult GetBucketFileList(ConfigurationPayload payload)
        {
            try
            {
                var getBucketFiles = GetBucketFiles(payload);

                if (getBucketFiles.Result == null)
                {
                    Console.WriteLine("Exception when getting files");
                    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                }

                List<string> files = getBucketFiles.Result;

                NodeEntryCollection cItems = new NodeEntryCollection();

                foreach (var fileEntry in files)
                {
                    cItems.AddEntry(fileEntry, 0);
                }

                var arr = cItems.Values.ToArray();

                List<FileNode> nodes = new List<FileNode>();

                //TODO currently the result isn't recurrsive and returns only first level of children
                foreach (NodeEntry nodeEntry in arr)
                {
                    var newNode = new FileNode { name = nodeEntry.name, fileType = "folder" };

                    if (nodeEntry.name.EndsWith(".json"))
                    {
                        newNode.fileType = "file";

                        nodes.Add(newNode);

                        continue;
                    }

                    newNode.children = new List<FileNode>();

                    foreach (var child in nodeEntry.children)
                    {
                        var newChild = new FileNode() { name = child.Key };

                        if (child.Key.EndsWith(".json"))
                        {
                            newChild.fileType = "file";
                        }
                        newNode.children.Add(newChild);
                    }

                    nodes.Add(newNode);
                }

                return new OkObjectResult(nodes);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }

        private async static Task<List<string>> GetBucketFiles(ConfigurationPayload payload)
        {
            GetStaticS3Bucket(payload.DeploymentId, out string staticBucket, out string bucketRegion);

            IAmazonS3 s3Client = ClientFactory.GetS3Client(bucketRegion);

            List<string> files = new List<string>();

            try
            {
                ListObjectsV2Request request = new ListObjectsV2Request
                {
                    BucketName = staticBucket,
                    MaxKeys = 1000
                };

                ListObjectsV2Response response;

                do
                {
                    response = await s3Client.ListObjectsV2Async(request);

                    // Process the response.
                    foreach (S3Object entry in response.S3Objects)
                    {
                        if (entry.Key.EndsWith(".json"))
                        {
                            files.Add(entry.Key);
                        }
                    }

                    request.ContinuationToken = response.NextContinuationToken;

                } while (response.IsTruncated);
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                Console.WriteLine("S3 error occurred. Exception: " + amazonS3Exception.ToString());
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
                return null;
            }

            return files;

        }

        private static void GetStaticS3Bucket(string deploymentId, out string staticBucket, out string bucketRegion)
        {
            staticBucket = string.Empty;
            bucketRegion = string.Empty;

            string accessKey = System.Environment.GetEnvironmentVariable("AWS_ACCESS_KEY_ID");
            Console.WriteLine("FOUND ACCESS KEY = " + accessKey);

            string secretKey = System.Environment.GetEnvironmentVariable("AWS_SECRET_ACCESS_KEY");
            Console.WriteLine("FOUND SECRET KEY = " + secretKey);

            string token = System.Environment.GetEnvironmentVariable("AWS_SESSION_TOKEN");
            Console.WriteLine("FOUND TOKEN = " + token);

            string deploymentApiEndpoint = System.Environment.GetEnvironmentVariable("DEPLOYMENT_API_ENDPOINT");
            Console.WriteLine(deploymentApiEndpoint);

            if (string.IsNullOrEmpty(deploymentApiEndpoint))
            {
                deploymentApiEndpoint = "https://dev.deployment.fd19.sports.intel.com/fd19/deployments"; //for INT env use-> "https://deployment-int.tee.sports.intel.com/fd19/deployments"
            }

            var client = new HttpClient();

            var signer = new AWS4RequestSigner(accessKey, secretKey);

            var content = new StringContent("", Encoding.UTF8, "application/json");

            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,

                RequestUri = new Uri(deploymentApiEndpoint + "/" + deploymentId),

                Content = content
            };

            //The token is mandatory
            request.Headers.Add("X-Amz-Security-Token", token);

            request = signer.Sign(request, "execute-api", "us-east-1").Result;

            HttpResponseMessage response = client.SendAsync(request).Result;

            var jsonData = response.Content.ReadAsStringAsync().Result;

            var configFile = JObject.Parse(jsonData);

            staticBucket = configFile["periodic_metadata"]["s3_bucket"].ToString();

            bucketRegion = configFile["region"].ToString();

            Console.WriteLine("FOUND STATIC BUCKET = " + staticBucket);

            Console.WriteLine("FOUND STATIC BUCKET REGION = " + bucketRegion);
        }

        public static ActionResult SetConfigContent(ConfigurationPayload payload)
        {
            var setConfigContentAsync = SetConfigContentAsync(payload);

            if (setConfigContentAsync.Result == null)
            {
                Console.WriteLine("Exception when setting config content");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }

            var result = setConfigContentAsync.Result;

            return new OkObjectResult(result);
        }

        static async Task<string> SetConfigContentAsync(ConfigurationPayload payload)
        {
            GetStaticS3Bucket(payload.DeploymentId, out string staticBucket, out string bucketRegion);

            //var bucketName = "intel-sports-us-east-1-teecontrol-" + payload.DeploymentId;

            IAmazonS3 s3Client = ClientFactory.GetS3Client(bucketRegion);

            var keyName = payload.KeyName;

            // 1. Put object-specify only key name for the new object.
            var putRequest1 = new PutObjectRequest
            {
                BucketName = staticBucket,//bucketName,
                Key = keyName,
                ContentBody = payload.ContentBody//"sample text"
            };

            try
            {
                PutObjectResponse response1 = await s3Client.PutObjectAsync(putRequest1);

                return response1.HttpStatusCode.ToString();
                // 2. Put the object-set ContentType and add metadata.
                //var putRequest2 = new PutObjectRequest
                //{
                //    BucketName = bucketName,
                //    Key = keyName2,
                //    FilePath = filePath,
                //    ContentType = "text/plain"
                //};

                //putRequest2.Metadata.Add("x-amz-meta-title", "someTitle");
                //PutObjectResponse response2 = await client.PutObjectAsync(putRequest2);
            }
            catch (AmazonS3Exception e)
            {
                Console.WriteLine("payload.keyName" + payload.KeyName + "payload.ContentBody" + payload.ContentBody + "bucketName" + staticBucket);
                Console.WriteLine(string.Format("Error encountered ***. Message:'{0}' when writing an object", e.Message));
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine("payload.keyName" + payload.KeyName + "payload.ContentBody" + payload.ContentBody + "bucketName" + staticBucket);
                Console.WriteLine(string.Format("Unknown encountered on server. Message:'{0}' when writing an object Details: {1}", e.Message, "putRequest1.Key=" + putRequest1.Key + "payload.keyName" + payload.KeyName + "payload.ContentBody" + payload.ContentBody + "bucketName" + staticBucket));
                return null;
            }
        }

        public static ActionResult GetConfigContent(ConfigurationPayload payload)
        {
            var getConfigFileContent = GetConfigFileContent(payload);

            if (getConfigFileContent.Result == null)
            {
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }

            var content = getConfigFileContent.Result;

            return new OkObjectResult(content);
        }

        private static async Task<JObject> GetConfigFileContent(ConfigurationPayload payload)
        {
            string bucket;
            string bucketRegion;

            if (payload.ConfigType == "Publisher" || payload.ConfigType == "DebugKit")
            {
                bucket = ClientFactory.S3ProgramsBucket;
                bucketRegion = ClientFactory.S3ProgramsBucketRegion;
            }
            else
            {
                GetStaticS3Bucket(payload.DeploymentId, out bucket, out bucketRegion);
            }

            IAmazonS3 s3Client = ClientFactory.GetS3Client(bucketRegion);

            var keyName = payload.KeyName;

            GetObjectRequest request = new GetObjectRequest
            {
                BucketName = bucket,//bucketName,
                Key = keyName
            };

            string responseBody = "";
            JObject configFile = null;

            try
            {
                using (GetObjectResponse response = await s3Client.GetObjectAsync(request))
                using (Stream responseStream = response.ResponseStream)
                using (StreamReader reader = new StreamReader(responseStream))
                {
                    string title = response.Metadata["x-amz-meta-title"]; // Assume you have "title" as medata added to the object.

                    Console.WriteLine("title=" + title);

                    string contentType = response.Headers["Content-Type"];

                    Console.WriteLine("contentType=" + contentType);

                    responseBody = reader.ReadToEnd(); // Now you process the response body.

                    Console.WriteLine("responseBody=" + responseBody);

                    //return responseBody;
                    configFile = JObject.Parse(responseBody);
                }
            }
            catch (AmazonS3Exception e)
            {
                // If bucket or object does not exist
                Console.WriteLine("Error encountered ***. Message:'{0}' when reading object", e.Message);
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine("Unknown encountered on server. Message:'{0}' when reading object", e.Message);
                return null;
            }

            return configFile;
        }
        #endregion Deployments

        #region FlinkTasks

        public static ActionResult GetFlinkJarList()
        {
            return new OkObjectResult(GetJars().Result);
        }

        private async static Task<List<string>> GetJars()
        {
            IAmazonS3 s3Client = ClientFactory.GetS3Client();

            List<string> jars = new List<string>();

            try
            {
                ListObjectsV2Request request = new ListObjectsV2Request
                {
                    BucketName = ClientFactory.S3ProgramsBucket,
                    Prefix = "Flink/FlinkJars",
                    MaxKeys = 1000
                };

                ListObjectsV2Response response;

                do
                {
                    response = await s3Client.ListObjectsV2Async(request);

                    // Process the response.
                    foreach (S3Object entry in response.S3Objects)
                    {
                        if (entry.Key.EndsWith(".jar"))
                        {
                            var jarName = entry.Key.Replace("Flink/FlinkJars/", "");

                            jars.Add(jarName);
                        }
                        //Console.WriteLine("key = {0} size = {1}",
                        //    entry.Key, entry.Size);
                    }

                    //Console.WriteLine("Next Continuation Token: {0}", response.NextContinuationToken);

                    request.ContinuationToken = response.NextContinuationToken;

                } while (response.IsTruncated);
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                Console.WriteLine("S3 error occurred. Exception: " + amazonS3Exception.ToString());
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.ToString());
                Console.ReadKey();
            }

            return jars;
        }

        #endregion FlinkTasks
        //Mongo DocumentDB
        //public static string CreateTask()
        //{
        //    string caKeyFilePath = "./rds-ca-2019-root.pem";//Environment.GetEnvironmentVariable(Constants.AWS_REGION);
        //    string dbName = "test";// Environment.GetEnvironmentVariable(Constants.AWS_REGION);
        //    string collectionName = "tasks";// Environment.GetEnvironmentVariable(Constants.AWS_REGION);

        //    string caContentString = "before";

        //    try
        //    {
        //        string template = "mongodb://{0}:{1}@{2}/test?ssl=true&replicaSet=rs0&readpreference={3}&retryWrites=false";
        //        string username = "master";
        //        string password = "gilshalev";
        //        string readPreference = "secondaryPreferred";
        //        string clusterEndpoint = "sample-cluster.cluster-cg3tqrom77fm.eu-west-1.docdb.amazonaws.com:27017";

        //        string connectionString = String.Format(template, username, password, clusterEndpoint, readPreference);

        //        // ADD CA certificate to local trust store
        //        // DO this once - Maybe when your service starts
        //        X509Store localTrustStore = new X509Store(StoreName.Root);

        //        caContentString = System.IO.File.ReadAllText(caKeyFilePath);//, Encoding.ASCII);

        //        //caContentString = caContentString.Replace("\n", "");
        //        //string embdedCa = "-----BEGIN CERTIFICATE-----\nMIIEBjCCAu6gAwIBAgIJAMc0ZzaSUK51MA0GCSqGSIb3DQEBCwUAMIGPMQswCQYD\nVQQGEwJVUzEQMA4GA1UEBwwHU2VhdHRsZTETMBEGA1UECAwKV2FzaGluZ3RvbjEi\nMCAGA1UECgwZQW1hem9uIFdlYiBTZXJ2aWNlcywgSW5jLjETMBEGA1UECwwKQW1h\nem9uIFJEUzEgMB4GA1UEAwwXQW1hem9uIFJEUyBSb290IDIwMTkgQ0EwHhcNMTkw\nODIyMTcwODUwWhcNMjQwODIyMTcwODUwWjCBjzELMAkGA1UEBhMCVVMxEDAOBgNV\nBAcMB1NlYXR0bGUxEzARBgNVBAgMCldhc2hpbmd0b24xIjAgBgNVBAoMGUFtYXpv\nbiBXZWIgU2VydmljZXMsIEluYy4xEzARBgNVBAsMCkFtYXpvbiBSRFMxIDAeBgNV\nBAMMF0FtYXpvbiBSRFMgUm9vdCAyMDE5IENBMIIBIjANBgkqhkiG9w0BAQEFAAOC\nAQ8AMIIBCgKCAQEArXnF/E6/Qh+ku3hQTSKPMhQQlCpoWvnIthzX6MK3p5a0eXKZ\noWIjYcNNG6UwJjp4fUXl6glp53Jobn+tWNX88dNH2n8DVbppSwScVE2LpuL+94vY\n0EYE/XxN7svKea8YvlrqkUBKyxLxTjh+U/KrGOaHxz9v0l6ZNlDbuaZw3qIWdD/I\n6aNbGeRUVtpM6P+bWIoxVl/caQylQS6CEYUk+CpVyJSkopwJlzXT07tMoDL5WgX9\nO08KVgDNz9qP/IGtAcRduRcNioH3E9v981QO1zt/Gpb2f8NqAjUUCUZzOnij6mx9\nMcZ+9cWX88CRzR0vQODWuZscgI08NvM69Fn2SQIDAQABo2MwYTAOBgNVHQ8BAf8E\nBAMCAQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUc19g2LzLA5j0Kxc0LjZa\npmD/vB8wHwYDVR0jBBgwFoAUc19g2LzLA5j0Kxc0LjZapmD/vB8wDQYJKoZIhvcN\nAQELBQADggEBAHAG7WTmyjzPRIM85rVj+fWHsLIvqpw6DObIjMWokpliCeMINZFV\nynfgBKsf1ExwbvJNzYFXW6dihnguDG9VMPpi2up/ctQTN8tm9nDKOy08uNZoofMc\nNUZxKCEkVKZv+IL4oHoeayt8egtv3ujJM6V14AstMQ6SwvwvA93EP/Ug2e4WAXHu\ncbI1NAbUgVDqp+DRdfvZkgYKryjTWd/0+1fS8X1bBZVWzl7eirNVnHbSH2ZDpNuY\n0SBd8dj5F6ld3t58ydZbrTHze7JJOd8ijySAp4/kiu9UfZWuTPABzDa/DSdz9Dk/\nzPW4CXXvhLmE02TA9/HeCw3KEHIwicNuEfw=\n-----END CERTIFICATE-----\n";
        //        //string embdedCa = "-----BEGIN CERTIFICATE-----nMIIEBjCCAu6gAwIBAgIJAMc0ZzaSUK51MA0GCSqGSIb3DQEBCwUAMIGPMQswCQYDVQQGEwJVUzEQMA4GA1UEBwwHU2VhdHRsZTETMBEGA1UECAwKV2FzaGluZ3RvbjEiMCAGA1UECgwZQW1hem9uIFdlYiBTZXJ2aWNlcywgSW5jLjETMBEGA1UECwwKQW1hem9uIFJEUzEgMB4GA1UEAwwXQW1hem9uIFJEUyBSb290IDIwMTkgQ0EwHhcNMTkwODIyMTcwODUwWhcNMjQwODIyMTcwODUwWjCBjzELMAkGA1UEBhMCVVMxEDAOBgNVBAcMB1NlYXR0bGUxEzARBgNVBAgMCldhc2hpbmd0b24xIjAgBgNVBAoMGUFtYXpvbiBXZWIgU2VydmljZXMsIEluYy4xEzARBgNVBAsMCkFtYXpvbiBSRFMxIDAeBgNVBAMMF0FtYXpvbiBSRFMgUm9vdCAyMDE5IENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArXnF/E6/Qh+ku3hQTSKPMhQQlCpoWvnIthzX6MK3p5a0eXKZoWIjYcNNG6UwJjp4fUXl6glp53Jobn+tWNX88dNH2n8DVbppSwScVE2LpuL+94vY0EYE/XxN7svKea8YvlrqkUBKyxLxTjh+U/KrGOaHxz9v0l6ZNlDbuaZw3qIWdD/I6aNbGeRUVtpM6P+bWIoxVl/caQylQS6CEYUk+CpVyJSkopwJlzXT07tMoDL5WgX9O08KVgDNz9qP/IGtAcRduRcNioH3E9v981QO1zt/Gpb2f8NqAjUUCUZzOnij6mx9McZ+9cWX88CRzR0vQODWuZscgI08NvM69Fn2SQIDAQABo2MwYTAOBgNVHQ8BAf8EBAMCAQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUc19g2LzLA5j0Kxc0LjZapmD/vB8wHwYDVR0jBBgwFoAUc19g2LzLA5j0Kxc0LjZapmD/vB8wDQYJKoZIhvcNAQELBQADggEBAHAG7WTmyjzPRIM85rVj+fWHsLIvqpw6DObIjMWokpliCeMINZFVynfgBKsf1ExwbvJNzYFXW6dihnguDG9VMPpi2up/ctQTN8tm9nDKOy08uNZoofMcNUZxKCEkVKZv+IL4oHoeayt8egtv3ujJM6V14AstMQ6SwvwvA93EP/Ug2e4WAXHucbI1NAbUgVDqp+DRdfvZkgYKryjTWd/0+1fS8X1bBZVWzl7eirNVnHbSH2ZDpNuY0SBd8dj5F6ld3t58ydZbrTHze7JJOd8ijySAp4/kiu9UfZWuTPABzDa/DSdz9Dk/zPW4CXXvhLmE02TA9/HeCw3KEHIwicNuEfw=-----END CERTIFICATE-----";
        //        X509Certificate2 caCert = new X509Certificate2(Encoding.ASCII.GetBytes(caContentString));
        //        //X509Certificate2 caCert = new X509Certificate2(Encoding.ASCII.GetBytes(embdedCa));


        //        try
        //        {
        //            localTrustStore.Open(OpenFlags.ReadWrite);
        //            localTrustStore.Add(caCert);
        //        }
        //        catch (Exception ex)
        //        {
        //            Console.WriteLine("Root certificate import failed: " + ex.Message);
        //            throw;
        //        }
        //        finally
        //        {
        //            localTrustStore.Close();
        //        }

        //        //var settings = MongoClientSettings.FromUrl(new MongoUrl("mongodb://master:gilshalev@sample-cluster.cluster-cg3tqrom77fm.eu-west-1.docdb.amazonaws.com:27017/test?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false"));// connectionString));
        //        //settings.AllowInsecureTls = true;
        //        //settings.SslSettings = new SslSettings();
        //        //settings.SslSettings.CheckCertificateRevocation = false;
        //        //settings.SslSettings.ServerCertificateValidationCallback = (o, c, ch, er) => true;

        //        //var client = new MongoClient(settings);

        //        var client = new MongoClient("mongodb://master:gilshalev@sample-cluster.cluster-cg3tqrom77fm.eu-west-1.docdb.amazonaws.com:27017/?ssl=true&ssl_ca_certs=rds-ca-2019-root.pem&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false");
        //        //var client = new MongoClient("mongodb://master:gilshalev@no-tls.cluster-cg3tqrom77fm.eu-west-1.docdb.amazonaws.com:27017/test?replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false");

        //        var database = client.GetDatabase(dbName);

        //        var collection = database.GetCollection<BsonDocument>(collectionName);

        //        var docToInsert = new BsonDocument { { "gil", 1000000 } };

        //        collection.InsertOne(docToInsert);
        //    }
        //    catch (Exception xcp)
        //    {
        //        Console.WriteLine(xcp.Message);

        //        return xcp.Message;
        //    }

        //    return "OK";
        //}
        public static ActionResult GetMQEndpoints()
        {
            try
            {
                Console.WriteLine("Inside GetMQEndpoints");

                string accessKey = System.Environment.GetEnvironmentVariable("AWS_ACCESS_KEY_ID");
                Console.WriteLine(accessKey);

                string secretKey = System.Environment.GetEnvironmentVariable("AWS_SECRET_ACCESS_KEY");
                Console.WriteLine(secretKey);

                string token = System.Environment.GetEnvironmentVariable("AWS_SESSION_TOKEN");
                Console.WriteLine(token);

                var client = new HttpClient();

                var signer = new AWS4RequestSigner(accessKey, secretKey);

                var content = new StringContent("", Encoding.UTF8, "application/json");

                //TODO Read from deployment.json the endpoint address -->use env variable!!!

                string mqEndpoints = "https://mq-auth-int.tee.sports.intel.com/token";
               
                //string mqEndpoints = "https://mq-auth-test.tee.sports.intel.com/token";
                //string mqEndpoints = "https://mq-auth-dev.tee.sports.intel.com/token";

                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Get,

                    RequestUri = new Uri(mqEndpoints),

                    Content = content
                };

                //The token is mandatory
                request.Headers.Add("X-Amz-Security-Token", token);

                request = signer.Sign(request, "execute-api", "us-east-1").Result;

                HttpResponseMessage response = client.SendAsync(request).Result;

                if (!(response.StatusCode == HttpStatusCode.OK))
                {
                    Console.WriteLine("Invalid response when invoking remote lambda:");
                    Console.WriteLine(response);
                    return new StatusCodeResult((int)response.StatusCode);
                }

                var mqEndpointsJsonString = response.Content.ReadAsStringAsync().Result;

                var brokerData = JsonConvert.DeserializeObject<BrokerData>(mqEndpointsJsonString);

                return new OkObjectResult(brokerData);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception when invoking lambda:");
                Console.WriteLine(e);
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}

//settings.AllowInsecureTls = true;
//settings.UseTls = false;

//settings.SslSettings = new SslSettings()
//{
//  CheckCertificateRevocation = false,
//  ServerCertificateValidationCallback = (o, c, ch, er) => true,
//  //ServicePointManager.ServerCertificateValidationCallback += (o, c, ch, er) => true;
//};


//var embeddedProvider = new EmbeddedFileProvider(Assembly.GetExecutingAssembly());

//byte[] buffer = new byte[1456];
//using (var reader = embeddedProvider.GetFileInfo("rds-ca-2019-root.pem").CreateReadStream())
//{
//  // some logic with stream reader
//  //byte [] buffer = new byte[1456];
//  int bytes = reader.Read(buffer, 0,1456);
//}



//static List<Folder> GetFoldersFormStrings(List<string> strings)
//{
//    var folders = new List<Folder>();
//    strings.Sort(StringComparer.InvariantCultureIgnoreCase);
//    var folderByPath = new Dictionary<string, Folder>();
//    foreach (var str in strings)
//    {
//        if (str.EndsWith("/")) // we have a folder
//        {
//            EnsureFolder(folders, folderByPath, str);
//        }
//        else // we have a file
//        {
//            var lastSlashPosition = str.LastIndexOf("/");
//            var parentFolderPath = str.Substring(0, lastSlashPosition + 1);
//            var parentFolder = EnsureFolder(folders, folderByPath, parentFolderPath);
//            var fileName = str.Substring(lastSlashPosition + 1);
//            var file = new Fd19ControllerApi.Common.Model.File
//            {
//                Name = fileName
//            };
//            parentFolder.Files.Add(file);
//        }
//    }
//    return folders;
//}
//private static Folder EnsureFolder(List<Folder> rootFolders, Dictionary<string, Folder> folderByPath, string folderPath)
//{
//    if (!folderByPath.TryGetValue(folderPath, out var folder))
//    {
//        var folderPathWithoutEndSlash = folderPath.TrimEnd('/');
//        var lastSlashPosition = folderPathWithoutEndSlash.LastIndexOf("/");
//        List<Folder> folders;
//        string folderName;
//        if (lastSlashPosition < 0) // it's a first level folder
//        {
//            folderName = folderPathWithoutEndSlash;
//            folders = rootFolders;
//        }
//        else
//        {
//            var parentFolderPath = folderPath.Substring(0, lastSlashPosition + 1);
//            folders = folderByPath[parentFolderPath].Folders;
//            folderName = folderPathWithoutEndSlash.Substring(lastSlashPosition + 1);
//        }
//        folder = new Folder
//        {
//            Name = folderName
//        };
//        folders.Add(folder);
//        folderByPath.Add(folderPath, folder);
//    }
//    return folder;
//}
//private static void ShowFolders(List<Folder> folders)
//{
//    foreach (var folder in folders)
//    {
//        ShowFolder(folder, 0);
//    }
//}
//private static void ShowFolder(Folder folder, int indentation)
//{
//    string folderIndentation = new string(' ', indentation);
//    string fileIndentation = folderIndentation + "  ";
//    Console.WriteLine($"{folderIndentation}-{folder.Name}");
//    foreach (var file in folder.Files)
//    {
//        Console.WriteLine($"{fileIndentation}-{file.Name}");
//    }
//    foreach (var subfolder in folder.Folders)
//    {
//        ShowFolder(subfolder, indentation + 2);
//    }
//}