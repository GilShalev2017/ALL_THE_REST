using Amazon;
using Amazon.DynamoDBv2;
using Amazon.S3;
using Fd19ControllerApi;
using System;

namespace Common
{
    public class ClientFactory
    {
        public static IAmazonDynamoDB GetAmazonDynamoDBClient()
        {
            var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(AwsRegion));

            return dynamoDbClient;
        }

        public static IAmazonS3 GetS3Client(string regionOverride = null)
        {
            IAmazonS3 s3Client = null;
            if (!(regionOverride == null))
            {
                s3Client = new AmazonS3Client(RegionEndpoint.GetBySystemName(regionOverride));
            }
            else
            {
                s3Client = new AmazonS3Client(RegionEndpoint.GetBySystemName(AwsRegion));
            }

            return s3Client;
        }

        private static string _awsRegion;
        public static string AwsRegion
        {
            get
            {
                if (string.IsNullOrEmpty(_awsRegion))
                {
                    _awsRegion = Environment.GetEnvironmentVariable(Constants.AWS_REGION);
                    if (_awsRegion == null)
                    {
                        _awsRegion = Startup.Configuration[Constants.AWS_REGION];
                        if (_awsRegion == null)
                        {
                            var chain = new Amazon.Runtime.CredentialManagement.CredentialProfileStoreChain();
                            Amazon.Runtime.CredentialManagement.CredentialProfile awsCredentials;
                            if (chain.TryGetProfile("default", out awsCredentials))
                            {
                                _awsRegion = awsCredentials.Region.SystemName;
                            }
                        }
                    }
                }
                return _awsRegion;
            }
        }

        private static string _dynamoDbTable;
        public static string DynamoDbTable
        {
            get
            {
                if (string.IsNullOrEmpty(_dynamoDbTable))
                {
                    _dynamoDbTable = Environment.GetEnvironmentVariable(Constants.DYNAMO_DB_PROGRAMS);
                    if (_dynamoDbTable == null)
                    {
                        _dynamoDbTable = Startup.Configuration[Constants.DYNAMO_DB_PROGRAMS];
                    }
                }
                return _dynamoDbTable;
            }
        }

        private static string _dynamoDbTable2;
        public static string DynamoDbTable2
        {
            get
            {
                if (string.IsNullOrEmpty(_dynamoDbTable2))
                {
                    _dynamoDbTable2 = Environment.GetEnvironmentVariable(Constants.DYNAMO_DB_FLOWS);
                    if (_dynamoDbTable2 == null)
                    {
                        _dynamoDbTable2 = Startup.Configuration[Constants.DYNAMO_DB_FLOWS];
                    }
                }
                return _dynamoDbTable2;
            }
        }

        private static string _dynamoDbTable3;
        public static string DynamoDbTable3
        {
            get
            {
                if (string.IsNullOrEmpty(_dynamoDbTable3))
                {
                    _dynamoDbTable3 = Environment.GetEnvironmentVariable(Constants.DYNAMO_DB_TASKS);
                    if (_dynamoDbTable3 == null)
                    {
                        _dynamoDbTable3 = Startup.Configuration[Constants.DYNAMO_DB_TASKS];
                    }
                }
                return _dynamoDbTable3;
            }
        }

        private static string _dynamoDbTableCompletedTasks;
        public static string DynamoDbTableCompletedTasks
        {
            get
            {
                if (string.IsNullOrEmpty(_dynamoDbTableCompletedTasks))
                {
                    _dynamoDbTableCompletedTasks = Environment.GetEnvironmentVariable(Constants.DYNAMO_DB_COMPLETED_TASKS);
                    if (_dynamoDbTableCompletedTasks == null)
                    {
                        _dynamoDbTableCompletedTasks = Startup.Configuration[Constants.DYNAMO_DB_COMPLETED_TASKS];
                    }
                }
                return _dynamoDbTableCompletedTasks;
            }
        }

        private static string _s3ProgramsBucket;
        public static string S3ProgramsBucket
        {
            get
            {
                if (string.IsNullOrEmpty(_s3ProgramsBucket))
                {
                    _s3ProgramsBucket = Environment.GetEnvironmentVariable(Constants.S3_PROGRAMS_BUCKET);
                    if (_s3ProgramsBucket == null)
                    {
                        _s3ProgramsBucket = Startup.Configuration[Constants.S3_PROGRAMS_BUCKET];
                    }
                }
                return _s3ProgramsBucket;
            }
        }

        private static string _s3ProgramsBucketRegion;
        public static string S3ProgramsBucketRegion
        {
            get
            {
                if (string.IsNullOrEmpty(_s3ProgramsBucketRegion))
                {
                    _s3ProgramsBucketRegion = Environment.GetEnvironmentVariable(Constants.S3_PROGRAMS_BUCKET_REGION);
                    if (_s3ProgramsBucketRegion == null)
                    {
                        _s3ProgramsBucketRegion = Startup.Configuration[Constants.S3_PROGRAMS_BUCKET_REGION];
                    }
                }
                return _s3ProgramsBucketRegion;
            }
        }

    }
}
