using Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Fd19ControllerApi.Common.Model;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Common.Model;
using System;

namespace UtilityFunctionTests
{
    [TestClass]
    public class UnitTest1
    {
        //[TestMethod]
        //public void TestMethod1()
        //{
        //    var res = UtilityFunctions.GetActiveDeployments();
        //}

        //[TestMethod]
        //public void NewGetBucketFileTree()
        //{
        //    GeneralServicePayload generalServicePayload = new GeneralServicePayload() { BucketName = "debug-kits", BucketBaseKey = "e02v4402wul18nh", BucketRegion = "us-east-1" };

        //    var res = UtilityFunctions.NewGetBucketFileTree(generalServicePayload);
        //}

        [TestMethod]
        public void TestAddProgram()
        {
            Environment.SetEnvironmentVariable("AWS_REGION", "us-west-2");
            Environment.SetEnvironmentVariable("REGION", "us-west-2");
            Environment.SetEnvironmentVariable("PROGRAMS_BUCKET", "intel-sports-us-west-2-fdtest");
            Environment.SetEnvironmentVariable("DYNAMO_DB_PROGRAMS", "pdaas_fdtest_fdcontroller-programs");

            ODProgram program = new ODProgram();
            program.Name = "ZZZ";
            program.Description = "ZZZ";
            program.Package = "ZZZ";
            program.IsPackageCompressed = true;
            program.ExecutedProgram = "ZZZ";
            program.ExecutedProgramParams = "ZZZ";
            program.CategoryGroup = CategoryGroup.Debug;
            program.ProgramType = ProgramType.bashScript;
            program.ConfigurationFile = "ZZZ";
            program.CreatedBy = "ZZZ";
            program.UpdatedBy = "ZZZ";

            var res = UtilityFunctions.AddODProgram(program);
        }


        [TestMethod]
        public void TestDeleteProgram()
        {
            Environment.SetEnvironmentVariable("AWS_REGION", "us-west-2");
            Environment.SetEnvironmentVariable("REGION", "us-west-2");
            Environment.SetEnvironmentVariable("PROGRAMS_BUCKET", "intel-sports-us-west-2-fdtest");
            Environment.SetEnvironmentVariable("DYNAMO_DB_PROGRAMS", "pdaas_fdtest_fdcontroller-programs");
            var res = UtilityFunctions.DeleteODProgram("3536db03-2c03-4338-ab2c-1bb7027874ba");
        }

        [TestMethod]
        public void TestGetBucketFileTree()
        {
            //GetHashCode m3u8
            //GeneralServicePayload generalServicePayload = new GeneralServicePayload() { BucketName = "isg-teecontrol-data-management-svc-dev", BucketBaseKey = "e02v4rc6fsyl3zu/v440rel/mp4_packager/1/10_55_10", BucketRegion = "us-east-1" };
            GeneralServicePayload generalServicePayload = new GeneralServicePayload() { BucketName = "gil-test-videos", BucketBaseKey = "", BucketRegion = "us-east-1" };

            //Get Jpegs
            //GeneralServicePayload generalServicePayload = new GeneralServicePayload() { BucketName = "debug-kits", BucketBaseKey = "e02v4402wul18nh/15102020_094808/F50100-50100", BucketRegion = "us-east-1" };

            //GeneralServicePayload generalServicePayload = new GeneralServicePayload() { BucketName = "debug-kits", BucketBaseKey = "e02v441rc5vxjjx/05-11-2020/14_44_24/Frames-180000-180080/Multicam_View/", BucketRegion = "us-east-1" };

            //GeneralServicePayload generalServicePayload = new GeneralServicePayload() { BucketName = "debug-kits", BucketBaseKey = "e02v4402wul18nh/15102020_094808", BucketRegion = "us-east-1" };

            generalServicePayload = new GeneralServicePayload() { BucketName = "4sasha", BucketBaseKey = "fd19-dep-video/a01ver445jykhy8/2020_11_17/15_34/mp4", BucketRegion = "us-east-1" };

            var res = UtilityFunctions.GetBucketFileTree(generalServicePayload);

            //Get Configurations

            //GeneralServicePayload generalServicePayload2 = new GeneralServicePayload() { BucketName = "intel-sports-us-east-1-teecontrol-a01networkh2tj2", BucketBaseKey = "", BucketRegion = "us-east-1" };

            //var res2 = UtilityFunctions.GetBucketFileTree(generalServicePayload2);
        }

        [TestMethod]
        public void TestGetS3FilePreSignedURL()
        {
            GeneralServicePayload generalServicePayload = new GeneralServicePayload() { BucketName = "debug-kits", FileKey = "e02v4402wul18nh/15102020_094808/F50100-50100/render-360s_converted/vcam30_F00050100.jpg", BucketRegion = "us-east-1", HttpVerb="GET" };

            var res2 = UtilityFunctions.GetS3FilePreSignedURL(generalServicePayload) as OkObjectResult;
        
            if(res2 != null)
            {
                dynamic obj = res2.Value;
                var url = obj["URL_STRING"].ToString();
                //System.Diagnostics.Process.Start(url);
                OpenUrl(url);
            }
            //System.Diagnostics.Process.Start(res2.Value["URL_STRING"]);
        }
        private static void OpenUrl(string url)
        {
            try
            {
                Process.Start(url);
            }
            catch
            {
                // hack because of this: https://github.com/dotnet/corefx/issues/10361
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    url = url.Replace("&", "^&");
                    Process.Start(new ProcessStartInfo("cmd", $"/c start {url}") { CreateNoWindow = true });
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                {
                    Process.Start("xdg-open", url);
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                {
                    Process.Start("open", url);
                }
                else
                {
                    throw;
                }
            }
        }
       
        [TestMethod]
        public void TestGetProgramPreSignedURL()
        {
            //Environment.SetEnvironmentVariable("S3ProgramsBucketRegion", "intel-sports-us-west-2-fdtest");
            Environment.SetEnvironmentVariable("REGION", "us-east-1");
            Environment.SetEnvironmentVariable("PROGRAMS_BUCKET", "intel-sports-us-west-2-fdtest");

            PresignedPayload presignedPayload = new PresignedPayload()
            {
                ProgramName = "SanityTest/0098899d-5443-49ec-b620-86368e2d9518.html",
                CategoryGroup = "Reports",
                HttpVerb = "GET"
            };

            var res = UtilityFunctions.GetProgramPreSignedURL(presignedPayload) as OkObjectResult;

            if (res != null)
            {
                dynamic obj = res.Value;
                var url = obj["URL_STRING"].ToString();
                OpenUrl(url);
            }
        }

        [TestMethod]
        public void TestGetActiveDeployments()
        {
           
            Environment.SetEnvironmentVariable("AWS_ACCESS_KEY_ID", "AKIAJAOGGOPNYW7WJUUQ");
            Environment.SetEnvironmentVariable("AWS_SECRET_ACCESS_KEY", "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");
            Environment.SetEnvironmentVariable("DEPLOYMENT_API_ENDPOINT", "https://dev.deployment.fd19.sports.intel.com/fd19/deployments");
            var res = UtilityFunctions.GetActiveDeployments();
        }

        [TestMethod]
        public void TestGetConfigFileContent()
        {
            Environment.SetEnvironmentVariable("REGION", "us-east-1");
            Environment.SetEnvironmentVariable("PROGRAMS_BUCKET", "intel-sports-us-west-2-fdtest");

            ConfigurationPayload configurationPayload = new ConfigurationPayload() { ConfigType = "DebugKit", DeploymentId= "a02v4rc8l2cazm0", KeyName= "Flink/fd-core-flink-paralelism-config.json" };

            var res = UtilityFunctions.GetConfigContent(configurationPayload) as OkObjectResult;
            
        }

        [TestMethod]
        public void TestGetODProgramList()
        {
            Environment.SetEnvironmentVariable("AWS_REGION", "us-west-2");
            Environment.SetEnvironmentVariable("DYNAMO_DB_PROGRAMS", "pdaas_fdtest_fdcontroller-programs");
            var res = UtilityFunctions.GetODProgramList() as OkObjectResult;
        }

        [TestMethod]
        public void TestGetODProgram()
        {
            Environment.SetEnvironmentVariable("AWS_REGION", "us-west-2");
            Environment.SetEnvironmentVariable("DYNAMO_DB_PROGRAMS", "pdaas_fdtest_fdcontroller-programs");
            var res = UtilityFunctions.GetODProgram("5f1eeb75-5aa2-445a-aea6-8120416e01df");
        }


        [TestMethod]
        public void TestGetODFlowList()
        {
            Environment.SetEnvironmentVariable("AWS_REGION", "us-west-2");
            Environment.SetEnvironmentVariable("DYNAMO_DB_FLOWS", "pdaas_fdtest_fdcontroller-flows");
            var res = UtilityFunctions.GetODFlowList() as OkObjectResult;
        }

        [TestMethod]
        public void TestUpdateFlow()
        {
            ODFlow flow = new ODFlow();
            flow.Name = "TEST_123456";
            flow.Description = "TEST_123456";
            flow.Id = "ac345f7e-6cae-4957-abcc-6d974f8c5792";
            flow.RunInParallel = "true";
            flow.IsFlinkFlow = "false";
            Environment.SetEnvironmentVariable("AWS_REGION", "us-west-2");
            Environment.SetEnvironmentVariable("DYNAMO_DB_FLOWS", "pdaas_fdtest_fdcontroller-flows");
            var res = UtilityFunctions.UpdateODFlow(flow) as OkObjectResult;
        }

        [TestMethod]
        public void TestDeleteProgramFromS3Bucket()
        {
            Environment.SetEnvironmentVariable("AWS_REGION", "us-west-2");
            Environment.SetEnvironmentVariable("REGION", "us-west-2");
            Environment.SetEnvironmentVariable("PROGRAMS_BUCKET", "intel-sports-us-west-2-fdtest");
            Environment.SetEnvironmentVariable("DYNAMO_DB_PROGRAMS", "pdaas_fdtest_fdcontroller-programs");
            var res = UtilityFunctions.DeleteProgramFromS3Bucket("032d8144-8bcc-4c1e-865f-4f8d2f0b76d9");
        }
    }
}
