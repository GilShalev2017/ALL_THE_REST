﻿using Amazon.S3.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NewS3Crawler
{
    public class RetransmitOperations
    {
        protected Regex regex = null;
        protected S3Operation s3Ops = null;
        protected List<long> frmaeIds;
        private object lockObj = new object();

        public RetransmitOperations()
        {
            s3Ops = new S3Operation();
            frmaeIds = new List<long>();
        }

        public async Task<RetransmitS3Data> GetRetransmitS3Data(string bucketName, string prefix)
        {
            RetransmitS3Data retransmitS3Data = new RetransmitS3Data
            {
                ListObjectsV2Response = await s3Ops.ListBucketFilesAsync(bucketName, prefix, null, 1)
            };

            if (retransmitS3Data.ListObjectsV2Response != null && retransmitS3Data.ListObjectsV2Response.S3Objects != null && retransmitS3Data.ListObjectsV2Response.S3Objects.Count > 0)
            {
                retransmitS3Data.FirstS3Key = retransmitS3Data.ListObjectsV2Response.S3Objects[0].Key;
            }            

            if (retransmitS3Data.FirstS3Key != null)
            {
                retransmitS3Data.FirstFrameId = GetFrameId(Path.GetFileName(retransmitS3Data.FirstS3Key));
                retransmitS3Data.DirectoryName = Path.GetDirectoryName(retransmitS3Data.FirstS3Key);
                retransmitS3Data.FileNameWithoutExtension = Path.GetFileNameWithoutExtension(retransmitS3Data.FirstS3Key);
                retransmitS3Data.FileExtension = Path.GetExtension(retransmitS3Data.FirstS3Key);
            }
            else
            {
                return null;
            }

            return retransmitS3Data;
        }

        public async Task<string> GetRanges(string bucketName, string prefix, int numberOfFramesToConsider, int? startFromFrameId)
        {
            //  Get the first file
            var retransmitData = await GetRetransmitS3Data(bucketName, prefix);
            if(retransmitData == null)
            {
                return null;
            }

            List<Task> tasks = new List<Task>();

            long maxFrameId = retransmitData.FirstFrameId + numberOfFramesToConsider;

            long frameId = retransmitData.FirstFrameId;

            if (startFromFrameId != null)
            {
                maxFrameId = startFromFrameId.Value + numberOfFramesToConsider;

                frameId = startFromFrameId.Value - 1; //  to make it inclusive 
            }
            else
            {
                frmaeIds.Add(retransmitData.FirstFrameId);
            }

            long maxFramesToRetrieve = 0;

            if ((maxFrameId - frameId) >= 1000)
            {
                maxFramesToRetrieve = 1000;
            }
            else
            {
                maxFramesToRetrieve = maxFrameId - frameId;
            }

            while ((frameId <= maxFrameId) && maxFramesToRetrieve > 0)
            {

                var task = s3Ops.ListBucketFilesAsync(bucketName, prefix, GetNextStartAfterKey(retransmitData, frameId), (int)maxFramesToRetrieve)
                                .ContinueWith((antecedent) =>
                                {
                                    GetFrameIds(antecedent);
                                });

                tasks.Add(task);


                if ((maxFrameId - (frameId + 1000)) >= 1000)
                {
                    maxFramesToRetrieve = 1000;
                    frameId += 1000;
                }
                else
                {
                    maxFramesToRetrieve = maxFrameId - (frameId + 1000);
                    frameId += (maxFrameId - (frameId + 1000));
                }
            }

            Task.WaitAll(tasks.ToArray());

            frmaeIds.Sort();

            dynamic frameRangesJson = new JObject();

            frameRangesJson.frames = getFrameRanges(frmaeIds);

            return frameRangesJson.ToString();
        }

        public string GetNextStartAfterKey(RetransmitS3Data retransmitS3Data, long nextFrameId)
        {
            string nextStartAfterKey =
             Path.Join(Path.GetDirectoryName(retransmitS3Data.FirstS3Key),
                                Regex.Replace(retransmitS3Data.FileNameWithoutExtension, @"[\d-]", string.Empty) +
                                nextFrameId.ToString("D9") + retransmitS3Data.FileExtension).Replace(@"\", @"/");

            return nextStartAfterKey;
        }

        public long GetFrameId(string s3Filename)
        {
            if (regex == null)
                regex = new Regex(@"\d+");

            long returnValue = -1;
            Match match = regex.Match(s3Filename);
            if (match.Success)
            {
                if (long.TryParse(match.Value, out returnValue))
                {
                    return returnValue;
                }
                else
                {
                    Console.WriteLine("Could not parse value: " + match.Value);
                    return -1;
                }
            }

            Console.WriteLine("Regex failure. Could not parse value: " + s3Filename);
            return -1;
        }

        private void GetFrameIds(Task<ListObjectsV2Response> task)
        {
            foreach (var s3Object in task.Result.S3Objects)
            {
                long value = 0;
                lock (lockObj)
                {
                    value = GetFrameId(Path.GetFileName(s3Object.Key));
                    if (value != -1)
                    {
                        frmaeIds.Add(value);
                    }
                }
            }
        }

        public static JArray getFrameRanges(List<long> frmaeIds)
        {
            JArray arrayOfRanges = new JArray();

            if (frmaeIds.Count == 0)
                return arrayOfRanges;

            int index = 0;
            long startRange = frmaeIds[0];
            List<int> ranges = new List<int>();

            while (index < frmaeIds.Count)
            {
                if ((index + 1) < frmaeIds.Count && ((frmaeIds[index]) + 1) == frmaeIds[index + 1])
                {
                    index++;
                    continue;
                }
                else if ((index + 1) < frmaeIds.Count && frmaeIds[index] == frmaeIds[index + 1])       // For some reason ranges list has duplicates. So we skip              
                {
                    index++;
                    continue;
                }
                else
                {
                    // Add to a json array
                    JArray singleFrameRange = new JArray();
                    singleFrameRange.Add(startRange);
                    singleFrameRange.Add(frmaeIds[index]);
                    arrayOfRanges.Add(singleFrameRange);

                    //  Set the next start range
                    if ((index + 1) < frmaeIds.Count)
                    {
                        startRange = frmaeIds[index + 1];
                    }
                }

                index++;
            }

            return arrayOfRanges;
        }
    }
}
