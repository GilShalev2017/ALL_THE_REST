﻿using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace NewS3Crawler
{
    public class RetransmitS3Data
    {
        public ListObjectsV2Response ListObjectsV2Response { get; set; }
        public long FirstFrameId { get; set; }
        public string FirstS3Key { get; set; }
        public string DirectoryName { get; set; }
        public string FileNameWithoutExtension { get; set; }
        public string FileExtension { get; set; }
    }
}
