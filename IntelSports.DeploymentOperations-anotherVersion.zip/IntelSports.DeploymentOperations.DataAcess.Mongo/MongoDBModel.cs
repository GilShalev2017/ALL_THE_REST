﻿using System;
using MongoDB.Bson;
using MongoDB.Driver;

namespace IntelSports.DeploymentOperations.DataAcess.Mongo
{
    public class MongoDBModel
    {
        
        private IMongoDatabase db;
        public MongoDBModel(string databaseName)
        {
            var client = new MongoClient();
            db = client.GetDatabase(databaseName);
        }

        public void InsertRecord<T>(string table, T record)
        {
            var collection = db.GetCollection<T>(table);
            collection.InsertOne(record);
        }
    }
}
