﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.AWS.S3
{
    public interface IIntelSportsS3Client
    {
        Task<string> GetS3JSONFile(string bucketName, string fileName);
        Task<JObject> GetS3JSONFileAsJObject(string bucketName, string fileName);
        void CreateS3Folder(string bucketName, string folderKeyName);
     }
}
