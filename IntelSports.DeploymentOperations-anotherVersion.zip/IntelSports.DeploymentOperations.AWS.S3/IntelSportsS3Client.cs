﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.Util;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.AWS.S3
{
    public class IntelSportsS3Client : IIntelSportsS3Client
    {
        protected Amazon.S3.AmazonS3Client s3Client = null;
        //public IntelSportsS3Client()
        //{
        //    s3Client = new Amazon.S3.AmazonS3Client();
        //}

        public IntelSportsS3Client(string region)
        {
            s3Client = new Amazon.S3.AmazonS3Client(RegionEndpoint.GetBySystemName(region));
        }

        public IntelSportsS3Client(string accessKey, string secretKey, RegionEndpoint region)
        {
            s3Client = new Amazon.S3.AmazonS3Client(accessKey, secretKey, region);
        }

        public async Task<JObject> GetS3JSONFileAsJObject(string bucketName, string fileName)
        {
            var result = await GetS3JSONFile(bucketName, fileName);
            return JObject.Parse(result);
        }
        public async Task<string> GetS3JSONFile(string bucketName, string fileName)
        {
            if (string.IsNullOrEmpty(bucketName))
                throw new ArgumentNullException("bucketName","bucketName param must not be null or empty");

            if (string.IsNullOrEmpty(fileName))
                throw new ArgumentNullException("fileName", "fileName param must not be null or empty");


            GetObjectRequest req = new GetObjectRequest() { BucketName = bucketName, Key = fileName, };
            string jsonData = string.Empty;
            using (GetObjectResponse response = await s3Client.GetObjectAsync(req))
            using (Stream responseStream = response.ResponseStream)
            using (StreamReader reader = new StreamReader(responseStream))
            {
                jsonData = reader.ReadToEnd(); 
            }
            return jsonData;
        }

        public void CreateS3Folder(string bucketName, string folderPath)
        {
            PutObjectRequest request = new PutObjectRequest()
            {
                BucketName = bucketName,
                Key = folderPath // <-- in S3 key represents a path  
            };

            PutObjectResponse response = s3Client.PutObjectAsync(request).Result;
        }
    }
}
