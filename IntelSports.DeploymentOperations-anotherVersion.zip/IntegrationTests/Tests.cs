﻿using IntelSports.DeploymentOperations.AWS.S3;
using IntelSports.DeploymentOperations.AWSCognitoSecurity;
using IntelSports.DeploymentOperations.Model.DB;
using IntelSports.DeploymentOperations.Worker;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IntegrationTests
{

    public class Tests
    {
        IOpenIdConnect cognitoSecurityService = null;
        //Tests(dynamic configFile)
        //{
        //    cognitoSecurityService  = new AWSCognitoService(configFile.PoolId, configFile.AppClientId,
        //                                                                       Amazon.RegionEndpoint.GetBySystemName(configFile.AWSCognitoServiceRegion),
        //                                                                       new BasicLoginRequest() { Password = configFile.Password, UserName = configFile.UnserName });
        //}



        [SetUp]
        public void Setup()
        {
            //Environment.SetEnvironmentVariable(Constants.AWS_REGION, "eu-west-1");
        }

        [Test]
        public void TesDownloadFlinkProgramAndUncompress()
        {
            ExecutionManager executionManager = new ExecutionManager(cognitoSecurityService);

            executionManager.DownloadFlinkProgramAndUncompress();
        }

        [Test]
        public void TesDownloadFlinkJar()
        {
            cognitoSecurityService = new AWSCognitoService("us-east-1_YuSwcvMEa", "4s1to8qbshl6qdqpu075t3ojtc",
                                                           Amazon.RegionEndpoint.GetBySystemName("us-east-1"),
                                                           new BasicLoginRequest() { Password = "+25Up5v?g2g4t^L>", UserName = "gil" });

            WorkerConfig.S3BucketForUploadDownloadPrograms = "intel-sports-us-west-2-fddev";
            WorkerConfig.S3BucketRegionForUploadDownloadPrograms = "us-west-2";

            ExecutionManager executionManager = new ExecutionManager(cognitoSecurityService);

            executionManager.DownloadFlinkJar("zzz.jar");
        }

        [Test]
        public void TesCreateFlinkTaskJsonFile()
        {
            ExecutionManager executionManager = new ExecutionManager(cognitoSecurityService);

            FlinkTaskPayload payload = new FlinkTaskPayload();

            payload.FlinkTaskType = FlinkTaskType.GetDeployedJarList;
            var file1 = executionManager.CreateFlinkTaskJsonFile(payload);

            payload.FlinkTaskType = FlinkTaskType.GetDeployedJarPlan;
            payload.JarName = "flinkflow-1.0.0-360.jar";
            var file2 = executionManager.CreateFlinkTaskJsonFile(payload);

            payload.FlinkTaskType = FlinkTaskType.RunJar;
            payload.JarName = "flinkflow-1.0.0-360.jar";
            var file3 = executionManager.CreateFlinkTaskJsonFile(payload);

            payload.FlinkTaskType = FlinkTaskType.UploadJar;
            payload.JarName = "flinkflow-1.0.0-360.jar";
            var file4 = executionManager.CreateFlinkTaskJsonFile(payload);
        }
        
        [Test]
        public void TesRunFlinkTask()
        {
            ExecutionManager executionManager = new ExecutionManager(cognitoSecurityService);

            FlinkTaskPayload payload = new FlinkTaskPayload();
            payload.DeploymentId = "smallinfrakjdk5";

            //Get Deployed Jars
            payload.FlinkTaskType = FlinkTaskType.GetDeployedJarList;
            Task<ExecutingTaskStatus> result1 = executionManager.RunFlinkTask(payload, "http://63.33.241.11:5000/TaskProcessHub");

            var resFinal = result1.Result;
            /*
            //Get Jar Plan
            payload.FlinkTaskType = FlinkTaskType.GetDeployedJarPlan;
            payload.JarName = "flinkflow-1.0.0-20200423.103410-59.jar";
            Task<ExecutingTaskStatus> result2 = executionManager.RunFlinkTask(payload, "http://63.33.241.11:5000/TaskProcessHub");

            //Run Jar
            payload.FlinkTaskType = FlinkTaskType.RunJar;
            payload.JarName = "flinkflow-1.0.0-20200423.103410-59.jar";
            Task<ExecutingTaskStatus> result3 = executionManager.RunFlinkTask(payload, "http://63.33.241.11:5000/TaskProcessHub");

            //Upload Jar
            payload.FlinkTaskType = FlinkTaskType.UploadJar;
            payload.JarName = "flinkflow-1.0.0-20200423.103410-59.jar";
            Task<ExecutingTaskStatus> result4 = executionManager.RunFlinkTask(payload, "http://63.33.241.11:5000/TaskProcessHub");
            */
        }

    
        [Test]
        public void TestCreateS3Folder()
        {
            IntelSportsS3Client client = new IntelSportsS3Client("us-west-2");

            client.CreateS3Folder("intel-sports-us-west-2-fddev", "Flink/");

            client.CreateS3Folder("intel-sports-us-west-2-fddev", "XXX/");
        }

        [Test]
        public void TestConvertComplexJsonToDictioanry()
        {
            //In oreder to debug create a breakpoint in the static constructor and push the
            //cursor to the end of this ctor !!!
            var flowJsonParameters = new
            {
                GameID = @"998877",
                PlayID = "778899",
                RunId = "123456",
                RunTimeStart = "1601830936165320",
                RunTimeEnd = "1601841363631990",
                RunMode = "runPclRender",
                CamMode = "Auto",
                ExecuterName = "Some-Cognito-User-Name",
                StoragePath = new
                {
                    SourceVcamConfigS3Bucket = "TBD",
                    SourceVcamConfigS3Prefix = "TBD",
                },
                DebugParams = new {
                    CreateMP4 = true,
                    MP4Params = new {
                        VcamIdxForMP4 = "[1, 2, 8]",
                        destVcamVideoS3Bucket = "some s3 bucket, including region",
                        destVcamVideoS3Prefix = "some prefix"
                    },
                    CreateDebugKit = true,
                    DebugKitParams = new { }
                }
            };

            string json_data = JsonConvert.SerializeObject(flowJsonParameters);

            dynamic flowJsonParametersObject = JObject.Parse(json_data);

            var dic = new Dictionary<string, string>();

            //In oreder to debug create a breakpoint in the static constructor and push the
            //cursor to the end of this ctor !!!

            ExecutionManager.ConvertDynamic2Dictionary(flowJsonParametersObject, dic);
        }
    }
}
