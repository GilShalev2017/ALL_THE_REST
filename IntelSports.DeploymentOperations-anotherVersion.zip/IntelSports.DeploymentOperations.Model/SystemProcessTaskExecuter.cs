﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using IntelSports.DeploymentOperations.Model.DB;
using IntelSports.DeploymentOperations.AWSCognitoSecurity;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon;
using TaskStatus = IntelSports.DeploymentOperations.Model.DB.TaskStatus;

namespace IntelSports.DeploymentOperations.Model
{
    public class SystemProcessTaskExecuter : ITaskExecuter
    {
        protected TaskExecuterHubClient taskExecuterHubClient = null;

        public TaskPayload _taskPayload;
        public string _executerId;
        public Process process = null;
        
        public string _taskName; //for stopping flink
        public string _taskId;//for stopping flink

        private ExecutingTaskStatus _executingTaskStatus;
        private ExecutingTaskData _executingTaskData;
        private IOpenIdConnect iOpenIdConnect = null;
        private string _dynamoDbTableName;
        private string _dynamoDbTableRegion;
        private string _name;
        private string _description;
        private string _categoryGroup;
        private string _taskParameters;

        public SystemProcessTaskExecuter(string serverHubUrl, IOpenIdConnect iOpenIdConnect, TaskPayload taskPayload, string executerId, 
                                         string dynamoDbTableName, string dynamoDbTableRegion, string fdControllerId,
                                         string name, string description, string categoryGroup, string taskParameters)
        {
            this.iOpenIdConnect = iOpenIdConnect;

            _taskName = name;
            _taskId = taskPayload.TaskId;

            _name = name;
            _description = description;
            _categoryGroup = categoryGroup;
            _taskParameters = taskParameters;

            taskExecuterHubClient = new TaskExecuterHubClient(serverHubUrl, this.iOpenIdConnect, this);
            _taskPayload = taskPayload;
            _executerId = executerId;
            _executingTaskStatus = new ExecutingTaskStatus { 
                                                             TaskId= taskPayload.TaskId,
                                                             DeploymentId = taskPayload.DeploymentId,
                                                             ExecuterId = executerId,
                                                             ExecuterName = taskPayload.ExecuterName,
                                                             FdControllerId = fdControllerId,
                                                             TaskType = taskPayload.TaskType,
                                                             DynamicTaskName = taskPayload.DynamicTaskName,
                                                             S3DebugKitBucketUrl = taskPayload.s3BucketUrl
            };
            _executingTaskData = new ExecutingTaskData { 
                                                         TaskId = taskPayload.TaskId,
                                                         DeploymentId = taskPayload.DeploymentId,
                                                         ExecuterId = executerId, 
                                                         ExecuterName = taskPayload.ExecuterName, 
                                                         FdControllerId = fdControllerId,
                                                         TaskType = taskPayload.TaskType,
                                                         DynamicTaskName = taskPayload.DynamicTaskName
                                                       };

            _executingTaskData.IsFlinkTask = taskPayload.IsFlinkTask;
            _executingTaskData.FlinkTaskType = taskPayload.FlinkTaskType;

            if (taskPayload.RunAsPartOfAFlow)
            {
                _executingTaskStatus.FlowExecuterId = taskPayload.FlowExecuterId;
                _executingTaskData.FlowExecuterId = taskPayload.FlowExecuterId;
                _executingTaskStatus.FlowId = taskPayload.FlowId;
                _executingTaskData.FlowId = taskPayload.FlowId;
            }

            _dynamoDbTableName = dynamoDbTableName;
            _dynamoDbTableRegion = dynamoDbTableRegion;
        }
        public async Task<ExecutingTaskStatus> ExecuteTask(ODTask task)
        {           
            return await ExecuteDeploymentTask(task);           
        }
        private async Task<ExecutingTaskStatus> ExecuteDeploymentTask(ODTask task)
        {
            try
            {
                process = new Process();
                process.StartInfo.FileName = task.ProgramToExecute; //@"C:\Program Files\Java\jdk1.8.0_201\bin\java.exe";// "/bin/bash";//"./DemoApp";// 
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.UseShellExecute = false;
                process.EnableRaisingEvents = true;
                process.StartInfo.Arguments = task.ProgramParameters; // @"-jar C:\Users\gshalev6\Downloads\FLINK_TEST\monitoringApi6.jar C:\Users\gshalev6\Downloads\FLINK_TEST\list_of_jars.json";// task.ProgramParameters;
                //$"-c \"aws s3 ls 4sasha\"";
                //$"-c \"listS3.sh\"";// "9000 10000 60";// task.ProgramParameters;

                if (task.ReportStandardOutput)
                {
                    process.Exited += Process_Exited;
                    process.OutputDataReceived += new DataReceivedEventHandler(Process_OutputDataReceived);
                    process.ErrorDataReceived += new DataReceivedEventHandler(Process_ErrorDataReceived);
                }

                if (!string.IsNullOrEmpty(task.WorkingDirectory))
                {
                    process.StartInfo.WorkingDirectory = task.WorkingDirectory; ;// @"C:\Users\gshalev6\Downloads\FLINK_TEST\";//task.WorkingDirectory;
                }

                _executingTaskStatus.Status = TaskStatus.TaskStarting;
                await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

                process.Start();

                _executingTaskStatus.Status = TaskStatus.TaskStarted;
                _executingTaskStatus.StartDateTime = DateTime.Now;
                _executingTaskData.StartDateTime = _executingTaskStatus.StartDateTime;
                await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

                process.BeginErrorReadLine();
                process.BeginOutputReadLine();
                process.WaitForExit();

                _executingTaskStatus.EndDateTime = DateTime.Now;

                if (_executingTaskStatus.Status != TaskStatus.TaskStopped)
                {
                    if (!string.IsNullOrEmpty(_executingTaskStatus.ErrorData))
                    {
                        Console.WriteLine("ExitCode=" + process.ExitCode);

                        if (process.ExitCode != 0)
                        {
                            _executingTaskStatus.Status = TaskStatus.TaskCompletedWithError;
                        }
                        else
                        {
                            _executingTaskStatus.Status = TaskStatus.TaskCompleted;
                        }
                    }
                    else
                    {
                        _executingTaskStatus.Status = TaskStatus.TaskCompleted;
                    }
                }

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

                    await taskExecuterHubClient.Disconnect();
                }

                return _executingTaskStatus;
            }
            catch(Exception xcp)
            {
                _executingTaskStatus.EndDateTime = DateTime.Now;
                _executingTaskStatus.Status = TaskStatus.TaskCompletedWithError;
                _executingTaskStatus.ErrorData = xcp.Message;
                
                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
                    await taskExecuterHubClient.Disconnect();
                }
                Console.WriteLine("Exception occuured at ExecuteDeploymentTask: " + xcp.Message);
            }

            return _executingTaskStatus;
        }
        private async void Process_Exited(object sender, EventArgs e)
        {
            Console.WriteLine("Process Exited");

            if (_executingTaskStatus.Status != TaskStatus.TaskStopped)
            {
                _executingTaskStatus.Status = TaskStatus.ProcessExited;
            }

            if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
            {
                await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
            }

            SaveCompletedTaskInDynamoDbTable();
        }
        private CompletedTask CreateCompletedTask()
        {
            var completedTask = new CompletedTask()
            {
                Id = _executerId,
                Name = _name,
                CategoryGroup = _categoryGroup,
                Description = _description,
                TaskParameters = _taskParameters,
                StartDateTime = _executingTaskStatus.StartDateTime.ToString(),
                EndDateTime = _executingTaskStatus.EndDateTime.ToString(),
                Status = _executingTaskStatus.Status.ToString(),
                Error = _executingTaskStatus.ErrorData,
                ExecuterName = _executingTaskStatus.ExecuterName,
                DeploymentId = _executingTaskStatus.DeploymentId,
                FdControllerId = _executingTaskStatus.FdControllerId
            };

            return completedTask;
        }
        private async void Process_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            Console.WriteLine("From 'Process_ErrorDataReceived' :" + e.Data);

            if (!string.IsNullOrEmpty(e.Data))
            {
                //_executingTaskStatus.Status = TaskStatus.ErrorDataReceived;
                _executingTaskStatus.ErrorData = e.Data;
                //_executingTaskStatus.EndDateTime = DateTime.Now;
                //Find out if this means that the process failed ??? or it can send other statuses after this one?

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
                }

                SaveCompletedTaskInDynamoDbTable();
            }
        }
        private async void Process_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            try
            {
                Console.WriteLine("From EXECUTER: " + _executerId + " PROCESS_ID: " + process.Id + " Process_OutputDataReceived: " + e.Data);

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    _executingTaskData.Data = e.Data;
                    await taskExecuterHubClient.ReportOutputDataReceived(_executingTaskData);

                    //if(_executingTaskData.IsFlinkTask)
                    //{
                    //    HandleFlinkTaskOutput(e.Data);
                    //}
                }
            }
            catch(Exception xcp)
            {

            }
        }
        public async Task<ExecutingTaskStatus> StopTask(bool simulateTaskCompleted = false)
        {
            try
            {
                if (!process.HasExited)
                {
                    process.Kill();
                }
            }
            catch 
            {
                _executingTaskStatus.Status = TaskStatus.TaskStoppedError;
                _executingTaskStatus.EndDateTime = DateTime.Now;

                if (taskExecuterHubClient.connection.State == Microsoft.AspNetCore.SignalR.Client.HubConnectionState.Connected)
                {
                    await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);
                }

                SaveCompletedTaskInDynamoDbTable();

                return _executingTaskStatus;
            }

            if (simulateTaskCompleted)
            {
                _executingTaskStatus.Status = TaskStatus.TaskCompleted;
            }
            else
            {
                _executingTaskStatus.Status = TaskStatus.TaskStopped;
            }

            SaveCompletedTaskInDynamoDbTable();

            //should be sent when process is indeed stopped
            //_executingTaskStatus.EndDateTime = DateTime.Now;
            //await taskExecuterHubClient.ReportExecutingTaskStatus(_executingTaskStatus);

            return _executingTaskStatus;
        }
        public void SaveCompletedTaskInDynamoDbTable()
        {
            if (_executingTaskData.IsFlinkTask)  //In case of a flink task - don't report
                return;

            try
            {
                var completedTask = CreateCompletedTask();

                var dynamoDbClient = new AmazonDynamoDBClient(RegionEndpoint.GetBySystemName(_dynamoDbTableRegion));


                Dictionary<string, AttributeValue> dic = new Dictionary<string, AttributeValue>
            {
                { Constants.COLUMN_COMPLETED_TASK_ID, new AttributeValue(completedTask.Id) },
                { Constants.COLUMN_COMPLETED_TASK_NAME, new AttributeValue(completedTask.Name) },
                { Constants.COLUMN_COMPLETED_TASK_CATEGORY_GROUP, new AttributeValue(completedTask.CategoryGroup) },
                { Constants.COLUMN_COMPLETED_TASK_DESCRIPTION, new AttributeValue(completedTask.Description) },
                //{ Constants.COLUMN_COMPLETED_TASK_PARAMS, new AttributeValue(completedTask.TaskParameters) },
                { Constants.COLUMN_COMPLETED_TASK_START_DATE_TIME, new AttributeValue(completedTask.StartDateTime) },
                { Constants.COLUMN_COMPLETED_TASK_END_DATE_TIME, new AttributeValue(completedTask.EndDateTime) },
                { Constants.COLUMN_COMPLETED_TASK_STATUS, new AttributeValue(completedTask.Status) },
               // { Constants.COLUMN_COMPLETED_TASK_ERROR, new AttributeValue(completedTask.Error) },
                { Constants.COLUMN_COMPLETED_TASK_EXECUTER_NAME, new AttributeValue(completedTask.ExecuterName) },
                { Constants.COLUMN_COMPLETED_TASK_DEPLOYMENT_ID, new AttributeValue(completedTask.DeploymentId) },
                { Constants.COLUMN_COMPLETED_TASK_FD_CONTROLLER_ID, new AttributeValue(completedTask.FdControllerId) },
            };

                if (!string.IsNullOrEmpty(completedTask.TaskParameters))
                {
                    dic.Add(Constants.COLUMN_COMPLETED_TASK_PARAMS, new AttributeValue(completedTask.TaskParameters));
                }

                if (!string.IsNullOrEmpty(completedTask.Error))
                {
                    dic.Add(Constants.COLUMN_COMPLETED_TASK_ERROR, new AttributeValue(completedTask.Error));
                }

                PutItemResponse response = dynamoDbClient.PutItemAsync(_dynamoDbTableName, dic).Result;
            }
            catch(Exception xcp)
            {
                Console.WriteLine("Error in SaveCompletedTaskInDynamoDbTable " + xcp.Message);
            }
        }
    }
}

//public /*async*/ Task<TaskExecutionResult> StopTask(DeploymentTask task)
//{
//    var taskExecutionResult = new TaskExecutionResult() { TaskId = task.Id, TaskProcess = process, /*StartDateTime = task.StartDateTime*/ EndDateTime = DateTime.Now };
//    return Task.FromResult(taskExecutionResult);
//}

//TODO currently is obsolete
//public async Task<TaskExecutionResult> ExecuteTask(string taskId)
//{
//    //  Get Deployment Task
//    var deploymentTask = GetDeploymentTask(taskId);

//    //  Execute Deployment Task
//    return await ExecuteTask(deploymentTask);
//}

//private DeploymentTask GetDeploymentTask(string taskId)
//{

//    //Git clone
//    //return new DeploymentTask() { Id = taskId, Description = "My first great task", Name = "task1", ProgramToExecute = "git", ProgramParameters = "clone https://github.com/necolas/normalize.css.git", ReportStandardOutput = true };

//    //tree
//    return new DeploymentTask() { Id = taskId, Description = "Running the Tree", Name = "task1", ProgramToExecute = @"C:\Windows\System32\cmd.exe", ProgramParameters = "/C tree", WorkingDirectory = @"C:\temp", ReportStandardOutput = true };
//}

//private void HandleFlinkTaskOutput(string data)
//{
//    if (_executingTaskData.FlinkTaskType == FlinkTaskType.GetDeployedJarList)
//    {
//        if (data.StartsWith("address"))
//        {
//            await taskExecuterHubClient.ReportFlinkTaskOutputDataReceived(_executingTaskData);
//        }
//    }
//}