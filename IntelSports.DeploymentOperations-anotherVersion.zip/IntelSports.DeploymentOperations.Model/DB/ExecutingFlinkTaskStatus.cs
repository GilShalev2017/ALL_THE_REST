﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class ExecutingFlinkTaskStatus
    {
    }
}
