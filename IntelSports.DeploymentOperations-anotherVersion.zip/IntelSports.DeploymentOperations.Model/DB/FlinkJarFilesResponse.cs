﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class FlinkJarFilesResponse
    {
        public string address { get; set; }
        public DeployedJarFile files { get; set; }
    }

    public class DeployedJarFile
    {
        public string id { get; set; }
        public string name {get; set; }
        public string uploaded {get; set;}
        public Entry[] entry;
    }
    
    public class Entry
    {
        public string name { get; set; }
        public string description { get; set; }
    }
}
