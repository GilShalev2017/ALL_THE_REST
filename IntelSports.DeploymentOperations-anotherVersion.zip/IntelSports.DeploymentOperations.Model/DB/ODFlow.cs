﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class ODFlow
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public List<ODTask> Tasks { get; set; }
        public string RunInParallel { get; set; }
        public bool IsFlinkFlow { get; set; }
    }
}
