﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public enum TaskStatus
    {
        TaskStarting,
        TaskStarted,
        TaskCompleted,
        TaskCompletedWithError,
        ProcessExited,
        TaskStopped,
        TaskStoppedError,
    }

    public class ExecutingTaskStatus
    {
        public string TaskId { get; set; }
        //public string GameId{ get; set; }
        //public string PlayId { get; set; }
        //public string RunId { get; set; }
        public string ExecuterId { get; set; }
        public string DeploymentId { get; set; }
        public DateTime? StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public TaskStatus Status { get; set; }
        public string StatusString { get; set; }
        public string ErrorData { get; set; }
        public string FlowExecuterId { get; set; }
        public string FlowId { get; set; }
        public string ExecuterName { get; set; }
        public string FdControllerId { get; set; }
        public string TaskType { get; set; }
        public string DynamicTaskName { get; set; }
        public string S3DebugKitBucketUrl { get; set; }
        //public LogFileDetails LogFileDetails { get; set; }
    }
}
