﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class FlinkTaskPayload : TaskPayload
    {
        public string JarName { get; set; }
        public string JobId { get; set; }
    }
}
