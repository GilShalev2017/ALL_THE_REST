﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public class TaskPayload
    {
        public string TaskId { get; set; }
        //public string TaskName { get; set; }
        public string DeploymentId { get; set; }
        public string GameId { get; set; }
        public bool RunAsPartOfAFlow { get; set; }
        public string FlowExecuterId { get; set; }
        public string FlowId { get; set; }
        public bool IsFlinkTask { get; set; }
        public FlinkTaskType FlinkTaskType { get; set; }
        public string ExecuterId { get; set; }
        public string ExecuterName { get; set; }

        public string JsonConfigDynamicParameters { get; set; }
        public string DynamicParameters { get; set; }
        public string DynamicTaskName { get; set; }
        public string TaskType { get; set; }
        public string TargetPod { get; set; }
        public string s3BucketUrl { get; set; }

        public bool AreParametersOverriden { get; set; }
        public string OverridingParameters { get; set; }
        //public LogFileDetails LogFileDetails { get; set; }
        //public bool ConcatenateAutoLogName { get; set; }
        //RoundRobin, a group, specific docker
        //public FdControllerId {get; set;}
    }
}
