﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelSports.DeploymentOperations.Model.DB
{
    public enum FlinkTaskType
    {
        UploadJar,
        RunJar,
        StopJob,
        GetDeployedJarList,
        GetDeployedJarPlan,
        JobsOverview,
    }
}
