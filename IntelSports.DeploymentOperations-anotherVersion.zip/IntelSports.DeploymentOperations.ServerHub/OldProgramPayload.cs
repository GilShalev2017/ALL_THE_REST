﻿namespace IntelSports.DeploymentOperations.ServerHub
{
    public class OldProgramPayload
    {
    }
}