using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using IntelSports.DeploymentOperations.AWS.S3;
using IntelSports.DeploymentOperations.ServerHub.Hubs;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;

namespace IntelSports.DeploymentOperations.ServerHub
{
    public class Startup
    {
        readonly string MyAllowSpecificOriginsPolicy = "_myAllowSpecificOrigins";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddSignalR();
            services.AddSignalR(o =>
            {
                o.MaximumReceiveMessageSize = null; // no limit
                o.EnableDetailedErrors = true;
            });

            var Region = Environment.GetEnvironmentVariable("COGNITO_REGION"); // Configuration["AWSCognito:Region"];
            var PoolId = Environment.GetEnvironmentVariable("COGNITO_POOL_ID"); //Configuration["AWSCognito:PoolId"];
            var AppClientId = Environment.GetEnvironmentVariable("APP_CLIENT_ID"); //Configuration["AWSCognito:AppClientId"];
            string[] corsDomain = Environment.GetEnvironmentVariable("CORS_ALLOWED_DOMAINS").Split(",");

            services.AddAuthorization(options =>
            {
                options.AddPolicy(JwtBearerDefaults.AuthenticationScheme, policy =>
                {
                    policy.AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme);
                    policy.RequireClaim(ClaimTypes.Email);
                });
            });


            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
                {

                    options.Events = new JwtBearerEvents
                    {
                        OnMessageReceived = context =>
                        {
                            var accessToken = context.Request.Query["access_token"];
                            if (!string.IsNullOrEmpty(accessToken))
                            {
                                context.Token = accessToken;
                            }
                            return Task.CompletedTask;
                        }
                    };

                    options.SaveToken = true;

                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKeyResolver = (s, securityToken, identifier, parameters) =>
                        {
                            Console.WriteLine("Downloading from : " + parameters.ValidIssuer + "/.well-known/jwks.json");
                            // Get JsonWebKeySet from AWS
                            var json = new WebClient().DownloadString(parameters.ValidIssuer + "/.well-known/jwks.json");
                            // Serialize the result
                            return JsonConvert.DeserializeObject<JsonWebKeySet>(json).Keys;
                        },
                        ValidateIssuer = true,
                        ValidIssuer = $"https://cognito-idp.{Region}.amazonaws.com/{PoolId}",
                        ValidateLifetime = true,
                        LifetimeValidator = (before, expires, token, param) => expires > DateTime.UtcNow,
                        ValidateAudience = false,
                        ValidAudience = AppClientId

                    };
                    options.IncludeErrorDetails = true;

                });


            services.AddRazorPages();

            //services.AddCors(options =>
            //{
            //    options.AddPolicy(MyAllowSpecificOriginsPolicy,
            //    builder =>
            //    {

            //        builder.WithOrigins(Configuration.GetValue<string>("AllowedCORSDomains").Split(','));
            //    });
            //});
            
            services.AddCors(o => o.AddPolicy("CorsPolicy", builder =>
            {
                builder
                .AllowAnyMethod()
                .AllowAnyHeader()
                .AllowCredentials()
                //.AllowAnyOrigin();
                 .WithOrigins(corsDomain);
                //.WithOrigins("http://task-automation-tool-system.s3-website-eu-west-1.amazonaws.com", "http://taskautomationtoolsy-bucket-developmen.s3-website.us-east-2.amazonaws.com", "http://localhost:4200");
            }));

            //services.AddHttpsRedirection(options =>
            //{
            //    options.RedirectStatusCode = StatusCodes.Status307TemporaryRedirect;
            //    options.HttpsPort = 5001;
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            // Uncomment when ready to work with SSL
            // app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseCors("CorsPolicy");// MyAllowSpecificOriginsPolicy);

            //  Uncomment
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
                endpoints.MapHub<TaskProcessHub>("/TaskProcessHub");
            });
        }
    }
}
