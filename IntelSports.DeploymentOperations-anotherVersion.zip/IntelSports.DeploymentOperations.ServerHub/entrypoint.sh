#!/bin/sh
dotnet IntelSports.DeploymentOperations.ServerHub.dll
