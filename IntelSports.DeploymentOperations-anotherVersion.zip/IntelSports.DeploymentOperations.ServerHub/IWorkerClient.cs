﻿using IntelSports.DeploymentOperations.Model.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IntelSports.DeploymentOperations.ServerHub
{
    public interface IWorkerClient
    {
        #region UI commands (what can the UI command)

        Task StartTask(TaskPayload payload);
        Task StopTask(TaskPayload payload);
        Task StartFlow(FlowPayload payload);
        Task StopFlow(FlowPayload payload);
        Task GetFdControllerList(string deploymentId);
        Task GetWorkerConnectedDeployemnts();
        Task StartFlinkTask(FlinkTaskPayload payload);
        Task RefreshTasks();
        Task RefreshProgram(string programId);
        #endregion

        #region UI notifications (what will the UI receive)
        Task OnUIRegisteredStatus(string status);

        Task OnTaskStatusReport(ExecutingTaskStatus executingTaskStatus);
        Task OnFlowStatusReport(ExecutingFlowStatus executingFlowStatus);
        Task OutputDataReceived(ExecutingTaskData executingTaskData);

        Task OnFdControllerListReceived(List<FdController> fdControllers);
        Task OnWorkerConnectedDeploymentsReceived(List<string> workerConnectedDeployments);

        //Task OnClientListReceived(List<string> clients);

        #endregion UI notifications

        #region Worker notifications (what will the Worker receive)
        Task OnRegisteredWorkerStatus(FdController fdController);
        #endregion

        #region Program commands & notifications
        Task SendProgramMessage(ProgramMessage payload); //for instance flink send this to signal that it has finished
        Task OnProgramRegisteredStatus(string status);
        #endregion

        Task StopTaskCompleted();
    }
}