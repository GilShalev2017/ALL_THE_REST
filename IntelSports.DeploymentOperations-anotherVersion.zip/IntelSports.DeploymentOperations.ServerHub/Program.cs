using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml;
using IntelSports.DeploymentOperations.AWS.S3;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace IntelSports.DeploymentOperations.ServerHub
{
    public class Program
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static void Main(string[] args)
        {
            AddLog4Net();

            log.Info("fdcontroller - HUB application has launched");

            if (!ValidateEnvVariables())
                return;
          
            CreateHostBuilder(args).Build().Run();
        }

        private static bool ValidateEnvVariables()
        {
            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("COGNITO_REGION")))
            {
                log.Info("COGNITO_REGION ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("COGNITO_POOL_ID")))
            {
                log.Info("COGNITO_POOL_ID ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("APP_CLIENT_ID")))
            {
                log.Info("APP_CLIENT_ID ENV variable is not set. Exiting");
                return false;
            }

            if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("CORS_ALLOWED_DOMAINS")))
            {
                log.Info("CORS_ALLOWED_DOMAINS ENV variable is not set (if more than one domain, use comma delimited). Exiting");
                return false;
            }

            return true;
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {                  
            return Host.CreateDefaultBuilder(args).ConfigureAppConfiguration((hostingContext, config) =>
            {
               // IntelSportsS3Client s3Client = new IntelSportsS3Client();            

                //  Get config json file content from S3 bucket
                //var s3FileTask = s3Client.GetS3JSONFile(args[1], args[3]);
                //s3FileTask.Wait();

                //if(string.IsNullOrEmpty(s3FileTask.Result))
                //{
                //    throw new Exception("Could not find the config file.");
                //}
               
                ////  Write the file content to a the appsettings.json file
                //File.WriteAllText("appsettings.json", s3FileTask.Result.ToString());

                //config.AddJsonFile("appsettings.json",
                //    optional: true,
                //    reloadOnChange: true);
            })
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.ConfigureKestrel(serverOptions =>
                {
                    serverOptions.Listen(IPAddress.Parse("0.0.0.0"), 5000);

                    //({ new ServerPort("localhost", Port, ServerCredentials.Insecure) }

                    // uncomment the next lines when ready to work with SSL
                    //serverOptions.Listen(IPAddress.Parse("0.0.0.0"), 5002,
                    //listenOptions =>
                    //{
                    //    listenOptions.UseHttps("cert1", "abc1234");
                    //});

                }).UseStartup<Startup>();
            });

        }

        static void AddLog4Net()
        {
            XmlDocument log4netConfig = new XmlDocument();
            log4netConfig.Load(File.OpenRead("log4net.config"));
            var repo = log4net.LogManager.CreateRepository(Assembly.GetEntryAssembly(),
                       typeof(log4net.Repository.Hierarchy.Hierarchy));
            log4net.Config.XmlConfigurator.Configure(repo, log4netConfig["log4net"]);
        }
    }
}
