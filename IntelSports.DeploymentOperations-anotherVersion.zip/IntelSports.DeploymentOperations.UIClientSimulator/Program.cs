﻿using System;
using System.IO;
using System.Threading.Tasks;
using Amazon.CognitoIdentity;
using Amazon.CognitoIdentity.Model;
using Amazon.CognitoIdentityProvider;
using Amazon.CognitoIdentityProvider.Model;
using Amazon.Extensions.CognitoAuthentication;
using IntelSports.DeploymentOperations.AWSCognitoSecurity;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;


namespace IntelSports.DeploymentOperations.UIClientSimulator
{
    class Program
    {
        static void Main(string[] args)
        {
            //  Get Access Token from AWS Cognito Service
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            var config = builder.Build();

            //var openIdAuth = new AWSCognitoService(config["AWSCognito:PoolId"], config["AWSCognito:AppClientId"], Amazon.RegionEndpoint.EUWest1);
           // var authTask = openIdAuth.GetIdTokenAsync(new BasicLoginRequest() { Password= config["AWSCognito:Password"], UnserName= config["AWSCognito:UserName"] });

            var authTask = GetCognitoAccessToken(config);
            authTask.Wait();
            Console.WriteLine(authTask.Result);



            // HubConnection connection = new HubConnectionBuilder().WithUrl("https://localhost:5002/TaskProcessHub").Build();
            //   HubConnection connection = new HubConnectionBuilder().WithUrl("http://63.33.241.11:5000/TaskProcessHub").Build();
            // HubConnection connection = new HubConnectionBuilder().WithUrl("http://ec2-34-245-25-97.eu-west-1.compute.amazonaws.com:5000/FPSReportingHub").Build();
            // HubConnection connection = new HubConnectionBuilder().WithUrl("http://localhost:5000/TaskProcessHub").Build();

            var connection = new HubConnectionBuilder()
            .WithUrl("http://63.33.241.11:5000/TaskProcessHub", options =>
            {
                options.AccessTokenProvider = () => Task.FromResult(authTask.Result);
            })
            .Build();

            //  On Recieving Message
            //connection.On<string, string>("ReceiveMessage", (user, message) =>
            //{
            //    Console.WriteLine(user + ": "+ message);
            //});


            connection.On("TaskStarting", () =>
            {
                Console.WriteLine("TaskStarting");
            });


            connection.On<string>("TaskStarted", (connectionId) =>
            {
                Console.WriteLine("TaskStarted: " + connectionId);

                //  stop proccess
                var stopTask = connection.InvokeAsync("StopTask", connectionId);
                stopTask.Wait();

            });


            connection.On("TaskCompleted", () =>
            {
                Console.WriteLine("TaskCompleted:");
            });



            connection.On("StopTaskCompleted", () =>
            {
                Console.WriteLine("StopTaskCompleted");
            });



            connection.On<string>("OnUIRegisteredStatus", (status) =>
            {
                Console.WriteLine("OnUIRegisteredStatus:" + status);
            });





            //  On Closed Connection
            connection.Closed += async (error) =>
            {
                await Task.Delay(new Random().Next(0, 5) * 1000);
                await connection.StartAsync();
            };


            var task = connection.StartAsync();
            task.Wait();


            /// Tell the server that u are a UI client
            var registerUI = connection.InvokeAsync("RegisterUI");
            registerUI.Wait();

            //var testresults = connection.InvokeAsync("Test");
            //testresults.Wait();

            //var testresults2 = connection.InvokeAsync("Test2");
            //testresults2.Wait();

            var testresults3 = connection.InvokeAsync("Test3");
            testresults3.Wait();

            // Register with Server Hub. All cliets must do so, wether they have called StartTask or not
            //  var sendTask = connection.InvokeAsync("StartTask", 100);
            //   sendTask.Wait();



            // var stopTask = connection.InvokeAsync("StopTask", 100);
            // stopTask.Wait();
            Console.ReadKey();

        }
        /*
         public static async Task<string> GetCognitoAccessToken(IConfiguration config)
         {


            Console.WriteLine("PoolId: " + config["AWSCognito:PoolId"]);
            Console.WriteLine("AppClientId: " + config["AWSCognito:AppClientId"]);
            Console.WriteLine("UserName: " + config["AWSCognito:UserName"]);
            Console.WriteLine("Password: " + config["AWSCognito:Password"]);

            AmazonCognitoIdentityProviderClient provider =  new AmazonCognitoIdentityProviderClient(new Amazon.Runtime.AnonymousAWSCredentials(), Amazon.RegionEndpoint.EUWest1);
            CognitoUserPool userPool = new CognitoUserPool(config["AWSCognito:PoolId"], config["AWSCognito:AppClientId"], provider);
            CognitoUser user = new CognitoUser(config["AWSCognito:UserName"], config["AWSCognito:AppClientId"], userPool, provider);
            InitiateSrpAuthRequest authRequest = new InitiateSrpAuthRequest()
            {
                Password = config["AWSCognito:Password"]
            };
            AuthFlowResponse authResponse = await user.StartWithSrpAuthAsync(authRequest).ConfigureAwait(false);




            // When we need to change password, uncomment this
            //RespondToNewPasswordRequiredRequest res = new RespondToNewPasswordRequiredRequest()
            //{ 
            //    NewPassword = "Turtle789456@@", 
            //    SessionID = authResponse.SessionID 
            //};

            //var newresp = user.RespondToNewPasswordRequiredAsync(res);
            //Console.WriteLine(newresp.Result.AuthenticationResult.AccessToken);


             return authResponse.AuthenticationResult.AccessToken;


         }
        */
        public static async Task<string> GetCognitoAccessToken(IConfiguration config)
        {
            //Console.WriteLine("PoolId: " + config["AWSCognito:PoolId"]);
            //Console.WriteLine("AppClientId: " + config["AWSCognito:AppClientId"]);
            //Console.WriteLine("UserName: " + config["AWSCognito:UserName"]);
            //Console.WriteLine("Password: " + config["AWSCognito:Password"]);

            AmazonCognitoIdentityProviderClient provider = new AmazonCognitoIdentityProviderClient(Amazon.RegionEndpoint.USEast1);// new Amazon.Runtime.AnonymousAWSCredentials(), Amazon.RegionEndpoint.USEast1);
            CognitoUserPool userPool = new CognitoUserPool("us-east-1_YuSwcvMEa", "4s1to8qbshl6qdqpu075t3ojtc",provider, "+25Up5v?g2g4t^L>");// config["AWSCognito:PoolId"], config["AWSCognito:AppClientId"], provider);
            CognitoUser user = new CognitoUser("gil", "4s1to8qbshl6qdqpu075t3ojtc", userPool, provider, "+25Up5v?g2g4t^L>");// config["AWSCognito:UserName"], config["AWSCognito:AppClientId"], userPool, provider);
            InitiateSrpAuthRequest authRequest = new InitiateSrpAuthRequest()
            {
                Password = config["+25Up5v?g2g4t^L>"]// "AWSCognito:Password"]
            };
            AuthFlowResponse authResponse = await user.StartWithSrpAuthAsync(authRequest).ConfigureAwait(false);

            // When we need to change password, uncomment this
            //RespondToNewPasswordRequiredRequest res = new RespondToNewPasswordRequiredRequest()
            //{ 
            //    NewPassword = "Turtle789456@@", 
            //    SessionID = authResponse.SessionID 
            //};

            //var newresp = user.RespondToNewPasswordRequiredAsync(res);
            //Console.WriteLine(newresp.Result.AuthenticationResult.AccessToken);
            return authResponse.AuthenticationResult.AccessToken;
        }

        /*
        public static async Task<string> GetCognitoAccessToken2(IConfiguration config)
        {

            //AmazonCognitoIdentityProviderClient provider = new AmazonCognitoIdentityProviderClient(new Amazon.Runtime.AnonymousAWSCredentials(), Amazon.RegionEndpoint.EUWest1);
            //CognitoUserPool userPool = new CognitoUserPool("eu-west-1_sh8KzuDqm", "5ts8640maiuim2vrrb29of9tvk", provider);
            //CognitoUser user = new CognitoUser("jay", "5ts8640maiuim2vrrb29of9tvk", userPool, provider, "bcik7ul68lme6jeim0esrhusidoc7h5eot3bf3hakar4k058qf1");


            //// ("jay", "5ts8640maiuim2vrrb29of9tvk", userPool, provider, "bcik7ul68lme6jeim0esrhusidoc7h5eot3bf3hakar4k058qf1");
            ////InitiateAuthRequest xx = new InitiateAuthRequest() { AuthFlow= AuthFlowType.CUSTOM_AUTH}
            //InitiateSrpAuthRequest authRequest = new InitiateSrpAuthRequest()
            //{
            //    Password = "Turtle789456@@"
            //};
            //AuthFlowResponse authResponse = await user.StartWithSrpAuthAsync(authRequest).ConfigureAwait(false);


            AmazonCognitoIdentityClient client = new AmazonCognitoIdentityClient();
            Amazon.CognitoIdentity.AmazonCognitoIdentityClient client1 = new AmazonCognitoIdentityClient("AKIA26YVBY7T35MOJ37B", "C8aoBTnLbZITzq/9l5hdyx7hdGy5How2QXxtqDMk", Amazon.RegionEndpoint.EUWest1);
            GetIdRequest rr = new GetIdRequest() { AccountId = "753274046439", IdentityPoolId = "eu-west-1:c18f3dc4-dac8-4133-89a9-cf517ba428d3" };
            var x = await client.GetIdAsync(rr);

            return await Task.FromResult("");

            // When we need to change password, uncomment this
            //RespondToNewPasswordRequiredRequest res = new RespondToNewPasswordRequiredRequest()
            //{ 
            //    NewPassword = "Turtle789456@@", 
            //    SessionID = authResponse.SessionID 
            //};

            //var newresp = user.RespondToNewPasswordRequiredAsync(res);
            //Console.WriteLine(newresp.Result.AuthenticationResult.AccessToken);


            // return authResponse.AuthenticationResult.AccessToken;


        }
        */

    }


}
