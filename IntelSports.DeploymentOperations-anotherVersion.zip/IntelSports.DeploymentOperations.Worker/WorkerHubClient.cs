﻿using System;
using System.Threading;
using System.Threading.Tasks;
using IntelSports.DeploymentOperations.AWSCognitoSecurity;
using IntelSports.DeploymentOperations.Model.DB;
using Microsoft.AspNetCore.SignalR.Client;

namespace IntelSports.DeploymentOperations.Worker
{
    public class WorkerHubClient
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public HubConnection hubConnection = null;
        private Action<FdController> onRegisteredWorker = null;
        private Action<TaskPayload> onStartTask = null;
        private Action<TaskPayload> onStopTask = null;
        private Action<FlowPayload> onStartFlow = null;
        private Action<FlowPayload> onStopFlow = null;
        private Action<FlinkTaskPayload> onStartFlinkTask = null;
        private AutoResetEvent resetEvent;
        private ExecutionManager _manager;
        private FdController _dockerDetails;
        private IOpenIdConnect iOpenIdConnect = null;

        public WorkerHubClient(AutoResetEvent resetEvent, ExecutionManager executionManager, IOpenIdConnect iOpenIdConnect)
        {        
            this.resetEvent = resetEvent;
            onRegisteredWorker = new Action<FdController>(OnRegisteredWorkerHandler);
            onStartTask = new Action<TaskPayload>(OnStartTaskHandler);
            onStopTask = new Action<TaskPayload>(OnStopTaskHandler);
            onStartFlow = new Action<FlowPayload>(OnStartFlowHandler);
            onStopFlow = new Action<FlowPayload>(OnStopFlowHandler);
            onStartFlinkTask = new Action<FlinkTaskPayload>(OnStartFlinkTaskHandler);

            _manager = executionManager;

            var fdControllerName = Environment.GetEnvironmentVariable("HOSTNAME");
            WorkerConfig.FdControllerName = fdControllerName;

            if (!string.IsNullOrEmpty(fdControllerName))
            {
                log.Info("HOSTNAME = " + fdControllerName);
            }
            else
            {
                log.Info("HOSTNAME NOT FOUND !!!");
            }

            _dockerDetails = new FdController() { Name = fdControllerName, DeploymentId = WorkerConfig.DeploymentId };

            this.iOpenIdConnect = iOpenIdConnect;
        }

        //public static void GetBrokerData()
        //{
        //    try
        //    {
        //        if(WorkerConfig.BrokerData != null && !string.IsNullOrEmpty(WorkerConfig.BrokerData.mq_username))
        //        {
        //            return;
        //        }
                
        //        log.Info("Inside GetBrokerData");

        //        HttpClient client = new HttpClient();

        //        client.DefaultRequestHeaders.Add("Authorization", WorkerConfig.CognitoIdToken);// "eyJraWQiOiJkckdDeWFZTkxSSCtvU2F6YUNDRUNnbER6WnhSc21ZNEN2bFYzVFpIUE5VPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiIwNTlmMTcyOC02NDBhLTQwNzYtYmFmMC05M2JiZWNhMTNjM2QiLCJjb2duaXRvOmdyb3VwcyI6WyJwZGFhc19kZXZlbG9wZXJzIiwidGVtcF9kZXZlbG9wZXJzIiwiZGV2ZWxvcGVycyJdLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiY29nbml0bzpwcmVmZXJyZWRfcm9sZSI6ImFybjphd3M6aWFtOjo3NTMyNzQwNDY0Mzk6cm9sZVwvVEVNUC1URUUxOS1Db250cm9sLUFjY2Vzcy1BbGwiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV9ZdVN3Y3ZNRWEiLCJjb2duaXRvOnVzZXJuYW1lIjoiZ2lsIiwiY29nbml0bzpyb2xlcyI6WyJhcm46YXdzOmlhbTo6NzUzMjc0MDQ2NDM5OnJvbGVcL1RFRTE5LUNvbnRyb2wtUERBQVMtQWNjZXNzLWFsbC1Sb2xlIiwiYXJuOmF3czppYW06Ojc1MzI3NDA0NjQzOTpyb2xlXC9URU1QLVRFRTE5LUNvbnRyb2wtQWNjZXNzLUFsbCIsImFybjphd3M6aWFtOjo3NTMyNzQwNDY0Mzk6cm9sZVwvVEVFMTktQ29udHJvbC1BY2Nlc3MtQWxsIl0sImF1ZCI6IjRzMXRvOHFic2hsNnFkcXB1MDc1dDNvanRjIiwiZXZlbnRfaWQiOiIzNTBlYTZkNS0wZWVkLTQyMjMtYmUxNi1lYzYzMjQxYzA1ZDYiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTYxNDQ1MjIwMSwiZXhwIjoxNjE0NTM4NjAxLCJpYXQiOjE2MTQ0NTIyMDIsImVtYWlsIjoic2hhbGV2LmdpbEBpbnRlbC5jb20ifQ.fzhpl_s_aV3zsnni2onNdSRZnLDdiPav-zzKGU8J_b08b92QtGuI4fIvRPiNeny1_1LTVmMuMpvtN3Bn-67Vxi6IZC_XmiIoXG5bISB_t6yRL8x4XkJdLuBFWZOgNlO_QSjstsvNAvoimHQ5b5Y2MSPrjhJE9tZmkp49rldhzqm0Nyl5jWpr4PNuJ7Gl3D720OXjnnHu2NgV-usA46Y-gJeqeHCdy11nINjA4y9A5SstcZ35Pm7hFQq8_M0xNEtiNyZDHwlA5VGpnR1wKtbsyrk0QavEvMbXpBDRtSnZx8HUPsqSAArQcoPajCfagveuCEnsap7glmVYb76TER2soA");

        //        string url = "";

        //        log.Info("WorkerConfig.MqAuth = " + WorkerConfig.MqAuth);

        //        //if (!string.IsNullOrEmpty(WorkerConfig.MqAuth))
        //        //{
        //        //    url = WorkerConfig.MqAuth;
        //        //}
        //        //else
        //        //{
        //            url = "https://oyehf1z2cg.execute-api.us-west-2.amazonaws.com/default/api/Broker";
        //        //}

        //        //var responsestr = client.GetStringAsync(url).Result;

        //        var response = client.GetAsync(url).Result;

        //        log.Info("Response returned: " + response.ToString());
                 
        //        string content = response.Content.ReadAsStringAsync().Result;

        //        log.Info("Broker Data found: " + content);

        //        var brokerData = JsonConvert.DeserializeObject<BrokerData>(content);

        //        WorkerConfig.BrokerData = brokerData;
        //    }
        //    catch (Exception xcp)
        //    {
        //        log.Error("Exception Inside GetBrokerData" + xcp);

        //        log.Error("Configuring with hard-coded values");

        //        WorkerConfig.BrokerData = new BrokerData { mq_username = "tee_lambda", mq_password = "NoneNoneNoneNone", mq_stomp_url = "stomp+ssl://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61614", mq_openwire_url = "ssl://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61617", mq_wss_url = "wss://b-72583ad2-010f-44ce-a5a3-999cf71af6af-1.mq.us-east-1.amazonaws.com:61619" };
        //    }
        //}

        public async Task Init()
        {
            try
            {
                string serverUrl = WorkerConfig.DeploymentOperationsServerHubURL;
                hubConnection = new HubConnectionBuilder().WithUrl(serverUrl, options =>
                {
                    var token = this.iOpenIdConnect.GetIdTokenAsync(this.iOpenIdConnect.BasicLoginRequest).Result;
                    WorkerConfig.CognitoIdToken = token;
                    options.AccessTokenProvider = () => Task.FromResult(this.iOpenIdConnect.GetIdTokenAsync(this.iOpenIdConnect.BasicLoginRequest).Result);
                })
               .Build();

                hubConnection.On<FdController>("OnRegisteredWorkerStatus", onRegisteredWorker);
                hubConnection.On<TaskPayload>("StartTask", onStartTask);
                hubConnection.On<TaskPayload>("StopTask", onStopTask);
                hubConnection.On<FlowPayload>("StartFlow", onStartFlow);
                hubConnection.On<FlowPayload>("StopFlow", onStopFlow);
                hubConnection.On<FlinkTaskPayload>("StartFlinkTask", onStartFlinkTask);
                hubConnection.On("RefreshTasks", OnRefreshTasks);
                hubConnection.On<string>("RefreshProgram", OnRefreshProgram);

                //  On Closed Connection
                hubConnection.Closed += HubConnection_Closed;

                //GetBrokerData();

                //  Start the connection
                await hubConnection.StartAsync();

                //  Register with Server Hub
                await hubConnection.SendAsync("RegisterWorker", _dockerDetails);
            }
            catch (Exception exc)
            {
                log.Error("WorkerHubClient.Start:" + exc.Message);
                Console.WriteLine("WorkerHubClient.Start:" + exc.Message);
            }
        }

        public void OnRegisteredWorkerHandler(FdController fdContoller)
        {
            log.Info(string.Format("OnRegisterTaskExecuter Name: {0}, ConnectionId: {1}, ConnectionStatus: {2}",
                                            fdContoller.Name,
                                            fdContoller.ConnectionId,
                                            fdContoller.ConnectionStatus));

            Console.WriteLine(string.Format("OnRegisterTaskExecuter Name: {0}, ConnectionId: {1}, ConnectionStatus: {2}",
                                            fdContoller.Name,
                                            fdContoller.ConnectionId,
                                            fdContoller.ConnectionStatus));

            _dockerDetails = fdContoller;
        }

        public void OnStartTaskHandler(TaskPayload payload)
        {
            log.Info(string.Format("Starting Process to execute Task Id: {0}, Executer:{1}", payload.TaskId, payload.ExecuterName));

            //Filter event according to deployment
            if (payload.DeploymentId == WorkerConfig.DeploymentId)
            {
                _manager._shouldStopWaitingTask = true;
                _manager.RunTask(payload, WorkerConfig.DeploymentOperationsServerHubURL);
            }
            else
            {
                log.Info("Execution was skipped because it was meant for deployment: " + WorkerConfig.DeploymentId);
                log.Info("WorkerConfig.DeploymentId: " + WorkerConfig.DeploymentId);
                log.Info("payload.DeploymentId: " + payload.DeploymentId);
            }
        }
      
        public void OnStopTaskHandler(TaskPayload payload)
        {
            log.Info("Trying to stop Executer with Id: " + payload.ExecuterId);
            Console.WriteLine("Trying to stop Executer with Id: " + payload.ExecuterId);

            _manager.StopTask(payload.ExecuterId);
        }

        public void OnStartFlowHandler(FlowPayload payload)
        {
            log.Info("Starting flow with Id: " + payload.FlowId);
            Console.WriteLine("Starting flow with Id: " + payload.FlowId);

            //Filter event according to deployment
            if (payload.DeploymentId == WorkerConfig.DeploymentId)
            {
                _manager.RunFlow(payload, WorkerConfig.DeploymentOperationsServerHubURL);
            }
            else
            {
                log.Info("Execution was skipped because it was meant for deployment: " + WorkerConfig.DeploymentId);
                log.Info("WorkerConfig.DeploymentId: " + WorkerConfig.DeploymentId);
                log.Info("payload.DeploymentId: " + payload.DeploymentId);
            }
        }

        public void OnStopFlowHandler(FlowPayload payload)
        {
            log.Info("Trying to stop flow executer with Id: " + payload.FlowExecuterId);
            Console.WriteLine("Trying to stop flow executer with Id: " + payload.FlowExecuterId);
            _manager.StopFlow(payload.FlowExecuterId);
        }

        public void OnStartFlinkTaskHandler(FlinkTaskPayload payload)
        {
            log.Info("Starting Process to execute Flink Task of type: " + payload.FlinkTaskType);

            //Filter event according to deployment
            if (payload.DeploymentId == WorkerConfig.DeploymentId)
            {
                _manager.RunFlinkTask(payload, WorkerConfig.DeploymentOperationsServerHubURL);
            }
        }

        public void OnRefreshTasks()
        {
            log.Info("Worker received RefreshTasks message");

            _manager.RefreshODCollections();
        }

        public void OnRefreshProgram(string programId)
        {
            log.Info("Worker received RefreshProgram message");

            _manager.RemovePreviousVersionedProgram(programId);

            _manager.RefreshODCollections();
        }

        private Task HubConnection_Closed(Exception exc)
        {
            log.Info("HubConnection_Closed: Hub connection has been closed " + exc);
            Console.WriteLine("HubConnection_Closed: Hub connection has been closed " + exc);

            resetEvent.Set();
            return Task.FromResult("");
        }

    }
}

//ExecutionManager manager = new ExecutionManager();
//ODTask deploymentTask = manager.GetTaskToRun(taskId);

//string executerId = Guid.NewGuid().ToString();
//ITaskExecuter taskExecuter = new SystemProcessTaskExecuter(this.configFile.DeploymentOperationsServerHubURL.ToString(), taskId, executerId);
//_executers.Add(executerId, taskExecuter);

//var taskResult = taskExecuter.ExecuteTask(deploymentTask);

//if (_executers.ContainsKey(executerId))
//{
//    ITaskExecuter executer = _executers[executerId];
//    if(executer != null)
//    {
//        executer.StopTask();
//    }

//    //TODO consider keeping it and removing only if process stopped
//    //Listen to process end (exit/terminated ...) and remove from _executers
//    _executers.Remove(executerId);
//}

//private Action<ProgramMessage> onProgramMessage = null;


//onProgramMessage = new Action<ProgramMessage>(OnSendProgramMessageHandler);

//hubConnection.On<ProgramMessage>("SendProgramMessage", onProgramMessage);


//public void OnSendProgramMessageHandler(ProgramMessage payload)
//{
//    //log.Info(string.Format("Execution Manager received 'SendProgramMessage' from hub with DeploymentId = {0}, ExecuterId = {1}, FlowExecuterId = {2}, and MessageName = {3}", payload.DeploymentId, payload.ExecuterId, payload.FlowExecuterId, payload.MessageName));

//    if(!string.IsNullOrEmpty(payload.MessageSource))
//    {
//        log.Info(string.Format("Execution Manager received 'SendProgramMessage' from program = {0} In DeploymentId = {1} and MessageName = {2}", payload.MessageSource, payload.DeploymentId, payload.MessageName));
//    }
//    else
//    {
//        log.Info(string.Format("Execution Manager received 'SendProgramMessage' from hub with DeploymentId = {0} and MessageName = {1}", payload.DeploymentId, payload.MessageName));
//    }
//    //Filter event only according to deploymentId & MessageName
//    if (payload.DeploymentId == WorkerConfig.DeploymentId && 
//        payload.MessageName == "StopFlinkListener")
//    {
//        _manager.StopFlinkListener(payload);
//    }
//    else
//    {
//        log.Info("Execution was skipped because it was meant for deployment: " + WorkerConfig.DeploymentId);
//        log.Info("WorkerConfig.DeploymentId: " + WorkerConfig.DeploymentId);
//        log.Info("payload.DeploymentId: " + payload.DeploymentId);
//    }
//}
//public void OnStopFlinkTaskHandler(TaskPayload payload)
//{
//    //Console.WriteLine("Starting Process to execute Task Id: " + payload.TaskId);

//    //_manager.RunTask(payload, this.configFile.DeploymentOperationsServerHubURL.ToString());
//}