﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace IntelSports.DeploymentOperations.Worker.Logs
{
    public class LogRecorder
    {
        private static StreamWriter _logsFile;
        private static StreamWriter _monitorsFile;

        public static string DeploymentId { get; set; }
        public static string GameId { get; set; }
        public static string LosgPath { get; set; }
        public static string MonitorsPath { get; set; }

        public const string FDC_FirstChanceException = "FirstChanceException";
        public const string FDC_UnhandledExceptionEventArgs = "UnhandledExceptionEventArgs";
        public const string FDC_STARTED = "FDC Worker App has started...";

        public const string REGION_IS = "REGION = ";
        public const string DYNAMO_DB_TABLE_IS = "DYNAMO DB TABLE = ";
        public const string SQS_IS = "SQS = ";
        public const string S3_BUCKET_IS = "S3 BUCKET = ";
        public const string KDS_IS = "COMMON KDS = ";

        //LOGS & MONITORS
        public const string METRICS_COMM = "METRICS_COMM";
        public const string COMM_OPERATION = "comm_operation";
        public const string COMM_TYPE = "comm_type";
        public const string COMM_OPERATION_TIME = "comm_operation_time";
        public const string METRICS_STORAGE = "METRICS_STORAGE";
        public const string STORAGE_OPERATION = "db_operation";
        public const string STORAGE_TYPE = "db_type";
        public const string STORAGE_OPERATION_TIME = "db_operation_time";
        public const string STORAGE_SIZE = "db_size";
        public const string INIT_START = "init_start";
        public const string ERROR_FATAL = "error_fatal";
        public const string ERROR_INTERNAL = "error_internal";
        public const string ERROR_SOURCE = "error_source";
        public const string S3_READ = "S3 READ";
        public const string EXCEPTION = "Exception";

        public static void SetDeployemntIdGameIdLogsPathAndMonitorsPath(string deployment_id, string game_id, string logsPath, string monitorsPath)
        {
            DeploymentId = deployment_id;
            GameId = game_id;
            LosgPath = logsPath;
            MonitorsPath = monitorsPath;
        }

        public static void CreateLogAndMonitorFiles()
        {
            string logsFileName = LosgPath + @"/" + "fdc-worker-logs.log";
            string monitorsFileName = MonitorsPath + @"/" + "fdc-worker-monitors.log";

            try
            {
                _logsFile = new StreamWriter(logsFileName, false);//true=for append, false=new file
                _monitorsFile = new StreamWriter(monitorsFileName, false);//true=for append, false=new file
                _logsFile.AutoFlush = true;
                _monitorsFile.AutoFlush = true;
            }
            catch (Exception e)
            {
                Console.WriteLine("exception caught while creating the log / monitors files " + e);
            }
        }

        public static void AddLogRecord(LogRecord.Severity severity,
                                        long frameId,
                                        string message_body)
        {
            try
            {
                LogRecord logRecord = new LogRecord(severity, frameId, message_body);

                var serializedLogRecord = JsonConvert.SerializeObject(logRecord, logRecord.GetType(),null);

                Console.WriteLine(serializedLogRecord);

                lock (_logsFile)
                {
                    _logsFile.WriteLine(serializedLogRecord);
                }
            }
            catch (Exception xcp)
            {

            }
        }

        public static void AddMonitor(MonitorRecord.MonitorLevel level,
                                      long frameId,
                                      string eventName)
        {
            MonitorRecord monitor = new MonitorRecord(level, frameId, eventName);

            var serializedMonitorRecord = JsonConvert.SerializeObject(monitor);

            Console.WriteLine(serializedMonitorRecord);

            lock (_monitorsFile)
            {
                _monitorsFile.WriteLine(serializedMonitorRecord);
            }
        }

        public static void AddErrorMonitor(MonitorRecord.MonitorLevel level,
                                           long frameId,
                                           string eventName,
                                           Dictionary<string, string> errorMonitorMeasures)
        {
            ErrorMonitorRecord monitor = new ErrorMonitorRecord(level, frameId, eventName, errorMonitorMeasures);

            var serializedMonitorRecord = JsonConvert.SerializeObject(monitor);

            Console.WriteLine(serializedMonitorRecord);

            lock (_monitorsFile)
            {
                _monitorsFile.WriteLine(serializedMonitorRecord);
            }
        }

        public static void AddMetricsMonitor(MonitorRecord.MonitorLevel level,
                                             long frameId,
                                             string eventName,
                                             Dictionary<string, string> event_measures)
        {
            try
            {
                MetricsMonitorRecord metricsMonitorRecord = new MetricsMonitorRecord(level, frameId, eventName, event_measures);

                var serializedMonitorRecord = JsonConvert.SerializeObject(metricsMonitorRecord);

                Console.WriteLine(serializedMonitorRecord);

                lock (_monitorsFile)
                {
                    _monitorsFile.WriteLine(serializedMonitorRecord);
                }
            }
            catch (Exception xcp)
            {

            }
        }
    }
}