﻿using System;

namespace IntelSports.DeploymentOperations.Worker.Logs
{
    public class MonitorRecord
    {
        public string event_timestamp;
        public string deployment_id;
        public string game_id;
        public long frame_id;
        public /*MonitorLevel*/string  level;
        public string component_name = "fdc_worker";
        public string subsystem_name = "fd_core";
        public string event_name;

        public enum MonitorLevel
        {
            Extended,
            Detailed,
        }

        public MonitorRecord(MonitorLevel level,
                            long frame_id,
                            string event_name)
        {
            this.level = level.ToString();
            this.event_timestamp = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            //          "yyyy -MM-ddTHH:mm:ssZ");

            this.frame_id = frame_id;
            this.event_name = event_name;

            this.deployment_id = LogRecorder.DeploymentId;
            this.game_id = LogRecorder.GameId;
        }
    }
}
