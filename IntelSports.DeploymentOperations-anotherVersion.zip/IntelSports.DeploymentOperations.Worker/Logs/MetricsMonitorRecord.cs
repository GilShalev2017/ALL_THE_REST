﻿using System.Collections.Generic;

namespace IntelSports.DeploymentOperations.Worker.Logs
{
    public class MetricsMonitorRecord : MonitorRecord
    {
        public Dictionary<string, string> event_measures;

        public MetricsMonitorRecord(MonitorLevel level,
                                    long frameId,
                                    string event_name,
                                    Dictionary<string, string> event_measures)

            :base(level, frameId, event_name)
                                    
        {
            this.event_measures = event_measures;
        }
    }
}
