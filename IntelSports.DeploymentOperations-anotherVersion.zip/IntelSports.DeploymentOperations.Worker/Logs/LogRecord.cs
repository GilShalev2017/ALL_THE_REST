﻿using System;

namespace IntelSports.DeploymentOperations.Worker.Logs
{
    public class LogRecord
    {
        public string timestamp;
        public /*Severity*/string severity;
        public long frame_id;
        public string component_name = "fdc_worker";
        public string subsystem_name = "fd_core";
        public string message_body;
        public string deployment_id;
        public string game_id;

        public enum Severity
        {
            DEBUG,
            TRACE,
            INFO,
            WARN,
            ERROR,
            FATAL
        }

        public LogRecord(Severity severity,
                         long frame_id,
                         string message_body)
        {
            timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");// "yyyy -MM-dd'T'HH:mm:ss.SSS'Z'");

            this.severity = severity.ToString();
            this.frame_id = frame_id;
            this.message_body = message_body;

            this.deployment_id = LogRecorder.DeploymentId;
            this.game_id = LogRecorder.GameId;
        }
    }
}
