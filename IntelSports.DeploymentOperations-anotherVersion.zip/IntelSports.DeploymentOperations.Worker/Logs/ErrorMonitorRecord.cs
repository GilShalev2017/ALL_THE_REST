﻿using System.Collections.Generic;

namespace IntelSports.DeploymentOperations.Worker.Logs
{
    public class ErrorMonitorRecord : MonitorRecord
    {
        public Dictionary<string, string> event_measures { get; set; }

        public ErrorMonitorRecord(MonitorLevel level,
                                  long frame_id,
                                  string event_name,
                                  Dictionary<string, string> event_measures)
            :base(level, frame_id, event_name)
        {
            this.event_measures = event_measures;
        }
    }
}
