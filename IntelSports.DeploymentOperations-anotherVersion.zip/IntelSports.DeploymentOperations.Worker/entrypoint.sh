#!/bin/sh
set -e 
MQ_AUTH_URL=$(jq -cr '.mq.mq_auth' $DEPLOYMENT_JSON)
awscurl --region us-east-1 --service execute-api -X GET ${MQ_AUTH_URL} > response.json
export MQ_URL=$(jq -cr '.mq_openwire_url' response.json )
export MQ_USERNAME=$(jq -cr '.mq_username' response.json )
export MQ_PASSWORD=$(jq -cr '.mq_password' response.json )
echo "MQ_URL: ${MQ_URL}, MQ_USERNAME: ${MQ_USERNAME}, MQ_PASSWORD: ${MQ_PASSWORD}"
dotnet IntelSports.DeploymentOperations.Worker.dll $MQ_USERNAME $MQ_PASSWORD $MQ_URL
